export const getAllAvailableColumns =
{
  "masoneilanOverdue": {
    "maintitle": "Masoneilan - Overdue Backlogs",
    "series": [
      {
        "name": "Overdue Backlogs",
        "data": [
          [
            "2021W37",
            2
          ],
          [
            "2021W38",
            1
          ],
          [
            "2021W39",
            0
          ],
          [
            "2021W40",
            1
          ],
          [
            "2021W41",
            1
          ],
          [
            "2021W42",
            2
          ],
          [
            "2021W43",
            0
          ],
          [
            "2021W44",
            0
          ],
          [
            "2021W45",
            0
          ],
          [
            "2021W46",
            0
          ],
          [
            "2021W47",
            0
          ]
        ]
      }
    ],
    "xaxisTitle": "Weeks",
    "yaxisTitle": "Number of ERs"
  },
  "masoneilanTotalBacklog": {
    "maintitle": "Masoneilan - Total Backlogs",
    "series": [
      {
        "name": "Actual Output",
        "data": [
          [
            "2021W37",
            2
          ],
          [
            "2021W38",
            1
          ],
          [
            "2021W39",
            1
          ],
          [
            "2021W40",
            2
          ],
          [
            "2021W41",
            5
          ],
          [
            "2021W42",
            15
          ],
          [
            "2021W43",
            27
          ],
          [
            "2021W44",
            0
          ],
          [
            "2021W45",
            9
          ],
          [
            "2021W46",
            0
          ],
          [
            "2021W47",
            0
          ]
        ]
      },
      {
        "name": "Engineering Planed Output",
        "data": [
          [
            "2021W37",
            20
          ],
          [
            "2021W38",
            20
          ],
          [
            "2021W39",
            20
          ],
          [
            "2021W40",
            20
          ],
          [
            "2021W41",
            20
          ],
          [
            "2021W42",
            20
          ],
          [
            "2021W43",
            20
          ],
          [
            "2021W44",
            20
          ],
          [
            "2021W45",
            20
          ],
          [
            "2021W46",
            20
          ],
          [
            "2021W47",
            20
          ]
        ]
      },
      {
        "name": "Total Lines Due",
        "data": [
          [
            "2021W37",
            7
          ],
          [
            "2021W38",
            1
          ],
          [
            "2021W39",
            49
          ],
          [
            "2021W40",
            35
          ],
          [
            "2021W41",
            6
          ],
          [
            "2021W42",
            38
          ],
          [
            "2021W43",
            79
          ],
          [
            "2021W44",
            13
          ],
          [
            "2021W45",
            34
          ],
          [
            "2021W46",
            8
          ],
          [
            "2021W47",
            1
          ]
        ]
      }
    ],
    "xaxisTitle": "Weeks",
    "yaxisTitle": "Number of ERs"
  },
  "matrixType": [
    {
      "id": "BOMCOMPLETION",
      "text": "BOM Completion"
    }
  ],
  "month": [],
  "plantType": [
    "DVI",
    "JAX",
    "CONDE",
    "DJL -KARWIA",
    "GRE -GLOBAL COE",
    "Multiple Plants"
  ],
  "productFamilyType": [
    "Masoneilan"
  ],
  "startDate": null,
  "week": [],
  "year": null
}

