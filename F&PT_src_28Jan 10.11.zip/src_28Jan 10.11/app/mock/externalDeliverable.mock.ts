export const externalDeliverableData = [
    {
    "id": 16,
    "preConfigId": 12346,
    "childEr": null,
    "generalComments": "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss",
    "holdComments": null,
    "supportTeamId": 1,
    "edCreatedBySso": "503195167",
    "edCreatedByFirstname": "karthik",
    "edCreatedByLastname": "r",
    "levelTwoId": 6,
    "levelTwo": "Customer Drawings",
    "edCreatorStatusId": 5,
    "edCreatorStatus": "Ready for Review",
    "edProgressStatus": null,
    "hoursSpent": 0,
    "hoursAssigned": 0,
    "floatingDays": 0,
    "percentageCompleted": 0,
    "edLevelThreeCreator": [
    {
    "id": 5,
    "edCreatorId": 16,
    "levelThreeId": 3,
    "levelThree": "GA/CP Drawing",
    "childEr": null,
    "targetDate": null,
    "comments": null,
    "edCreatorCheckList": [
    {
    "workflowPhase": "EXTRENALDELIVERABLES",
    "checklistFor": "CREATOR",
    "checklist": "AlfrescoNumber",
    "comments": "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"
    },
    {
    "workflowPhase": "EXTRENALDELIVERABLES",
    "checklistFor": "CREATOR",
    "checklist": "FolderLocation",
    "comments": null
    }
    ],
    "statusId": 2,
    "status": "PROMOTE",
    "aging": 0
    },
    {
    "id": 6,
    "edCreatorId": 16,
    "levelThreeId": 2,
    "levelThree": "GA Drawing-Customer Template",
    "childEr": null,
    "targetDate": null,
    "comments": null,
    "edCreatorCheckList": [
    {
    "workflowPhase": "EXTRENALDELIVERABLES",
    "checklistFor": "CREATOR",
    "checklist": "AlfrescoNumber",
    "comments": null
    },
    {
    "workflowPhase": "EXTRENALDELIVERABLES",
    "checklistFor": "CREATOR",
    "checklist": "FolderLocation",
    "comments": null
    }
    ],
    "statusId": 2,
    "status": "PROMOTE",
    "aging": 0
    }
    ],
    "hold": false
    },
    {
    "id": 17,
    "preConfigId": 12346,
    "childEr": null,
    "generalComments": null,
    "holdComments": null,
    "supportTeamId": 1,
    "edCreatedBySso": "503195167",
    "edCreatedByFirstname": "Karthik",
    "edCreatedByLastname": "R",
    "levelTwoId": 2,
    "levelTwo": "Design Report",
    "edCreatorStatusId": 5,
    "edCreatorStatus": "Ready for Review",
    "edProgressStatus": null,
    "hoursSpent": 0,
    "hoursAssigned": 0,
    "floatingDays": 0,
    "percentageCompleted": 0,
    "edLevelThreeCreator": [],
    "hold": false
    },
    {
    "id": 18,
    "preConfigId": 12346,
    "childEr": null,
    "generalComments": null,
    "holdComments": null,
    "supportTeamId": 1,
    "edCreatedBySso": "503195167",
    "edCreatedByFirstname": "Karthik",
    "edCreatedByLastname": "R",
    "levelTwoId": 2,
    "levelTwo": "Design Report",
    "edCreatorStatusId": 5,
    "edCreatorStatus": "Ready for Review",
    "edProgressStatus": null,
    "hoursSpent": 0,
    "hoursAssigned": 0,
    "floatingDays": 0,
    "percentageCompleted": 0,
    "edLevelThreeCreator": [],
    "hold": false
    }
    ]


    export const reviewerData = [
        {
        "id": 29,
        "preConfigId": 12346,
        "childEr": null,
        "generalComments": null,
        "supportteamId": 1,
        "holdComments": null,
        "edCreatorId": 16,
        "edReviewedBySso": "503195167",
        "edReviewedByFirstname": "k",
        "edReviewedByLastname": "R",
        "levelTwoId": 6,
        "levelTwo": "Customer Drawings",
        "edLevelThreeReviewer": [
        {
        "id": 57,
        "edReviewerId": 29,
        "levelThreeId": 3,
        "levelThree": "GA/CP Drawing",
        "childEr": null,
        "targetDate": null,
        "comments": null,
        "status": "SAVE",
        "statusId": 1,
        "edCheckListReviewer": [
        {
        "workflowPhase": "EXTRENALDELIVERABLES",
        "checklistFor": "REVIEWER",
        "checklist": "AlfrescoReleased",
        "comments": null
        }
        ],
        "aging": 0
        },
        {
        "id": 58,
        "edReviewerId": 29,
        "levelThreeId": 2,
        "levelThree": "GA Drawing-Customer Template",
        "childEr": null,
        "targetDate": null,
        "comments": null,
        "status": "SAVE",
        "statusId": 1,
        "edCheckListReviewer": [
        {
        "workflowPhase": "EXTRENALDELIVERABLES",
        "checklistFor": "REVIEWER",
        "checklist": "AlfrescoReleased",
        "comments": null
        }
        ],
        "aging": 0
        }
        ],
        "edReviewerStatusId": 1,
        "edReviewerStatus": "WIP",
        "edProgressStatus": null,
        "floatingDays": 0,
        "percentageCompleted": 0,
        "hold": false
        }
        ];

        export const levelOneData = {
            "id": 16,
            "generalComments": "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss",
            "holdComments": null,
            "hold": false
        }