export const svcGetRequestAccessData = {
    'requestAccessData': [
        {
            'requestId': 1,
            'requstedBy': 'Tom',
            "productBrandId": 1,
            'productBrandName': 'Measoeilan',
            "departmentId": 1,
            'departmentName': 'Engineering',
            "roleId": 1,
            'roleName': 'Reviewer',
            "producTypeId": 1,
            'producTypeName': 'MN ACTUATORS',
            "productModelId": 1,
            'productModelName': 'MODEL 87/88 MULTISPRING',
            "productSubCategoryId": 1,
            'productSubCategoryName': 'Parts and Others',
            'manufacturingSite': 'JAX',
            'enggSite': 'Conde',
            'endUserType': 'Commerical',
            'productKnowledge': 'P01',
            'productVariant': 'valve',
            'date': '26-Aug-2020'
        },
        {
            'requestId': 2,
            'requstedBy': 'Mik',
            "productBrandId": 1,
            'productBrandName': 'Measoeilan',
            "departmentId": 1,
            'departmentName': 'Engineering',
            "roleId": 2,
            'roleName': 'Configurer',
            "producTypeId": 1,
            'producTypeName': 'MN ACTUATORS',
            'productModelName': 'MODEL 87/88 MULTISPRING',
            'productSubCategoryName': 'Parts and Others',
            'manufacturingSite': 'Conde',
            'enggSite': 'JAX',
            'endUserType': 'Military',
            'productKnowledge': 'P02',
            'productVariant': 'Instrument',
            'date': '26-Aug-2020'
        },
        {
            'requestId': 3,
            'requstedBy': 'Jhon',
            "productBrandId": 1,
            'productBrandName': 'Measoeilan',
            "departmentId": 1,
            'departmentName': 'Engineering',
            "roleId": 1,
            'roleName': 'Reviewer',
            "producTypeId": 1,
            'producTypeName': 'MN ACTUATORS',
            'productModelName': 'MODEL 870000/88 MULTISPRING',
            'productSubCategoryName': 'Parts Multiple and Others',
            'manufacturingSite': 'JAX',
            'enggSite': 'Conde',
            'endUserType': 'Commerical',
            'productKnowledge': 'P01',
            'productVariant': 'valve',
            'date': '26-Aug-2020'
        },
        {
            'requestId': 4,
            'requstedBy': 'Tim',
            "productBrandId": 1,
            'productBrandName': 'Measoeilan',
            "departmentId": 1,
            'departmentName': 'Engineering',
            "roleId": 2,
            'roleName': 'Configurer',
            "producTypeId": 1,
            'producTypeName': 'MN ACTUATORS',
            'productModelName': 'MODEL 870000/88 MULTISPRING',
            'productSubCategoryName': 'Parts Multiple and Others',
            'manufacturingSite': 'Conde',
            'enggSite': 'JAX',
            'endUserType': 'Military',
            'productKnowledge': 'P02',
            'productVariant': 'Instrument',
            'date': '26-Aug-2020'
        }

    ]
}


export const svcGetPKLData = {
    "pklMaster": [
        {
            "productKnowledgeId": 7,
            "productKnowledgeName": "P0",
            "roleId": 4,
            "roleName": "Config. Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 10,
            "productKnowledgeName": "P0",
            "roleId": 5,
            "roleName": "Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 1,
            "productKnowledgeName": "P1",
            "roleId": 2,
            "roleName": "Reviewer",
            "departmentId": 2,
            "departmentName": "Oil And Gas"
        },
        {
            "productKnowledgeId": 5,
            "productKnowledgeName": "P1",
            "roleId": 4,
            "roleName": "Config. Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 8,
            "productKnowledgeName": "P1",
            "roleId": 5,
            "roleName": "Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 15,
            "productKnowledgeName": "P1",
            "roleId": 7,
            "roleName": "Creator",
            "departmentId": 4,
            "departmentName": "Quality"
        },
        {
            "productKnowledgeId": 6,
            "productKnowledgeName": "P2",
            "roleId": 4,
            "roleName": "Config. Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 9,
            "productKnowledgeName": "P2",
            "roleId": 5,
            "roleName": "Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 16,
            "productKnowledgeName": "P2",
            "roleId": 7,
            "roleName": "Creator",
            "departmentId": 4,
            "departmentName": "Quality"
        },
        {
            "productKnowledgeId": 2,
            "productKnowledgeName": "P2",
            "roleId": 2,
            "roleName": "Reviewer",
            "departmentId": 2,
            "departmentName": "Oil And Gas"
        },
        {
            "productKnowledgeId": 3,
            "productKnowledgeName": "P3",
            "roleId": 2,
            "roleName": "Reviewer",
            "departmentId": 2,
            "departmentName": "Oil And Gas"
        },
        {
            "productKnowledgeId": 17,
            "productKnowledgeName": "P3",
            "roleId": 8,
            "roleName": "Approver",
            "departmentId": 4,
            "departmentName": "Quality"
        },
        {
            "productKnowledgeId": 12,
            "productKnowledgeName": "P3",
            "roleId": 9,
            "roleName": "Reviewer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 14,
            "productKnowledgeName": "P3",
            "roleId": 10,
            "roleName": "Approver",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 18,
            "productKnowledgeName": "P4",
            "roleId": 8,
            "roleName": "Approver",
            "departmentId": 4,
            "departmentName": "Quality"
        },
        {
            "productKnowledgeId": 4,
            "productKnowledgeName": "P4",
            "roleId": 3,
            "roleName": "Configurer",
            "departmentId": 1,
            "departmentName": "Other"
        },
        {
            "productKnowledgeId": 13,
            "productKnowledgeName": "P4",
            "roleId": 9,
            "roleName": "Reviewer",
            "departmentId": 3,
            "departmentName": "Engineering"
        },
        {
            "productKnowledgeId": 11,
            "productKnowledgeName": "P4",
            "roleId": 6,
            "roleName": "Design Engineer",
            "departmentId": 3,
            "departmentName": "Engineering"
        }
    ]
}


export const svcGetAdminFilterData = {
    "approvalStatus": [
        {
            "approvalStatusName": "Approved",
            "id": 1
        },
        {
            "approvalStatusName": "Rejected",
            "id": 2
        },
        {
            "approvalStatusName": "Pending",
            "id": 3
        }
    ],
    "activeStatus": [
        {
            "activeStatusName": "Yes",
            "id": 1
        },
        {
            "activeStatusName": "No",
            "id": 2
        }
    ]
}

export const svcGetActiveData = {
    "activeStatus": [
        {
            id: 1,
            statusName: "Yes"
        },
        {
            id: 2,
            statusName: "No"
        }
    ]
}