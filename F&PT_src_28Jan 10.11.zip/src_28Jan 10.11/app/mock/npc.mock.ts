export const svcGetNPCData = {

    "npcPartStatus": [

        {

            "department": "Engineering",

            "xPlantMatlStatus": "test1",

            "xDistChainStatus": "test2",

            "plantSpMaatlStatus": "test3",

            "Procurement type": "test4",

            "requestDate": 1634554453,

            "completionDate": 1634554453

        },

        {

            "department": "Quality",

            "xPlantMatlStatus": "test1",

            "xDistChainStatus": "test2",

            "plantSpMaatlStatus": "test3",

            "Procurement type": "test4",

            "requestDate": 1634554453,

            "completionDate": 1634554453

        },

        {

            "department": "Manufacturing",

            "xPlantMatlStatus": "test1",

            "xDistChainStatus": "test2",

            "plantSpMaatlStatus": "test3",

            "Procurement type": "test4",

            "requestDate": 1634554453,

            "completionDate": 1634554453

        },

        {

            "department": "Sourcing",

            "xPlantMatlStatus": "test1",

            "xDistChainStatus": "test2",

            "plantSpMaatlStatus": "test3",

            "Procurement type": "test4",

            "requestDate": 1634554453,

            "completionDate": 1634554453

        },

        {

            "department": "Finance",

            "xPlantMatlStatus": "test1",

            "xDistChainStatus": "test2",

            "plantSpMaatlStatus": "test3",

            "Procurement type": "test4",

            "requestDate": 1634554453,

            "completionDate": 1634554453

        },

        {

            "department": "Planning",

            "xPlantMatlStatus": "test1",

            "xDistChainStatus": "test2",

            "plantSpMaatlStatus": "test3",

            "Procurement type": "test4",

            "requestDate": 1634554453,

            "completionDate": 1634554453

        }

    ],
    "npcResponseDto": [
        {
            "id": 1,
            "status": 100,
            "erNpc": "ER-1156463-002-VPL-DS",
            "soLi": "1154285-1000",
            "dwgNo": 75454611,
            "mCode": 250,
            "qCode": 10000,
            "npcCategory": [
                {
                    "id": 1,
                    "npcCategoryName": "NPC Extension",
                },
                {
                    "id": 2,
                    "npcCategoryName": "NPC Combination",
                },
                {
                    "id": 3,
                    "npcCategoryName": "New KIt",
                },
            ],
            "npcComponent": [
                {
                    "id": 1,
                    "npcComponentName": "Body Stud Nut",
                },
                {
                    "id": 2,
                    "npcComponentName": "Body",
                },
                {
                    "id": 3,
                    "npcComponentName": "Body Stud",
                },
            ],
            "makeBuy": [
                {
                    "id": 1,
                    "makeBuyName": "Make",
                },
                {
                    "id": 2,
                    "makeBuyName": "Buy",
                }
            ]
        },
        {
            "id": 2,
            "status": 75,
            "erNpc": "ER-1156463-003-VPL-DS",
            "soLi": "1154285-1001",
            "dwgNo": 75454612,
            "mCode": 150,
            "qCode": 11000,
            "npcCategory": [
                {
                    "id": 1,
                    "npcCategoryName": "NPC Extension",
                },
                {
                    "id": 2,
                    "npcCategoryName": "NPC Combination",
                },
                {
                    "id": 3,
                    "npcCategoryName": "New KIt",
                },
            ],
            "npcComponent": [
                {
                    "id": 1,
                    "npcComponentName": "Body Stud Nut",
                },
                {
                    "id": 2,
                    "npcComponentName": "Body",
                },
                {
                    "id": 3,
                    "npcComponentName": "Body Stud",
                },
            ],
            "makeBuy": [
                {
                    "id": 1,
                    "makeBuyName": "Make",
                },
                {
                    "id": 2,
                    "makeBuyName": "Buy",
                }
            ]
        },
        {
            "id": 3,
            "status": 30,
            "erNpc": "ER-1156463-003-VPL-DS",
            "soLi": "1154285-1003",
            "dwgNo": 75454613,
            "mCode": 450,
            "qCode": 20000,
            "npcCategory": [
                {
                    "id": 1,
                    "npcCategoryName": "NPC Extension",
                },
                {
                    "id": 2,
                    "npcCategoryName": "NPC Combination",
                },
                {
                    "id": 3,
                    "npcCategoryName": "New KIt",
                },
            ],
            "npcComponent": [
                {
                    "id": 1,
                    "npcComponentName": "Body Stud Nut",
                },
                {
                    "id": 2,
                    "npcComponentName": "Body",
                },
                {
                    "id": 3,
                    "npcComponentName": "Body Stud",
                },
            ],
            "makeBuy": [
                {
                    "id": 1,
                    "makeBuyName": "Make",
                },
                {
                    "id": 2,
                    "makeBuyName": "Buy",
                }
            ]
        },
        {
            "id": 4,
            "status": 50,
            "erNpc": "ER-1156463-004-VPL-DS",
            "soLi": "1154285-5000",
            "dwgNo": 75454615,
            "mCode": 550,
            "qCode": 50000,
            "npcCategory": [
                {
                    "id": 1,
                    "npcCategoryName": "NPC Extension",
                },
                {
                    "id": 2,
                    "npcCategoryName": "NPC Combination",
                },
                {
                    "id": 3,
                    "npcCategoryName": "New KIt",
                },
            ],
            "npcComponent": [
                {
                    "id": 1,
                    "npcComponentName": "Body Stud Nut",
                },
                {
                    "id": 2,
                    "npcComponentName": "Body",
                },
                {
                    "id": 3,
                    "npcComponentName": "Body Stud",
                },
            ],
            "makeBuy": [
                {
                    "id": 1,
                    "makeBuyName": "Make",
                },
                {
                    "id": 2,
                    "makeBuyName": "Buy",
                }
            ]
        }
    ]
}


export const svcGetSubNPCData = {
    "subNpcResponseDto": [
        {
            "id": null,
            "department": "Engineering",
            "generalComments": null,
            "holdComments": null,
            "holdFlag": false,
            "requestDate": 1613673000.000000000,
            "completionDate": null,
            "enggCooridinatorList": null,
            "sapStatus": null
        },
        {
            "id": null,
            "department": "Quality",
            "generalComments": null,
            "holdComments": null,
            "holdFlag": false,
            "requestDate": 1613673000.000000000,
            "completionDate": null,
            "enggCooridinatorList": null,
            "sapStatus": null
        },
        {
            "id": null,
            "department": "Manufacturing",
            "generalComments": null,
            "holdComments": null,
            "holdFlag": false,
            "requestDate": 1613673000.000000000,
            "completionDate": null,
            "enggCooridinatorList": null,
            "sapStatus": null
        },
        {
            "id": null,
            "department": "Sourcing",
            "generalComments": null,
            "holdComments": null,
            "holdFlag": false,
            "requestDate": 1613673000.000000000,
            "completionDate": null,
            "enggCooridinatorList": null,
            "sapStatus": null
        },
        {
            "id": null,
            "department": "Finance",
            "generalComments": null,
            "holdComments": null,
            "holdFlag": false,
            "requestDate": 1613673000.000000000,
            "completionDate": null,
            "enggCooridinatorList": null,
            "sapStatus": null
        },
        {
            "id": null,
            "department": "Planning",
            "generalComments": null,
            "holdComments": null,
            "holdFlag": false,
            "requestDate": 1613673000.000000000,
            "completionDate": null,
            "enggCooridinatorList": null,
            "sapStatus": null
        }
    ]
}

export const npcData = {
    "npcTransactionList": [
        {
            "id": 1,
            "soli": "115420-1000",
            "parentId": 1,
            "mcode": "1123",
            "qcode": "1213",
            "drawingNumber": "111223341",
            "levelFourMasterId": null,
            "status": "SUBMIT",
            "npcReferenceId": null,
            "npcReferenceMappingId": null,
            "npcSubLevels": [],
            "npcWorkFlowStatus": "In Progress",
            "npcNumber": "ER-115420-1000-NPC-1",
            "npcSubCategoryId": 2,
            "npcSubCategory": "New Kit",
            "subLevelComponentId": 1,
            "subLevelComponent": "Body",
            "ecmNumber": null,
            "erNpc": "ER-115420-1000-NPC-1",
            "qcodeComments": null,
            "mcodeComments": null,
            "enggCoordinatorFirstName": null,
            "enggCoordinatorLastName": null,
            "enggCoordinator": null,
            "dwgHeader": "1221",
            "holdFlag": false,
            "mcodeDesc": "12",
            "makeBuy": null,
            "generalComments": "1231231c12ewq23432423423e",
            "holdComments": "2323",
            "qcodeDesc": "21"
        },
        {
            "id": 2,
            "soli": "115420-1000",
            "parentId": 1,
            "mcode": "1123",
            "qcode": "1213",
            "drawingNumber": "111223341",
            "levelFourMasterId": 2,
            "status": "SUBMIT",
            "npcReferenceId": null,
            "npcReferenceMappingId": null,
            "npcSubLevels": [],
            "npcWorkFlowStatus": "In Progress",
            "npcNumber": "ER-115420-1000-NPC-2",
            "npcSubCategoryId": 2,
            "npcSubCategory": "New Kit",
            "subLevelComponentId": 1,
            "subLevelComponent": "Body",
            "ecmNumber": null,
            "erNpc": null,
            "qcodeComments": null,
            "mcodeComments": null,
            "enggCoordinatorFirstName": null,
            "enggCoordinatorLastName": null,
            "enggCoordinator": null,
            "dwgHeader": "1221",
            "holdFlag": false,
            "mcodeDesc": "12",
            "makeBuy": null,
            "generalComments": "1231231c12ewq23432423423e",
            "holdComments": "2323",
            "qcodeDesc": "21"
        },
        {
            "id": 0,
            "soli": null,
            "parentId": 1,
            "mcode": null,
            "qcode": null,
            "drawingNumber": null,
            "levelFourMasterId": 1,
            "status": "NOT STARTED",
            "npcReferenceId": null,
            "npcReferenceMappingId": null,
            "npcSubLevels": null,
            "npcWorkFlowStatus": "NOT STARTED",
            "npcNumber": null,
            "npcSubCategoryId": 0,
            "npcSubCategory": null,
            "subLevelComponentId": 1,
            "subLevelComponent": "Body",
            "ecmNumber": null,
            "erNpc": null,
            "qcodeComments": null,
            "mcodeComments": null,
            "enggCoordinatorFirstName": null,
            "enggCoordinatorLastName": null,
            "enggCoordinator": null,
            "dwgHeader": null,
            "holdFlag": false,
            "mcodeDesc": null,
            "makeBuy": null,
            "generalComments": null,
            "holdComments": null,
            "qcodeDesc": null
        },
        {
            "id": 0,
            "soli": null,
            "parentId": 1,
            "mcode": null,
            "qcode": null,
            "drawingNumber": null,
            "levelFourMasterId": 3,
            "status": "NOT STARTED",
            "npcReferenceId": null,
            "npcReferenceMappingId": null,
            "npcSubLevels": null,
            "npcWorkFlowStatus": "NOT STARTED",
            "npcNumber": null,
            "npcSubCategoryId": 0,
            "npcSubCategory": null,
            "subLevelComponentId": 11,
            "subLevelComponent": "Cage",
            "ecmNumber": null,
            "erNpc": null,
            "qcodeComments": null,
            "mcodeComments": null,
            "enggCoordinatorFirstName": null,
            "enggCoordinatorLastName": null,
            "enggCoordinator": null,
            "dwgHeader": null,
            "holdFlag": false,
            "mcodeDesc": null,
            "makeBuy": null,
            "generalComments": null,
            "holdComments": null,
            "qcodeDesc": null
        }
    ],
    "workflowStatus": [
        {
            "id": 1,
            "status": "SAVE"
        },
        {
            "id": 2,
            "status": "PROMOTE"
        },
        {
            "id": 3,
            "status": "DEMOTE"
        },
        {
            "id": 4,
            "status": "NOT STARTED"
        },
        {
            "id": 5,
            "status": "Ready for Review"
        },
        {
            "id": 6,
            "status": "Ready for Release"
        },
        {
            "id": 7,
            "status": "Released"
        }
    ],
    "npcSubCategoryList": [
        {
            "id": 1,
            "npcSubCategory": "New QMD"
        },
        {
            "id": 2,
            "npcSubCategory": "New Kit"
        },
        {
            "id": 3,
            "npcSubCategory": "New Extensions"
        },
        {
            "id": 4,
            "npcSubCategory": "Tubes And Fittings"
        }
    ]
}