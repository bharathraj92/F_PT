export const svcGetMyDashboardData = {
    'myDashboardData': [
        {
            'erNumber': 'ER-115420-001',
            'workDesignated': 'BOM Configuartion',
            'indicator': 'ACTIVATED',
            'progress': '80%',
            'hoursAssigned': '1.00',
            'hoursSpent': '0.50',
            'startDate': '24-Oct-2019',
            'endDate': '24-Oct-2020'
        },
        {
            'erNumber': 'ER-115420-002',
            'workDesignated': 'BOM Configuartion',
            'indicator': 'HOLD',
            'progress': '60%',
            'hoursAssigned': '1.00',
            'hoursSpent': '0.50',
            'startDate': '24-Oct-2019',
            'endDate': '24-Oct-2020'
        },
        {
            'erNumber': 'ER-115420-003',
            'workDesignated': 'BOM Scheduling',
            'indicator': 'COMPLETED',
            'progress': '100%',
            'hoursAssigned': '0.25',
            'hoursSpent': '0.25',
            'startDate': '24-Oct-2019',
            'endDate': '24-Oct-2020'
        }
    ],
    "wipDeepDriveReport": [
        {
            "saleorder": "1173467",
            "itemNo": "1000",
            "dueWeek": 34,
            "Year": "2021",
            "csrProjectManager": "Susan Trask",
            "soldToName": "DRESSER KOREA, INC",
            "createdDate": 1635013800,
            "enggDueDate": 1635013800,
            "enggCompleteDate": 1635013800,
            "configurationEngg": "Doan,Tuan",
            "shippingDate": 1635013800,
            "headerStatusProfile": "CRPD",
            "leadTime": 14,
            "supportTeam": "JAX",
            "tagNumber": 1245
        },
        {
            "saleorder": "2373478",
            "itemNo": "1000",
            "dueWeek": 34,
            "Year": "2021",
            "csrProjectManager": "Susan Trask",
            "soldToName": "DRESSER KOREA, INC",
            "createdDate": 1635013800,
            "enggDueDate": 1635013800,
            "enggCompleteDate": 1635013800,
            "configurationEngg": "Doan,Tuan",
            "shippingDate": 1635013800,
            "headerStatusProfile": "CRPD",
            "leadTime": 14,
            "supportTeam": "JAX",
            "tagNumber": 1245
        },{
            "saleorder": "4573490",
            "itemNo": "1000",
            "dueWeek": 34,
            "Year": "2021",
            "csrProjectManager": "Susan Trask",
            "soldToName": "DRESSER KOREA, INC",
            "createdDate": 1635013800,
            "enggDueDate": 1635013800,
            "enggCompleteDate": 1635013800,
            "configurationEngg": "Doan,Tuan",
            "shippingDate": 1635013800,
            "headerStatusProfile": "CRPD",
            "leadTime": 14,
            "supportTeam": "JAX",
            "tagNumber": 1245
        }
    ]
}

