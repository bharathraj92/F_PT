export const calculationsCreatorGetData = {
    "workflowStatusList": [
      {
        "id": 1,
        "status": "SAVE"
      },
      {
        "id": 2,
        "status": "PROMOTE"
      },
      {
        "id": 3,
        "status": "DEMOTE"
      },
      {
        "id": 4,
        "status": "NOT STARTED"
      },
      {
        "id": 5,
        "status": "Ready for Review"
      },
      {
        "id": 6,
        "status": "Ready for Release"
      },
      {
        "id": 7,
        "status": "Released"
      }
    ],
    "progressStatusList": [
      {
        "id": 1,
        "status": "WIP"
      },
      {
        "id": 2,
        "status": "RISK REVIEW"
      },
      {
        "id": 3,
        "status": "ON TIME"
      },
      {
        "id": 4,
        "status": "ON TIME EARLY"
      },
      {
        "id": 5,
        "status": "LATE"
      },
      {
        "id": 6,
        "status": "OVD"
      },
      {
        "id": 7,
        "status": "CANCELLED"
      }
    ],
    "calculationsCreatorDtoList": [
      {
        "id": 0,
        "preConfigId": 8,
        "soli": "115420-4000",
        "tagNumber": "1234-56",
        "levelTwoId": 16,
        "levelTwo": "PED Calculations",
        "comments": null,
        "holdComments": null,
        "targetDate": null,
        "aging": 0,
        "hoursAssigned": 0,
        "floatingDays": 0,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "calculationProgressId": 1,
        "calculationProgress": "WIP",
        "calculationCreatorStatusId": 4,
        "calculationCreatorStatus": "NOT STARTED",
        "calculationCreatedBySso": null,
        "calculationCreatedByFirstname": null,
        "calculationCreatedByLastname": null,
        "calculationCurrentStatus": "NOT STARTED",
        "calculationCurrentStatusId": 4,
        "hold": false
      },
      {
        "id": 0,
        "preConfigId": 8,
        "soli": "115420-4000",
        "tagNumber": "1234-56",
        "levelTwoId": 17,
        "levelTwo": "Calculation Others",
        "comments": null,
        "holdComments": null,
        "targetDate": null,
        "aging": 0,
        "hoursAssigned": 0,
        "floatingDays": 0,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "calculationProgressId": 1,
        "calculationProgress": "WIP",
        "calculationCreatorStatusId": 4,
        "calculationCreatorStatus": "NOT STARTED",
        "calculationCreatedBySso": null,
        "calculationCreatedByFirstname": null,
        "calculationCreatedByLastname": null,
        "calculationCurrentStatus": "NOT STARTED",
        "calculationCurrentStatusId": 4,
        "hold": false
      }
    ]
  }