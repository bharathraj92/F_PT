export const svcGetSchedulingPlanningData = {
    "finalData":
        [
            {
                "taskOrder": 0,
                "parentTaskPhase": null,
                "taskName": "Phase 1 : Pre-Configuration",
                "taskDesc": "Phase 1 : Pre-Configuration",
                "roleId": 0,
                "roleName": null,
                "roleDesc": null,
                "departmentId": 0,
                "systemGeneratedDate": null,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 1,
                "usersList": null,
                "preConfigId": 0,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": null,
                "schedulingType": null,
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 0,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": null,
                "masterLevelTaskName": null,
                "modifiedPercent": 0
            },
            {
                "taskOrder": 1,
                "parentTaskPhase": "Phase 1 : Pre-Configuration",
                "taskName": "Pre-Configuration",
                "taskDesc": "Pre-Configuration",
                "roleId": 15,
                "roleName": "Project Leader / EPL",
                "roleDesc": "Project Leader / EPL (Pre-Conf, Engg Project)",
                "departmentId": 1,
                "systemGeneratedDate": 1614018600,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 1,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 0,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": null,
                "schedulingType": "PRECONFIG",
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": true,
                "autoUser": "503195167",
                "autoUsername": "KARTHIK RAVI (503195167)",
                "endUserTypeId": 0,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": "DVI",
                "masterLevelTaskName": "Pre-Configuration",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 0,
                "parentTaskPhase": null,
                "taskName": "Phase 2 : BOM Configuration",
                "taskDesc": "Phase 2 : BOM Configuration",
                "roleId": 0,
                "roleName": null,
                "roleDesc": null,
                "departmentId": 0,
                "systemGeneratedDate": null,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 3,
                "usersList": null,
                "preConfigId": 0,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": null,
                "schedulingType": null,
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 0,
                "siteId": 0,
                "manualDate": null,
                "enggSupportTeam": null,
                "masterLevelTaskName": null,
                "modifiedPercent": 0
            },
            {
                "taskOrder": 1,
                "parentTaskPhase": "Phase 2 : BOM Configuration",
                "taskName": "BOM Configuration",
                "taskDesc": "BOM-Valve Creator",
                "roleId": 4,
                "roleName": "Config. Engineer",
                "roleDesc": "Config. Engineer (BOM Creator)",
                "departmentId": 1,
                "systemGeneratedDate": 1616240121.873,
                "productKnowledgeId": 8,
                "productKnowledgeName": "L2",
                "complexityLevel": "L2",
                "taskCompletionPercentage": 3,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 3,
                "levelOneId": 1,
                "levelTwoId": 1,
                "levelThreeId": 0,
                "levelOneTransactionId": 27,
                "levelTwoTransactionId": 29,
                "levelThreeTransactionId": 0,
                "startDate": 1613932200,
                "schedulingType": "BOMCONFIG",
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 1,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": "DVI",
                "masterLevelTaskName": "Valve",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 2,
                "parentTaskPhase": "Phase 2 : BOM Configuration",
                "taskName": "BOM Configuration",
                "taskDesc": "BOM-Valve Reviewer",
                "roleId": 17,
                "roleName": "Reviewer",
                "roleDesc": "Reviewer(Valve BOM reviewer, Instrument BOM review)",
                "departmentId": 1,
                "systemGeneratedDate": 1616240121.873,
                "productKnowledgeId": 25,
                "productKnowledgeName": "Approver",
                "complexityLevel": "L2",
                "taskCompletionPercentage": 3,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 3,
                "levelOneId": 1,
                "levelTwoId": 1,
                "levelThreeId": 0,
                "levelOneTransactionId": 27,
                "levelTwoTransactionId": 29,
                "levelThreeTransactionId": 0,
                "startDate": 1613932200,
                "schedulingType": "BOMCONFIG",
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 1,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": "DVI",
                "masterLevelTaskName": "Valve",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 7,
                "parentTaskPhase": "Phase 2 : BOM Configuration",
                "taskName": "BOM Configuration",
                "taskDesc": "BOM-Release",
                "roleId": 15,
                "roleName": "Project Leader / EPL",
                "roleDesc": "Project Leader / EPL (Pre-Conf, Engg Project)",
                "departmentId": 1,
                "systemGeneratedDate": 1616240121.873,
                "productKnowledgeId": 22,
                "productKnowledgeName": "L2",
                "complexityLevel": "L2",
                "taskCompletionPercentage": 3,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 3,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": 1615894521.873,
                "schedulingType": "BOMCONFIG",
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": "503195167",
                "autoUsername": "Karthik Ravi (503195167)",
                "endUserTypeId": 0,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": "DVI",
                "masterLevelTaskName": "BOM-Release",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 0,
                "parentTaskPhase": null,
                "taskName": "Phase 3 : Design",
                "taskDesc": "Phase 3 : Design",
                "roleId": 0,
                "roleName": null,
                "roleDesc": null,
                "departmentId": 0,
                "systemGeneratedDate": null,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 7,
                "usersList": null,
                "preConfigId": 0,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": null,
                "schedulingType": null,
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 0,
                "siteId": 0,
                "manualDate": null,
                "enggSupportTeam": null,
                "masterLevelTaskName": null,
                "modifiedPercent": 0
            },
            {
                "taskOrder": 1,
                "parentTaskPhase": "Phase 3 : Design",
                "taskName": "Design",
                "taskDesc": "Valve-Body/Bonnet Creator",
                "roleId": 7,
                "roleName": "Engineer",
                "roleDesc": "Engineer(Draft, Design, Model)",
                "departmentId": 1,
                "systemGeneratedDate": 1616585722.136,
                "productKnowledgeId": 18,
                "productKnowledgeName": "L2",
                "complexityLevel": "L2",
                "taskCompletionPercentage": 7,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 3,
                "levelOneId": 2,
                "levelTwoId": 4,
                "levelThreeId": 1,
                "levelOneTransactionId": 28,
                "levelTwoTransactionId": 30,
                "levelThreeTransactionId": 13,
                "startDate": 1613932200,
                "schedulingType": "DESIGN",
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 1,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": "DVI",
                "masterLevelTaskName": "Body/Bonnet",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 2,
                "parentTaskPhase": "Phase 3 : Design",
                "taskName": "Design",
                "taskDesc": "Valve-Body/Bonnet Reviewer",
                "roleId": 6,
                "roleName": "Design Engineer",
                "roleDesc": "Design Engineer(Reviewer of designs)",
                "departmentId": 1,
                "systemGeneratedDate": 1616585722.136,
                "productKnowledgeId": 15,
                "productKnowledgeName": "Approver",
                "complexityLevel": "L2",
                "taskCompletionPercentage": 7,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 3,
                "levelOneId": 2,
                "levelTwoId": 4,
                "levelThreeId": 1,
                "levelOneTransactionId": 28,
                "levelTwoTransactionId": 30,
                "levelThreeTransactionId": 13,
                "startDate": 1613932200,
                "schedulingType": "DESIGN",
                "npcId": 0,
                "soli": "115420-5000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 1,
                "siteId": 1,
                "manualDate": null,
                "enggSupportTeam": "DVI",
                "masterLevelTaskName": "Body/Bonnet",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 0,
                "parentTaskPhase": null,
                "taskName": "Phase 4 : External Deliverables",
                "taskDesc": "Phase 4 : External Deliverables",
                "roleId": 0,
                "roleName": null,
                "roleDesc": null,
                "departmentId": 0,
                "systemGeneratedDate": null,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 3,
                "usersList": null,
                "preConfigId": 0,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": null,
                "schedulingType": null,
                "npcId": 0,
                "soli": "1199404-13000",
                "disableFlag": false,
                "autoUser": null,
                "autoUsername": null,
                "endUserTypeId": 0,
                "siteId": 3,
                "manualDate": null,
                "enggSupportTeam": null,
                "masterLevelTaskName": null,
                "modifiedPercent": 0
            },
            {
                "taskOrder": 2,
                "parentTaskPhase": "Phase 4 : External Deliverables",
                "taskName": "External Deliverables",
                "taskDesc": "External Deliverables",
                "roleId": 15,
                "roleName": "Creator",
                "roleDesc": "Ed Creator",
                "departmentId": 1,
                "systemGeneratedDate": 1616231130,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 3,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    },{
                        "ssoId": "503196033",
                        "firstName": "Bharath",
                        "lastName": "Raj",
                        "admin": true
                    },{
                        "ssoId": "503127424",
                        "firstName": "Shruti",
                        "lastName": "H",
                        "admin": true
                    }
                ],
                "preConfigId": 3,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": 1615885530,
                "schedulingType": "EXTERNALDELIVERABLES",
                "npcId": 0,
                "soli": "1199404-13000",
                "disableFlag": false,
                "autoUser": "503196033",
                "autoUsername": "Bharath Raj (503196033)",
                "endUserTypeId": 0,
                "siteId": 3,
                "manualDate": null,
                "enggSupportTeam": "Conde",
                "masterLevelTaskName": "External Deliverables",
                "modifiedPercent": 0
            },
            {
                "taskOrder": 1,
                "parentTaskPhase": "Phase 4 : External Deliverables",
                "taskName": "External Deliverables",
                "taskDesc": "External Deliverables",
                "roleId": 15,
                "roleName": "Reviewer",
                "roleDesc": "Ed Reviewer",
                "departmentId": 1,
                "systemGeneratedDate": 1616231130,
                "productKnowledgeId": 0,
                "productKnowledgeName": null,
                "complexityLevel": null,
                "taskCompletionPercentage": 3,
                "usersList": [
                    {
                        "ssoId": "503195167",
                        "firstName": "Karthik",
                        "lastName": "Ravi",
                        "admin": true
                    }
                ],
                "preConfigId": 0,
                "levelOneId": 0,
                "levelTwoId": 0,
                "levelThreeId": 0,
                "levelOneTransactionId": 0,
                "levelTwoTransactionId": 0,
                "levelThreeTransactionId": 0,
                "startDate": 1615885530,
                "schedulingType": "EXTERNALDELIVERABLES",
                "npcId": 0,
                "soli": "1199404-13000",
                "disableFlag": false,
                "autoUser": "503195167",
                "autoUsername": "Karthik Ravi (503195167)",
                "endUserTypeId": 0,
                "siteId": 3,
                "manualDate": null,
                "enggSupportTeam": "Conde",
                "masterLevelTaskName": "External Deliverables",
                "modifiedPercent": 0
            }
        ],
    "plant": "DVI",

    //   "schedulingResponseDto": [
    //     {
    //         "taskOrder": 0,
    //         "parentTaskPhase": null,
    //         "taskName": "Phase 1 : Pre-Configuration",
    //         "taskDesc": 'Pre-Configuration',
    //         "roleId": 0,
    //         "roleName": null,
    //         "roleDesc": null,
    //         "departmentId": 0,
    //         "systemGeneratedDate": null,
    //         "productKnowledgeId": 0,
    //         "productKnowledgeName": null,
    //         "complexityLevel": null,
    //         "taskCompletionPercentage": 14,
    //         "usersList": null
    //     },
    //     {
    //         "taskOrder": 1,
    //         "parentTaskPhase": "Phase 1 : Pre-Configuration",
    //         "taskName": "Pre-Configuration",
    //         "taskDesc": "Pre-Configuration",
    //         "roleId": 15,
    //         "roleName": "Project Leader / EPL",
    //         "roleDesc": "Project Leader / EPL (Pre-Conf, Engg Project)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606674600,
    //         "productKnowledgeId": 23,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 14,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 2,
    //         "parentTaskPhase": "Phase 2 : Bom-Configuration",
    //         "taskName": "Bom-Configuration",
    //         "taskDesc": "Bom-Configuration",
    //         "roleId": 15,
    //         "roleName": "Project Leader / EPL",
    //         "roleDesc": "Project Leader / EPL (Pre-Conf, Engg Project)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606674600,
    //         "productKnowledgeId": 23,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 15,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 0,
    //         "parentTaskPhase": null,
    //         "taskName": "Phase 2 : Bom-Configuration",
    //         "taskDesc": null,
    //         "roleId": 0,
    //         "roleName": null,
    //         "roleDesc": null,
    //         "departmentId": 0,
    //         "systemGeneratedDate": null,
    //         "productKnowledgeId": 0,
    //         "productKnowledgeName": null,
    //         "complexityLevel": null,
    //         "taskCompletionPercentage": 15,
    //         "usersList": null
    //     },
    //     {
    //         "taskOrder": 5,
    //         "parentTaskPhase": "Phase 3 : Design",
    //         "taskName": "Design",
    //         "taskDesc": "Valve-Body/Bonnet Creator",
    //         "roleId": 7,
    //         "roleName": "Engineer",
    //         "roleDesc": "Engineer(Draft, Design, Model)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606551064.796,
    //         "productKnowledgeId": 19,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 7,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 4,
    //         "parentTaskPhase": "Phase 3 : Design",
    //         "taskName": "Design",
    //         "taskDesc": "Valve-Body/Bonnet Reviewer",
    //         "roleId": 6,
    //         "roleName": "Design Engineer",
    //         "roleDesc": "Design Engineer(Reviewer of designs)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606551064.796,
    //         "productKnowledgeId": 14,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 7,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127421",
    //                 "firstName": "Aprajita",
    //                 "lastName": "Singh",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 6,
    //         "parentTaskPhase": "Phase 3 : Design",
    //         "taskName": "Design",
    //         "taskDesc": "Valve-Trim Parts Reviewer",
    //         "roleId": 6,
    //         "roleName": "Design Engineer",
    //         "roleDesc": "Design Engineer(Reviewer of designs)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606551064.803,
    //         "productKnowledgeId": 14,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 7,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127421",
    //                 "firstName": "Aprajita",
    //                 "lastName": "Singh",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 7,
    //         "parentTaskPhase": "Phase 3 : Design",
    //         "taskName": "Design",
    //         "taskDesc": "Valve-Parts Excluding Trim Creator",
    //         "roleId": 7,
    //         "roleName": "Engineer",
    //         "roleDesc": "Engineer(Draft, Design, Model)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606551064.805,
    //         "productKnowledgeId": 19,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 7,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 8,
    //         "parentTaskPhase": "Phase 3 : Design",
    //         "taskName": "Design",
    //         "taskDesc": "Valve-Parts Excluding Trim Reviewer",
    //         "roleId": 6,
    //         "roleName": "Design Engineer",
    //         "roleDesc": "Design Engineer(Reviewer of designs)",
    //         "departmentId": 1,
    //         "systemGeneratedDate": 1606551064.805,
    //         "productKnowledgeId": 14,
    //         "productKnowledgeName": "L3",
    //         "complexityLevel": "L3",
    //         "taskCompletionPercentage": 7,
    //         "usersList": [
    //             {
    //                 "ssoId": "503127424",
    //                 "firstName": "Shruti",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127425",
    //                 "firstName": "Xyz",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127426",
    //                 "firstName": "Abc",
    //                 "lastName": "H",
    //                 "admin": true
    //             },
    //             {
    //                 "ssoId": "503127421",
    //                 "firstName": "Aprajita",
    //                 "lastName": "Singh",
    //                 "admin": true
    //             }
    //         ]
    //     },
    //     {
    //         "taskOrder": 0,
    //         "parentTaskPhase": null,
    //         "taskName": "Phase 3 : Design",
    //         "taskDesc": null,
    //         "roleId": 0,
    //         "roleName": null,
    //         "roleDesc": null,
    //         "departmentId": 0,
    //         "systemGeneratedDate": null,
    //         "productKnowledgeId": 0,
    //         "productKnowledgeName": null,
    //         "complexityLevel": null,
    //         "taskCompletionPercentage": 7,
    //         "usersList": null
    //     }
    // ]
}