export const svcGetActivityTreeData = {

    "levelData": [
        {
            "id": 1,
            "levelName": "BOM CONFIGURATION",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 1,
                    "levelName": "Valve",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 2,
                    "levelName": "Level",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 3,
                    "levelName": "Instrument",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                }
            ],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 2,
            "levelName": "Design",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 4,
                    "levelName": "Valve Design",
                    "levelNo": "Two",
                    "subLevel": [
                        {
                            "id": 1,
                            "levelName": "BODY / BONNET",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 1,
                                    "levelName": "BODY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 2,
                                    "levelName": "BONNET",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 3,
                                    "levelName": "STUD_BODY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 4,
                                    "levelName": "NUT_BODY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 5,
                                    "levelName": "BONNET FLANGE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 6,
                                    "levelName": "BONNET, BELLOWS",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 7,
                                    "levelName": "STUD,BONNET",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 8,
                                    "levelName": "BELLOWS SUB-ASSEMBLY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 9,
                                    "levelName": "GASKET,BODY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 10,
                                    "levelName": "NUT,BONNET",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 2,
                            "levelName": "TRIM PARTS",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 11,
                                    "levelName": "CAGE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 12,
                                    "levelName": "CAGE, OUTER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 13,
                                    "levelName": "SEAT RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 14,
                                    "levelName": "LOWER SEAT RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 15,
                                    "levelName": "PLUG, VALVE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 16,
                                    "levelName": "STEM, PLUG",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 17,
                                    "levelName": "SHAFT, ROTARY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 18,
                                    "levelName": "PLUG AND STEM SUB-ASSEMBLY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 19,
                                    "levelName": "PLUG & STEM INTEGRAL, VALVE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 20,
                                    "levelName": "CAGE PIN",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 21,
                                    "levelName": "PILOT PLUGÂ Â Â Â  ",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 22,
                                    "levelName": "PILOT SPRING( HELICAL SPRING)",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 23,
                                    "levelName": "PILOT SPRING( SET OF DISC SPRINGS)",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 24,
                                    "levelName": "SEAT RING WITH DIFFUSER ",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 25,
                                    "levelName": "GASKET,CAGE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 26,
                                    "levelName": "CAGE, WASHER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 27,
                                    "levelName": "HIGH TEMP TWIST SEAL",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 28,
                                    "levelName": "COMPRESSION SPRING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 29,
                                    "levelName": "SPRING FLANGE (HTS)",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 30,
                                    "levelName": "LINER ",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 31,
                                    "levelName": "LOWER, LINER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 32,
                                    "levelName": "METAL SEAL",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 33,
                                    "levelName": "PLUG SUB-ASSEMBLY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 34,
                                    "levelName": "PLUG SUB-ASSEMBLY(SOFT SEAT)",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 35,
                                    "levelName": "SEAL_RING (INTERNAL)",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 36,
                                    "levelName": "PLUG PIN",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 37,
                                    "levelName": "RETAINING RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 38,
                                    "levelName": "LANTERN RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 39,
                                    "levelName": "SEAL RETAINER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 40,
                                    "levelName": "FLANGE, BOTTOM",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 41,
                                    "levelName": "STUD FLANGE BOTTOM",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 42,
                                    "levelName": "LODB PLATE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 43,
                                    "levelName": "UPPER PLUG",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 44,
                                    "levelName": "LOWER PLUG",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 45,
                                    "levelName": "DISC",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 46,
                                    "levelName": "DISC SEAT",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 47,
                                    "levelName": "SEAL FASTENERS",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 48,
                                    "levelName": "CV ADJUSTMENT PLATE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 49,
                                    "levelName": "BELLOWS STEM SUB-ASSEMBLY",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 3,
                            "levelName": "PARTS EXCLUDING TRIM",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 50,
                                    "levelName": "GUIDE_BUSH",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 51,
                                    "levelName": "STUD_PACKING_FLANGE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 52,
                                    "levelName": "NUT_PACKING_FLANGE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 53,
                                    "levelName": "GASKET_BODY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 54,
                                    "levelName": "GASKET_SEAT",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 55,
                                    "levelName": "PACKING_FOLLOWER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 56,
                                    "levelName": "PACKING_FLANGE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 57,
                                    "levelName": "DRIVE_NUT",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 58,
                                    "levelName": "PACKING BUSH",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 59,
                                    "levelName": "BONNET RINGÂ Â Â Â  ",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 60,
                                    "levelName": "CONICAL SPRING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 61,
                                    "levelName": "STACK S/A",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 62,
                                    "levelName": "PIPE PLUG",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 63,
                                    "levelName": "ORING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 64,
                                    "levelName": "FLOW ARROW",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 65,
                                    "levelName": "DRIVE SCREW",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 66,
                                    "levelName": "SPACER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 67,
                                    "levelName": "NUT LOCK",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 68,
                                    "levelName": " GUIDE BUSH",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 69,
                                    "levelName": "SEAT RING RETAINER",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 70,
                                    "levelName": "RETAINING SCREW",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 71,
                                    "levelName": "PACKING RETAINING RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 72,
                                    "levelName": "CIRCLIP (EXTERNAL)",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 73,
                                    "levelName": "SAFETY PIN",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 74,
                                    "levelName": "THRUST PAD",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 75,
                                    "levelName": "GLAND PACKING RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 76,
                                    "levelName": "BEARING PROTECTOR",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 77,
                                    "levelName": "DISC FASTENERS",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 78,
                                    "levelName": "END PLATE FASTENERS",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 79,
                                    "levelName": "PACKING SET",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 80,
                                    "levelName": "DISC GRUB SCREW",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 81,
                                    "levelName": "THRUST PAD FASTENERS",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 82,
                                    "levelName": "SHAFT KEY ",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 83,
                                    "levelName": "ADJ.RING,PACKING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 84,
                                    "levelName": "PACKING RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 85,
                                    "levelName": "ANTI-EXTRUSION RING",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 86,
                                    "levelName": "LUBRICATOR S/A",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        }
                    ],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 5,
                    "levelName": "Actuator Design",
                    "levelNo": "Two",
                    "subLevel": [
                        {
                            "id": 4,
                            "levelName": "PISTON SERVO VALVE AND OTHERS",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 87,
                                    "levelName": "PISTON SERVO VALVE AND OTHERS",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 6,
                            "levelName": "VALVE STEM",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 88,
                                    "levelName": "VALVE STEM",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 7,
                            "levelName": "LIFTING RINGS",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 89,
                                    "levelName": "LIFTING RINGS",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 8,
                            "levelName": "ENLARGED CONNECTION COVER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 90,
                                    "levelName": "ENLARGED CONNECTION COVER",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 9,
                            "levelName": "ACTUATOR OTHER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 91,
                                    "levelName": "ACTUATOR ASSEMBLY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 92,
                                    "levelName": "SPLIT CLAMP ASSEMBLY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 93,
                                    "levelName": "HANDWHEEL ASSEMBLY",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 94,
                                    "levelName": "OTHER BODY SA COMPONENTS",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 95,
                                    "levelName": "ACTUATOR ASSEMBLY DEPENDS ON SELECTION",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 96,
                                    "levelName": "ACTUATOR BONNET INTERFACE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 97,
                                    "levelName": "Interface Kit Design",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 98,
                                    "levelName": "SERIAL PLATE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 99,
                                    "levelName": "INSTALLATION PLATE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 100,
                                    "levelName": "INFORMATION PLATE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 101,
                                    "levelName": "WARNING LABEL",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 102,
                                    "levelName": "WARNING PLATE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 103,
                                    "levelName": "LINKAGE MODULE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 104,
                                    "levelName": "GEAR BOX ",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 105,
                                    "levelName": "SPLIT CLAMP",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 106,
                                    "levelName": "HAND WHEEL",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 107,
                                    "levelName": "LIMIT STOP MODULE",
                                    "levelNo": "Four"
                                },
                                {
                                    "id": 108,
                                    "levelName": "SHAFT_MODULE_KIT",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        }
                    ],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 6,
                    "levelName": "Instrument Design",
                    "levelNo": "Two",
                    "subLevel": [
                        {
                            "id": 10,
                            "levelName": "LODB PLATE",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 110,
                                    "levelName": "LODB PLATE",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 11,
                            "levelName": "LODB CARTRIDGE",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 111,
                                    "levelName": "LODB CARTRIDGE",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 12,
                            "levelName": "DESIGN STUDY",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 112,
                                    "levelName": "DESIGN STUDY",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        }
                    ],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 7,
                    "levelName": "Level Design",
                    "levelNo": "Two",
                    "subLevel": [
                        {
                            "id": 14,
                            "levelName": "END CAP MECHANISM CHAMBER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 113,
                                    "levelName": "END CAP MECHANISM CHAMBER",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 15,
                            "levelName": "FLANGED MECHANISM CHAMBER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 114,
                                    "levelName": "FLANGED MECHANISM CHAMBER",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 16,
                            "levelName": "DIVER CHAMBER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 115,
                                    "levelName": "DIVER CHAMBER",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 17,
                            "levelName": "FLANGE CONNECTIONS (ALL TYPES)",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 116,
                                    "levelName": "FLANGE CONNECTIONS (ALL TYPES)",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 18,
                            "levelName": "END FITTINGS (ALL TYPES) AND DIMENSIONS",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 117,
                                    "levelName": "END FITTINGS (ALL TYPES) AND DIMENSIONS",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 19,
                            "levelName": "DIVER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 118,
                                    "levelName": "DIVER",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 20,
                            "levelName": "TORSION TUBE",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 119,
                                    "levelName": "TORSION TUBE",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 21,
                            "levelName": "1500Lbs",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 120,
                                    "levelName": "1500Lbs(1500Lbs)",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 22,
                            "levelName": "1500Lbs HUB",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 121,
                                    "levelName": "1500Lbs HUB(1500Lbs HUB)",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 23,
                            "levelName": "2500Lbs",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 122,
                                    "levelName": "2500Lbs(2500Lbs)",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 24,
                            "levelName": "2500Lbs HUB",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 123,
                                    "levelName": "2500Lbs HUB(2500Lbs HUB)",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 25,
                            "levelName": "STEAM JACKET",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 124,
                                    "levelName": "STEAM JACKET",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        },
                        {
                            "id": 26,
                            "levelName": "OTHER",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 125,
                                    "levelName": "OTHER",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": []
                        }
                    ],
                    "siteLevelMapping": []
                }
            ],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 3,
            "levelName": "Calculation",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 8,
                    "levelName": "AQISQ Calculations",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 9,
                    "levelName": "PED Calculations",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 12,
                    "levelName": "Others",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                }
            ],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 4,
            "levelName": "Other Engg Activities",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 13,
                    "levelName": "Procedure Study",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 14,
                    "levelName": "TECHNICAL SPECIFICATION REVIEW",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 15,
                    "levelName": "TECHNICAL QUOTATION SUPPORT",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                }
            ],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 5,
            "levelName": "External Deliverables",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 16,
                    "levelName": "DESIGN REPORT",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 17,
                    "levelName": "CUSTOMER DRAWINGS",
                    "levelNo": "Two",
                    "subLevel": [
                        {
                            "id": 27,
                            "levelName": "GA/CP DRAWING",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 126,
                                    "levelName": "GA/CP DRAWING",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                },
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                },
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 28,
                            "levelName": "GA DRAWING - CUSTOMER TEMPLATE",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 127,
                                    "levelName": "GA DRAWING - CUSTOMER TEMPLATE",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                },
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 29,
                            "levelName": "CROSS SECTIONAL DRAWING",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 128,
                                    "levelName": "CROSS SECTIONAL DRAWING",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 30,
                            "levelName": "PNEUMATIC SCHEMATIC DRAWING",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 129,
                                    "levelName": "PNEUMATIC SCHEMATIC DRAWING",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 31,
                            "levelName": "WIRING DRAWING",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 130,
                                    "levelName": "WIRING DRAWING",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        },
                        {
                            "id": 32,
                            "levelName": "COG - CENTER OF GRAVITY",
                            "levelNo": "Three",
                            "levelFour": [
                                {
                                    "id": 131,
                                    "levelName": "COG - CENTER OF GRAVITY",
                                    "levelNo": "Four"
                                }
                            ],
                            "siteLevelMapping": [
                                {
                                    "siteId": 1,
                                    "siteName": "JAX"
                                }
                            ]
                        }
                    ],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 18,
                    "levelName": "ITP",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 19,
                    "levelName": "IOM",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 20,
                    "levelName": "ASSEMBLY & TEST PROCEDURE",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 21,
                    "levelName": "DATASHEET/SPECSHEET",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 22,
                    "levelName": "CV CURVE",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 23,
                    "levelName": "SPARE PARTS LIST",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 25,
                    "levelName": "IBR",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 26,
                    "levelName": "LEGAL - FILES / DOCUMENTS",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 27,
                    "levelName": "OTHERS",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                }
            ],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 6,
            "levelName": "Tests",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 28,
                    "levelName": "SESIMIC DESIGN REPORT",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 29,
                    "levelName": "CV TEST REPORT",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                },
                {
                    "id": 30,
                    "levelName": "OTHERS",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": [
                        {
                            "siteId": 1,
                            "siteName": "JAX"
                        }
                    ]
                }
            ],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 7,
            "levelName": "New Part Creation",
            "levelNo": "One",
            "subLevel": [],
            "siteLevelMapping": [
                {
                    "siteId": 1,
                    "siteName": "JAX"
                }
            ]
        },
        {
            "id": 8,
            "levelName": "Quality Activities",
            "levelNo": "One",
            "subLevel": [
                {
                    "id": 31,
                    "levelName": "PQA",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 32,
                    "levelName": "PQM",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 33,
                    "levelName": "PQP",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 34,
                    "levelName": "PROCEDURE / FILE",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 35,
                    "levelName": "TECHNICAL",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 36,
                    "levelName": "WELDING",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 37,
                    "levelName": "OTHER ACTIVITIES",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                },
                {
                    "id": 38,
                    "levelName": "QUALITY SYSTEM",
                    "levelNo": "Two",
                    "subLevel": [],
                    "siteLevelMapping": []
                }
            ],
            "siteLevelMapping": []
        }
    ]
}
export const getDesignCreator ={
    "workflowStatusList": [
      {
        "id": 1,
        "status": "SAVE"
      },
      {
        "id": 2,
        "status": "PROMOTE"
      },
      {
        "id": 3,
        "status": "DEMOTE"
      },
      {
        "id": 4,
        "status": "NOT STARTED"
      },
      {
        "id": 5,
        "status": "Ready for Review"
      },
      {
        "id": 6,
        "status": "Ready for Release"
      },
      {
        "id": 7,
        "status": "Released"
      },
      {
        "id": 8,
        "status": "WIP"
      },
      {
        "id": 9,
        "status": "HOLD"
      },
      {
        "id": 10,
        "status": "CANCELLED"
      },
      {
        "id": 11,
        "status": "Partial Release"
      }
    ],
    "progressStatusList": [
      {
        "id": 1,
        "status": "WIP"
      },
      {
        "id": 2,
        "status": "RISK REVIEW"
      },
      {
        "id": 3,
        "status": "ON TIME"
      },
      {
        "id": 4,
        "status": "ON TIME EARLY"
      },
      {
        "id": 5,
        "status": "LATE"
      },
      {
        "id": 6,
        "status": "OVD"
      },
      {
        "id": 7,
        "status": "CANCELLED"
      }
    ],
    "designCreatorDtoList": [
      {
        "id": 1,
        "preConfigId": 2,
        "soli": "1229759-10000",
        "tagNumber": "4-30-33PV0701",
        "geometry": null,
        "mcode": null,
        "qcode": null,
        "levelFourId": 1,
        "levelFour": "Body",
        "levelFourTransactionId": 2,
        "levelThreeId": 1,
        "levelThreeName": "Body/Bonnet",
        "levelThreeTransactionId": 3,
        "levelTwoId": 4,
        "levelTwoName": "Valve Design",
        "levelTwoTransactionId": 3,
        "levelOneId": 2,
        "levelOneName": "Design",
        "levelOneTransactionId": 2,
        "comments": null,
        "holdComments": null,
        "targetDate": 1620212121,
        "aging": 406,
        "hoursAssigned": 0,
        "floatingDays": 406,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "designProgressId": 6,
        "designProgress": "OVD",
        "designCreatorStatusId": 1,
        "designCreatorStatus": "SAVE",
        "designCurrentStatusId": 8,
        "designCurrentStatus": "WIP",
        "designCreatedBySso": "503238554",
        "designCreatedByFirstname": "Arul  Prakash",
        "designCreatedByLastname": "Prakash",
        "geometryDesc": null,
        "mcodeDesc": null,
        "designChecklistMaster": [
          {
            "id": 13,
            "name": "ECO Number",
            "type": "textBox",
            "value": null
          },
          {
            "id": 14,
            "name": "ECM Number",
            "type": "textBox",
            "value": null
          }
        ],
        "levelFourRefId": null,
        "levelFourRefTransactionId": null,
        "levelFourRefNum": null,
        "levelThreeHold": false,
        "levelThreeHoldComments": null,
        "levelThreeComments": null,
        "readOnly": false,
        "maunualAdd": false,
        "designChildRefStatus": null,
        "designChildComments": null,
        "designChildHoldComments": null,
        "childEr": null,
        "childErNumber": null,
        "childGeometry": null,
        "childMcode": null,
        "childQcode": null,
        "currentErNumber": "ER-1229759-10000-2-DSG_VAL_BOD-CRE1",
        "designChildLevelFourId": null,
        "designChildLevelThreeId": null,
        "designChildLevelTwoId": null,
        "designChildPreConfigId": null,
        "supportSite": 2,
        "supportUserSsoId": "212552023",
        "supportUserFirstName": null,
        "hold": false
      },
      {
        "id": 3,
        "preConfigId": 2,
        "soli": "1229759-10000",
        "tagNumber": "4-30-33PV0701",
        "geometry": "aaaaaaaaa",
        "mcode": "aaaa",
        "qcode": "aaaa",
        "levelFourId": 12,
        "levelFour": "Cage,Outer",
        "levelFourTransactionId": 3,
        "levelThreeId": 2,
        "levelThreeName": "Trim Parts",
        "levelThreeTransactionId": 4,
        "levelTwoId": 4,
        "levelTwoName": "Valve Design",
        "levelTwoTransactionId": 3,
        "levelOneId": 2,
        "levelOneName": "Design",
        "levelOneTransactionId": 2,
        "comments": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "holdComments": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "targetDate": 1620212121,
        "aging": 406,
        "hoursAssigned": 0,
        "floatingDays": 406,
        "hourSpent": 0,
        "percentageCompleted": 100,
        "designProgressId": 6,
        "designProgress": "OVD",
        "designCreatorStatusId": 2,
        "designCreatorStatus": "PROMOTE",
        "designCurrentStatusId": 7,
        "designCurrentStatus": "Released",
        "designCreatedBySso": "503238554",
        "designCreatedByFirstname": "Arul  Prakash",
        "designCreatedByLastname": "Prakash",
        "geometryDesc": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "mcodeDesc": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "designChecklistMaster": [
          {
            "id": 13,
            "name": "ECO Number",
            "type": "textBox",
            "value": null
          },
          {
            "id": 14,
            "name": "ECM Number",
            "type": "textBox",
            "value": null
          }
        ],
        "levelFourRefId": null,
        "levelFourRefTransactionId": null,
        "levelFourRefNum": null,
        "levelThreeHold": false,
        "levelThreeHoldComments": null,
        "levelThreeComments": null,
        "readOnly": false,
        "maunualAdd": false,
        "designChildRefStatus": null,
        "designChildComments": null,
        "designChildHoldComments": null,
        "childEr": null,
        "childErNumber": null,
        "childGeometry": null,
        "childMcode": null,
        "childQcode": null,
        "currentErNumber": "ER-1229759-10000-2-DSG_VAL_TRI-CRE3",
        "designChildLevelFourId": null,
        "designChildLevelThreeId": null,
        "designChildLevelTwoId": null,
        "designChildPreConfigId": null,
        "supportSite": 2,
        "supportUserSsoId": "204059934",
        "supportUserFirstName": "ravi",
        "hold": false
      },
      {
        "id": 0,
        "preConfigId": 2,
        "soli": "1229759-10000",
        "tagNumber": "4-30-33PV0701",
        "geometry": null,
        "mcode": null,
        "qcode": null,
        "levelFourId": 0,
        "levelFour": null,
        "levelFourTransactionId": 0,
        "levelThreeId": 3,
        "levelThreeName": "Parts Excluding Trim",
        "levelThreeTransactionId": 5,
        "levelTwoId": 4,
        "levelTwoName": "Valve Design",
        "levelTwoTransactionId": 3,
        "levelOneId": 2,
        "levelOneName": "Design",
        "levelOneTransactionId": 2,
        "comments": null,
        "holdComments": null,
        "targetDate": 1620212121,
        "aging": 406,
        "hoursAssigned": 0,
        "floatingDays": 406,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "designProgressId": 1,
        "designProgress": "WIP",
        "designCreatorStatusId": 4,
        "designCreatorStatus": "NOT STARTED",
        "designCurrentStatusId": 4,
        "designCurrentStatus": "NOT STARTED",
        "designCreatedBySso": "503238554",
        "designCreatedByFirstname": "Arul  Prakash",
        "designCreatedByLastname": "Prakash",
        "geometryDesc": null,
        "mcodeDesc": null,
        "designChecklistMaster": [
          {
            "id": 13,
            "name": "ECO Number",
            "type": "textBox",
            "value": null
          },
          {
            "id": 14,
            "name": "ECM Number",
            "type": "textBox",
            "value": null
          }
        ],
        "levelFourRefId": null,
        "levelFourRefTransactionId": null,
        "levelFourRefNum": null,
        "levelThreeHold": false,
        "levelThreeHoldComments": null,
        "levelThreeComments": null,
        "readOnly": false,
        "maunualAdd": false,
        "designChildRefStatus": null,
        "designChildComments": null,
        "designChildHoldComments": null,
        "childEr": null,
        "childErNumber": null,
        "childGeometry": null,
        "childMcode": null,
        "childQcode": null,
        "currentErNumber": null,
        "designChildLevelFourId": null,
        "designChildLevelThreeId": null,
        "designChildLevelTwoId": null,
        "designChildPreConfigId": null,
        "supportSite": null,
        "supportUserSsoId": null,
        "supportUserFirstName": null,
        "hold": false
      },
      {
        "id": 0,
        "preConfigId": 2,
        "soli": "1229759-10000",
        "tagNumber": "4-30-33PV0701",
        "geometry": null,
        "mcode": null,
        "qcode": null,
        "levelFourId": 0,
        "levelFour": null,
        "levelFourTransactionId": 0,
        "levelThreeId": 10,
        "levelThreeName": "LODB Plate",
        "levelThreeTransactionId": 6,
        "levelTwoId": 4,
        "levelTwoName": "Valve Design",
        "levelTwoTransactionId": 3,
        "levelOneId": 2,
        "levelOneName": "Design",
        "levelOneTransactionId": 2,
        "comments": null,
        "holdComments": null,
        "targetDate": 1620212121,
        "aging": 406,
        "hoursAssigned": 0,
        "floatingDays": 406,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "designProgressId": 1,
        "designProgress": "WIP",
        "designCreatorStatusId": 4,
        "designCreatorStatus": "NOT STARTED",
        "designCurrentStatusId": 4,
        "designCurrentStatus": "NOT STARTED",
        "designCreatedBySso": "503238554",
        "designCreatedByFirstname": "Arul  Prakash",
        "designCreatedByLastname": "Prakash",
        "geometryDesc": null,
        "mcodeDesc": null,
        "designChecklistMaster": [
          {
            "id": 13,
            "name": "ECO Number",
            "type": "textBox",
            "value": null
          },
          {
            "id": 14,
            "name": "ECM Number",
            "type": "textBox",
            "value": null
          }
        ],
        "levelFourRefId": null,
        "levelFourRefTransactionId": null,
        "levelFourRefNum": null,
        "levelThreeHold": false,
        "levelThreeHoldComments": null,
        "levelThreeComments": null,
        "readOnly": false,
        "maunualAdd": false,
        "designChildRefStatus": null,
        "designChildComments": null,
        "designChildHoldComments": null,
        "childEr": null,
        "childErNumber": null,
        "childGeometry": null,
        "childMcode": null,
        "childQcode": null,
        "currentErNumber": null,
        "designChildLevelFourId": null,
        "designChildLevelThreeId": null,
        "designChildLevelTwoId": null,
        "designChildPreConfigId": null,
        "supportSite": null,
        "supportUserSsoId": null,
        "supportUserFirstName": null,
        "hold": false
      },
      {
        "id": 0,
        "preConfigId": 2,
        "soli": "1229759-10000",
        "tagNumber": "4-30-33PV0701",
        "geometry": null,
        "mcode": null,
        "qcode": null,
        "levelFourId": 0,
        "levelFour": null,
        "levelFourTransactionId": 0,
        "levelThreeId": 12,
        "levelThreeName": "Design Study",
        "levelThreeTransactionId": 7,
        "levelTwoId": 4,
        "levelTwoName": "Valve Design",
        "levelTwoTransactionId": 3,
        "levelOneId": 2,
        "levelOneName": "Design",
        "levelOneTransactionId": 2,
        "comments": null,
        "holdComments": null,
        "targetDate": 1620212121,
        "aging": 406,
        "hoursAssigned": 0,
        "floatingDays": 406,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "designProgressId": 1,
        "designProgress": "WIP",
        "designCreatorStatusId": 4,
        "designCreatorStatus": "NOT STARTED",
        "designCurrentStatusId": 4,
        "designCurrentStatus": "NOT STARTED",
        "designCreatedBySso": "503238554",
        "designCreatedByFirstname": "Arul  Prakash",
        "designCreatedByLastname": "Prakash",
        "geometryDesc": null,
        "mcodeDesc": null,
        "designChecklistMaster": [
          {
            "id": 13,
            "name": "ECO Number",
            "type": "textBox",
            "value": null
          },
          {
            "id": 14,
            "name": "ECM Number",
            "type": "textBox",
            "value": null
          }
        ],
        "levelFourRefId": null,
        "levelFourRefTransactionId": null,
        "levelFourRefNum": null,
        "levelThreeHold": false,
        "levelThreeHoldComments": null,
        "levelThreeComments": null,
        "readOnly": false,
        "maunualAdd": false,
        "designChildRefStatus": null,
        "designChildComments": null,
        "designChildHoldComments": null,
        "childEr": null,
        "childErNumber": null,
        "childGeometry": null,
        "childMcode": null,
        "childQcode": null,
        "currentErNumber": null,
        "designChildLevelFourId": null,
        "designChildLevelThreeId": null,
        "designChildLevelTwoId": null,
        "designChildPreConfigId": null,
        "supportSite": null,
        "supportUserSsoId": null,
        "supportUserFirstName": null,
        "hold": false
      },
      {
        "id": 0,
        "preConfigId": 2,
        "soli": "1229759-10000",
        "tagNumber": "4-30-33PV0701",
        "geometry": null,
        "mcode": null,
        "qcode": null,
        "levelFourId": 0,
        "levelFour": null,
        "levelFourTransactionId": 0,
        "levelThreeId": 33,
        "levelThreeName": "Study Procedures",
        "levelThreeTransactionId": 8,
        "levelTwoId": 4,
        "levelTwoName": "Valve Design",
        "levelTwoTransactionId": 3,
        "levelOneId": 2,
        "levelOneName": "Design",
        "levelOneTransactionId": 2,
        "comments": null,
        "holdComments": null,
        "targetDate": 1620212121,
        "aging": 406,
        "hoursAssigned": 0,
        "floatingDays": 406,
        "hourSpent": 0,
        "percentageCompleted": 0,
        "designProgressId": 1,
        "designProgress": "WIP",
        "designCreatorStatusId": 4,
        "designCreatorStatus": "NOT STARTED",
        "designCurrentStatusId": 4,
        "designCurrentStatus": "NOT STARTED",
        "designCreatedBySso": "503238554",
        "designCreatedByFirstname": "Arul  Prakash",
        "designCreatedByLastname": "Prakash",
        "geometryDesc": null,
        "mcodeDesc": null,
        "designChecklistMaster": [
          {
            "id": 13,
            "name": "ECO Number",
            "type": "textBox",
            "value": null
          },
          {
            "id": 14,
            "name": "ECM Number",
            "type": "textBox",
            "value": null
          }
        ],
        "levelFourRefId": null,
        "levelFourRefTransactionId": null,
        "levelFourRefNum": null,
        "levelThreeHold": false,
        "levelThreeHoldComments": null,
        "levelThreeComments": null,
        "readOnly": false,
        "maunualAdd": false,
        "designChildRefStatus": null,
        "designChildComments": null,
        "designChildHoldComments": null,
        "childEr": null,
        "childErNumber": null,
        "childGeometry": null,
        "childMcode": null,
        "childQcode": null,
        "currentErNumber": null,
        "designChildLevelFourId": null,
        "designChildLevelThreeId": null,
        "designChildLevelTwoId": null,
        "designChildPreConfigId": null,
        "supportSite": null,
        "supportUserSsoId": null,
        "supportUserFirstName": null,
        "hold": false
      }
    ],
    "supportTeamList": [
      {
        "id": 2,
        "siteName": "JAX",
        "siteCode": "1811"
      },
      {
        "id": 3,
        "siteName": "Conde",
        "siteCode": "6260"
      },
      {
        "id": 4,
        "siteName": "DJL -KARWIA",
        "siteCode": "7150"
      },
      {
        "id": 5,
        "siteName": "GRE -GLOBAL COE",
        "siteCode": "1111"
      }
    ],
    "completed": 1,
    "holdCount": 0,
    "wipCount": 5,
    "totalCount": 6,
    "supportTeamUserListCreator": [
      {
        "ssoId": "503238554",
        "firstName": "Arul ",
        "lastName": "Prakash",
        "siteName": "DVI",
        "siteCode": "5500",
        "siteId": 1
      },
      {
        "ssoId": "503073700",
        "firstName": "Rajadurai",
        "lastName": "-",
        "siteName": "DVI",
        "siteCode": "5500",
        "siteId": 1
      },
      {
        "ssoId": "503051477",
        "firstName": "Jeevanaadam",
        "lastName": "-",
        "siteName": "DVI",
        "siteCode": "5500",
        "siteId": 1
      },
      {
        "ssoId": "503230186",
        "firstName": "Muralitharan",
        "lastName": "P",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "503230155",
        "firstName": "Nagarajan",
        "lastName": "Azhagumalai",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "503261049",
        "firstName": "UjwalHassanArkakeerthi",
        "lastName": "Indra",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "212543650",
        "firstName": "Williams",
        "lastName": " Brian P",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "212476031",
        "firstName": "Rogers-Hehr",
        "lastName": " Timothy ",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "204062171",
        "firstName": "Betley",
        "lastName": " Justin W",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "503254477",
        "firstName": "VARUN",
        "lastName": "KENKERE",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "212552023",
        "firstName": "Zaremba",
        "lastName": " Alexi D",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "503111014",
        "firstName": "Naveenkumar",
        "lastName": "Ramalingam",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "204059934",
        "firstName": "Kay",
        "lastName": " Charles",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "212308224",
        "firstName": "Gosselin",
        "lastName": " Peter David",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "204061929",
        "firstName": "Wali",
        "lastName": " Vigneshwar",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "212547334",
        "firstName": "Obasa",
        "lastName": " Idowu EMMANUEL",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "503261020",
        "firstName": "Michael",
        "lastName": "Rosarioraj",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      },
      {
        "ssoId": "503247210",
        "firstName": "VIJAY",
        "lastName": "KULKARNI",
        "siteName": "JAX",
        "siteCode": "1811",
        "siteId": 2
      }
    ],
    "supportTeamUserListReviewer": null
  }
export const getcomplexityList = {

    "complexityList":
        [
            { name: 'L0', id: 'L0' },
            { name: 'L1', id: 'L1' },
            { name: 'L2', id: 'L2' },
            { name: 'L3', id: 'L3' },
        ],
    "npcData": [
        {
            id: null,
            drawingNumber: '12345',
            mcode: 'M-12345',
            qcode: 'Q-12345',
            soli: '115420-4000',
            npcReferenceMappingId: null,
            npcReferenceId: null,
            npcDetails: [{
                makeBuy: '',
                erNPC: '',
                dwgHeader: '1111',
                mcodeDesc: '111',
                qcodeDesc: '111',
                generalComments: '1111',
                holdFlag: false,
                holdComments: '111',
            }]
        },


    ],
    "bomDesign": {

        "workflowStatusList": [
            {
                "id": 1,
                "status": "SAVE"
            },
            {
                "id": 2,
                "status": "PROMOTE"
            },
            {
                "id": 3,
                "status": "DEMOTE"
            },
            {
                "id": 4,
                "status": "NOT STARTED"
            },
            {
                "id": 5,
                "status": "Ready for Review"
            },
            {
                "id": 6,
                "status": "Ready for Release"
            },
            {
                "id": 7,
                "status": "Released"
            }
        ],
        "progressStatusList": [
            {
                "id": 1,
                "status": "WIP"
            },
            {
                "id": 2,
                "status": "RISK REVIEW"
            },
            {
                "id": 3,
                "status": "ON TIME"
            },
            {
                "id": 4,
                "status": "ON TIME EARLY"
            },
            {
                "id": 5,
                "status": "LATE"
            },
            {
                "id": 6,
                "status": "OVD"
            },
            {
                "id": 7,
                "status": "CANCELLED"
            }
        ],
        "design": [
            {
                "id": 0,
                "preConfigId": 2,
                "soli": "115420-4000",
                "tagNumber": "1234-56",
                "geometry": null,
                "mcode": null,
                "qcode": null,
                "levelFourId": 0,
                "levelFour": null,
                "levelFourTransactionId": 0,
                "levelThreeId": 1,
                "levelThreeName": "Body/Bonnet",
                "levelThreeTransactionId": 1,
                "levelTwoId": 4,
                "levelTwoName": "Valve Design",
                "levelTwoTransactionId": 2,
                "levelOneId": 2,
                "levelOneName": "Design",
                "levelOneTransactionId": 2,
                "comments": null,
                "holdComments": null,
                "targetDate": null,
                "aging": 0,
                "hoursAssigned": 0,
                "floatingDays": 0,
                "hourSpent": 0,
                "percentageCompleted": 0,
                "designProgressId": 1,
                "designProgress": "WIP",
                "designCreatorStatusId": 4,
                "designCreatorStatus": "NOT STARTED",
                "designCreatedBySso": null,
                "designCreatedByFirstname": null,
                "designCreatedByLastname": null,
                "designChecklistCreatorTransaction": null,
                "designChecklistMaster": [
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECONumber",
                        "checked": false
                    },
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECMNumber",
                        "checked": false
                    }
                ],
                "hold": false
            }],
        "designCreatorDtoList": [
            {
                "id": 0,
                "preConfigId": 2,
                "soli": "115420-4000",
                "tagNumber": "1234-56",
                "geometry": null,
                "mcode": null,
                "qcode": null,
                "levelFourId": 0,
                "levelFour": null,
                "levelFourTransactionId": 0,
                "levelThreeId": 1,
                "levelThreeName": "Body/Bonnet",
                "levelThreeTransactionId": 1,
                "levelTwoId": 4,
                "levelTwoName": "Valve Design",
                "levelTwoTransactionId": 2,
                "levelOneId": 2,
                "levelOneName": "Design",
                "levelOneTransactionId": 2,
                "comments": null,
                "holdComments": null,
                "targetDate": null,
                "aging": 0,
                "hoursAssigned": 0,
                "floatingDays": 0,
                "hourSpent": 0,
                "percentageCompleted": 0,
                "designProgressId": 1,
                "designProgress": "WIP",
                "designCreatorStatusId": 4,
                "designCreatorStatus": "NOT STARTED",
                "designCreatedBySso": null,
                "designCreatedByFirstname": null,
                "designCreatedByLastname": null,
                "designChecklistCreatorTransaction": null,
                "designChecklistMaster": [
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECONumber",
                        "checked": false
                    },
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECMNumber",
                        "checked": false
                    }
                ],
                "hold": false
            },
            {
                "id": 0,
                "preConfigId": 2,
                "soli": "115420-4000",
                "tagNumber": "1234-56",
                "geometry": null,
                "mcode": null,
                "qcode": null,
                "levelFourId": 0,
                "levelFour": null,
                "levelFourTransactionId": 0,
                "levelThreeId": 2,
                "levelThreeName": "Trim Parts",
                "levelThreeTransactionId": 2,
                "levelTwoId": 4,
                "levelTwoName": "Valve Design",
                "levelTwoTransactionId": 2,
                "levelOneId": 2,
                "levelOneName": "Design",
                "levelOneTransactionId": 2,
                "comments": null,
                "holdComments": null,
                "targetDate": null,
                "aging": 0,
                "hoursAssigned": 0,
                "floatingDays": 0,
                "hourSpent": 0,
                "percentageCompleted": 0,
                "designProgressId": 1,
                "designProgress": "WIP",
                "designCreatorStatusId": 4,
                "designCreatorStatus": "NOT STARTED",
                "designCreatedBySso": null,
                "designCreatedByFirstname": null,
                "designCreatedByLastname": null,
                "designChecklistCreatorTransaction": null,
                "designChecklistMaster": [
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECONumber",
                        "checked": false
                    },
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECMNumber",
                        "checked": false
                    }
                ],
                "hold": false
            },
            {
                "id": 0,
                "preConfigId": 2,
                "soli": "115420-4000",
                "tagNumber": "1234-56",
                "geometry": null,
                "mcode": null,
                "qcode": null,
                "levelFourId": 0,
                "levelFour": null,
                "levelFourTransactionId": 0,
                "levelThreeId": 3,
                "levelThreeName": "Parts Excluding Trim",
                "levelThreeTransactionId": 3,
                "levelTwoId": 4,
                "levelTwoName": "Valve Design",
                "levelTwoTransactionId": 2,
                "levelOneId": 2,
                "levelOneName": "Design",
                "levelOneTransactionId": 2,
                "comments": null,
                "holdComments": null,
                "targetDate": null,
                "aging": 0,
                "hoursAssigned": 0,
                "floatingDays": 0,
                "hourSpent": 0,
                "percentageCompleted": 0,
                "designProgressId": 1,
                "designProgress": "WIP",
                "designCreatorStatusId": 4,
                "designCreatorStatus": "NOT STARTED",
                "designCreatedBySso": null,
                "designCreatedByFirstname": null,
                "designCreatedByLastname": null,
                "designChecklistCreatorTransaction": null,
                "designChecklistMaster": [
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECONumber",
                        "checked": false
                    },
                    {
                        "workflowPhase": "DESIGN",
                        "checklistFor": "CREATOR",
                        "checklist": "ECMNumber",
                        "checked": false
                    }
                ],
                "hold": false
            }
        ]
    }


}​​
export const getBomCreatorClone ={
    "workflowStatusList": [
        {
            "id": 1,
            "status": "SAVE"
        },
        {
            "id": 2,
            "status": "PROMOTE"
        },
        {
            "id": 3,
            "status": "DEMOTE"
        },
        {
            "id": 4,
            "status": "NOT STARTED"
        },
        {
            "id": 5,
            "status": "Ready for Review"
        },
        {
            "id": 6,
            "status": "Ready for Release"
        },
        {
            "id": 7,
            "status": "Released"
        },
        {
            "id": 8,
            "status": "WIP"
        }
    ],
    "progressStatusList": [
        {
            "id": 1,
            "status": "WIP"
        },
        {
            "id": 2,
            "status": "RISK REVIEW"
        },
        {
            "id": 3,
            "status": "ON TIME"
        },
        {
            "id": 4,
            "status": "ON TIME EARLY"
        },
        {
            "id": 5,
            "status": "LATE"
        },
        {
            "id": 6,
            "status": "OVD"
        },
        {
            "id": 7,
            "status": "CANCELLED"
        }
    ],
    "bomCreatorDtoList": [
        {
            "id": 6,
            "preConfigId": 40,
            "soli": "1199404-44000",
            "tagNumber": "X053RJCI",
            "levelTwoId": 182,
            "levelTwo": "Valve",
            "comments": "2313123",
            "holdComments": "123123123123",
            "targetDate": 1616372775,
            "aging": 18,
            "hoursAssigned": 0,
            "floatingDays": 18,
            "hourSpent": 0,
            "percentageCompleted": 100,
            "bomProgressId": 6,
            "bomProgress": "OVD",
            "bomCreatorStatusId": 2,
            "bomCreatorStatus": "SAVE",
            "bomCreatedBySso": "503196033",
            "bomCreatedByFirstname": "Bharath Pitla",
            "bomCreatedByLastname": "Pitla",
            "bomCurrentStatus": "Ready for Release",
            "bomCurrentStatusId": 6,
            "bomChecklistCreatorTransaction": [],
            "bomChecklistMaster": [
                {
                    "workflowPhase": "BOM",
                    "checklistFor": "CREATOR",
                    "checklist": "ECMNumber",
                    "comments": null,
                    "checked": false
                }
            ],
            "readOnly": false,
            "hold": false
        },
        {
            "id": 7,
            "preConfigId": 41,
            "soli": "1199404-44000",
            "tagNumber": "12345",
            "levelTwoId": 183,
            "levelTwo": "Valve",
            "comments": "2313123",
            "holdComments": "123123123123",
            "targetDate": 1616372775,
            "aging": 15,
            "hoursAssigned": 0,
            "floatingDays": 15,
            "hourSpent": 0,
            "percentageCompleted": 100,
            "bomProgressId": 6,
            "bomProgress": "OVD",
            "bomCreatorStatusId": 2,
            "bomCreatorStatus": "SAVE",
            "bomCreatedBySso": "503196033",
            "bomCreatedByFirstname": "Bharath Pitla",
            "bomCreatedByLastname": "Pitla",
            "bomCurrentStatus": "Ready for Release",
            "bomCurrentStatusId": 6,
            "bomChecklistCreatorTransaction": [],
            "bomChecklistMaster": [
                {
                    "workflowPhase": "BOM",
                    "checklistFor": "CREATOR",
                    "checklist": "ECMNumber",
                    "comments": null,
                    "checked": false
                }
            ],
            "readOnly": true,
            "hold": false
        }
    ]
}
export const getBomReviewerClone =[
    {
        "id": 1,
        "preConfigId": 40,
        "bomConfigCreatorId": 6,
        "levelTwoId": 182,
        "levelTwo": "Valve",
        "comments": null,
        "holdComments": null,
        "floatingDays": 0,
        "percentageCompleted": 100,
        "bomReviewerStatus": "SAVE",
        "bomReviewerStatusId": 2,
        "reviewedBySso": "503195167",
        "reviewedByFirstname": "Karthik Ravi",
        "reviewedByLastname": "Ravi",
        "bomCurrentStatusId": 6,
        "bomCurrentStatus": "Ready for Release",
        "bomProgressId": 0,
        "bomProgress": null,
        "bomChecklistReviewerTransaction": [],
        "bomChecklistMaster": [
            {
                "workflowPhase": "BOM",
                "checklistFor": "REVIEWER",
                "checklist": "ECMReleased",
                "checked": false
            },
            {
                "workflowPhase": "BOM",
                "checklistFor": "REVIEWER",
                "checklist": "ValvePortionChecked",
                "checked": false
            },
            {
                "workflowPhase": "BOM",
                "checklistFor": "REVIEWER",
                "checklist": "InstrumentportionChecked",
                "checked": false
            }
        ],
        "readOnly": false,
        "hold": false
    },
    {
        "id": 2,
        "preConfigId": 41,
        "bomConfigCreatorId": 6,
        "levelTwoId": 183,
        "levelTwo": "Valve",
        "comments": null,
        "holdComments": null,
        "floatingDays": 15,
        "percentageCompleted": 100,
        "bomReviewerStatus": "SAVE",
        "bomReviewerStatusId": 2,
        "reviewedBySso": "503195167",
        "reviewedByFirstname": "Karthik Ravi",
        "reviewedByLastname": "Ravi",
        "bomCurrentStatusId": 6,
        "bomCurrentStatus": "Ready for Release",
        "bomProgressId": 0,
        "bomProgress": null,
        "bomChecklistReviewerTransaction": [],
        "bomChecklistMaster": [
            {
                "workflowPhase": "BOM",
                "checklistFor": "REVIEWER",
                "checklist": "ECMReleased",
                "checked": false
            },
            {
                "workflowPhase": "BOM",
                "checklistFor": "REVIEWER",
                "checklist": "ValvePortionChecked",
                "checked": false
            },
            {
                "workflowPhase": "BOM",
                "checklistFor": "REVIEWER",
                "checklist": "InstrumentportionChecked",
                "checked": false
            }
        ],
        "readOnly": true,
        "hold": false
    }
]