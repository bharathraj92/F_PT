
// export const getRolesData = {
//     "site": [
//         {
//             "siteId": 1,
//             "siteName": "JAX"
//         }
//         // {
//         //     "siteId": 2,
//         //     "siteName": "Conde"
//         // }
//     ],
//     "enggSite": [
//         {
//             "enggSiteId": 1,
//             "enggSiteName": "JAX"
//         },
//         {
//             "enggSiteId": 2,
//             "enggSiteName": "Conde"
//         }, {
//             "enggSiteId": 3,
//             "enggSiteName": "DVI"
//         },
//         {
//             "enggSiteId": 4,
//             "enggSiteName": "DJL-Karwai"
//         },
//         {
//             "enggSiteId": 5,
//             "enggSiteName": "GRE-Global COE"
//         }
//     ],
//     "endUserType": [
//         {
//             "endUserTypeId": 1,
//             "endUserTypeName": "Commerical",
//             "siteId": 1,
//             "siteName": "JAX"
//         },
//         {
//             "endUserTypeId": 2,
//             "endUserTypeName": "Military",
//             "siteId": 1,
//             "siteName": "JAX"
//         },
//         {
//             "endUserTypeId": 3,
//             "endUserTypeName": "Nuclear",
//             "siteId": 2,
//             "siteName": "Conde"
//         }
//     ],
//     "productBrand": [
//         {
//             "productBrandId": 1,
//             "productBrandName": "Measoneilan",
//             "siteId": 1,
//             "siteName": "Conde",
//             "department": [
//                 {
//                     "departmentId": 1,
//                     "departmentName": "Engineering",
//                     "role": [
//                         {
//                             "roleId": 1,
//                             "roleName": "Reviewer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 1,
//                                     "productKnowledgeName": "P01"
//                                 },
//                                 {
//                                     "productKnowledgeId": 2,
//                                     "productKnowledgeName": "P02"
//                                 }
//                             ]
//                         },
//                         {
//                             "roleId": 2,
//                             "roleName": "Configurer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 3,
//                                     "productKnowledgeName": "P03"
//                                 },
//                                 {
//                                     "productKnowledgeId": 4,
//                                     "productKnowledgeName": "P04"
//                                 }
//                             ]
//                         }
//                     ]
//                 },
//                 {
//                     "departmentId": 2,
//                     "departmentName": "Quality",
//                     "role": [
//                         {
//                             "roleId": 1,
//                             "roleName": "Reviewer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 3,
//                                     "productKnowledgeName": "P03"
//                                 },
//                                 {
//                                     "productKnowledgeId": 4,
//                                     "productKnowledgeName": "P04"
//                                 }
//                             ]
//                         },
//                         {
//                             "roleId": 2,
//                             "roleName": "Configurer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 3,
//                                     "productKnowledgeName": "P03"
//                                 },
//                                 {
//                                     "productKnowledgeId": 4,
//                                     "productKnowledgeName": "P04"
//                                 }
//                             ]
//                         }
//                     ]
//                 }
//             ],
//             "productDetails": [
//                 {
//                     "producTypeId": 1,
//                     "producTypeName": "MN ACTUATORS",
//                     "productModelId": 1,
//                     "productModelName": "MODEL 87/88 MULTISPRING",
//                     "productSubCategoryId": 1,
//                     "productSubCategoryName": "Parts and Others",
//                     "roleId": 1,
//                     "roleName": "Reviewer",
//                     "productVariant": [
//                         {
//                             "productVariantId": 1,
//                             "productVariantName": "Valve",
//                             "roleId": 1
//                         },
//                         {
//                             "productVariantId": 2,
//                             "productVariantName": "Level",
//                             "roleId": 1
//                         }
//                     ]

//                 },
//                 {
//                     "producTypeId": 2,
//                     "producTypeName": "MN ACTUATORS 111",
//                     "productModelId": 2,
//                     "productModelName": "MODEL 870000/88 MULTISPRING",
//                     "productSubCategoryId": 2,
//                     "productSubCategoryName": "Parts Multiple and Others",
//                     "roleId": 2,
//                     "roleName": "Configurer",
//                     "productVariantId": 2,
//                     "productVariantName": "Level"
//                 }
//             ]
//         },
//         {
//             "productBrandId": 1,
//             "productBrandName": "Measoneilan",
//             "siteId": 2,
//             "siteName": "JAX",
//             "department": [
//                 {
//                     "departmentId": 1,
//                     "departmentName": "Approver",
//                     "role": [
//                         {
//                             "roleId": 1,
//                             "roleName": "Reviewer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 1,
//                                     "productKnowledgeName": "P01"
//                                 },
//                                 {
//                                     "productKnowledgeId": 2,
//                                     "productKnowledgeName": "P02"
//                                 }
//                             ]
//                         },
//                         {
//                             "roleId": 2,
//                             "roleName": "Configurer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 3,
//                                     "productKnowledgeName": "P03"
//                                 },
//                                 {
//                                     "productKnowledgeId": 4,
//                                     "productKnowledgeName": "P04"
//                                 }
//                             ]
//                         }
//                     ]
//                 },
//                 {
//                     "departmentId": 2,
//                     "departmentName": "Creator",
//                     "role": [
//                         {
//                             "roleId": 1,
//                             "roleName": "Reviewer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 3,
//                                     "productKnowledgeName": "P03"
//                                 },
//                                 {
//                                     "productKnowledgeId": 4,
//                                     "productKnowledgeName": "P04"
//                                 }
//                             ]
//                         },
//                         {
//                             "roleId": 2,
//                             "roleName": "Configurer",
//                             "productKnowledge": [
//                                 {
//                                     "productKnowledgeId": 3,
//                                     "productKnowledgeName": "P03"
//                                 },
//                                 {
//                                     "productKnowledgeId": 4,
//                                     "productKnowledgeName": "P04"
//                                 }
//                             ]
//                         }
//                     ]
//                 }
//             ],
//             "productDetails": [
//                 {
//                     "producTypeId": 1,
//                     "producTypeName": "MN ACTUATORS 123",
//                     "productModelId": 1,
//                     "productModelName": "MODEL 87/88 MULTISPRING 1",
//                     "productSubCategoryId": 1,
//                     "productSubCategoryName": "Parts and Others 1",
//                     "roleId": 1,
//                     "roleName": "Reviewer",
//                     "productVariantId": 1,
//                     "productVariantName": "Valve"
//                 },
//                 {
//                     "producTypeId": 2,
//                     "producTypeName": "MN ACTUATORS 456",
//                     "productModelId": 2,
//                     "productModelName": "MODEL 870000/88 MULTISPRING 2",
//                     "productSubCategoryId": 2,
//                     "productSubCategoryName": "Parts Multiple and Others 2",
//                     "roleId": 2,
//                     "roleName": "Configurer",
//                     "productVariantId": 2,
//                     "productVariantName": "Instrument"
//                 }
//             ]
//         }
//     ]
// }

export const getRolesData = {
    "site": [
        {
            "siteId": 1,
            "siteName": "JAX"
        }
    ],
    "enggSite": [
        {
            "enggSiteId": 1,
            "enggSiteName": "JAX"
        },
        {
            "enggSiteId": 2,
            "enggSiteName": "Conde"
        },
        {
            "enggSiteId": 3,
            "enggSiteName": "GRE -GLOBAL COE"
        },
        {
            "enggSiteId": 4,
            "enggSiteName": "DVI"
        },
        {
            "enggSiteId": 5,
            "enggSiteName": "DJL -KARWIA"
        }
    ],
    "endUserType": [
        {
            "endUserTypeId": 1,
            "endUserTypeName": "Commercial",
            "siteId": 1
        },
        {
            "endUserTypeId": 4,
            "endUserTypeName": "Commercial",
            "siteId": 4
        },
        {
            "endUserTypeId": 7,
            "endUserTypeName": "Military",
            "siteId": 2
        },
        {
            "endUserTypeId": 11,
            "endUserTypeName": "Commercial",
            "siteId": 3
        },
        {
            "endUserTypeId": 10,
            "endUserTypeName": "Military",
            "siteId": 5
        },
        {
            "endUserTypeId": 6,
            "endUserTypeName": "Nuclear",
            "siteId": 2
        },
        {
            "endUserTypeId": 5,
            "endUserTypeName": "Commercial",
            "siteId": 2
        },
        {
            "endUserTypeId": 8,
            "endUserTypeName": "Commercial",
            "siteId": 5
        },
        {
            "endUserTypeId": 3,
            "endUserTypeName": "Military",
            "siteId": 1
        },
        {
            "endUserTypeId": 2,
            "endUserTypeName": "Nuclear",
            "siteId": 1
        },
        {
            "endUserTypeId": 9,
            "endUserTypeName": "Nuclear",
            "siteId": 5
        }
    ],
    "productBrand": [
        {
            "productBrandId": 1,
            "productBrandName": "Masoneilan",
            "siteId": 1,
            "siteName": "JAX",
            "department": [
                {
                    "departmentId": 1,
                    "departmentName": "Other",
                    "role": [
                        {
                            "roleId": 1,
                            "roleName": "Admin",

                        },
                        {
                            "roleId": 3,
                            "roleName": "Configurer",

                        }
                    ]
                },
                {
                    "departmentId": 2,
                    "departmentName": "Oil And Gas",
                    "role": [
                        {
                            "roleId": 2,
                            "roleName": "Planning",

                        },
                        {
                            "roleId": 3,
                            "roleName": "Finance",

                        }
                    ]
                }
            ]
        },
        {
            "productBrandId": 1,
            "productBrandName": "Masoneilan",
            "siteId": 2,
            "siteName": "Conde",
            "department": [
                {
                    "departmentId": 1,
                    "departmentName": "Other",
                    "role": [
                        {
                            "roleId": 2,
                            "roleName": "Reviewer",

                        },
                        {
                            "roleId": 4,
                            "roleName": "Config. Engineer",

                        }
                    ]
                },
                {
                    "departmentId": 2,
                    "departmentName": "Oil And Gas",
                    "role": [
                        {
                            "roleId": 5,
                            "roleName": "Engineer",

                        },
                        {
                            "roleId": 6,
                            "roleName": "Design Engineer",

                        }
                    ]
                }
            ]
        }
    ]
}

export const getProductDetailsData = {
    "productDetails": [
        {
            // "roleId": 2,
            // "roleName": "Design Engineer",
            // "producType": [
            // {
            "producTypeId": 1,
            "producTypeName": "MN ACTUATORS",
            "productModel": [
                {
                    "productModelId": 1,
                    "productModelName": "OTHER_ACTUATOR",
                    "productSubCategory": [
                        {
                            "productSubCategoryId": 1,
                            "productSubCategoryName": "PARTS AND OTHERS"
                        },
                        {
                            "productSubCategoryId": 2,
                            "productSubCategoryName": "COMPLETE ASSEMBLY"
                        }
                    ]
                }
            ]
            // }

            // ]
        }
    ]
}


export const getProductVariantKnownledgeData = {
    "productVariant": [
        {
            "productVariantId": 1,
            "productVariantName": "Valve",
            // "roleId": 2
        },
        {
            "productVariantId": 2,
            "productVariantName": "Level",
            // "roleId": 2
        },
        {
            "productVariantId": 3,
            "productVariantName": "Instrument",
            // "roleId": 2
        }
    ],
    "productKnowledge": [
        {
            "productKnowledgeId": 2,
            "productKnowledgeName": "P2",
            // "roleId": 2
        },
        {
            "productKnowledgeId": 1,
            "productKnowledgeName": "P1",
            // "roleId": 2
        },
        {
            "productKnowledgeId": 3,
            "productKnowledgeName": "P3",
            // "roleId": 2
        }
    ]
}

