export const commonOptionData = {
  "projectClassification": [
    {
      "id": 1,
      "projectClassification": "L1-Lower Risk"
    },
    {
      "id": 2,
      "projectClassification": "L2-Medium Risk"
    },
    {
      "id": 3,
      "projectClassification": "L3-High Risk"
    }
  ],
  "etoClassification": [
    {
      "id": 1,
      "etoClassification": "Pressure Containing ETO"
    },
    {
      "id": 2,
      "etoClassification": "Pressure Retaining ETO"
    },
    {
      "id": 3,
      "etoClassification": "Actuator ETO"
    },
    {
      "id": 4,
      "etoClassification": "Actuator S/A ETO"
    },
    {
      "id": 5,
      "etoClassification": "Accessories ETO"
    }
  ],
  "soLineClassification": [
    {
      "id": 1,
      "soLiClassification": "L0"
    },
    {
      "id": 2,
      "soLiClassification": "L1"
    },
    {
      "id": 3,
      "soLiClassification": "L2"
    },
    {
      "id": 4,
      "soLiClassification": "L3"
    }
  ],
  "valveType": [
    {
      "id": 1,
      "valveType": "Unit/Valve"
    },
    {
      "id": 2,
      "valveType": "Spare"
    }
  ],
  "supportTeam": [
    {
      "id": 1,
      "supportTeam": "Jax"
    },
    {
      "id": 2,
      "supportTeam": "Conde"
    },
    {
      "id": 3,
      "supportTeam": "DVI"
    },
    {
      "id": 4,
      "supportTeam": "Global CoE"
    },
    {
      "id": 5,
      "supportTeam": "Multiple Plants"
    }
  ],
  "endUserType": [
    {
      "endUserTypeId": 11,
      "endUserTypeName": "Commercial",
      "siteId": null
    },
    {
      "endUserTypeId": 10,
      "endUserTypeName": "Military",
      "siteId": null
    },
    {
      "endUserTypeId": 9,
      "endUserTypeName": "Nuclear",
      "siteId": null
    }
  ],
  "configurationType": [
    {
      "id": 1,
      "configurationType": "Varient Configuration"
    },
    {
      "id": 2,
      "configurationType": "Non-VC"
    }
  ],
  "bomType": [
    {
      "id": 1,
      "bomType": "Configure To Order (CTO)"
    },
    {
      "id": 2,
      "bomType": "Engineer To Order (ETO)"
    },
    {
      "id": 3,
      "bomType": "Partial Configure To Order (P-CTO)"
    }
  ]
}