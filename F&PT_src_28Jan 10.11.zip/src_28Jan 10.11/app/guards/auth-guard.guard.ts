import { Injectable } from '@angular/core';
import {
  CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot,
  Router
} from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService } from '../Services/common.service';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  role: any;


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    if (state.url === '/requestAccess' || (state.url === '/feedback')) {
      return false;
    }
    const admin = _.find(this.role, ['roleName', 'Admin']);
    if (admin !== undefined) {
      return true;
    }
    this.router.navigate(['/startInspection']);
    return false;
  }

  constructor(private commonservice: CommonService, private router: Router) {
    this.commonservice.userDetails.subscribe(
      (val) => {
        if (typeof (val) === 'object' && Object.keys(val).length > 0) {
          this.role = val['roles'];
        }
      },
      (err) => {
        console.error('userDetails subscribe -> ' + err);
      });
  }
}
