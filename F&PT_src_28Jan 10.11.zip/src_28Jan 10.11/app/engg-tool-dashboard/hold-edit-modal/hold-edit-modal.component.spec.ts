import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoldEditModalComponent } from './hold-edit-modal.component';

describe('HoldEditModalComponent', () => {
  let component: HoldEditModalComponent;
  let fixture: ComponentFixture<HoldEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoldEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoldEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
