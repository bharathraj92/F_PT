
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { holdData } from '../hold-dashboard/hold-dashboard.component';
import { DatePipe } from '@angular/common';
import { MessageHistoryModalComponent } from '../../engg-tool/message-history-modal/message-history-modal.component';

@Component({
  selector: 'app-hold-edit-modal',
  templateUrl: './hold-edit-modal.component.html',
  styleUrls: ['./hold-edit-modal.component.scss']
})
export class HoldEditModalComponent implements OnInit {
  element: any = {};
  edit: boolean
  messageHistoryModal: MatDialogRef<MessageHistoryModalComponent>;
  constructor(
    public holdDialogRef: MatDialogRef<HoldEditModalComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    @Inject(MAT_DIALOG_DATA) public data: holdData,
    public dialog: MatDialog
  ) {
  }

  ngOnInit(): void {
    this.edit = this.data['edit'];
    this.element = this.data['holdData'];
    if (this.element['creatorid'] && !this.element['reveiwerid']) {
      this.element['holdComments'] = this.element['holdFlag']==true?this.element['creatorHoldComments']: this.element['creatorUnholdComments'];
      this.element['generalComments'] = this.element['creatorGeneralComments'];
    } else if (!this.element['creatorid'] && this.element['reveiwerid']) {
      this.element['holdComments'] = this.element['holdFlag']==true?this.element['reviewerHoldComments']: this.element['reviewerUnholdComments'];
      this.element['generalComments'] = this.element['reviewerGeneralComments'];
    }else{
      this.element['holdComments'] =''; 
      this.element['generalComments'] = '';
    }
  }


  save(item: any) {
    this.apiMappingsService.saveHoldData(item).subscribe((data: []) => {
      if (data) {
        this.holdDialogRef.close();
        this.bhAlertService.showAlert('success', 'top', 5000, 'Comments Saved Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Comments!');
      }
    });
  }

  showMessageHistoryModal(task: any, user: any, item: any, field: any) {
    if (item['creatorid'] && !item['reveiwerid']) {
      user='creator';
      item.id=item['creatorid'];
    } else if (!item['creatorid'] && item['reveiwerid']) {
      user='reviewer';
      item.id=item['reveiwerid'];
    }
    if (field !== null) {
      this.messageHistoryModal = this.dialog.open(MessageHistoryModalComponent, { data: { task: task, user: user, item: item, fieldName: field } });
      this.messageHistoryModal.afterClosed().subscribe(value => {
        if (value) {
        }
      });
    } else {
      //this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select field.!');
    }
  }


}


