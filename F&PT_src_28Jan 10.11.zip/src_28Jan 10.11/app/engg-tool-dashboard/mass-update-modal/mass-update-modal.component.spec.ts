import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MassUpdateModalComponent } from './mass-update-modal.component';

describe('MassUpdateModalComponent', () => {
  let component: MassUpdateModalComponent;
  let fixture: ComponentFixture<MassUpdateModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MassUpdateModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassUpdateModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
