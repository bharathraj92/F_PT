import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { massUpdateData, ERDashboardInterface } from '../er-dashboard/er-dashboard.component';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-mass-update-modal',
  templateUrl: './mass-update-modal.component.html',
  styleUrls: ['./mass-update-modal.component.scss']
})
export class MassUpdateModalComponent implements OnInit {
  datasource = new MatTableDataSource<any[]>();
  displayedColumns: string[] = ['soli', 'creator', 'reviewer', 'release'];
  manualSchedulingList = [];
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  creatorList: any[] = [];
  reviewerList: any[] = [];
  releasedByList: any[] = [];
  reviewer: any;
  creator: any;
  releasedBy: any;
  // massUpdateFlag: boolean =false;
  // disableFlag: boolean =false;
  // comments: any;


  constructor(public MassUpdateModalDialogRef: MatDialogRef<MassUpdateModalComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    @Inject(MAT_DIALOG_DATA) public data: massUpdateData) { }

  ngOnInit(): void {
    this.datasource.data = this.data['massUpdateData'];
    this.datasource.paginator = this.paginator;
    this.datasource.sort = this.sort;
    this.getUserList(this.datasource.data[0]['plant']);
    // this.disable();
  }

  getUserList(plant: any) {
    this.apiMappingsService.getUserList(plant).subscribe((data: []) => {
      if (data) {
        this.creatorList = data['creator'];
        this.reviewerList = data['reviewer'];
        this.releasedByList = data['releasedBy'];
      }
    });
  }

  // disable() {
  //   let roles = JSON.parse(localStorage.getItem("roles"));
  //   let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Tool Administrator')
  //   if(roles && roles.length>0){
  //   if ((role && role.length > 0)) {
  //     this.disableFlag = false;
  //   } else {
  //     this.disableFlag = true;
  //   }
  // }else{
  //   return true;
  // }
  // }

  massUpdate() {
    let obj: any;
    let array: any[] = [];
    this.datasource.data.forEach((row: any) => {
      array.push({ 'soli': row.soli, "preConfigId": row.preConfigId })
    });
    if (this.creator) {
      obj = {
        "creator": this.creator['ssoId'],
        "selectedMasterData": array
      }
    } else if (this.reviewer) {
      obj = {
        "reviewer": this.reviewer['ssoId'],
        "selectedMasterData": array
      }
    } else if (this.releasedBy) {
      obj = {
        "release": this.releasedBy['ssoId'],
        "selectedMasterData": array
      }
    }

    this.apiMappingsService.saveAssigneeList(obj).subscribe((data: []) => {
      if (data) {
        // this.creator=" ";
        // this.reviewer=" ";
        // this.releasedBy=" ";
        if (this.creator) {
          this.datasource.data.forEach((row: any) => {
            row['creator'] = data['selectedMasterData'][0]['creator'];
            this.creator = null;
            console.log(this.creator);
          });
        } else if (this.reviewer) {
          this.datasource.data.forEach((row: any) => {
            row['reviewer'] = data['selectedMasterData'][0]['reviewer'];
            this.reviewer = null;
          });
        } else if (this.releasedBy) {
          this.datasource.data.forEach((row: any) => {
            row['release'] = data['selectedMasterData'][0]['release'];
            this.releasedBy = null;
          });
        }
        this.bhAlertService.showAlert('success', 'top', 5000, 'Assignee List updated Successfully!'
        );
      } else {

        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to update Assignee List!');
      }
    });
    // this.MassUpdateModalDialogRef.close();
  }

  cancel() {
    this.MassUpdateModalDialogRef.close();
  }



}
