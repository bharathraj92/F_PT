import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnggToolDashboardComponent } from './engg-tool-dashboard.component';

describe('EnggToolDashboardComponent', () => {
  let component: EnggToolDashboardComponent;
  let fixture: ComponentFixture<EnggToolDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnggToolDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnggToolDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
