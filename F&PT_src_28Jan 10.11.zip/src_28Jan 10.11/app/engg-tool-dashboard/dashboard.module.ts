import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

export * from './my-dashboard/my-dashboard.component';
export * from './er-dashboard/er-dashboard.component';
export * from './child-er-dashboard/child-er-dashboard.component';
export * from './npc-dashboard/npc-dashboard.component';
export * from './hold-dashboard/hold-dashboard.component';

import { ThemeLibModule, NavService } from 'bh-theme';
import { BhAlertService } from 'bh-theme';
import { MatSortModule } from '@angular/material/sort';
import { BrowserModule } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';
import { from } from 'rxjs';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { ChildERDashboardComponent } from './child-er-dashboard/child-er-dashboard.component';
import { NpcDashboardComponent } from './npc-dashboard/npc-dashboard.component';
import { HoldDashboardComponent } from './hold-dashboard/hold-dashboard.component';
import { ErDashboardComponent } from './er-dashboard/er-dashboard.component';
import { TranslateLoader, TranslateModule, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';



@NgModule({
  declarations: [
    MyDashboardComponent,
    ErDashboardComponent,
    ChildERDashboardComponent,
    NpcDashboardComponent,
    HoldDashboardComponent
  ],
  imports: [
    CommonModule,
    ThemeLibModule,
    FormsModule,
    BrowserModule,
    MatTableModule,
    MatSortModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ],
  exports: [
    MyDashboardComponent,
    ChildERDashboardComponent,
    NpcDashboardComponent,
    HoldDashboardComponent,
  ],
  providers: [NavService, BhAlertService]
})
export class DashboardModule { }

// AOT compilation support
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, "assets/i18n/", ".json");
}
