import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNPcModalComponent } from './add-npc-modal.component';

describe('AddNPcModalComponent', () => {
  let component: AddNPcModalComponent;
  let fixture: ComponentFixture<AddNPcModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNPcModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNPcModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
