
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { data } from '../npc-dashboard/npc-dashboard.component';
import * as Mock from 'src/app/mock/npc.mock';
import { DatePipe } from '@angular/common';
import { NPCSearchModalComponent } from '../../engg-tool/npc-search-modal/npc-search-modal.component';
import { EnggToolComponent } from 'src/app/engg-tool/engg-tool.component';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-add-npc-modal',
  templateUrl: './add-npc-modal.component.html',
  styleUrls: ['./add-npc-modal.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ]
})
export class AddNPcModalComponent implements OnInit {
  // columnsToDisplay: string[] = ['Department', 'SAPStatus', 'EnggCoordinator', 'RequestedDate', 'CompletionDate'];
  columnsToDisplay: string[] = ['department', 'sapMaterialStatus', 'sapDistributionMaterialStatus','plantSpecificMaterialStatus','procurementType', 'requestedDate', 'completedDate'];
  partStatusDataSource = new MatTableDataSource<PartStatusInterface>();
  filteredOptions: any;
  npcSearchModal: MatDialogRef<NPCSearchModalComponent>;
  datePipe = new DatePipe("en-US");
  npcComponentList: any;
  npcCategoryList: any;
  plantMasterList: any;
  subNpcListData: any = Mock.svcGetSubNPCData.subNpcResponseDto;
  element: any = {};
  npcFormDisable: boolean;
  edit: boolean
  npcFormValid: boolean;
  partStatusData: any;
  sapErrorMessage: any;



  constructor(
    public ChildErForceClosureDialogRef: MatDialogRef<AddNPcModalComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    public commonService: CommonService, private bhAlertService: BhAlertService,
    private enggToolComponent: EnggToolComponent,
    @Inject(MAT_DIALOG_DATA) public data: data,
    public dialog: MatDialog
  ) {
  }

  ngOnInit(): void {
    this.getPreConfigMasterData();
    this.edit = this.data['edit'];
    this.npcFormDisable = this.data['disabled'];

  }
  getPreConfigMasterData() {
    this.apiMappingsService.getPreConfigMasterData().subscribe((data: []) => {
      if (data) {
        this.npcCategoryList = data['npcSubCategory'];
        this.npcComponentList = data['npcSubComponent'];
        this.plantMasterList = data['plantMaster'];
        this.filteredOptions = this.npcComponentList;
        this.getsubNpcList();
      }
    });
  }

  //Get sub NPC Data
  getsubNpcList() {
    this.apiMappingsService.getSubNpcData(null).subscribe((data: []) => {
      if (data) {
        this.formatDateforSubNpc(data);
      }
    });
  }
  //Get Part Status Data
  getPartStatusData(element) {
    let formData = {};
    element["sapErrorMessage"] = null;
    formData["id"] = element.id,
    formData["partNumber"] = element.partNumber,
    formData["plant"] = element.plantCode
    // formData["id"] = null,
    // formData["partNumber"] = '720028395-888-0000',
    // formData["plant"] = '7150',
    //this.partStatusData = Mock.svcGetNPCData;//Mock data
    //this.partStatusDataSource.data = this.partStatusData['npcPartStatus'];//Mock data
    this.partStatusDataSource.data = [];
    if (formData["partNumber"] != null && formData["plant"] != null) {
      this.apiMappingsService.getPartStatusData(formData).subscribe((data: any) => {
        if (data) {
          console.log(data);
          this.partStatusData = data;
          this.partStatusDataSource.data = this.partStatusData['npcPartStatus'];
          element["sapErrorMessage"] = this.partStatusDataSource.data[0].sapErrorMessage;
        }
      });
    }
  }
  // 
  formatDateforSubNpc(data: any) {
    data.forEach((item: any) => {
      item.formattedRequestDate = this.datePipe.transform((item.requestDate * 1000), 'dd-MMM-yyyy hh:mm aa');
    });
    this.subNpcListData = data;
    if (this.edit) {
      this.element = this.data['npcData'];
      //
      const selectedComponent = _.filter(this.npcComponentList, { 'levelName': this.element.subLevelComponent });
      if (selectedComponent.length > 0) {
        this.element['subLevelComponentId'] = selectedComponent[0].id;
      }
      //
      this.element.subNpcResponseDto = this.subNpcListData;
    } else {
      this.element = {
        drawingNumber: null,
        dwgHeader: null,
        ecmNumber: null,
        enggCoordinator: null,
        enggCoordinatorFirstName: null,
        enggCoordinatorLastName: null,
        erNpc: null,
        generalComments: null,
        holdComments: null,
        holdFlag: null,
        id: null,
        levelFourMasterId: null,
        makeBuy: null,
        mcode: null,
        mcodeComments: null,
        mcodeDesc: null,
        npcNumber: null,
        npcReferenceId: null,
        npcReferenceMappingId: null,
        npcSubCategory: null,
        npcSubCategoryId: null,
        npcSubLevels: null,
        npcWorkFlowStatus: "NOT STARTED",
        parentId: null,
        qcode: null,
        qcodeComments: null,
        qcodeDesc: null,
        status: null,
        subLevelComponent: null,
        subLevelComponentId: null,
        orphanFlag:true,
        subNpcResponseDto: this.subNpcListData
      }
    }
  }


  updateList(value: any) {
    this.filteredOptions = this.npcComponentList;
    this.filteredOptions = this.npcComponentList.filter(option => option.levelName.toLowerCase().includes(value));
  }

  onCategogyChange(item: any) {
    if (!item.npcSubCategoryId) {
      item.npcSubCategory = null;
      item.npcSubCategoryId = null;
    }
    if (item.npcSubCategoryId != 5) {
      item.partNumber = null;
    } else if (item.npcSubCategoryId === 5) {
      item.drawingNumber = null;
      item.mcode = null;
      item.qcode = null;
    }
  }

  change(value: any) {
    let obj = this.filteredOptions.filter((row: any) => row.id == value.subLevelComponentId);
    if (obj && obj[0]) {
      value.subLevelComponent = obj[0].levelName;
    }
  }
  validateNPC(element) {
    if (element !== null && element !== undefined) {
      if (element.holdFlag === true && (element.holdComments === '' || element.holdComments === null)) {
        this.npcFormValid = false;
        this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill Hold Comments');
      }

      if (element.subLevelComponentId === null) {
        this.npcFormValid = false;
        this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill NPC Component');
      }
      //npc SubCategory no equalto Legacy/Others
      if (element.npcSubCategoryId != 5) {
        if (element.drawingNumber === null || element.mcode === null || element.qcode === null) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill "DWG no/M-code/Q-code" fields..!');
        } else if (element.drawingNumber.length < 9 || element.mcode.length < 4 || element.qcode.length < 4) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, '"DWG no" should contain 9 characters and "M-code/Q-code" should contain 4 characters');
        }
      }
      if (element.npcSubCategoryId === 5) {
        if (element.plantCode === null || element.partNumber === null) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Plant and Part Number fileds are required ..!');
        } else if (element.partNumber.length < 4) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Part Number should contain min 4 characters..!');
        }
      }
    }
  }

  saveNpc(item: any, action: any) {
    item['npcReferenceId'] = null;
    item['npcReferenceMappingId'] = null;
    ///item['orphanFlag'] = true;
    //NPC Validation
    this.npcFormValid = true;
    this.validateNPC(item);
    if (this.npcFormValid === true) {
      if (action === 'SAVE') {
        item['status'] = 'SAVE';
        this.apiMappingsService.saveNpcData(item).subscribe((data: []) => {
          if (data) {
            //this.ChildErForceClosureDialogRef.close();
            this.bhAlertService.showAlert('success', 'top', 5000, 'NPC Saved Successfully!');
          } else {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save NPC!');
          }
        });
      } else if (action === 'PROMOTE') {
        item['status'] = 'PROMOTE';
        this.apiMappingsService.saveNpcData(item).subscribe((data: []) => {
          if (data) {
            this.ChildErForceClosureDialogRef.close();
            this.bhAlertService.showAlert('success', 'top', 5000, 'NPC Promoted Successfully!');
          } else {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote NPC!');
          }
        }, err => {
          item['status'] = 'SAVE';
        });
      }
    }
  }
  //Mcode Description Auto Populate
  onMcodeChange(element) {
    element['disableMcodeDesc'] = false;
    //element.mcodeDesc = null;
    let mCodeValue = element.mcode;
    if (mCodeValue != null && mCodeValue.length === 4) {
      this.apiMappingsService.getMcodeDesc(mCodeValue).subscribe((data) => {
        if (data && data != null) {
          if (data['mcode_flag'] === true) {
            element.mcodeDesc = data['mcodeDesc'];
            element['disableMcodeDesc'] = true;
          } else if (data['mcode_flag'] === false) {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'M-code-' + element.mcode + ' is Disabled!');
            element.mcode = null;
            element.mcodeDesc = null;
          }
        } else {
          element.mcodeDesc = null;
        }
      });
    }
  }

  ///
  npcCombinationCheck(element, orphanFlag) {
    if (element.drawingNumber != null && element.mcode != null && element.qcode != null && element.plantCode != null) {
      if (element.drawingNumber.length === 9 && element.mcode.length === 4 && element.qcode.length === 4) {
        this.enggToolComponent.npcCombinationCheck(element, orphanFlag);
      }
    }
  }
  partNumberValidation(element, orphanFlag) {
    if (element.npcSubCategoryId === 5) {
      if (element.partNumber != null && element.partNumber != '' && element.partNumber.length > 3 && element.plantCode != null) {
        if (element.parentId) {
          element['preConfigId'] = element.parentId;
        }
        this.enggToolComponent.partNumberValidation(element, orphanFlag);
      }
    }
  }
  //onNPCPlantChange
  validateNpcPartNumber(element) {
    let orphanFlag = true;
    if (element.npcSubCategoryId === 5) {
      this.partNumberValidation(element, orphanFlag);
    } else {
      this.npcCombinationCheck(element, orphanFlag);
    }

  }
  disable() {
    let roles = JSON.parse(localStorage.getItem("roles"));
    let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Tool Administrator' || obj.roleId == 9)//9-NPC Approver Engineering
    if ((role && role.length > 0)) {
      return false;
    } else {
      return true;
    }
  }
}

export interface PartStatusInterface{
  // Department: string;
  // SAPStatus: string;
  // EnggCoordinator: string;
  // RequestedDate: any; 
  // CompletionDate: any;

  department: string;
  sapMaterialStatus: string;
  sapDistributionMaterialStatus: string;
  plantSpecificMaterialStatus: string;
  procurementType: string;
  requestedDate: any;
  completedDate: any;
  sapErrorMessage: any;

}
