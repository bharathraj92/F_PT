import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.scss']
})
export class MyDashboardComponent implements OnInit {

  pageIndex: number = 0;//Pagination
  pageSize: number = 100;//Pagination
  totalCount: number;
  myDashboardform: FormGroup;
  soLiList: any;
  complexityList: any;
  statusList: any;
  activityList: any;
  navRoute: any;
  search: any = "";
  datePipe = new DatePipe("en-US");
  //filterEntity: MyDashboardInterface;//FilterNew
  //filterType: MatTableFilter;
  displayedColumns: string[] = [
    'indicator',
    'orderNumber',
    'soli',
    'erNumber',
    'plant',//new
    'task',
    'subTask',
    'subComponent',//new
    'holdFlag',//new
    'roleName',
    'assignee',
    //'tagNumber',
    'ageing',//new
    'workFlowStatus',//new
    'currentStepStatus',//new
    'startDate',
    'endDate',
    'completedDate',//new
    'partNumbers',//new
    'dwgHeader',//new
    'creatorComments',//new
    'reviewerComments',//new
    'geomentryCode',//new
    'qCode',//new
    'mCode',//new
    'complexity',//new
    'secondaryEnggTeam',//new
    'releasedByEPLName',//new
    'orderBookedDate',//new
    'shipmentDate',//new
    'bomNeedDate',//new
    'valveBomCreator',//new
    'valveBomReviewer',//new
    'instrumentBOMCreator',//new
    'instrumentBomReviewer',//new
    'projectManager',//new
    'floatingDays',//new  
    'hoursAssign',
    'hoursSpent',
    'progress',
    //'searchType'
  ];
  logginUserFirstName: any;
  currentDate: Date;
  myDashboardTableData: any;
  masterData: any;
  erTotalCount = null;
  erOpenCount = null;
  erWipCount = null;
  erHoldCount = null;
  erClosedCount = null;
  filterSelectObj = [];//
  filterList = [];
  statusMaster = [];
  taskList = [];
  subTaskList = [];
  roleNameList = [];
  filteredSubTask: any;
  supportTeamMaster = [];
  allFiltersSelected = true;
  filterValues = {};
  isExpanded = false;
  // 
  indicator = null;
  orderNumber = null;
  soli = null;
  erNumber = null;
  roleName = null;
  //tagNumber = null;
  plant = null;
  complexity = null;
  customerName = null;
  sapHeader = null;
  sapHeaderDesc = null;
  erStatus = null;
  erCompletionDate = null;
  creator = null;
  reviewer = null;
  release = null;
  orderBookedDate = null;
  shipDate = null;
  enggCompletionDate = null;
  supportTeam = null;
  erRevisionNumber = null;
  costOfTheLine = null;
  enggBlocks = null;
  // 'Id',
  filterEntity = new MatTableDataSource<MyDashboardInterface>(ELEMENT_DATA);
  filterType = MatTableFilter.ANYWHERE;
  dataSource = new MatTableDataSource<MyDashboardInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<MyDashboardInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('myDashboard') myDashboardTable: MatTable<MyDashboardInterface>;
  @ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  routesArray = [{ task: "PRECONFIG", route: "enggTool/preConfig" }, { task: "BOMCONFIG", route: "enggTool/bomConfig" },
  { task: "DESIGN", route: "enggTool/bomConfig" }, { task: "NPC", route: "enggTool/bomConfig" },
  { task: "Calculation", route: "enggTool/configuration" }, { task: "Tests", route: "enggTool/configuration" },
  { task: "External Deliverables", route: "enggTool/configuration" }, { task: "Other Engg Activities", route: "enggTool/configuration" },
  { task: "Quality Activities", route: "enggTool/qualityDoc" }]
  npcComponentList: any;
  filteredOptions: any;
  workFlowStatusMaster: any;
  plantMaster: any;

  //selection = new SelectionModel<MyDashboardInterface>(true, []);
  //selectedRowIndex: number;

  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder, private http: HttpClient, public router: Router, private element: ElementRef) {
    // 
    this.commonService.userDetails.subscribe(val => {
      this.logginUserFirstName = val['firstName'];
      this.currentDate = new Date();
    });
    this.getMyWorkflowMasterData();
    this.getPreConfigMasterData();
    this.getMasterData();
    // Object to create Filter for
    this.filterSelectObj = [
      {
        name: 'Order Number',
        columnProp: 'orderNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Soli',
        columnProp: 'soli',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'ER Number',
        columnProp: 'erNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'ER Status',
        columnProp: 'indicator',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Plant',
        columnProp: 'plant',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Task',
        columnProp: 'task',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Sub Task',
        columnProp: 'subTask',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      // New Filters Start
      {
        name: 'Sub Component',
        columnProp: 'subComponent',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      {
        name: 'Hold Flag',
        columnProp: 'holdFlag',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      // New Filters END
      {
        name: 'Role',
        columnProp: 'roleName',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      {
        name: 'Assigned to',
        columnProp: 'assignee',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      //  {
      //   name: 'Tag Number',
      //   columnProp: 'tagNumber',
      //   isChecked: true,
      //   type: 'text',
      //   value: '',
      //   options: []
      // }, 
      // New Filters Start
      {
        name: 'Ageing',
        columnProp: 'ageing',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'Workflow flow status',
        columnProp: 'workFlowStatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      {
        name: 'Current step status',
        columnProp: 'currentStepStatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      // New Filters END
      {
        name: 'Requested Date',
        columnProp: 'startDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      }, {
        name: 'Target Date',
        columnProp: 'endDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      },
      // New Filters START
      {
        name: 'Completed Date',
        columnProp: 'completedDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      },
      {
        name: 'Part Number',
        columnProp: 'partNumbers',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Complexity',
        columnProp: 'complexity',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Secondary Engg.Team',
        columnProp: 'secondaryEnggTeam',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Released By/EPL Name',
        columnProp: 'releasedByEPLName',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }
    ]
    // 
  }

  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }
  ngOnInit(): void {
    this.commonService.currentview.next('Dashboad > My Dashboard');
    this.getMyDashboardData();
    this.createForm();
    //this.dataSource.filterPredicate = this.createFilter();//
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      console.log(data);
      console.log(filter);
      let matchFound = false;
      for (let column of this.displayedColumns) {
        if (column in data) {
          if (data[column]) {
            matchFound = (matchFound || data[column].toString().trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1)
          }
        }
      }
      return matchFound;
    }
  }

  ngAfterViewInit() {
    //this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.allFiltersSelected = true;
    //this.toggleAllSelection()
  }
  resetSearchFilters() {
    this.filterSelectObj.forEach(item => {
      item.value = '';
    });
    this.search = "";
    this.dataSource.filter = "";
    this.onSearch();
  }
  onFilterListSelection() {
    console.log(this.filterList);
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes('all')) {
        this.filterList.push(item.columnProp);
      }
    });
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes(item.columnProp)) {
        item.isChecked = true;
      } else {
        item.isChecked = false;
      }

    });
  }
  toggleAllSelection() {
    if (this.allFiltersSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
  optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allFiltersSelected = newStatus;
  }
  openClick() {
    this.toggleAllSelection();
  }
  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }
  updateList(value) {
    console.log(value);
    this.filteredSubTask = this.subTaskList;
    this.filteredSubTask = this.subTaskList.filter(option => option.toLowerCase().includes(value));
    console.log(this.filteredSubTask);
    //this.filteredOptions = rfilteredOptions;
  }
  //
  createForm() {
    this.myDashboardform = this.formBuilder.group({
      filterList: [''],
      filterConfig: [''],
      indicator: [''],
      orderNumber: [''],
      soli: [''],
      erNumber: [''],
      task: [''],
      subTask: [''],
      roleName: [],
      //tagNumber: [''],
      assignee: [''],
      hoursAssign: [''],
      hoursSpent: [''],
      progress: [''],
      startDate: [''],
      endDate: ['']
    })
    // const group = this.formBuilder.group({});
    //  filterList.forEach(element => {
    //   const control = this.formBuilder.control(
    //     element.value,
    //     );
    //     group.addControl(element.columnProp, control);
    //   });
    //   return group;
  }

  onSearch() {
    let formvalue = this.myDashboardform.value;
    const formData = {};
    formData['pageNumber'] = this.pageIndex;
    formData['pageSize'] = this.pageSize;
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    console.log(formData);
    this.apiMappingsService.getMyDashboardData(formData).subscribe((data) => {
      if (data) {
        console.log(data);
        this.masterData = data;
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        this.myDashboardTableData = data['filtersData'];
        this.totalCount = data['totalCount'];
        this.prepareTableData(this.myDashboardTableData);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }
  ///Master Data
  getMasterData() {
    const formData = {};
    //this.isDataLoaded = false;
    this.apiMappingsService.getMasterData(formData).subscribe((data) => {
      //this.isDataLoaded = true;
      if (data) {
        this.workFlowStatusMaster = data['bomStatusMaster'];
        this.complexityList = data['complexityMaster'];
      }
    });
  }
  getPreConfigMasterData() {
    //const data = CommonMock.commonOptionData;
    this.apiMappingsService.getPreConfigMasterData().subscribe((data: []) => {
      if (data) {
        this.npcComponentList = data['npcSubComponent'];
        this.filteredOptions = this.npcComponentList;
      }
    });
  }
  //NPC Component filter options
  updateComponentList(value) {
    this.filteredOptions = this.npcComponentList;
    this.filteredOptions = this.npcComponentList.filter(option => option.levelName.toLowerCase().includes(value));
  }
  getMyWorkflowMasterData() {
    // Uncomment below line of code once api is done and comment mock
    const formData = {};
    const searchType = [];
    formData['pageNumber'] = this.pageIndex;
    formData['pageSize'] = this.pageSize;
    this.apiMappingsService.getMyWorkflowMasterData().subscribe((data) => {
      if (data) {
        //const data = Mock.svcGetMyDashboardData;
        //this.masterData = data['filtersData'];
        this.erTotalCount = data['erCount'];
        this.erOpenCount = data['openCount'];
        this.erWipCount = data['wipCount'];
        this.erHoldCount = data['holdCount'];
        this.erClosedCount = data['closedCount'];
        this.statusMaster = data['statusMaster'];
        this.taskList = data['taskMaster'];
        this.subTaskList = data['subTaskMaster'];
        this.filteredSubTask = data['subTaskMaster'];
        this.roleNameList = data['roleNameMaster'];
        this.plantMaster = data['plantMaster'];
        this.supportTeamMaster = data['supportTeamMaster'];
      }
    });
  }
  getMyDashboardData() {
    // Uncomment below line of code once api is done and comment mock
    const formData = {};
    const searchType = [];
    formData['pageNumber'] = this.pageIndex;
    formData['pageSize'] = this.pageSize;
    this.apiMappingsService.getMyDashboardData(formData).subscribe((data) => {
      if (data) {
        //const data = Mock.svcGetMyDashboardData;
        this.masterData = data['filtersData'];
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        // this.statusMaster = data['statusMaster'];
        // this.taskList = data['taskMaster'];
        // this.subTaskList = data['subTaskMaster'];
        // this.filteredSubTask = data['subTaskMaster'];
        // this.roleNameList =data['roleNameMaster'];
        //this.supportTeamMaster = data['supportTeamMaster'];
        this.myDashboardTableData = data['filtersData'];
        this.totalCount = data['totalCount'];
        this.prepareTableData(this.myDashboardTableData);
      }
    });
  }

  prepareTableData(myDashboardTableData) {
    ELEMENT_DATA = [];
    myDashboardTableData.forEach(myDashboard => {
      ELEMENT_DATA.push({

        preConfigId: myDashboard.preConfigId,
        indicator: myDashboard.indicator,
        orderNumber: myDashboard.orderNumber,
        soli: myDashboard.soli,
        erNumber: myDashboard.erNumber,
        task: myDashboard.task,
        subTask: myDashboard.subTask,
        roleName: myDashboard.roleName,
        roleId: myDashboard.roleId,
        //tagNumber: myDashboard.tagNumber,
        assignee: myDashboard.assignee,
        hoursAssign: myDashboard.hoursAssign,
        hoursSpent: myDashboard.hoursSpent,
        progress: myDashboard.progress,
        startDate: this.dateFormatter(myDashboard.startDate),//startDate,
        endDate: this.dateFormatter(myDashboard.endDate),//endDate,
        searchType: myDashboard.searchType,
        levelThreeId: myDashboard.levelThreeId,
        levelTwoId: myDashboard.levelTwoId
      });
      // id: erRequest.id,
    });
    this.dataSource.data = ELEMENT_DATA;
    // 
    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(ELEMENT_DATA, o.columnProp);
    });
    // 
  }
  // 
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);

  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      console.log(searchTerms);

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }


  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }
  // 
  dateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');
      return result;
    }
  }
  //excel Date Formatter
  excelDateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      //const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');//String
      const result = new Date(value * 1000);
      return result;
    }
  }
  onSearchERRequest(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onClickWorkFLowRedirection(navItem: any, saleOrder: any, erNumber: any, soLiNumber: any, task: any, subTask: any, preConfigId: any, element: any) {
    this.commonService.saleOrderNumber.next('');
    this.commonService.erNumber.next('');
    sessionStorage.setItem('erNumber', '');
    sessionStorage.setItem('soLiNumber', '');
    if (Helpers.isLowerCaseEquals(navItem, 'soLi')) {
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.saleOrderNumber.next(saleOrder);
      sessionStorage.setItem('saleOrderNumber', saleOrder);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      let task = this.routesArray.filter(item => item.task == task);
      let row = this.routesArray.filter(item => item.task == task);
      if (row && row.length > 0) {
        this.router.navigate([row[0].route]);
      }
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
      // this.navRoute = 'enggTool/preConfig';
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.erNumber.next(erNumber);
      sessionStorage.setItem('erNumber', erNumber);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      sessionStorage.setItem('preConfigId', preConfigId);
      sessionStorage.setItem('creatorid', element.creatorid);
      sessionStorage.setItem('reveiwerid', element.reveiwerid);
      sessionStorage.setItem('navigateFromDashboard', "true");
      sessionStorage.setItem("subTask", subTask);
      sessionStorage.setItem("task", task);
      sessionStorage.setItem("levelTwoId", element.levelTwoId);
      sessionStorage.setItem("levelThreeId", element.levelThreeId);
      if (task == 'npc') {
        sessionStorage.setItem('npcId', element.npcId);
        sessionStorage.setItem('navigateFromNPCDashboard', "true");
      }
      let row = this.routesArray.filter(item => item.task == task);
      if (row && row.length > 0) {
        sessionStorage.setItem("subTask", subTask);
        sessionStorage.setItem("task", task);
        this.router.navigate([row[0].route]);
      }
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    }
  }
  //Pagenation
  public changePage(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.onSearch();
  }
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("myDashboard");
  }
  exportArray() {
    const formData = {};
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    this.apiMappingsService.getMyDashboardExcelData(formData).subscribe((data) => {
      if (data) {
        const excelData = data['filtersData']
        const onlyNameAndSymbolArr: Partial<MyDashboardInterface>[] = excelData.map(myDashboard => ({
          // const onlyNameAndSymbolArr: Partial<MyDashboardInterface>[] = this.myDashboardTableData.map(myDashboard => ({
          // status: myDashboard.indicator,
          // soli: myDashboard.soli,
          // orderNumber: myDashboard.orderNumber,
          // erNumber: myDashboard.erNumber,
          // task: myDashboard.task,
          // subTask: myDashboard.subTask,
          // //tagNumber: myDashboard.tagNumber,
          // roleId: myDashboard.roleId,
          // roleName: myDashboard.roleName,
          // assignee: myDashboard.assignee,
          // hoursAssign: myDashboard.hoursAssign,
          // hoursSpent: myDashboard.hoursSpent,
          // progress: myDashboard.progress,
          // startDate: this.excelDateFormatter(myDashboard.startDate),//startDate,
          // endDate: this.excelDateFormatter(myDashboard.endDate),//endDate,
          // //searchType: myDashboard.searchType
          /////////New Fields
          orderNumber: myDashboard.orderNumber,
          soli: myDashboard.soli,
          erNumber: myDashboard.erNumber,
          erStatus: myDashboard.indicator,
          plant: myDashboard.plant,
          task: myDashboard.task,
          subTask: myDashboard.subTask,
          //tagNumber: myDashboard.tagNumber,
          subComponent: '',//new
          holdFlag: '',//new
          //roleId: myDashboard.roleId,
          role: myDashboard.roleName,//roleName
          assignedTo: myDashboard.assignee,
          ageing: '',//new
          workFlowStatus: '',//new
          currentStepStatus: '',//new    
          requestedDate: this.excelDateFormatter(myDashboard.startDate),//startDate,
          targetDate: this.excelDateFormatter(myDashboard.endDate),//endDate,
          completedDate: '',//new
          partNumbers: '',//new
          dwgHeader: '',//new
          creatorComments: '',//new
          reviewerComments: '',//new
          geomentryCode: '',//new
          qCode: '',//new
          mCode: '',//new
          complexity: '',//new
          secondaryEnggTeam: '',//new
          releasedByEPLName: '',//new
          orderBookedDate: '',//new
          shipmentDate: '',//new
          bomNeedDate: '',//new
          valveBomCreator: '',//new
          valveBomReviewer: '',//new
          instrumentBOMCreator: '',//new
          instrumentBomReviewer: '',//new
          projectManager: '',//new
          floatingDays: '',//new     
          hoursAssign: myDashboard.hoursAssign,
          hoursSpent: myDashboard.hoursSpent,
          percentageCompletion: myDashboard.progress
        }));
        ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "My Dashboard");
        //F&PT_MyDashboardData
      }
    });
  }
}

export interface MyDashboardInterface {
  //status:string;
  preConfigId: number;
  indicator: string;
  orderNumber: string;
  erNumber: string;
  task: string;
  subTask: string;
  roleName: string;
  //tagNumber: string;
  roleId: number;
  soli: string;
  assignee: string;
  hoursAssign: number;
  hoursSpent: number;
  progress: string;
  startDate: any;
  endDate: any;
  searchType: string;
  levelThreeId: string;
  levelTwoId: string
}
let ELEMENT_DATA: MyDashboardInterface[] = [];