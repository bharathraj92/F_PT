import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildERDashboardComponent } from './child-er-dashboard.component';

describe('ChildERDashboardComponent', () => {
  let component: ChildERDashboardComponent;
  let fixture: ComponentFixture<ChildERDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildERDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildERDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
