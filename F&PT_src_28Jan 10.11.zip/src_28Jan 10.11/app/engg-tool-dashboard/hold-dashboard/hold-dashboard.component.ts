import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NpcForceCloseComponent } from '../npc-force-close/npc-force-close.component';
import { HoldEditModalComponent } from '../hold-edit-modal/hold-edit-modal.component';

@Component({
  selector: 'app-hold-dashboard',
  templateUrl: './hold-dashboard.component.html',
  styleUrls: ['./hold-dashboard.component.scss']
})
export class HoldDashboardComponent implements OnInit {

  holdDashboardform: FormGroup;
  soLiList: any;
  complexityList: any;
  statusList: any;
  activityList: any;
  navRoute: any;
  datePipe = new DatePipe("en-US");
  filteredOptions: any;
  accessCheck;
  disableFlag: boolean;
  search: any = "";
  //filterEntity: HoldDashboardInterface;//FilterNew
  //filterType: MatTableFilter;
  displayedColumns: string[] = [
    'holdEdit',
    'soli',
    'erNumber',
    'projectManager',
    'status',
    'plant',
    'aging',
    'partNumber',
    'task',
    'subTask',
    'tagNumber',
    'roleName',
    'creator',
    'reveiwer',
    'releasedBy',
    'holdComments',
    'unholdComments',
    'holdDate',
    // 'creatorHoldComments',
    'unholdDate',
    // 'creatorUnholdComments',
    // 'reviewerHoldDate',
    // 'reviewerHoldComments',
    // 'reviewerUnholdDate',
    // 'reviewerUnholdComments',
  ];
  logginUserFirstName: any;
  currentDate: Date;
  holdDashboardTableData: any;
  masterData: any;
  erTotalCount = null;
  erOpenCount = null;
  erWipCount = null;
  erHoldCount = null;
  erClosedCount = null;
  filterSelectObj = [];//
  filterList = [];
  statusMaster = [];
  taskList = [];
  subTaskList = [];
  roleNameList = [];
  filteredSubTask: any;
  supportTeamMaster = [];
  plantMaster = [];
  allFiltersSelected = true;
  filterValues = {};
  isExpanded = false;
  isDataLoaded = false;
  // 
  //orderNumber = null;
  soli = null;
  erNumber = null;
  projectManager = null;
  plant = null;
  aging = null;
  task = null;
  subTask = null;
  tagNumber = null;
  roleName = null;
  creator = null;
  reveiwer = null;
  releasedBy = null;
  holdComments = null;
  unholdComments = null;
  holdDate = null;
  creatorHoldComments = null;
  unholdDate = null;
  creatorUnholdComments = null;
  reviewerHoldDate = null;
  reviewerHoldComments = null;
  reviewerUnholdDate = null;
  reviewerUnholdComments = null;

  // 'Id',
  filterEntity = new MatTableDataSource<HoldDashboardInterface>(ELEMENT_DATA);
  filterType = MatTableFilter.ANYWHERE;
  dataSource = new MatTableDataSource<HoldDashboardInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<HoldDashboardInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('holdDashboard') holdDashboardTable: MatTable<HoldDashboardInterface>;
  @ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  ChildErForceClosureModal: MatDialogRef<NpcForceCloseComponent>;
  HoldEditModal: MatDialogRef<HoldEditModalComponent>;

  routesArray = [{ task: "PRECONFIG", route: "enggTool/preConfig" }, { task: "BOMCONFIG", route: "enggTool/bomConfig" },
  { task: "DESIGN", route: "enggTool/bomConfig" }, { task: "NPC", route: "enggTool/bomConfig" },
  { task: "Calculation", route: "enggTool/configuration" }, { task: "Tests", route: "enggTool/configuration" },
  { task: "External Deliverables", route: "enggTool/configuration" }, { task: "Other Engg Activities", route: "enggTool/configuration" },
  { task: "Quality Activities", route: "enggTool/qualityDoc" }]

  //selection = new SelectionModel<HoldDashboardInterface>(true, []);
  //selectedRowIndex: number;

  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder, private http: HttpClient, public router: Router, private element: ElementRef, public dialog: MatDialog) {
    // 
    this.commonService.userDetails.subscribe(val => {
      this.logginUserFirstName = val['firstName'];
      this.currentDate = new Date();
    });
    this.getHoldDashboardData();
    // Object to create Filter for
    this.filterSelectObj = [
      {
        name: 'Soli',
        columnProp: 'soli',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'ER Number',
        columnProp: 'erNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Project Manager',
        columnProp: 'projectManager',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },{
        name: 'Status',
        columnProp: 'status',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },{
        name: 'Plant',
        columnProp: 'plant',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Task',
        columnProp: 'task',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      {
        name: 'Sub Task',
        columnProp: 'subTask',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Aging',
        columnProp: 'aging',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Tag Number',
        columnProp: 'tagNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Role Name',
        columnProp: 'roleName',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Creator',
        columnProp: 'creator',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Reveiwer',
        columnProp: 'reveiwer',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Released By',
        columnProp: 'releasedBy',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Hold Date',
        columnProp: 'holdDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      }, {
        name: 'UnholdDate',
        columnProp: 'unholdDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      },
      // {
      //   name: 'Reviewer HoldDate',
      //   columnProp: 'reviewerHoldDate',
      //   isChecked: true,
      //   type: 'date',
      //   value: '',
      //   options: []
      // }, {
      //   name: 'Reviewer UnholdDate',
      //   columnProp: 'reviewerUnholdDate',
      //   isChecked: true,
      //   type: 'date',
      //   value: '',
      //   options: []
      // }
    ]
  }

  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }
  ngOnInit(): void {
    this.accessCheck = localStorage.getItem('allowAccess');
    this.commonService.currentview.next('Dashboad > Hold Dashboard');
    //this.getHoldDashboardData();
    this.enableForceClosure();
    this.createForm();
    //this.dataSource.filterPredicate = this.createFilter();//
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      console.log(data);
      console.log(filter);
      let matchFound = false;
      for (let column of this.displayedColumns) {
        if (column in data) {
          if (data[column]) {
            matchFound = (matchFound || data[column].toString().trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1)
          }
        }
      }
      return matchFound;
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.allFiltersSelected = true;
    //this.toggleAllSelection()
  }
  resetSearchFilters() {
    this.filterSelectObj.forEach(item => {
      item.value = '';
    });
    this.search = "";
    this.dataSource.filter = "";
    this.onSearch();
  }
  onFilterListSelection() {
    console.log(this.filterList);
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes('all')) {
        this.filterList.push(item.columnProp);
      }
    });
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes(item.columnProp)) {
        item.isChecked = true;
      } else {
        item.isChecked = false;
      }

    });
  }
  toggleAllSelection() {
    if (this.allFiltersSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
  optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allFiltersSelected = newStatus;
  }
  openClick() {
    this.toggleAllSelection();
  }
  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }
  updateList(value) {
    console.log(value);
    this.filteredSubTask = this.subTaskList;
    this.filteredSubTask = this.subTaskList.filter(option => option.toLowerCase().includes(value));
    console.log(this.filteredSubTask);
    //this.filteredOptions = rfilteredOptions;
  }

  createForm() {
    this.holdDashboardform = this.formBuilder.group({
      filterList: [''],
      filterConfig: [''],
      //orderNumber: [''],
      soli: [''],
      erNumber: [''],
      projectManager: [''],
      aging: [''],
      task: [''],
      subTask: [''],
      tagNumber: [''],
      plant: [''],
      roleName: [''],
      creator: [''],
      reveiwer: [''],
      releasedBy: [''],
      holdComments: [''],
      unholdComments: [''],
      holdDate: [''],
      unholdDate: [''],
      reviewerHoldDate: [''],
      reviewerUnholdDate: [''],
    })
    // const group = this.formBuilder.group({});
    //  filterList.forEach(element => {
    //   const control = this.formBuilder.control(
    //     element.value,
    //     );
    //     group.addControl(element.columnProp, control);
    //   });
    //   return group;
  }

  onSearch() {
    let formvalue = this.holdDashboardform.value;
    const formData = {};
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    console.log(formData);
    this.apiMappingsService.getHoldDashboardData(formData).subscribe((data) => {
      if (data) {
        console.log(data);
        this.masterData = data;
        this.erTotalCount = data['erCount'];
        this.erOpenCount = data['openCount'];
        this.erWipCount = data['wipCount'];
        this.erHoldCount = data['holdCount'];
        this.erClosedCount = data['closedCount'];
        this.holdDashboardTableData = data['filtersData']
        this.prepareTableData(this.holdDashboardTableData);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }

  getHoldDashboardData() {
    // Uncomment below line of code once api is done and comment mock

    this.isDataLoaded = false;
    this.apiMappingsService.getHoldDashboardData({ searchType: [] }).subscribe((data) => {
      this.isDataLoaded = true;
      if (data) {
        // const data = Mock.svcGetHoldDashboardData;
        this.masterData = data['filtersData'];
        this.erTotalCount = data['erCount'];
        this.erOpenCount = data['openCount'];
        this.erWipCount = data['wipCount'];
        this.erHoldCount = data['holdCount'];
        this.erClosedCount = data['closedCount'];
        this.statusMaster = data['statusMaster'];
        this.taskList = data['taskMaster'];
        this.subTaskList = data['subTaskMaster'];
        this.filteredSubTask = data['subTaskMaster'];
        this.roleNameList = data['roleNameMaster'];
        this.plantMaster = data['plantMaster'];
        //this.supportTeamMaster = data['supportTeamMaster'];
        this.holdDashboardTableData = data['filtersData']
        this.prepareTableData(this.holdDashboardTableData);
      }
    });
  }

  prepareTableData(holdDashboardTableData) {
    ELEMENT_DATA = [];
    holdDashboardTableData.forEach(holdDashboard => {
      ELEMENT_DATA.push({

        soli: holdDashboard.soli,
        erNumber: holdDashboard.erNumber,
        projectManager: holdDashboard.projectManager,
        plant: holdDashboard.plant,
        aging: holdDashboard.aging,
        task: holdDashboard.task,
        subTask: holdDashboard.subTask,
        tagNumber: holdDashboard.tagNumber,
        roleName: holdDashboard.roleName,
        creator: holdDashboard.creator,
        reveiwer: holdDashboard.reveiwer,
        releasedBy: holdDashboard.releasedBy,
        holdComments: holdDashboard.holdComments,
        unholdComments: holdDashboard.unholdComments,
        holdDate: this.dateFormatter(holdDashboard.holdDate),//holdDashboard.holdDate,
        creatorHoldComments: holdDashboard.creatorHoldComments,
        unholdDate: this.dateFormatter(holdDashboard.unholdDate),//holdDashboard.unholdDate,
        creatorUnholdComments: holdDashboard.creatorUnholdComments,
        reviewerHoldDate: this.dateFormatter(holdDashboard.reviewerHoldDate),//holdDashboard.reviewerHoldDate,
        reviewerHoldComments: holdDashboard.reviewerHoldComments,
        reviewerUnholdDate: this.dateFormatter(holdDashboard.reviewerUnholdDatee),//holdDashboard.reviewerUnholdDate,
        reviewerUnholdComments: holdDashboard.reviewerUnholdComments,
        allowAccess: this.commonService.checkAccess(holdDashboard.plant),//this.accessCheck,
        generalComments: holdDashboard.generalComments,
        creatorid: holdDashboard.creatorid,
        reveiwerid: holdDashboard.reveiwerid,
        preConfigId: holdDashboard.preConfigId,
        holdFlag: holdDashboard.holdFlag,
        reviewerGeneralComments: holdDashboard.reviewerGeneralComments,
        creatorGeneralComments: holdDashboard.creatorGeneralComments,
        partNumber: holdDashboard.partNumber,
        status: holdDashboard.status,
        levelThreeId: holdDashboard.levelThreeId,
        levelTwoId: holdDashboard.levelTwoId,
        allowEdit:this.commonService.checkEditAccess(holdDashboard.plant),
      });
      // id: erRequest.id,

      // 'reveiwer',    'releasedBy',
    });
    this.dataSource.data = ELEMENT_DATA;
    // 
    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(ELEMENT_DATA, o.columnProp);
    });
    // 
  }
  //// 
  // checkAccess(plant) {
  //   let isAdmin = localStorage.getItem("admin");
  //   let siteAdminPlantCode = localStorage.getItem('siteAdminPlantCode');
  //   let allowAccess = 'false';
  //   if (isAdmin == 'false') {
  //     if (this.accessCheck == 'true') {
  //       allowAccess = 'true';
  //       if (siteAdminPlantCode != null && siteAdminPlantCode == plant) {
  //         allowAccess = 'true';
  //       } else {
  //         allowAccess = 'false';
  //       }
  //     }
  //     }else if(isAdmin == 'true')
  //     {
  //       allowAccess = 'true';
  //     }
  //     return allowAccess;
  //   } 
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);

  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      console.log(searchTerms);

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }


  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }
  // 
  dateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');
      //console.log(result);
      return result;
    }
  }
  //excel Date Formatter
  excelDateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      //const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');//String
      const result = new Date(value * 1000);
      return result;
    }
  }
  onSearchERRequest(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  enableForceClosure() {
    let roles = JSON.parse(localStorage.getItem("roles"));
    let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Tool Administrator')
    if ((role && role.length > 0)) {
      this.disableFlag = false;
    } else {
      this.disableFlag = true;
    }
  }

  onClickWorkFLowRedirection(navItem: any, saleOrder: any, erNumber: any, soLiNumber: any, task: any, subTask: any, preConfigId: any, element: any) {
    this.commonService.saleOrderNumber.next('');
    this.commonService.erNumber.next('');
    sessionStorage.setItem('erNumber', '');
    sessionStorage.setItem('soLiNumber', '');
    if (Helpers.isLowerCaseEquals(navItem, 'soLi')) {
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.saleOrderNumber.next(saleOrder);
      sessionStorage.setItem('saleOrderNumber', saleOrder);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      // let task = this.routesArray.filter(item => item.task.toLowerCase() == task.toLowerCase());
      let row = this.routesArray.filter(item => item.task.toLowerCase() == task.toLowerCase());
      if (row && row.length > 0) {
        //this.router.navigate([row[0].route]);
        //New Tab
        window.open(`${location.origin}${location.pathname}#/${row[0].route}`, '_blank');
      }
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
      // this.navRoute = 'enggTool/preConfig';
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.erNumber.next(erNumber);
      sessionStorage.setItem('erNumber', erNumber);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      sessionStorage.setItem('preConfigId', preConfigId);
      sessionStorage.setItem('creatorid', element.creatorid);
      sessionStorage.setItem('reveiwerid', element.reveiwerid);
      sessionStorage.setItem('navigateFromDashboard', "true");
      sessionStorage.setItem("subTask", subTask);
      sessionStorage.setItem("task", task);
      sessionStorage.setItem("levelTwoId", element.levelTwoId);
      sessionStorage.setItem("levelThreeId", element.levelThreeId);
      sessionStorage.setItem("roleName",element.roleName);
      if (task == 'npc') {
        sessionStorage.setItem('npcId', element.creatorid);
        sessionStorage.setItem('navigateFromNPCDashboard', "true");
      }
      let row = this.routesArray.filter(item => item.task.toLowerCase() == task.toLowerCase());
      if (row && row.length > 0) {
        sessionStorage.setItem("subTask", subTask);
        sessionStorage.setItem("task", task);
        //this.router.navigate([row[0].route]);
        //New Tab
        window.open(`${location.origin}${location.pathname}#/${row[0].route}`, '_blank');
      }
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    }
  }

  // edit New NPC
  holdEdit(element: any) {
    this.HoldEditModal = this.dialog.open(HoldEditModalComponent, { data: { holdData: element, edit: true } });
    this.HoldEditModal.afterClosed().subscribe(value => {
      this.getHoldDashboardData();
    });
  }

  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("holdDashboard");
  }
  exportArray() {
    const onlyNameAndSymbolArr: Partial<HoldDashboardInterface>[] = this.holdDashboardTableData.map(holdDashboard => ({
      soli: holdDashboard.soli,
      erNumber: holdDashboard.erNumber,
      projectManager: holdDashboard.projectManager,      
      status: holdDashboard.status,
      plant: holdDashboard.plant,
      aging_Days: holdDashboard.aging,
      task: holdDashboard.task,
      subTask: holdDashboard.subTask,
      tagNumber: holdDashboard.tagNumber,
      roleName: holdDashboard.roleName,
      creator: holdDashboard.creator,
      reveiwer: holdDashboard.reveiwer,
      releasedBy: holdDashboard.releasedBy,
      holdComments: holdDashboard.holdComments,
      unholdComments: holdDashboard.unholdComments,
      holdDate: this.excelDateFormatter(holdDashboard.holdDate),//holdDashboard.holdDate,
      creatorHoldComments: holdDashboard.creatorHoldComments,
      unholdDate: this.excelDateFormatter(holdDashboard.unholdDate),//holdDashboard.unholdDate,
      creatorUnholdComments: holdDashboard.creatorUnholdComments,
      reviewerHoldDate: this.excelDateFormatter(holdDashboard.reviewerHoldDate),//holdDashboard.reviewerHoldDate,
      reviewerHoldComments: holdDashboard.reviewerHoldComments,
      reviewerUnholdDate: this.excelDateFormatter(holdDashboard.reviewerUnholdDate),//holdDashboard.reviewerUnholdDate,
      reviewerUnholdComments: holdDashboard.reviewerUnholdComments,
      //
      generalComments: holdDashboard.generalComments,
      holdFlag: holdDashboard.holdFlag,
      reviewerGeneralComments: holdDashboard.reviewerGeneralComments,
      creatorGeneralComments: holdDashboard.creatorGeneralComments,
      partNumber: holdDashboard.partNumber,
    }));
    ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "Hold Dashboard");
    //F&PT_NpcDashboardData
  }
}

export interface HoldDashboardInterface {

  // preConfigId: number;
  // npcWorkFlowStatus: string;
  // //orderNumber: string;
  // erNumber: string;
  // drawingNumber: string;
  // dwgHeader: string;
  // mcode: string;
  // qcode: string;
  // partNumber: string,
  // projectManager: string,
  // roleId: number;
  // soli: string;
  // mcodeDesc: string;
  // enggCoordinatorFirstName: string;
  // reveiwer: string,
  // releasedBy: string,
  // holdComments: string;
  // generalComments: string;
  // id: number;
  // allowAccess: any;
  // orphanFlag: boolean;
  // enggCoordinator: number;
  // ecmNumber: number

  soli: string;
  erNumber: string;
  projectManager: string;
  plant: string;
  aging: string;
  task: string;
  subTask: string;
  tagNumber: string;
  roleName: string;
  creator: string;
  reveiwer: string;
  releasedBy: string;
  holdComments: string;
  unholdComments: string;
  holdDate: any;
  creatorHoldComments: string;
  unholdDate: any;
  creatorUnholdComments: string;
  reviewerHoldDate: any;
  reviewerHoldComments: string;
  reviewerUnholdDate: any;
  reviewerUnholdComments: string;
  allowAccess: any;
  generalComments: any;
  reveiwerid: any;
  creatorid: any;
  preConfigId: any;
  holdFlag: any;
  creatorGeneralComments: string;
  reviewerGeneralComments: string;
  partNumber: string;
  status: string;
  levelThreeId: string;
  levelTwoId: string;
  allowEdit:any;
}
export interface holdData {
  animal: string;
  name: string;
}
let ELEMENT_DATA: HoldDashboardInterface[] = [];