import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpcForceCloseComponent } from './npc-force-close.component';

describe('NpcForceCloseComponent', () => {
  let component: NpcForceCloseComponent;
  let fixture: ComponentFixture<NpcForceCloseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpcForceCloseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpcForceCloseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
