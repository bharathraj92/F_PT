
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as Mock from 'src/app/mock/attachments.mock';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { data } from '../npc-dashboard/npc-dashboard.component';

@Component({
  selector: 'app-npc-force-close',
  templateUrl: './npc-force-close.component.html',
  styleUrls: ['./npc-force-close.component.scss']
})
export class NpcForceCloseComponent implements OnInit {
  comments: any;
  erData: any;
  masterErData: any[]=[];
  displayedColumns: string[] = ['sn','erNumber'];

  constructor(
    public ChildErForceClosureDialogRef: MatDialogRef<NpcForceCloseComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    @Inject(MAT_DIALOG_DATA) public data: data,
  ) {
  }

  ngOnInit(): void {
   this.erData=this.data['erData'];
  //  this.masterErData = this.data['masterData'];
   this.getMasterData(this.erData);
  }

  getMasterData(data:any){
    let obj={
      "preConfigId": data['preConfigId'],
      "reviewerId": data['reviewerId'],
      "npcId":data['id'],
      "task": 'NPC'
    }
    let masterERData: any[]=[];
    this.apiMappingsService.getChildERData(obj).subscribe((MasterData: any) => {
      this.masterErData=MasterData['childERPreConfigData'];
    });
  }

  ChildErForceClosure(data: any){
    let obj={
      "preConfigId": data['preConfigId'],
      "reviewerId": data['reviewerId'],
      "npcId":data['id'],
      "task": 'NPC',
      "comments": this.comments,
      "orphanFlag": data['orphanFlag']
    }
    this.apiMappingsService.forceClose(obj).subscribe((obj: any) => {
      if (data) {
        this.ChildErForceClosureDialogRef.close();
        this.bhAlertService.showAlert('success', 'top', 5000, 'Child Er was Force Closed Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Force Close Child Er!');
      }
    });
  }


}

