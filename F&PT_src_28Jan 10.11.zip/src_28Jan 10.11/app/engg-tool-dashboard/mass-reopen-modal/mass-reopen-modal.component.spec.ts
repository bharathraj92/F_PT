import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MassReopenModelComponent } from './mass-reopen-modal.component';

describe('MassReopenModelComponent', () => {
  let component: MassReopenModelComponent;
  let fixture: ComponentFixture<MassReopenModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MassReopenModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassReopenModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
