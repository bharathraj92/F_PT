import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as Mock from 'src/app/mock/attachments.mock';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { dialogData } from '../child-er-dashboard/child-er-dashboard.component';

@Component({
  selector: 'app-child-er-force-closure-modal',
  templateUrl: './child-er-force-closure-modal.component.html',
  styleUrls: ['./child-er-force-closure-modal.component.scss']
})
export class ChildErForceClosureModalComponent implements OnInit {
  comments: any;
  erData: any;
  masterErData: any[]=[];
  displayedColumns: string[] = ['sn','erNumber'];

  constructor(
    public ChildErForceClosureDialogRef: MatDialogRef<ChildErForceClosureModalComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    @Inject(MAT_DIALOG_DATA) public data: dialogData,
  ) {

  }

  getMasterData(data:any, creatorId: any){
    let obj={
      "preConfigId": data['preConfigId'],
      "creatorId": creatorId,
      "reviewerId": null,
      "task": data['task'],
      "levelTwoId":data['levelTwoId'],
      "levelThreeId": data['levelThreeId']
    } 
    let masterERData=""
    this.apiMappingsService.getChildERData(obj).subscribe((MasterData: any) => {
      if (MasterData) {
        this.masterErData=MasterData['childERPreConfigData'];
      }
    });
      
  }

  getcreatorId(data: any){
    let obj={
      "preConfigId": data['preConfigId'],
      "creatorId": data['createrid'],
      "reviewerId": data['reveiwerid'],
      "task": data['task'],
      "levelTwoId":data['levelTwoId'],
      "levelThreeId": data['levelThreeId']
    } 
    let masterERData=""
    this.apiMappingsService.getCreatorId(obj).subscribe((creatorId: any) => {
      if (creatorId) {
        this.getMasterData(data, creatorId);
      }
    });
  }

  ngOnInit(): void {
   this.erData=this.data['erData'];
  //  this.masterErData = this.data['masterData'];
   this.getcreatorId(this.erData);
  }

  ChildErForceClosure(data: any){
    let obj={
      "preConfigId": data['preConfigId'],
      "creatorId": data['createrid'],
      "reviewerId": data['reveiwerid'],
      "task": data['task'],
      "levelTwoId": data['levelTwoId'],
      "levelThreeId": data['levelThreeId'],
      "comments": this.comments
    }
    this.apiMappingsService.forceClose(obj).subscribe((obj: any) => {
      if (data) {
        this.ChildErForceClosureDialogRef.close();
        this.bhAlertService.showAlert('success', 'top', 5000, 'Child Er was Force Closed Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Force Close Child Er!');
      }
    });
  }


}

