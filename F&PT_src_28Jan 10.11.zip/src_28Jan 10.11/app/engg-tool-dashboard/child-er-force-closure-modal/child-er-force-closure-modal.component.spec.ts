import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildErForceClosureModalComponent } from './child-er-force-closure-modal.component';

describe('ChildErForceClosureModalComponent', () => {
  let component: ChildErForceClosureModalComponent;
  let fixture: ComponentFixture<ChildErForceClosureModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildErForceClosureModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildErForceClosureModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
