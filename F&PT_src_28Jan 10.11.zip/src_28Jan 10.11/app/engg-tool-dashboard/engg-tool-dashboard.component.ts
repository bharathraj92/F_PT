import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engg-tool-dashboard',
  templateUrl: './engg-tool-dashboard.component.html',
  styleUrls: ['./engg-tool-dashboard.component.scss']
})
export class EnggToolDashboardComponent implements OnInit {
 
  constructor() { }

  ngOnInit(): void {
    
  }

}
