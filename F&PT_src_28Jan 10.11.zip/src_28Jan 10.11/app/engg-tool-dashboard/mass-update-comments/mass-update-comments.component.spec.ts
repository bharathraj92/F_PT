import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MassUpdateCommentsComponent } from './mass-update-comments.component';

describe('MassUpdateCommentsComponent', () => {
  let component: MassUpdateCommentsComponent;
  let fixture: ComponentFixture<MassUpdateCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MassUpdateCommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassUpdateCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
