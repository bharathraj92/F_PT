
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { massUpdateData, ERDashboardInterface } from '../er-dashboard/er-dashboard.component';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-mass-update-comments',
  templateUrl: './mass-update-comments.component.html',
  styleUrls: ['./mass-update-comments.component.scss']
})
export class MassUpdateCommentsComponent implements OnInit {
  datasource = new MatTableDataSource<any[]>();
  displayedColumns: string[] = ['soli', 'customerName'];
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  comments: any;


  constructor(public MassUpdateModalDialogRef: MatDialogRef<MassUpdateCommentsComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    @Inject(MAT_DIALOG_DATA) public data: massUpdateData) { }

  ngOnInit(): void {
    this.datasource.data = this.data['massUpdateData'];
    this.datasource.paginator = this.paginator;
    this.datasource.sort = this.sort;
  }


  massUpdate() {
    let obj: any;
    let array: any[] = [];
    this.datasource.data.forEach((row: any) => {
      array.push({ 'soli': row.soli, "preConfigId": row.preConfigId })
    });
    if (this.comments) {
      obj = {
        "generalComments": this.comments,
        "selectedMasterData": array
      }
    } 
    this.apiMappingsService.saveGeneralcomments(obj).subscribe((data: []) => {
      if (data) {
        this.bhAlertService.showAlert('success', 'top', 5000, 'Comments updated Successfully!'
        );
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to update Comments!');
      }
    });
    this.MassUpdateModalDialogRef.close();
  }

  cancel(){
    this.MassUpdateModalDialogRef.close();
  }



}
