import { Component, OnInit, Inject, ViewChild, ElementRef, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { filter, findIndex, take, timeout } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { fromEvent, Observable, Subscription } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router, NavigationEnd } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
import { MassUpdateModalComponent } from '../mass-update-modal/mass-update-modal.component';
import { MassUpdateCommentsComponent } from '../mass-update-comments/mass-update-comments.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as _ from 'lodash';
import { MassReopenModelComponent } from '../mass-reopen-modal/mass-reopen-modal.component';
import { ConfirmDialogComponent, ConfirmDialogModel } from 'src/app/util/confirm-dialog/confirm-dialog.component';
@Component({
  selector: 'app-er-dashboard',
  templateUrl: './er-dashboard.component.html',
  styleUrls: ['./er-dashboard.component.scss']
})
export class ErDashboardComponent implements OnInit {

  //erDashboardform: FormGroup;
  pageIndex: number = 0;
  pageSize: number = 100;
  totalCount: number;
  soLiList: any;
  complexityList: any;
  statusList: any;
  activityList: any;
  navRoute: any;
  datePipe = new DatePipe("en-US");
  search: any = "";
  massUpdateModal: MatDialogRef<MassUpdateModalComponent>;
  massUpdateCommentsModal: MatDialogRef<MassUpdateCommentsComponent>;
  massReopenModal: MatDialogRef<MassReopenModelComponent>;
  //filterEntity: ERDashboardInterface;//FilterNew
  //filterType: MatTableFilter;
  displayedColumns: string[] = [
    'Select',
    'orderNumber',
    'soli',
    'erNumber',
    'erRevisionNumber',
    'tagNumber',
    'plant',
    'erStatus',
    'complexity',
    'customerName',
    'sapHeader',
    'sapHeaderDesc',
    'bomCompletionstatus',
    //'erCompletionDate',
    'creator',
    'reviewer',
    'valveBomCurrentStep',//new
    'valveBomCreationDate',//new
    'valveBomReviwerDate',//new
    'instrumentBomCreator',//new
    'instrumentBomReviewer',//new
    'instrumentBomCurrentStep',//new
    'instrumentBomCreationDate',//new
    'instrumentBomReviwerDate',//new
    'release',
    'orderBookedDate',
    'ageing',//new
    'preConfCompletionDate',//new
    'bomNeedDate',
    // 'enggBlockedDate',
    'enggCompletionDate',
    'shipDate',
    'bomScoreCard',//new
    'designScoreCard',//new
    'npcScoreCard',//new
    'enggDocScoreCard',//new
    'QualityDocScoreCard',//new
    'supportTeam',
    'costOfTheLine',
    'itemStatusProfile',
    'headerStatusProfile',
    'projectManager',
    'productHirearchy',//new
    'endUserCountry',//new
    'configurationType',//new
    'valveType',//new
    'endUserType',//new
    'taskFamily',//new
    'bomType',//new
    'actDescription',//new
    'cyberPlanDate',//new
    'enggCommitmentDate',//new
    'finalDate',//new
    'inputComments',
    'delayComments',//new
  ];
  erMasterTableData: any;
  masterData: any;
  erTotalCount = null;
  erOpenCount = null;
  erWipCount = null;
  erHoldCount = null;
  erClosedCount = null;
  filterSelectObj = [];//
  filterList = [];
  statusMaster = [];
  bomStatusMaster = [];
  plantMaster = [];
  complexityMaster = [];
  supportTeamMaster = [];
  allFiltersSelected = true;
  filterValues = {};
  isExpanded = false;
  // 
  orderNumber = null;
  soli = null;
  erNumber = null;
  tagNumber = null;
  plant = null;
  erStatus = null;
  complexity = null;
  customerName = null;
  sapHeader = null;
  sapHeaderDesc = null;
  bomCompletionstatus = null;
  //erCompletionDate = null;
  creator = null;
  reviewer = null;
  release = null;
  orderBookedDate = null;
  shipDate = null;
  bomNeedDate = null;
  enggCompletionDate = null;
  supportTeam = null;
  erRevisionNumber = null;
  costOfTheLine = null;
  itemStatusProfile = null;
  headerStatusProfile = null;
  projectManager = null;
  allowLinkAccess;
  isDataLoaded = false;
  userPlant: any;
  hideFlag: boolean = false;
  // 'Id',
  filterEntity = new MatTableDataSource<ERDashboardInterface>(ELEMENT_DATA);
  filterType = MatTableFilter.ANYWHERE;
  dataSource = new MatTableDataSource<ERDashboardInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<ERDashboardInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('erDashboard') myDashboardTable: MatTable<ERDashboardInterface>;
  @ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  selection = new SelectionModel<ERDashboardInterface>(true, []);
  //selection = new SelectionModel<ERDashboardInterface>(true, []);
  //selectedRowIndex: number;

  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder, private http: HttpClient, public router: Router,
    private element: ElementRef, public dialog: MatDialog) {
    //Get User Details Plant
    this.commonService.userDetails.subscribe(val => {
      this.userPlant = '';
      if (val['plant'] != null && val['plant'] != undefined) {
        this.userPlant = val['plant'];
      }
    });
    // 
    // subscribe to the router events
    // this.router.events.subscribe((e: any) => {
    //   // If it is a NavigationEnd event re-initalise the component
    //   if (e instanceof NavigationEnd) {
    //     this.initialiseInvites();
    //   }
    // });
    this.getMasterData();
    // this.getMasterDashboardCount(); 
    // this.getMasterDashboardHoldCount();
    //this.getMasterDashboardData();
    // Object to create Filter for
    this.filterSelectObj = [
      {
        name: 'Order Number',
        columnProp: 'orderNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Soli',
        columnProp: 'soli',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'ER Number',
        columnProp: 'erNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'Tag Number',
        columnProp: 'tagNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Plant',
        columnProp: 'plant',
        isChecked: true,
        type: 'select',
        value: '',
        options: this.plantMaster
      }, {
        name: 'ER Status',
        columnProp: 'erStatus',
        isChecked: true,
        type: 'select',
        value: '',//Default Filter
        options: this.statusMaster
      }, {
        name: 'Complexity',
        columnProp: 'complexity',
        isChecked: true,
        type: 'select',
        value: '',
        options: this.complexityMaster
      }, {
        name: 'Customer Name',
        columnProp: 'customerName',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'SAP Header',
        columnProp: 'sapHeader',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'SAP Header Desc',
        columnProp: 'sapHeaderDesc',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'BOM Status',
        columnProp: 'bomCompletionstatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: this.bomStatusMaster
      }, {
        name: 'Valve BOM - Creator',
        columnProp: 'creator',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Valve BOM - Reviewer',
        columnProp: 'reviewer',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      //New Filters START
      {
        name: 'Valve BOM - Current step',
        columnProp: 'valveBomCurrentStep',
        isChecked: true,
        type: 'select',
        value: '',
        options: this.statusMaster
      }, {
        name: 'Instrument BOM - Creator',
        columnProp: 'instrumentBomCreator',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Instrument BOM - Reviewer',
        columnProp: 'instrumentBomReviewer',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'Instrument - Current step',
        columnProp: 'instrumentBomCurrentStep',
        isChecked: true,
        type: 'select',
        value: '',
        options: this.statusMaster
      },
      //New Filters END
      {
        name: 'Released By/EPL Name',
        columnProp: 'release',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Order Booked Date',
        columnProp: 'orderBookedDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      },
      //New Filters START
      {
        name: 'Ageing',
        columnProp: 'ageing',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      //New Filters END
      {
        name: 'BOM Need Date',
        columnProp: 'bomNeedDate',//'bomNeedDate',//Need to change after api change
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      },
      {
        name: 'ER Closing Date',
        columnProp: 'enggCompletionDate',//projectManager
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      }, {
        name: 'Shipment Date',
        columnProp: 'shipDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      },
      {
        name: 'Secondary Engg. Team',
        columnProp: 'supportTeam',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      },
      //  {
      //   name: 'ER Revision No',
      //   columnProp: 'erRevisionNumber',
      //   isChecked: true,
      //   type: 'text',
      //   value: '',
      //   options: []
      // },
      // {
      //   name: 'Item Net Value (USD)',
      //   columnProp: 'costOfTheLine',
      //   isChecked: true,
      //   type: 'text',
      //   value: '',
      //   options: [],
      // }, {
      //   name: 'Item Status Profile',
      //   columnProp: 'itemStatusProfile',
      //   isChecked: true,
      //   type: 'text',
      //   value: '',
      //   options: []
      // },
      // {
      //   name: 'Header Status Profile',
      //   columnProp: 'headerStatusProfile',
      //   isChecked: true,
      //   type: 'text',
      //   value: '',
      //   options: []
      // },
      {
        name: 'Project Manager',
        columnProp: 'projectManager',//projectManager
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      // {
      //   name: 'ER Due Date(14% of Target Date)',
      //   columnProp: 'erCompletionDate',
      //   isChecked: true,
      //   type: 'date',
      //   value: '',
      //   options: []
      // },

    ]
    //
  }
  // initialiseInvites() {
  //   // Set default values and re-fetch any data you need.
  //   this.getMasterDashboardData();
  // }
  // refreshPage() {
  //   this._document.defaultView.location.reload();
  // }
  // refreshPage() {
  //   setTimeout(() => {
  //     location.reload();
  //   }, 10000);
  // }
  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }
  ngOnInit(): void {
    // this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    //this.loadDefaultFilters();
    this.allowLinkAccess = localStorage.getItem('linkAccess');
    this.commonService.currentview.next('Dashboad > My Dashboard');
    this.getMasterDashboardData();
    this.getMasterDashboardHoldCount();
    // setTimeout(() => {      
    // this.getMasterDashboardCount(); 
    // this.getMasterDashboardHoldCount();
    // }, 10000); 
    //this.createForm();
    this.disable();
    //this.dataSource.filterPredicate = this.createFilter();//
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      console.log(data);
      console.log(filter);
      let matchFound = false;
      for (let column of this.displayedColumns) {
        if (column in data) {
          if (data[column]) {
            matchFound = (matchFound || data[column].toString().trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1)
          }
        }
      }
      return matchFound;
    }
  }

  ngAfterViewInit() {
    //this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.allFiltersSelected = true;
    //this.toggleAllSelection()
  }
  resetSearchFilters() {
    this.filterSelectObj.forEach(item => {
      item.value = '';
    });
    this.search = "";
    if (this.selection) {
      this.selection.clear();
    }
    this.dataSource.filter = "";
    this.onFilterSearch();
  }
  onFilterListSelection() {
    console.log(this.filterList);
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes('all')) {
        this.filterList.push(item.columnProp);
      }
    });
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes(item.columnProp)) {
        item.isChecked = true;
      } else {
        item.isChecked = false;
      }

    });
  }
  toggleAllSelection() {
    if (this.allFiltersSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
  optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allFiltersSelected = newStatus;
  }
  openClick() {
    this.toggleAllSelection();
  }
  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }
  //
  // createForm() {
  //   this.erDashboardform = this.formBuilder.group({
  //     filterList: [''],
  //     filterConfig: [''],
  //     orderNumber: [''],
  //     soli: [''],
  //     erNumber: [''],
  //     tagNumber: [''],
  //     plant: [''],
  //     erStatus: [''],
  //     complexity: [''],
  //     customerName: [''],
  //     sapHeader: [''],
  //     sapHeaderDesc: [''],
  //     bomStatus: [''],
  //     erCompletionDate: [''],
  //     creator: [''],
  //     reviewer: [''],
  //     release: [''],
  //     orderBookedDate: [''],
  //     shipDate: [''],
  //     bomNeedDate: [''],
  //     enggCompletionDate: [''],
  //     supportTeam: [''],
  //     erRevisionNumber: [''],
  //     costOfTheLine: [''],
  //     itemStatusProfile: [''],
  //     headerStatusProfile: [''],
  //     projectManager: ['']
  //   })
  //   // const group = this.formBuilder.group({});
  //   //  filterList.forEach(element => {
  //   //   const control = this.formBuilder.control(
  //   //     element.value,
  //   //     );
  //   //     group.addControl(element.columnProp, control);
  //   //   });
  //   //   return group;
  // }
  onFilterSearch() {
    this.pageIndex = 0;
    this.onSearch();
  }
  onSearch() {
    //let formvalue = this.erDashboardform.value;
    const formData = {};
    const searchType = [];
    formData['pageNumber'] = this.pageIndex;
    formData['pageSize'] = this.pageSize;
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    this.apiMappingsService.getMasterDashboardData(formData).subscribe((data) => {
      if (data) {
        console.log(data);
        this.masterData = data;
        this.totalCount = data['totalCount'];
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        this.erMasterTableData = data['filtersData']
        this.prepareTableData(this.erMasterTableData);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }
  getMasterData() {
    // Uncomment below line of code once api is done and comment mock
    //console.log("load");
    const formData = {};
    // set Default Filters
    //formData['pageNumber']=this.pageIndex;
    //formData['erStatus'] = 'Open';
    //formData['plant'] = this.userPlant;
    //formData['searchType'] = ['erStatus', 'plant'];
    this.isDataLoaded = false;
    this.apiMappingsService.getMasterData(formData).subscribe((data) => {
      this.isDataLoaded = true;
      if (data) {
        //const data = Mock.svcGetERDashboardData;
        this.masterData = data;
        //this.erTotalCount = data['erCount'];
        this.erOpenCount = data['openCount'];
        this.erWipCount = data['wipCount'];
        //this.erHoldCount = data['holdCount'];
        this.erClosedCount = data['closedCount'];
        this.statusMaster = data['statusMaster'];
        this.bomStatusMaster = data['bomStatusMaster'];
        this.supportTeamMaster = data['supportTeamMaster'];
        this.complexityMaster = data['complexityMaster'];
        this.plantMaster = data['plantMaster'];
        // this.erMasterTableData = data['filtersData']
        // this.setDefaultFilters();
        // this.prepareTableData(this.erMasterTableData);
        //this.ngAfterViewInit();
      }
    });
  }
  //getMasterDashboardCount
  getMasterDashboardCount() {
    this.apiMappingsService.getMasterDashboardCount().subscribe((data) => {
      this.isDataLoaded = true;
      if (data) {
        this.erTotalCount = data['erCount'];
      }
    });
  }
  //getMasterDashboardHoldCount
  getMasterDashboardHoldCount() {
    this.apiMappingsService.getMasterDashboardHoldCount().subscribe((data) => {
      this.isDataLoaded = true;
      if (data) {
        this.erHoldCount = data['holdCount'];
      }
    });
  }
  getMasterDashboardData() {
    const formData = {};
    formData['pageNumber'] = this.pageIndex;
    formData['pageSize'] = this.pageSize;
    //formData['erStatus'] = 'Open';
    //formData['plant'] = this.userPlant;
    //formData['plant'] = this.userPlant;
    //formData['searchType'] = ['plant'];
    this.isDataLoaded = false;
    this.apiMappingsService.getMasterDashboardData(formData).subscribe((data) => {
      this.isDataLoaded = true;
      if (data) {
        //const data = Mock.svcGetERDashboardData;
        // this.masterData = data;
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        // this.statusMaster = data['statusMaster'];
        // this.bomStatusMaster = data['bomStatusMaster'];
        // this.supportTeamMaster = data['supportTeamMaster'];
        this.erMasterTableData = data['filtersData'];
        this.totalCount = data['totalCount'];
        //this.setDefaultFilters();
        this.prepareTableData(this.erMasterTableData);
        //this.ngAfterViewInit();
      }
    });
  }
  // setDefaultFilters() {
  //   this.filterSelectObj.forEach(field => {
  //     if (field.columnProp == 'erStatus') {
  //       field.value = 'Open'
  //     }
  //     if (field.columnProp == 'plant') {
  //       field.value = this.userPlant;
  //     }
  //   }
  //   );
  // }
  prepareTableData(erMasterTableData) {
    ELEMENT_DATA = [];
    erMasterTableData.forEach(erMaster => {
      ELEMENT_DATA.push({
        orderNumber: erMaster.orderNumber,
        soli: erMaster.soli,
        erNumber: erMaster.erNumber,
        tagNumber: erMaster.tagNumber,
        plant: erMaster.plant,
        erStatus: erMaster.erStatus,
        complexity: erMaster.complexity,
        customerName: erMaster.customerName,
        sapHeader: erMaster.sapHeader,
        sapHeaderDesc: erMaster.sapHeaderDesc,
        bomCompletionstatus: erMaster.bomCompletionstatus,
        //erCompletionDate: erMaster.erCompletionDate,//this.dateFormatter(erMaster.calculated14Percent),//
        creator: erMaster.creator,
        reviewer: erMaster.reviewer,
        release: erMaster.release,
        orderBookedDate: erMaster.orderBookedDate,//this.dateFormatter(erMaster.orderBookedDate),//
        shipDate: erMaster.shipDate,//this.dateFormatter(erMaster.shipDate),//
        bomNeedDate: erMaster.bomNeedDate,//this.dateFormatter(erMaster.bomNeedDate),//
        enggCompletionDate: erMaster.enggCompletionDate,//this.dateFormatter(erMaster.enggCompletionDate),//
        supportTeam: erMaster.supportTeam,
        erRevisionNumber: erMaster.erRevisionNumber,
        costOfTheLine: erMaster.costOfTheLine,
        itemStatusProfile: erMaster.itemStatusProfile,
        headerStatusProfile: erMaster.headerStatusProfile,
        projectManager: erMaster.projectManager,
        allowAccess: this.commonService.checkAccess(erMaster.plant),
        generalComments: erMaster.generalComments,
        preConfigId: erMaster.preConfigId
      });
      // id: erRequest.id,
    });
    this.dataSource.data = ELEMENT_DATA;
    // 
    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(ELEMENT_DATA, o.columnProp);
    });
    // 
  }

  checkAccess(plant) {
    let hasAdminRole = localStorage.getItem("hasAdminRole");
    let userPlant = localStorage.getItem("userPlant");
    let siteAdminPlantCode = localStorage.getItem('siteAdminPlantCode');
    let allowAccess = 'false';
    if (hasAdminRole == 'false') {
      if (this.allowLinkAccess == 'true') {
        //allowAccess = 'true';
        if (plant != null) {
          if (userPlant == plant) {
            allowAccess = 'true';
          } else {
            allowAccess = 'false';
          }
        }
      }
    } else if (hasAdminRole == 'true') {
      allowAccess = 'true';
      if (siteAdminPlantCode != null) {
        if (siteAdminPlantCode == plant) {
          allowAccess = 'true';
        } else {
          allowAccess = 'false';
        }
      }
    }
    return allowAccess;
  }
  // 
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);

  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      console.log(searchTerms);

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }


  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }
  // 
  dateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      //const result = this.datePipe.transform(new Date(value * 1000));
      const result = new Date(value * 1000);
      //console.log(result);
      return result;
    }
  }
  onSearchERRequest(event: Event) {
    this.selection.clear();
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  disable() {
    let roles = JSON.parse(localStorage.getItem("roles"));
    let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Tool Administrator')
    if (roles && roles.length > 0) {
      if ((role && role.length > 0)) {
        this.hideFlag = false;
      } else {
        this.hideFlag = true;
      }
    } else {
      this.hideFlag = true;
    }
  }

  massUpdateResource(data: any) {
    let plant = _.uniqBy(data, 'plant');
    if (plant && plant.length > 1) {
      this.bhAlertService.showAlert('warning', 'top', 5000, 'Multiple Plants are selected. Please check once!');
    } else {
      this.massUpdateModal = this.dialog.open(MassUpdateModalComponent, { data: { massUpdateData: data } });
      this.massUpdateModal.afterClosed().subscribe(value => {
        this.selection.clear();
        //this.getMasterDashboardData();
        this.onSearch();
      });
    }
  }

  massUpdateComments(data: any) {
    let plant = _.uniqBy(data, 'plant');
    if (plant && plant.length > 1) {
      this.bhAlertService.showAlert('warning', 'top', 5000, 'Multiple Plants are selected. Please check once!');
    } else {
      this.massUpdateCommentsModal = this.dialog.open(MassUpdateCommentsComponent, { data: { massUpdateData: data } });
      this.massUpdateCommentsModal.afterClosed().subscribe(value => {
        this.selection.clear();
        this.getMasterDashboardData();
      });
    }
  }
  // Mass Reopen
  massReopen(data: any) {
    let plant = _.uniqBy(data, 'plant');
    let sapHoldData = data.filter(item => item.erStatus === 'Sap Hold');
    if (plant && plant.length > 1) {
      this.bhAlertService.showAlert('warning', 'top', 5000, 'Multiple Plants not allowed! Please select single plant at a time');
    } else if (sapHoldData && sapHoldData.length > 0) {
      this.massReopenModal = this.dialog.open(MassReopenModelComponent, { data: { massUpdateData: sapHoldData } });
      this.massReopenModal.afterClosed().subscribe(value => {
        this.selection.clear();
        this.getMasterDashboardData();
      });
    } else {
      this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select SAP-HOLD status sale-orders for Reopening');
    }
  }
  //
  masterToggle() {
    let data = this.dataSource.data;
    if (this.search) {
      data = this.dataSource.filteredData;
    }
    data = data.filter((row: any) => row.allowAccess === "true")
    console.log(this.isAllSelected());
    this.isAllSelected() ?
      this.selection.clear() :
      data.forEach(row => (this.selection.select(row)));
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    let data = this.dataSource.data;
    if (this.search) {
      data = this.dataSource.filteredData;
    }
    data = data.filter((row: any) => row.allowAccess === "true")
    const numRows = data.length;
    return numSelected === numRows;
  }

  checkboxLabel(row?: ERDashboardInterface): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'}`;
  }
  //'soLi', element.orderNumber, element.erNumber, element.soli
  productHierarchyValidation(element) {
    this.apiMappingsService.getProductHierarchyData(element.soli).subscribe((data) => {
      if (data && data['productHierarchy'] === false) {
        const message = data['info'];
        const dialogData = new ConfirmDialogModel("Confirm Action on Product Hierarchy", message);
        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: dialogData
        });
        dialogRef.afterClosed().subscribe(dialogResult => {
          if (dialogResult === true) {
            this.onClickWorkFLowRedirection('soLi', element.orderNumber, element.erNumber, element.soli);
          }
        });
      } else if (data && data['productHierarchy'] === true) {
        this.onClickWorkFLowRedirection('soLi', element.orderNumber, element.erNumber, element.soli);
      }
    });
  }

  onClickWorkFLowRedirection(navItem: any, saleOrder: any, erNumber: any, soLiNumber: any) {
    this.commonService.saleOrderNumber.next('');
    this.commonService.erNumber.next('');
    sessionStorage.setItem('erNumber', '');
    sessionStorage.setItem('soLiNumber', '');
    sessionStorage.setItem('cloneER', '');
    sessionStorage.setItem('task', '');
    // localStorage.setItem('preConfigId', '');
    if (Helpers.isLowerCaseEquals(navItem, 'soLi')) {
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.saleOrderNumber.next(saleOrder);
      this.commonService.soLiNumber.next(soLiNumber);
      sessionStorage.setItem('saleOrderNumber', saleOrder);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      //
      //this.commonService.setERInfo(soLiNumber);
      //  this.router.navigate([this.navRoute], {
      //     state: { example: 'data' }}
      //     );
      window.open(`${location.origin}${location.pathname}#/${this.navRoute}`, '_blank');

      //  this.router.navigate([]).then(result => {  window.open( this.navRoute, '_blank'); });
      // let url =  this.router.navigate([this.navRoute]);
      //  window.open( url, '_blank');
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
      // this.navRoute = 'enggTool/preConfig';
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.erNumber.next(erNumber);
      sessionStorage.setItem('erNumber', erNumber);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      // this.router.navigate([this.navRoute]);//For Same tab
      window.open(`${location.origin}${location.pathname}#/${this.navRoute}`, '_blank');
      // this.isSchedulingAndPlanningDone(erNumber);
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    }
  }

  isSchedulingAndPlanningDone(erNumber: any) {
    let preConfidId = erNumber.split("-").pop();
    this.apiMappingsService.isSchedulingAndPlanningDone(preConfidId).subscribe((data: any) => {
      if (data) {
        sessionStorage.setItem('EnableTabs', data);
      }
    });
  }
  ///Pagenation
  public changePage(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.onSearch();
  }

  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("erDashboard");
  }
  exportArray() {
    const formData = {};
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    this.apiMappingsService.getMasterDashboardExcelData(formData).subscribe((data) => {
      if (data) {
        const excelData = data['filtersData']
        const onlyNameAndSymbolArr: Partial<ERDashboardInterface>[] = excelData.map(erMaster => ({
          // const onlyNameAndSymbolArr: Partial<ERDashboardInterface>[] = this.erMasterTableData.map(erMaster => ({
          orderNumber: erMaster.orderNumber,
          soli: erMaster.soli,
          erNumber: erMaster.erNumber,
          erRevisionNumber: erMaster.erRevisionNumber,
          tagNumber: erMaster.tagNumber,
          plant: erMaster.plant,
          erStatus: erMaster.erStatus,
          complexity: erMaster.complexity,
          customerName: erMaster.customerName,
          sapHeader: erMaster.sapHeader,
          sapHeaderDesc: erMaster.sapHeaderDesc,
          bomStatus: erMaster.bomCompletionstatus,
          //erCompletionDate: this.dateFormatter(erMaster.erCompletionDate),//erCompletionDate,
          valve_BOM_Creator: erMaster.creator,
          valve_BOM_Reviewer: erMaster.reviewer,
          valveBomCurrentStep: '',//new
          valveBomCreationDate: '',//new
          valveBomReviwerDate: '',//new
          instrumentBomCreator: '',//new
          instrumentBomReviewer: '',//new
          instrumentBomCurrentStep: '',//new
          instrumentBomCreationDate: '',//new
          instrumentBomReviwerDate: '',//new
          releasedBy_EPLname: erMaster.release,
          orderBookedDate: this.dateFormatter(erMaster.orderBookedDate),//orderBookedDate,
          ageing: '',//new
          preConfCompletionDate: '',//new
          bomNeedDate: this.dateFormatter(erMaster.bomNeedDate),
          erClosingDate: this.dateFormatter(erMaster.enggCompletionDate),//enggCompletionDate,
          shipDate: this.dateFormatter(erMaster.shipDate),//shipDate,
          bomScoreCard: '',//new
          designScoreCard: '',//new
          npcScoreCard: '',//new
          enggDocScoreCard: '',//new
          QualityDocScoreCard: '',//new
          secondary_Engg_Team: erMaster.supportTeam,
          itemNetValue_USD: erMaster.costOfTheLine,
          itemStatusProfile: erMaster.itemStatusProfile,
          headerStatusProfile: erMaster.headerStatusProfile,
          projectManager: erMaster.projectManager,
          productHirearchy: '',//new
          endUserCountry: '',//new
          configurationType: '',//new
          valveType: '',//new
          endUserType: '',//new
          taskFamily: '',//new
          bomType: '',//new
          actDescription: '',//new
          cyberPlanDate: '',//new
          enggCommitmentDate: '',//new
          finalDate: '',//new
          input_Comments: erMaster.generalComments,
          delayComments: ''//new
        }));
        ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "Master Dashboard");
        //F&PT_MasterDashboardData
      }
    });
  }
}

export interface ERDashboardInterface {
  orderNumber: string;
  soli: string;
  erNumber: string;
  tagNumber: string;
  plant: string;
  erStatus: string;
  complexity: string;
  customerName: string;
  sapHeader: string;
  sapHeaderDesc: string;
  bomCompletionstatus: string;
  //erCompletionDate: any;
  creator: string;
  reviewer: string;
  release: string;
  orderBookedDate: any;
  shipDate: any;
  bomNeedDate: any;
  enggCompletionDate: any;
  supportTeam: string;
  erRevisionNumber: number;
  costOfTheLine: number;
  itemStatusProfile: string;
  headerStatusProfile: string;
  projectManager: string,
  allowAccess: any;
  generalComments: any;
  preConfigId: any;

}
let ELEMENT_DATA: ERDashboardInterface[] = [];

export interface massUpdateData {
  animal: string;
  name: string;
}