import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErDashboardComponent } from './er-dashboard.component';

describe('ErDashboardComponent', () => {
  let component: ErDashboardComponent;
  let fixture: ComponentFixture<ErDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
