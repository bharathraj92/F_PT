import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NpcForceCloseComponent } from '../npc-force-close/npc-force-close.component';
import { AddNPcModalComponent } from '../add-npc-modal/add-npc-modal.component';

@Component({
  selector: 'app-npc-dashboard',
  templateUrl: './npc-dashboard.component.html',
  styleUrls: ['./npc-dashboard.component.scss']
})
export class NpcDashboardComponent implements OnInit {
  pageIndex: number = 0;///Pagination
  pageSize: number = 100;///
  totalCount: number;///
  npcDashboardform: FormGroup;
  soLiList: any;
  complexityList: any;
  statusList: any;
  activityList: any;
  navRoute: any;
  datePipe = new DatePipe("en-US");
  npcCategoryList: any;
  npcComponentList: any;
  filteredOptions: any;
  search: any = "";
  accessCheck;
  //filterEntity: NpcDashboardInterface;//FilterNew
  //filterType: MatTableFilter;
  displayedColumns: string[] = [
    'saleOrder',
    'soli',
    'forceClose',
    'editNPC',
    'npcNumber',
    'plant',
    'plantCode',
    'partNumber',
    'dwgHeader',
    'npcWorkFlowStatus',
    'department',//NPC Part Status
    'sapMaterialStatus',//NPC Part Status
    'sapDistributionMaterialStatus',//NPC Part Status
    'plantSpecificMaterialStatus',//NPC Part Status
    'procurementType',//NPC Part Status
    'holdFlag',
    'holdComments',
    'requestedDate',
    'targetDate',
    'completedDate',
    'creator',
    'reveiwer',
    'releasedBy',
    'projectManager',
    'generalComments',
    'mcodeDesc',
    'mcode',
    'npcSubCategory',
    'subLevelComponent',
    'drawingNumber',
    'orphanFlag',
    //'qcode',
    'ecmNumber',
    //NPC Part Status Addition fields
    'enggStartDate',
    'enggCompletedDate',
    'enggAging',
    'planningStartDate',
    'planningCompletedDate',
    'planningAging',
    'qualityStartDate',
    'qualityCompletedDate',
    'qualityAging',
    'sourcingStartDate',
    'sourcingCompletedDate',
    'sourcingAging',
    'manufacturingStartDate',
    'manufacturingCompletedDate',
    'manufacturingAging',
    'financeStartDate',
    'financeCompletedDate',
    'financeAging',
    //'enggCoordinator',
    'enggCoordinatorName',
    'sapErrorStatus'
  ];
  logginUserFirstName: any;
  currentDate: Date;
  npcDashboardTableData: any;
  masterData: any;
  erTotalCount = null;
  erOpenCount = null;
  erWipCount = null;
  erHoldCount = null;
  erClosedCount = null;
  filterSelectObj = [];//
  filterList = [];
  statusMaster = [];
  //taskList =[];
  //subTaskList =[];
  //roleNameList =[];
  //filteredSubTask :any;
  supportTeamMaster = [];
  allFiltersSelected = true;
  filterValues = {};
  isExpanded = true;
  // 
  npcWorkFlowStatus = null;
  //orderNumber = null;
  soli = null;
  npcNumber = null;
  mcode = null;
  //qcode = null;
  partNumber = null;
  projectManager = null;
  plant = null;
  complexity = null;
  customerName = null;
  sapHeader = null;
  sapHeaderDesc = null;
  erStatus = null;
  erCompletionDate = null;
  creator = null;
  reviewer = null;
  release = null;
  orderBookedDate = null;
  shipDate = null;
  enggCompletionDate = null;
  supportTeam = null;
  erRevisionNumber = null;
  costOfTheLine = null;
  disableForceClosureFlag: boolean;
  editOrphanNPCFlag: boolean;
  disableNPCFlag: boolean;
  enggBlocks = null;
  plantTypeList: any;
  plantMaster = [];
  // 'Id',
  filterEntity = new MatTableDataSource<NpcDashboardInterface>(ELEMENT_DATA);
  filterType = MatTableFilter.ANYWHERE;
  dataSource = new MatTableDataSource<NpcDashboardInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<NpcDashboardInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('npcDashboard') npcDashboardTable: MatTable<NpcDashboardInterface>;
  @ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  ChildErForceClosureModal: MatDialogRef<NpcForceCloseComponent>;
  AddNPcModal: MatDialogRef<AddNPcModalComponent>;

  routesArray = [{ task: "PRECONFIG", route: "enggTool/preConfig" }, { task: "BOMCONFIG", route: "enggTool/bomConfig" },
  { task: "DESIGN", route: "enggTool/bomConfig" }, { task: "NPC", route: "enggTool/bomConfig" },
  { task: "Calculation", route: "enggTool/configuration" }, { task: "Tests", route: "enggTool/configuration" },
  { task: "External Deliverables", route: "enggTool/configuration" }, { task: "Other Engg Activities", route: "enggTool/configuration" },
  { task: "Quality Activities", route: "enggTool/qualityDoc" }]
  departmentMaster: any;
  plantSpecificMaterialStatusMaster: any;
  procurementTypeMaster: any;
  sapDistributionMaterialStatusMaster: any;
  sapMaterialStatusMaster: any;
  orphanFlagMaster: any;
  erToolUser: string;

  //selection = new SelectionModel<NpcDashboardInterface>(true, []);
  //selectedRowIndex: number;

  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder, private http: HttpClient, public router: Router, private element: ElementRef, public dialog: MatDialog) {
    // 
    this.commonService.userDetails.subscribe(val => {
      this.logginUserFirstName = val['firstName'];
      this.currentDate = new Date();
      this.erToolUser = localStorage.getItem("erToolUser");
    });
    this.getPreConfigMasterData();
    this.getNpcDashboardMasterData();
    //this.getNpcDashboardData();
    // Object to create Filter for
    this.filterSelectObj = [
      {
        name: 'Sale Order',
        columnProp: 'saleOrder',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'Soli',
        columnProp: 'soli',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'NPC ER Number',
        columnProp: 'npcNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Plant',
        columnProp: 'plant',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Part Number',
        columnProp: 'partNumber',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'NPC WorkFlow Status',
        columnProp: 'npcWorkFlowStatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Current Department',
        columnProp: 'department',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'SAP Material Status',
        columnProp: 'sapMaterialStatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'SAP Dist.Mat.Status',
        columnProp: 'sapDistributionMaterialStatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Plant Spec.Mat.Status',
        columnProp: 'plantSpecificMaterialStatus',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Procurement Type',
        columnProp: 'procurementType',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Requested Date',
        columnProp: 'requestedDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      }, {
        name: 'Target Date',
        columnProp: 'targetDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      }, {
        name: 'Completed Date',
        columnProp: 'completedDate',
        isChecked: true,
        type: 'date',
        value: '',
        options: []
      }, {
        name: 'Creator',
        columnProp: 'creator',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Reveiwer',
        columnProp: 'reveiwer',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'Released By',
        columnProp: 'releasedBy',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      },
      {
        name: 'Project Manager',
        columnProp: 'projectManager',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'M-Code',
        columnProp: 'mcode',
        isChecked: true,
        type: 'text',
        value: '',
        options: []
      }, {
        name: 'NPC Category',
        columnProp: 'npcSubCategory',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'NPC Component',
        columnProp: 'subLevelComponent',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }, {
        name: 'Orphan',
        columnProp: 'orphanFlag',
        isChecked: true,
        type: 'select',
        value: '',
        options: []
      }
    ]
  }

  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }
  ngOnInit(): void {
    this.accessCheck = localStorage.getItem('allowAccess');
    this.commonService.currentview.next('Dashboad > NPC Dashboard');
    this.getNpcDashboardData();
    this.enableForceClosure();
    this.createForm();
    //this.dataSource.filterPredicate = this.createFilter();//
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      console.log(data);
      console.log(filter);
      let matchFound = false;
      for (let column of this.displayedColumns) {
        if (column in data) {
          if (data[column]) {
            matchFound = (matchFound || data[column].toString().trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1)
          }
        }
      }
      return matchFound;
    }
  }
  //common options
  getPreConfigMasterData() {
    //const data = CommonMock.commonOptionData;
    this.apiMappingsService.getPreConfigMasterData().subscribe((data: []) => {
      if (data) {
        this.npcCategoryList = data['npcSubCategory'];
        this.npcComponentList = data['npcSubComponent'];
        this.filteredOptions = this.npcComponentList;
        //this.plantTypeList = data['supportTeam'];
        this.plantMaster = data['plantMaster'];
      }
    });
  }
  ngAfterViewInit() {
    ///this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.allFiltersSelected = true;
    //this.toggleAllSelection()
  }
  resetSearchFilters() {
    this.filterSelectObj.forEach(item => {
      item.value = '';
    });
    this.search = "";
    this.dataSource.filter = "";
    this.onFilterSearch();
  }
  onFilterListSelection() {
    console.log(this.filterList);
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes('all')) {
        this.filterList.push(item.columnProp);
      }
    });
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes(item.columnProp)) {
        item.isChecked = true;
      } else {
        item.isChecked = false;
      }

    });
  }
  toggleAllSelection() {
    if (this.allFiltersSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
  optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allFiltersSelected = newStatus;
  }
  openClick() {
    this.toggleAllSelection();
  }
  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }
  // updateList(value) {
  //   console.log(value);
  //   this.filteredSubTask = this.subTaskList;
  //   this.filteredSubTask = this.subTaskList.filter(option => option.toLowerCase().includes(value));
  //   console.log(this.filteredSubTask);
  //   //this.filteredOptions = rfilteredOptions;
  // }
  //
  createForm() {
    this.npcDashboardform = this.formBuilder.group({
      filterList: [''],
      filterConfig: [''],
      npcWorkFlowStatus: [''],
      saleOrder: [''],
      soli: [''],
      npcNumber: [''],
      drawingNumber: [''],
      orphanFlag: [''],
      dwgHeader: [''],
      mcode: [],
      //qcode: [''],
      partNumber: [''],
      projectManager: [''],
      mcodeDesc: [''],
      npcSubCategory: [''],
      subLevelComponent: [''],
      creator: [''],
      reveiwer: [''],
      releasedBy: [''],
      plant: ['']
    })
    // const group = this.formBuilder.group({});
    //  filterList.forEach(element => {
    //   const control = this.formBuilder.control(
    //     element.value,
    //     );
    //     group.addControl(element.columnProp, control);
    //   });
    //   return group;
  }
  onFilterSearch() {
    this.pageIndex = 0;
    this.onSearch();
  }
  onSearch() {
    let formvalue = this.npcDashboardform.value;
    const formData = {};
    formData['pageNumber'] = this.pageIndex;///
    formData['pageSize'] = this.pageSize;///
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    console.log(formData);
    this.apiMappingsService.getNpcDashboardData(formData).subscribe((data) => {
      if (data) {
        console.log(data);
        this.masterData = data;
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        this.totalCount = data['totalCount'];
        this.npcDashboardTableData = data['filtersData']
        this.prepareTableData(this.npcDashboardTableData);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }
  //NPC Component filter options
  updateList(value) {
    this.filteredOptions = this.npcComponentList;
    this.filteredOptions = this.npcComponentList.filter(option => option.levelName.toLowerCase().includes(value));
  }


  getNpcDashboardMasterData() {
    // Uncomment below line of code once api is done and comment mock
    this.apiMappingsService.getNpcDashboardMasterData({}).subscribe((data) => {
      if (data) {
        //const data = Mock.svcGetNpcDashboardData;
        //this.masterData = data['filtersData'];
        this.erTotalCount = data['erCount'];
        this.erOpenCount = data['openCount'];
        this.erWipCount = data['wipCount'];
        this.erHoldCount = data['holdCount'];
        this.erClosedCount = data['closedCount'];
        this.statusMaster = data['statusMaster'];
        //        
        this.departmentMaster = data['departmentMaster'];
        this.plantSpecificMaterialStatusMaster = data['plantSpecificMaterialStatusMaster'];
        this.procurementTypeMaster = data['procurementTypeMaster'];
        this.sapDistributionMaterialStatusMaster = data['sapDistributionMaterialStatusMaster'];
        this.sapMaterialStatusMaster = data['sapMaterialStatusMaster'];
        //this.taskList = data['taskMaster'];
        //this.subTaskList = data['subTaskMaster'];
        //this.filteredSubTask = data['subTaskMaster'];
        //this.roleNameList =data['roleNameMaster'];
        //this.supportTeamMaster = data['supportTeamMaster'];
        ///this.npcDashboardTableData = data['filtersData']
        ///this.prepareTableData(this.npcDashboardTableData);
      }
    });
  }
  getNpcDashboardData() {
    // Uncomment below line of code once api is done and comment mock
    this.apiMappingsService.getNpcDashboardData({}).subscribe((data) => {
      if (data) {
        //const data = Mock.svcGetNpcDashboardData['NpcDashboardData'];//Mock Data
        this.masterData = data['filtersData'];
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        // this.statusMaster = data['statusMaster'];
        //this.taskList = data['taskMaster'];
        //this.subTaskList = data['subTaskMaster'];
        //this.filteredSubTask = data['subTaskMaster'];
        //this.roleNameList =data['roleNameMaster'];
        //this.supportTeamMaster = data['supportTeamMaster'];
        this.totalCount = data['totalCount'];
        this.npcDashboardTableData = data['filtersData']
        this.prepareTableData(this.npcDashboardTableData);
      }
    });
  }

  prepareTableData(npcDashboardTableData) {
    ELEMENT_DATA = [];
    npcDashboardTableData.forEach(npcDashboard => {
      ELEMENT_DATA.push({
        preConfigId: npcDashboard.parentId,
        npcWorkFlowStatus: npcDashboard.npcWorkFlowStatus,
        saleOrder: npcDashboard.saleOrder,
        soli: npcDashboard.soli,
        npcNumber: npcDashboard.npcNumber,
        drawingNumber: npcDashboard.drawingNumber,
        dwgHeader: npcDashboard.dwgHeader,
        mcode: npcDashboard.mcode,
        roleId: npcDashboard.roleId,
        qcode: npcDashboard.qcode,
        partNumber: npcDashboard.partNumber,
        sapMaterialStatus: npcDashboard.sapMaterialStatus,//NPC Part Status
        sapDistributionMaterialStatus: npcDashboard.sapDistributionMaterialStatus,//NPC Part Status
        plantSpecificMaterialStatus: npcDashboard.plantSpecificMaterialStatus,//NPC Part Status
        procurementType: npcDashboard.procurementType,//NPC Part Status
        department: npcDashboard.department,//NPC Part Status
        projectManager: npcDashboard.projectManager,
        mcodeDesc: npcDashboard.mcodeDesc,
        npcSubCategory: npcDashboard.npcSubCategory,
        subLevelComponent: npcDashboard.subLevelComponent,
        creator: npcDashboard.creator,
        reveiwer: npcDashboard.reveiwer,
        releasedBy: npcDashboard.releasedBy,
        holdFlag: npcDashboard.holdFlag,
        holdComments: npcDashboard.holdComments,
        generalComments: npcDashboard.generalComments,
        id: npcDashboard.id,
        allowAccess: this.commonService.checkAccess(npcDashboard.plantCode),//this.accessCheck,
        orphanFlag: npcDashboard.orphanFlag,
        npcSubCategoryId: npcDashboard.npcSubCategoryId,
        npcComponentId: npcDashboard.subLevelComponentId,
        //enggCoordinator: npcDashboard.enggCoordinator,
        ecmNumber: npcDashboard.ecmNumber,
        formattedtargetDate: this.dateFormatter(npcDashboard.targetDate),
        formattedcompletedDate: this.dateFormatter(npcDashboard.completedDate),
        formattedrequestedDate: this.dateFormatter(npcDashboard.requestedDate),
        status: npcDashboard.status,
        plant: npcDashboard.plant,
        plantCode: npcDashboard.plantCode,
        allowEdit: this.commonService.checkEditAccess(npcDashboard.plantCode),
        //allowEdit: 'true',
        allowForceClose: this.commonService.allowForceClose(npcDashboard.plant),
        //NPC Part Status Addition fields//START
        //enggStartDate: this.dateFormatter(npcDashboard.enggStartDate),
        enggStartDate: npcDashboard.enggStartDate,
        enggCompletedDate: npcDashboard.enggCompletedDate,
        enggAging: npcDashboard.enggAging,
        planningStartDate: npcDashboard.planningStartDate,
        planningCompletedDate: npcDashboard.planningCompletedDate,
        planningAging: npcDashboard.planningAging,
        qualityStartDate: npcDashboard.qualityStartDate,
        qualityCompletedDate: npcDashboard.qualityCompletedDate,
        qualityAging: npcDashboard.qualityAging,
        sourcingStartDate: npcDashboard.sourcingStartDate,
        sourcingCompletedDate: npcDashboard.sourcingCompletedDate,
        sourcingAging: npcDashboard.sourcingAging,
        manufacturingStartDate: npcDashboard.manufacturingStartDate,
        manufacturingCompletedDate: npcDashboard.manufacturingCompletedDate,
        manufacturingAging: npcDashboard.manufacturingAging,
        financeStartDate: npcDashboard.financeStartDate,
        financeCompletedDate: npcDashboard.financeCompletedDate,
        financeAging: npcDashboard.financeAging,
        enggCoordinatorFirstName: npcDashboard.enggCoordinatorFirstName,
        enggCoordinatorLastName: npcDashboard.enggCoordinatorLastName,
        enggCoordinatorName: npcDashboard.enggCoordinatorName,
        sapErrorStatus: npcDashboard.sapErrorStatus
        //NPC Part Status Addition fields//END
      });
      // id: erRequest.id,

      // 'reveiwer',    'releasedBy',
    });
    this.dataSource.data = ELEMENT_DATA;
    // 
    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(ELEMENT_DATA, o.columnProp);
    });
    // 
  }
  // 
  //// 
  //  checkAccess(plant) {
  //   let isAdmin = localStorage.getItem("admin");
  //   let siteAdminPlantCode = localStorage.getItem('siteAdminPlantCode');
  //   let allowAccess = 'false';
  //   if (isAdmin == 'false') {
  //     if (this.accessCheck == 'true') {
  //       allowAccess = 'true';
  //       if (siteAdminPlantCode != null && siteAdminPlantCode == plant) {
  //         allowAccess = 'true';
  //       } else {
  //         allowAccess = 'false';
  //       }
  //     }
  //     }else if(isAdmin == 'true')
  //     {
  //       allowAccess = 'true';
  //     }
  //     return allowAccess;
  //   } 
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);

  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      console.log(searchTerms);

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }


  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }
  // 
  dateFormatter(value) {
    if (value && value != null) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy hh:mm a');
      return result;
    }
  }
  //excel Date Formatter
  excelDateFormatter(value) {
    if (value && value != null) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      //const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');//String
      const result = new Date(value * 1000);
      return result;
    }
  }
  onSearchERRequest(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  enableForceClosure() {
    let roles = JSON.parse(localStorage.getItem("roles"));
    let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Tool Administrator' ||obj.roleId == 9)//9-NPC Approver Engineering)//|| obj.roleName == 'NPC Approver'
    if ((role && role.length > 0)) {
      this.disableNPCFlag = false;
    } else {
      this.disableNPCFlag = true;
    }
  }

  openDilaog(data: any) {
    // let obj={
    //   "preConfigId": data['preConfigId'],
    //   "reviewerId": data['reviewerId'],
    //   "npcId":data['id'],
    //   "task": 'NPC'
    // }
    // let masterERData: any[]=[];
    // this.apiMappingsService.getChildERData(obj).subscribe((MasterData: any) => {
    //   masterERData=MasterData['childERPreConfigData'];
    //   this.ChildErForceClosureModal = this.dialog.open(NpcForceCloseComponent, { data: { erData: data , masterData: masterERData} });
    // });
    this.ChildErForceClosureModal = this.dialog.open(NpcForceCloseComponent, { data: { erData: data } });
    this.ChildErForceClosureModal.afterClosed().subscribe(value => {
      this.resetSearchFilters();
      this.getNpcDashboardData();
      this.getNpcDashboardMasterData();
    });
  }

  onClickWorkFLowRedirection(navItem: any, saleOrder: any, npcNumber: any, soLiNumber: any, task: any, subTask: any, preConfigId: any, npcId: any, element: any) {
    if (element.orphanFlag && element.orphanFlag == true) {
      this.editNPC(element, true);
    } else {
      this.commonService.saleOrderNumber.next('');
      this.commonService.erNumber.next('');
      sessionStorage.setItem('erNumber', '');
      sessionStorage.setItem('soLiNumber', '');
      if (Helpers.isLowerCaseEquals(navItem, 'soLi')) {
        this.navRoute = 'enggTool/summaryInfo';
        this.commonService.saleOrderNumber.next(saleOrder);
        sessionStorage.setItem('saleOrderNumber', saleOrder);
        sessionStorage.setItem('soLiNumber', soLiNumber);
        let task = this.routesArray.filter(item => item.task == task);
        let row = this.routesArray.filter(item => item.task == task);
        if (row && row.length > 0) {
          //this.router.navigate([row[0].route]);
          //New Tab
        window.open(`${location.origin}${location.pathname}#/${row[0].route}`, '_blank');
        }
        //ActivitiTree Data
        if (soLiNumber) {
          this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
            if (data) {
              //this.commonService.activitiTreeData.next(data);
              sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
            }
          });
        }
      } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
        // this.navRoute = 'enggTool/preConfig';
        this.navRoute = 'enggTool/summaryInfo';
        this.commonService.erNumber.next(npcNumber);
        sessionStorage.setItem('erNumber', npcNumber);
        sessionStorage.setItem('soLiNumber', soLiNumber);
        sessionStorage.setItem('preConfigId', preConfigId);
        sessionStorage.setItem('npcId', npcId);
        sessionStorage.setItem('navigateFromNPCDashboard', "true");
        let row = this.routesArray.filter(item => item.task == task);
        if (row && row.length > 0) {
          sessionStorage.setItem("subTask", subTask);
          sessionStorage.setItem("task", task);
          //this.router.navigate([row[0].route]);
          //New Tab
        window.open(`${location.origin}${location.pathname}#/${row[0].route}`, '_blank');
        }
        //ActivitiTree Data
        if (soLiNumber) {
          this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
            if (data) {
              //this.commonService.activitiTreeData.next(data);
              sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
            }
          });
        }
      }
    }
  }

  // Add New NPC
  addNPC() {
    this.AddNPcModal = this.dialog.open(AddNPcModalComponent, { data: { npcData: {}, edit: false, disabled: false } });
    this.AddNPcModal.afterClosed().subscribe(value => {
      this.resetSearchFilters();
      this.getNpcDashboardData();
      this.getNpcDashboardMasterData();
    });
  }

  // edit New NPC
  editNPC(element: any, disabled: any) {
    this.AddNPcModal = this.dialog.open(AddNPcModalComponent, { data: { npcData: element, edit: true, disabled: true } });
    this.AddNPcModal.afterClosed().subscribe(value => {
      this.resetSearchFilters();
      this.getNpcDashboardData();
      this.getNpcDashboardMasterData();
    });
  }
  ///Pagenation
  public changePage(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.onSearch();
  }
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("npcDashboard");
  }
  exportArray() {
    const formData = {};
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    this.apiMappingsService.getNpcDashboardExcelData(formData).subscribe((data) => {
      if (data) {
        const excelData = data['filtersData']
        const onlyNameAndSymbolArr: Partial<NpcDashboardInterface>[] = excelData.map(npcDashboard => ({
          //const onlyNameAndSymbolArr: Partial<NpcDashboardInterface>[] = this.npcDashboardTableData.map(npcDashboard => ({
          saleOrder: npcDashboard.saleOrder,
          soli: npcDashboard.soli,
          npcNumber: npcDashboard.npcNumber,
          plant: npcDashboard.plant,
          partNumber: npcDashboard.partNumber,
          dwgHeader: npcDashboard.dwgHeader,
          npcWorkFlowStatus: npcDashboard.npcWorkFlowStatus,
          current_department: npcDashboard.department,//NPC Part Status
          sapMaterialStatus: npcDashboard.sapMaterialStatus,//NPC Part Status
          sapDistributionMaterialStatus: npcDashboard.sapDistributionMaterialStatus,//NPC Part Status
          plantSpecificMaterialStatus: npcDashboard.plantSpecificMaterialStatus,//NPC Part Status
          procurementType: npcDashboard.procurementType,//NPC Part Status
          //qcode: npcDashboard.qcode,
          holdFlag: npcDashboard.holdFlag,
          holdComments: npcDashboard.holdComments,
          requestedDate: this.excelDateFormatter(npcDashboard.requestedDate),
          targetDate: this.excelDateFormatter(npcDashboard.targetDate),
          completedDate: this.excelDateFormatter(npcDashboard.completedDate),
          creator: npcDashboard.creator,
          reveiwer: npcDashboard.reveiwer,
          releasedBy: npcDashboard.releasedBy,
          projectManager: npcDashboard.projectManager,
          generalComments: npcDashboard.generalComments,
          //roleId: npcDashboard.roleId,
          mcodeDesc: npcDashboard.mcodeDesc,
          mcode: npcDashboard.mcode,
          npcCategory: npcDashboard.npcSubCategory,
          npcComponent: npcDashboard.subLevelComponent,
          dwgNumber: npcDashboard.drawingNumber,
          //id: npcDashboard.id,
          orphanFlag: npcDashboard.orphanFlag,
          ecmNumber: npcDashboard.ecmNumber,
          //NPC Part Status Addition fields//START
          enggStartDate: this.excelDateFormatter(npcDashboard.enggStartDate),
          enggCompletedDate: this.excelDateFormatter(npcDashboard.enggCompletedDate),
          enggAging_hrs: npcDashboard.enggAging,
          planningStartDate: this.excelDateFormatter(npcDashboard.planningStartDate),
          planningCompletedDate: this.excelDateFormatter(npcDashboard.planningCompletedDate),
          planningAging_hrs: npcDashboard.planningAging,
          qualityStartDate: this.excelDateFormatter(npcDashboard.qualityStartDate),
          qualityCompletedDate: this.excelDateFormatter(npcDashboard.qualityCompletedDate),
          qualityAging_hrs: npcDashboard.qualityAging,
          sourcingStartDate: this.excelDateFormatter(npcDashboard.sourcingStartDate),
          sourcingCompletedDate: this.excelDateFormatter(npcDashboard.sourcingCompletedDate),
          sourcingAging_hrs: npcDashboard.sourcingAging,
          manufacturingStartDate: this.excelDateFormatter(npcDashboard.manufacturingStartDate),
          manufacturingCompletedDate: this.excelDateFormatter(npcDashboard.manufacturingCompletedDate),
          manufacturingAging_hrs: npcDashboard.manufacturingAging,
          financeStartDate: this.excelDateFormatter(npcDashboard.financeStartDate),
          financeCompletedDate: this.excelDateFormatter(npcDashboard.financeCompletedDate),
          financeAging_hrs: npcDashboard.financeAging,
          //enggCoordinatorFirstName: npcDashboard.enggCoordinatorFirstName,
          //enggCoordinatorLastName: npcDashboard.enggCoordinatorLastName,
          enggCoordinatorName: npcDashboard.enggCoordinatorName,
          sapErrorStatus: npcDashboard.sapErrorStatus
        }));
        ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "NPC Dashboard");
        //F&PT_NpcDashboardData
      }
    });
  }
}

export interface NpcDashboardInterface {

  preConfigId: number;
  npcWorkFlowStatus: string;
  //orderNumber: string;
  saleOrder: string;
  npcNumber: string;
  drawingNumber: string;
  dwgHeader: string;
  mcode: string;
  qcode: string;
  partNumber: string;
  sapMaterialStatus: string;//NPC Part Status
  sapDistributionMaterialStatus: string;//NPC Part Status
  plantSpecificMaterialStatus: string;//NPC Part Status
  procurementType: string;//NPC Part Status
  department: string;//NPC Part Status
  projectManager: string;
  roleId: number;
  soli: string;
  mcodeDesc: string;
  npcSubCategory: string;
  subLevelComponent: string;
  creator: string;
  reveiwer: string,
  releasedBy: string,
  holdComments: string;
  generalComments: string;
  id: number;
  allowAccess: any;
  orphanFlag: boolean;
  npcComponentId: number;
  npcSubCategoryId: number;
  //enggCoordinator: number;
  ecmNumber: number;
  formattedtargetDate: string;
  formattedcompletedDate: string;
  formattedrequestedDate: string;
  holdFlag: boolean;
  status: string;
  plant: string;
  plantCode: string;
  allowEdit: any;
  allowForceClose: any;
  //NPC Part Status Addition fields//START
  enggStartDate: any;
  enggCompletedDate: any;
  enggAging: any;
  planningStartDate: any;
  planningCompletedDate: any;
  planningAging: any;
  qualityStartDate: any;
  qualityCompletedDate: any;
  qualityAging: any;
  sourcingStartDate: any;
  sourcingCompletedDate: any;
  sourcingAging: any;
  manufacturingStartDate: any;
  manufacturingCompletedDate: any;
  manufacturingAging: any;
  financeStartDate: any;
  financeCompletedDate: any;
  financeAging: any;
  enggCoordinatorFirstName: any;
  enggCoordinatorLastName: any;
  enggCoordinatorName: any;
  sapErrorStatus: any;
}
export interface data {
  animal: string;
  name: string;
}
let ELEMENT_DATA: NpcDashboardInterface[] = [];