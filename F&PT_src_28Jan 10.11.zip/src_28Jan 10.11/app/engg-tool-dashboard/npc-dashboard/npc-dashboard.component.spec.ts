import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpcDashboardComponent } from './npc-dashboard.component';

describe('NpcDashboardComponent', () => {
  let component: NpcDashboardComponent;
  let fixture: ComponentFixture<NpcDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpcDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpcDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
