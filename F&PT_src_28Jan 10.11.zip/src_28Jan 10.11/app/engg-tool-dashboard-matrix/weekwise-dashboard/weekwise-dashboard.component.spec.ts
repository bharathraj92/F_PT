import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeekwiseDashboardComponent } from './weekwise-dashboard.component';

describe('WeekwiseDashboardComponent', () => {
  let component: WeekwiseDashboardComponent;
  let fixture: ComponentFixture<WeekwiseDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeekwiseDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeekwiseDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
