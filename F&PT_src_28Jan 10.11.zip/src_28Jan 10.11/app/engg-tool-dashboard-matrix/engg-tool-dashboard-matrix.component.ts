import { Component, OnInit } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { Router } from '@angular/router';///
import { FormGroup, FormBuilder } from '@angular/forms';
import { ApiMappingsService } from '../Services/api-mappings.service';
import { CommonService } from '../Services/common.service';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
@Component({
  selector: 'app-engg-tool',
  templateUrl: './engg-tool-dashboard-matrix.component.html',
  styleUrls: ['./engg-tool-dashboard-matrix.component.scss']
})
export class DashboardMatrixComponent implements OnInit {
  panelOpenState = true;
  navLinks: any[];
  activeLinkIndex = -1;
  bannerForm: FormGroup;
  bannerData: any;
  //InfoFields
  saleOrder;
  soLiNumber;
  erNumber;
  preConfigId;
  erStatus;
  erRequestDate;
  customerName;
  enggCompletionDate;
  soli;
  complexity;
  datePipe = new DatePipe("en-US");

  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private apiMappingsService: ApiMappingsService,
    private commonservice: CommonService
  ) {
    this.navLinks = [
      {
        label: 'GENERAL DASHBOARD',
        link: './generalDashboard',
        index: 0
      }, {
        label: 'WEEKWISE LOB ',
        link: './weekwiseDashboard',
        index: 1
      }, {
        label: 'MASONEILAN LOB',
        link: './masoneilanDashboard',
        index: 2,
        //disable:true
      },
      {
        label: 'PLANT DASHBOARD',
        link: './plantDashboard',
        index: 3,
        //disable:true
      }, {
        label: 'WIP REPORT',
        link: './wipReport',
        index: 4,
        //disable:true
      }, {
        label: 'WIP REPORT DEEPDIVE',
        link: './wipReportDeepdive',
        index: 5,
        //disable:true
      }
    ];
    ///Getting ER Number and  SaleOrder from DashBoard
    // this.commonservice.saleOrderNumber.subscribe((data) => {
    //   this.saleOrder = data;
    // });
    // this.commonservice.erNumber.subscribe((data) => {
    //   this.erNumber = data;
    // });
    // if (this.saleOrder === '') {
    //   this.saleOrder = localStorage.getItem('saleOrderNumber');
    // }
    
    //   this.soLiNumber = localStorage.getItem('soLiNumber');
 
    // if (this.erNumber === '') {
    //   this.erNumber = localStorage.getItem('erNumber');
    // }
    // if (this.preConfigId === '') {
    //   this.preConfigId = localStorage.getItem('preConfigId');
    // }
  }
  ngOnInit(): void {
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });
    // this.bannerForm = this.formBuilder.group({
    //   saleOrder: [null],
    //   erNumber: [null],
    //   erStatus: [null],
    //   erRequestDate: [null],
    //   customerName: [null],
    //   enggCompletionDate: [null],
    //   soli: [null],
    //   complexity: [null],
    // })
    // if ((this.soLiNumber && this.router.url === '/enggTool/summaryInfo') || this.erNumber === '') {
    //   this.getERSummaryInfo(this.soLiNumber);
    // } else if (this.erNumber) {
    //   // else if (this.erNumber && this.router.url === '/enggTool/preConfig') {
    //   this.getERPreConfigInfo(this.erNumber);
    // }
    // this.bannerForm.disable();
  }
  getActiveClass(indexOfRouteLink) {
    let tabsclass = 'mat-tab-link';
    if (this.activeLinkIndex === indexOfRouteLink) {
      tabsclass = 'mat-tab-link mat-tab-label-active';
    }
    return tabsclass;
  }

  //get ER Summary Info
  // getERSummaryInfo(soLiNumber) {
  //   this.apiMappingsService.getERSummaryInfo(soLiNumber).subscribe((data: []) => {
  //     if (data) {
  //       this.bannerData = data;
  //       this.bannerForm.patchValue(this.bannerData);
  //       //Date format change
  //       this.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy'));
  //       this.bannerForm.get('enggCompletionDate').patchValue(this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy'));
  //     }
  //   });
  // }
  //get ER Summary Info
  // getERPreConfigInfo(erNumber) {
  //   this.apiMappingsService.getERPreConfigInfo(erNumber).subscribe((data: []) => {
  //     if (data) {
  //       this.bannerData = data;
  //       this.bannerForm.patchValue(this.bannerData);
  //       localStorage.setItem('soLiNumber', this.bannerData['soli']);
  //       localStorage.setItem('preConfigId', this.bannerData['id']);
  //       //Date format change
  //       // this.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'], 'dd-MMM-yyyy'));
  //       this.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy'));

  //     }
  //   });
  // }
}
