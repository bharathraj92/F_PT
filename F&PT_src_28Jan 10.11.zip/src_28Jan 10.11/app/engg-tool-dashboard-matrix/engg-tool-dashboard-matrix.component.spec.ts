import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardMatrixComponent } from './engg-tool-dashboard-matrix.component';

describe('DashboardMatrixComponent', () => {
  let component: DashboardMatrixComponent;
  let fixture: ComponentFixture<DashboardMatrixComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardMatrixComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardMatrixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
