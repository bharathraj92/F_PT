import { Component, OnInit, Inject, ViewChild, ElementRef, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import * as Mock from 'src/app/mock/scheduling-graph.mock';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ExportExcel } from "src/app/util/exportExcel";
import { BarGraphComponentComponent } from "src/app/util/bar-graph-component/bar-graph-component.component";
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import exportingtable from 'highcharts/modules/export-data';
import offlineexporting from 'highcharts/modules/offline-exporting'
import { MatMonthView } from '@angular/material/datepicker';
@Component({
  selector: 'app-general-dashboard',
  templateUrl: './general-dashboard.component.html',
  styleUrls: ['./general-dashboard.component.scss']
})
export class GeneralDashboardComponent implements OnInit, OnDestroy, OnChanges {
  //Chart: Chart;
  filterForm: FormGroup;
  isExpanded = false;
  loaded = false;
  graphData: any;
  _graphData: any;
  freqChart: any;
  _freqChart: any;
  matrixTypeList: any;
  plantType: any;
  plantTypeList: any;
  startDate: any;
  endDate: any;
  year: any;
  month: any;
  week: any;
  weekDefault: any;
  yearList: any;
  monthList: any;
  weekList: any;
  weekFilter: any;
  endUserTypeList: any;
  productFamilyList: any;
  ovdUsers: any;
  ovdSaleOrders: any;
  riskReviewUsers: any;
  riskReviewSaleOrders: any;
  totalOVDStatus: any;//Chart_2
  otdSelection: any;//Chart_3
  overallOTDtrend: any;//Chart_4
  totalRiskReviewStatus: any; //Chart_5
  chart1Options: any;
  chart4Options: any;
  chart5Options: any;
  //ssoId: any;
  //chart1: Highcharts.Chart;
  chart1: Chart;
  chart2: Chart;
  chart3: Chart;
  chart4: Chart;
  chart5: Chart;
  masterFilters: any;
  userPlant: string;
  constructor(
    //public dialogRef: MatDialogRef<any>,
    //@Inject(MAT_DIALOG_DATA) 
    //public graphData,
    public formBuilder: FormBuilder,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, ) {
    this.graphData = [];
    //Get User Details Plant
    this.commonService.userDetails.subscribe(val => {
      this.userPlant = '';
      if (val['plantName'] != null && val['plantName'] != undefined) {
        this.userPlant = val['plantName'];
      }
    });
  }

  ngOnInit(): void {
    //this.masterFilters = Mock.getAllAvailableColumns['MasterFilters'];
    //this.filterForm = this.createFilterControls(this.masterFilters);
    this.filterForm = this.formBuilder.group({
      matrixType: [null],
      plantType: [null],
      startDate: [null],
      endDate: [null],
      // year: [[null], [Validators.required]],
      // month: [null],
      // week: [null],
      endUserType: [null],
      productFamilyType: [null]
    });
    this.getYearMonthWeek(new Date());
    this.getMatrixFiltersData();
  }

  ngOnDestroy(): void {
  }
  // createFilterControls(masterFilters: any) {
  //   let group: any = {};
  //   masterFilters.forEach(x => {
  //     group[x.control] = new FormControl();
  //   })
  //   return new FormGroup(group);
  // }

  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    let cdata = changes.graphData.currentValue;
    if (this.loaded === true && cdata !== undefined) {
      this.loadGraphs(cdata);
    }
  }

  getYearMonthWeek(d: any) {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart: any = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
    console.log([d.getUTCFullYear(), d.getMonth(), weekNo]);
    this.year = d.getUTCFullYear();
    this.month = (d.getMonth() + 1).toString();
    this.weekDefault = weekNo;
    return [d.getUTCFullYear(), d.getMonth(), weekNo];
  }
  getMatrixFiltersData() {
    //this.yearList = Mock.getAllAvailableColumns['columnData']['year'];
    //this.monthList = Mock.getAllAvailableColumns['columnData']['month'];
    // this.weekList = Mock.getAllAvailableColumns['columnData']['week'];    
    // this.weekFilter =  Mock.getAllAvailableColumns['columnData']['week'];
    this.apiMappingsService.getMatrixFiltersData().subscribe((data) => {
      if (data) {
        this.matrixTypeList = data['matrixType'];
        this.plantTypeList = data['plantType'];
        // this.yearList = data['year'];
        // this.monthList = data['month'];
        // this.weekList = data['week'];
        // this.weekFilter = data['week'];
        this.endUserTypeList = data['endUserType'];
        this.productFamilyList = data['productFamilyType'];
        this.loadDefaultFilters();
      }
    });
  }
  loadDefaultFilters() {
    this.filterForm.get('matrixType').patchValue(this.matrixTypeList[0]);
    ///this.filterForm.get('plantType').patchValue([...this.plantTypeList.map(item => item)]);
    this.filterForm.get('plantType').patchValue([this.userPlant]);
    //this.filterForm.get('year').patchValue([this.year]);
    //this.filterForm.get('month').patchValue([this.month]);
    this.filterForm.get('endUserType').patchValue(['Commercial']);
    this.filterForm.get('productFamilyType').patchValue(['Masoneilan']);
    // this.onMonthSelect();
    // const weekSelect = _.filter(this.weekFilter, { 'week': this.weekDefault });
    // this.filterForm.get('week').patchValue(weekSelect);
    this.expandAction();
    this.getGeneralDashboardData();
  }
  resetFilters() {
    this.filterForm.reset();
    this.getGeneralDashboardData();
  }
  //date Formatter to Time stamp
  // dateFormatter(value) {
  //   if (value) {
  //   let selectedDate = new Date(value).getTime();
  //         const DateStr = selectedDate + '';
  //         selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
  //         return selectedDate;
  //   }
  // }
  getGeneralDashboardData() {
    let formData = {};
    formData = this.filterForm.value;
    formData['startDate'] = this.commonService.dateTimestamp(this.filterForm.value.startDate);
    formData['endDate'] = this.commonService.dateTimestamp(this.filterForm.value.endDate);
    this.apiMappingsService.getGeneralDashboardData(formData).subscribe((data) => {
      if (data) {
        this.graphData = [];
        this._graphData = [];
        this.graphData = data;
        this._graphData = _.cloneDeep(this.graphData)
        this.loadGraphs(this.graphData);
      }
    });
  }
  onMonthSelect() {
    const months = this.filterForm.get('month').value;
    this.weekFilter = [];
    this.week = [];
    if (months != null && months.length > 0) {
      months.forEach(month => {
        this.weekList.forEach(week => {
          if ((week.month.toString()) === month) {
            this.weekFilter.push(week);
            this.week.push(week);
          }
        });
      });
    }
    this.filterForm.get('week').patchValue(this.week);
  }
  loadGraphs(data) {
    this.freqChart = [];
    this._freqChart = [];
    const columnData = data['columnData'];
    this.freqChart = columnData['totalStatus'];//Chart-1
    this._freqChart = _.cloneDeep(this.freqChart);
    this.totalOVDStatus = columnData['totalOVDStatus'];//Chart-2
    this.otdSelection = columnData['otdselection'];//Chart-3
    this.overallOTDtrend = columnData['overallOTDtrend'];//Chart-4
    this.totalRiskReviewStatus = columnData['totalRISKREVIEWStatus'];//Chart-5

    const colData = Mock.getAllAvailableColumns['columnData'];//Mock Data
    //let graphData = columnData['TotalStatus'];
    //let graphData = data;
    //this.totalOVDStatus = columnData['TotalOVDStatus'];//Chart-2
    //this.totalRiskReviewStatus = colData['totalRISKREVIEWStatus'];//Chart-5

    this.initChart1(this.totalOVDStatus);//Chart-2
    this.initChart3(this.otdSelection);//Chart-3
    this.initChart4(this.overallOTDtrend);//Chart-4
    this.initChart5(this.totalRiskReviewStatus);//Chart-5
    this.loaded = true;
  }
  // TotalOVDStatus Filters
  totalOVDStatusFilters(saleOrder, filterType) {
    if (filterType === 'saleOrder') {
      // document.getElementById('riskReviewUsers'). = '';
      // doctument.getElementById('riskReviewSaleOrders') = '';
    } else {

    }
    let preData = this.totalOVDStatus.series[0].data;
    let filteredPoint = [];
    this.chart1Options.series[1].data.forEach(item => {
      item.forEach(element => {
        if (element === saleOrder.value) {
          filteredPoint.push(item);
        }
      });
    });
    if (filteredPoint.length) {
      this.chart1Options.series[0].data = filteredPoint;
    } else {
      this.chart1Options.series[0].data = preData;
    }
    this.chart1 = new Chart(this.chart1Options);
  }
  // Total RiskReview Filters
  totalRiskReviewFilters(saleOrder, filterType) {
    //   let input = document.getElementById('myInput'),
    //     saleOrders = this.chart1Options.series[1].categories,
    //   let res = data.map(x => ({ ...x, is: saleOrder.value.includes(x) }))
    //   let filteredPoint = saleOrders.filter(item => item == saleOrder.value);
    if (filterType === 'saleOrder') {
      // document.getElementById('riskReviewUsers'). = '';
      // doctument.getElementById('riskReviewSaleOrders') = '';
    } else {

    }
    let preData = this.totalRiskReviewStatus.series[0].data;
    let preCostData = this.totalRiskReviewStatus.series[1].data;
    let filteredPoint = [];
    let filteredCost = [];
    this.chart5Options.series[2].data.forEach(item => {
      item.forEach(element => {
        if (element === saleOrder.value) {
          filteredPoint.push(item);
        }
      });
    });
    if (filteredPoint.length) {
      //let newData = [];
      // for (let i in data) {
      //   newData.push(null)
      // }
      //newData[filteredPoint[0].index] = filteredPoint[0].y
      //newData.push(null) //--- extra null as a workaround for bug
      //  
      this.chart5Options.series[0].data = filteredPoint;
    } else {
      this.chart5Options.series[0].data = preData;
    }
    //Filter Cost data
    this.chart5Options.series[3].data.forEach(item => {
      item.forEach(element => {
        if (element === saleOrder.value) {
          filteredCost.push(item);
        }
      });
    });
    if (filteredCost.length) {
      this.chart5Options.series[1].data = filteredCost;
    } else {
      this.chart5Options.series[1].data = preCostData;
    }
    // 
    this.chart5 = new Chart(this.chart5Options);
  }
  // 
  @ViewChild("chart1El", { read: ElementRef }) chart1El: ElementRef;
  //chart1Options: Highcharts.Options;
  //chart1Options: Chart.Options;
  initChart1(chartData) {
    let seriesName: any = [];
    let seriesData: any = [];
    if (chartData.series.length) {
      seriesName = chartData.series[0].name;
      seriesData = chartData.series[0].data;
    }
    if (chartData != null) {
      this.ovdUsers = chartData.users;
      this.ovdSaleOrders = chartData.saleOrders;
      if (this.chart1 != undefined) {
        if (this.chart1['dataTableDiv'] != undefined) {
          this.chart1['dataTableDiv'].remove();
        }
      }
      this.chart1Options = {
        chart: {
          type: 'column'
        },
        credits: {
          enabled: false
        },
        title: {
          text: chartData.maintitle
        },
        xAxis: {
          //categories: chartData.categories,
          type: 'category',
          title: {
            text: chartData.xaxisTitle
          },
          crosshair: true
        },
        yAxis: {
          min: 0,
          title: {
            text: chartData.yaxisTitle
          }
        },
        tooltip: {
          headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
          pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
          footerFormat: '</table>',
          shared: true,
          useHTML: true
        },
        plotOptions: {
          column: {
            pointPadding: 0.2,
            borderWidth: 0
          }
        },
        series: [{
          name: seriesName,//chartData.series[0].name,
          data: seriesData,//chartData.series[0].data,
          visible: true,
          showInLegend: false,
          opacity: 0.8,
          dataLabels: {
            enabled: true,
            style: {
              color: Highcharts.getOptions().colors[1]
            },
            formatter: function () {
              if (this.y != null && this.y > 0) {
                return this.y;
              }
            }
          },
        }, {
          name: seriesName,//chartData.series[0].name,
          data: seriesData,//chartData.series[0].data,
          visible: false,
          showInLegend: false,
          categories: chartData.categories
        }]
      }
      //this.chart1 = Highcharts.chart(this.chart1El.nativeElement, this.chart1Options);
      this.chart1 = new Chart(this.chart1Options);
    }
  }
  // 
  initChart3(chartData) {

    if (this.chart3 != undefined) {
      if (this.chart3['dataTableDiv'] != undefined) {
        this.chart3['dataTableDiv'].remove();
      }
    }

    let chart3Options = {
      chart: {
        type: 'pie',
        options3d: {
          enabled: true,
          alpha: 45
        }
      },
      credits: {
        enabled: false
      },
      title: {
        text: chartData.maintitle
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          innerSize: '60%',
          depth: 45,
          cursor: 'pointer',
          dataLabels: {
            enabled: true,
            distance: -40,
            formatter: function () {
              return this.y > 0 ? this.y : null;
            }
          },
          showInLegend: true,
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      series: [{
        name: 'OTD',
        type: undefined,
        data: [["OTD", chartData.data[0]], ["ON TIME", chartData.data[1]]]//chartData.data
      }]
    }
    this.chart3 = new Chart(chart3Options);
  }
  // 
  initChart4(chartData) {

    if (this.chart4 != undefined) {
      if (this.chart4['dataTableDiv'] != undefined) {
        this.chart4['dataTableDiv'].remove();
      }
    }

    this.chart4Options = {
      chart: {
        type: 'column'
      },
      credits: {
        enabled: false
      },
      title: {
        text: chartData.maintitle
      },
      xAxis: {

        type: 'category',
        // categories: [
        //   '1',
        //   '2',
        //   '3',
        //   '4',
        //   '5',
        //   '6',
        //   '7',
        //   '8'
        // ],
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: chartData.yaxisTitle
        },
        plotLines: [{
          color: 'darkorange',
          value: chartData.averageValue,
          width: 2,
          zIndex: 4
        }]
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [{
        name: chartData.xaxisTitle,
        type: undefined,
        data: chartData.data,
        opacity: 0.8,
        dataLabels: {
          enabled: true,
          style: {
            color: Highcharts.getOptions().colors[1]
          },
          formatter: function () {
            if (this.y != null && this.y > 0) {
              return this.y;
            }
          }
        }
      }]
    }
    this.chart4 = new Chart(this.chart4Options);
  }
  // 
  initChart5(chartData) {
    //let seriesName : any =[];
    let seriesData: any = [];
    let costData: any = [];
    let seriesName: any = [];
    let costName: any = [];
    if (chartData.series.length) {
      seriesName = chartData.series[0].name;
      costName = chartData.series[1].name;
      seriesData = chartData.series[0].data;
      costData = chartData.series[1].data;
    }
    this.riskReviewUsers = chartData.users;
    this.riskReviewSaleOrders = chartData.saleOrders;
    if (this.chart5 != undefined) {
      if (this.chart5['dataTableDiv'] != undefined) {
        this.chart5['dataTableDiv'].remove();
      }
    }

    this.chart5Options = {
      chart: {
        type: 'column'
      },
      credits: {
        enabled: false
      },
      title: {
        text: chartData.maintitle //'Total Risk Review Status'
      },
      xAxis: {
        type: 'category',
        title: {
          text: chartData.xaxisTitle
        },
        // categories: [
        //   '11223',
        //   '11334',
        //   '11445',
        //   '11556',
        //   '11667',
        //   '11554',
        //   '12546',
        //   '45698'
        // ],
        crosshair: true
      },
      yAxis: [{
        min: 0,
        title: {
          text: seriesName // 'Number of ERs'
        }
      }, {
        min: 0,
        title: {
          text: costName // 'Number of ERs'
        },
        opposite: true
      }],
      tooltip: {
        headerFormat: '<span style="font-size:10px">SaleOrder : {point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [{
        name: seriesName,
        //type: undefined,
        data: seriesData,
        visible: true,
        showInLegend: true,
        opacity: 0.8,
        dataLabels: {
          enabled: true,
          style: {
            color: Highcharts.getOptions().colors[1]
          },
          formatter: function () {
            if (this.y != null && this.y > 0) {
              return this.y;
            }
          }
        }
      }, {
        name: costName,//seriesName,//chartData.series[0].name,
        type: 'spline',
        yAxis: 1,
        data: costData,//chartData.series[0].data,
        dataLabels: {
          enabled: true,
          style: {
            color: Highcharts.getOptions().colors[1]
          },
          formatter: function () {
            if (this.y != null && this.y > 0) {
              return this.y;
            }
          }
        }
        //categories: chartData.categories
      },
      {//Hidden for Filtering
        name: seriesName,//chartData.series[0].name,
        data: seriesData,//chartData.series[0].data,
        visible: false,
        showInLegend: false,
      }, {//Hidden for Filtering
        name: costName,//chartData.series[0].name,
        data: costData,//chartData.series[0].data,
        visible: false,
        showInLegend: false,
      }]

    }
    this.chart5 = new Chart(this.chart5Options);
  }
  // 
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("GeneralDashboard");
  }
  // exportArray() {
  //   const onlyNameAndSymbolArr: Partial<GeneralDashboardInterface>[] = this.erMasterTableData.map(erMaster => ({
  //     orderNumber: erMaster.orderNumber,
  //     soli: erMaster.soli,
  //     erNumber: erMaster.erNumber,
  //     tagNumber: erMaster.tagNumber,
  //     plant: erMaster.plant,
  //     complexity: erMaster.complexity,
  //     customerName: erMaster.customerName,
  //     sapHeader: erMaster.sapHeader,
  //     sapHeaderDesc: erMaster.sapHeaderDesc,
  //     erStatus: erMaster.erStatus,
  //     erCompletionDate: new Date(erMaster.erCompletionDate),//erCompletionDate,
  //     creator: erMaster.creator,
  //     reviewer: erMaster.reviewer,
  //     release: erMaster.release,
  //     orderBookedDate: new Date(erMaster.orderBookedDate),//orderBookedDate,
  //     shipDate: new Date(erMaster.orderBookedDate),//shipDate,
  //     enggCompletionDate: new Date(erMaster.enggCompletionDate),//enggCompletionDate,
  //     supportTeam: erMaster.supportTeam,
  //     erRevisionNumber: erMaster.erRevisionNumber,
  //     costOfTheLine: erMaster.costOfTheLine,
  //     enggBlocks: erMaster.enggBlocks
  //   }));
  //   ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "Master Dashboard");
  //   //F&PT_MasterDashboardData
  // }
}

export interface GeneralDashboardInterface {
  orderNumber: string;
  soli: string;
  erNumber: string;
  tagNumber: string;
  plant: string;
  complexity: string;
  customerName: string;
  sapHeader: string;
  sapHeaderDesc: string;
  erStatus: string;
  erCompletionDate: any;
  creator: string;
  reviewer: string;
  release: string;
  orderBookedDate: any;
  shipDate: any;
  enggCompletionDate: any;
  supportTeam: string;
  erRevisionNumber: number,
  costOfTheLine: number,
  enggBlocks: string
}
let ELEMENT_DATA: GeneralDashboardInterface[] = [];