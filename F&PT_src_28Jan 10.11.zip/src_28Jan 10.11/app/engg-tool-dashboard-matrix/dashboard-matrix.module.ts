import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
export * from './general-dashboard/general-dashboard.component';
export * from './weekwise-dashboard/weekwise-dashboard.component';
export * from './masoneilan-dashboard/masoneilan-dashboard.component';
export * from './plant-dashboard/plant-dashboard.component';
export * from './wip-dashboard/wip-dashboard.component';
export * from './wip-deepdive-dashboard/wip-deepdive-dashboard.component';

import { ThemeLibModule, NavService } from 'bh-theme';
import { BhAlertService } from 'bh-theme';
import { MatSortModule } from '@angular/material/sort';
import { BrowserModule } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';
import { from } from 'rxjs';
import { DashboardMatrixComponent } from './engg-tool-dashboard-matrix.component';
import { GeneralDashboardComponent } from './general-dashboard/general-dashboard.component';
import { TranslateLoader, TranslateModule, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';

@NgModule({
  declarations: [
    //DashboardMatrixComponent,
    //GeneralDashboardComponent
  ],
  imports: [
    CommonModule,
    ThemeLibModule,
    FormsModule,
    BrowserModule,
    MatTableModule,
    MatSortModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ],
  exports: [
  ],
  providers: [NavService, BhAlertService]
})
export class DashboardModule { }

// AOT compilation support
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, "assets/i18n/", ".json");
}
