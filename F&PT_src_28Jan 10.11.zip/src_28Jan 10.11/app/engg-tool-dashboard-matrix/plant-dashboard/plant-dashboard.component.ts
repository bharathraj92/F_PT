import { Component, OnInit, Inject, ViewChild, ElementRef, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import * as Mock from 'src/app/mock/scheduling-graph.mock';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ExportExcel } from "src/app/util/exportExcel";
import { BarGraphComponentComponent } from "src/app/util/bar-graph-component/bar-graph-component.component";
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import exportingtable from 'highcharts/modules/export-data';
import offlineexporting from 'highcharts/modules/offline-exporting'
import noData from 'highcharts/modules/no-data-to-display'

noData(Highcharts)

@Component({
  selector: 'app-plant-dashboard',
  templateUrl: './plant-dashboard.component.html',
  styleUrls: ['./plant-dashboard.component.scss']
})
export class PlantDashboardComponent implements OnInit, OnDestroy, OnChanges {
  //Chart: Chart;
  filterForm: FormGroup;
  isExpanded = false;
  loaded = false;
  graphData: any;
  _graphData: any;
  freqChart: any;
  _freqChart: any;
  matrixTypeList: any;
  plantTypeList: any;
  startDate: any;
  endDate: any;
  // year: any;
  // month: any;
  // week: any;
  // yearList: any;
  // monthList: any;
  // weekList: any;
  // weekFilter: any;
  // weekDefault: any;
  endUserTypeList: any;
  productFamilyList: any;
  chart1Options: any;
  chart1: Chart;

  chart2Options: any;
  chart2: Chart;

  plantList = [];

  masterFilters: any;
  userPlant: string;
  constructor(
    //public dialogRef: MatDialogRef<any>,
    //@Inject(MAT_DIALOG_DATA)
    //public graphData,
    public formBuilder: FormBuilder,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, ) {
      //Get User Details Plant
    this.commonService.userDetails.subscribe(val => {
      this.userPlant = '';
      if (val['plantName'] != null && val['plantName'] != undefined) {
        this.userPlant = val['plantName'];
      }
    });
  }

  ngOnInit(): void {
    this.filterForm = this.formBuilder.group({
      matrixType: [null],
      plantType: [null],
      startDate: [null],
      endDate: [null],
      // year: [[null], [Validators.required]],
      // month: [null],
      // week: [null],
      endUserType: [null],
      productFamilyType: [null]
    });
    //this.getYearMonthWeek(new Date());
    this.getMatrixFiltersData();
    this.plantList = [
      "Jax",
      "Conde",
      "DVI",
      "Global CoE",
      "Multiple Plants"
    ];
  }

  ngOnDestroy(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    let cdata = changes.graphData.currentValue;
    if (this.loaded === true && cdata !== undefined) {
      this.loadGraphs(cdata);
    }
  }
  // getYearMonthWeek(d: any) {
  //   d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  //   d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  //   const yearStart: any = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  //   const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  //   console.log([d.getUTCFullYear(), d.getMonth(), weekNo]);
  //   this.year = d.getUTCFullYear();
  //   this.month = (d.getMonth() + 1);
  //   this.week = weekNo + 1;
  //   return [d.getUTCFullYear(), d.getMonth(), weekNo];
  // }

  loadDefaultFilters() {
    this.filterForm.get('matrixType').patchValue(this.matrixTypeList[0]);
    ///this.filterForm.get('plantType').patchValue([...this.plantTypeList.map(item => item)]);
    this.filterForm.get('plantType').patchValue([this.userPlant]);
    //this.filterForm.get('year').patchValue([this.year]);
    this.filterForm.get('endUserType').patchValue(['Commercial']);
    this.filterForm.get('productFamilyType').patchValue(['Masoneilan']);
    //this.filterForm.get('month').patchValue([this.month]);
    // this.onMonthSelect();
    // const weekSelect = _.filter(this.weekFilter, { 'week': this.weekDefault });
    // this.filterForm.get('week').patchValue(weekSelect);
    this.expandAction();
    this.getPlantDashboardData();
  }
  // onMonthSelect() {
  //   const months = this.filterForm.get('month').value;
  //   this.weekFilter = [];
  //   this.week = [];
  //   if (months != null && months.length > 0) {
  //     months.forEach(month => {
  //       this.weekList.forEach(week => {
  //         if ((week.month.toString()) === month) {
  //           this.weekFilter.push(week);
  //           this.week.push(week);
  //         }
  //       });
  //     });
  //   }
  //   this.filterForm.get('week').patchValue(this.week);
  // }
  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }

  getMatrixFiltersData() {
    // this.yearList = Mock.getAllAvailableColumns['columnData']['year'];
    // this.monthList = Mock.getAllAvailableColumns['columnData']['month'];
    // this.weekList = Mock.getAllAvailableColumns['columnData']['week'];
    this.apiMappingsService.getMatrixFiltersData().subscribe((data) => {
      if (data) {
        this.matrixTypeList = data['matrixType'];
        this.plantTypeList = data['plantType'];
        // this.yearList = data['year'];
        // this.monthList = data['month'];
        // this.weekList = data['week'];
        // this.weekFilter = data['week'];
        this.endUserTypeList = data['endUserType'];
        this.productFamilyList = data['productFamilyType'];
        this.loadDefaultFilters();
      }
    });
  }
  resetFilters() {
    this.filterForm.reset();
    this.getPlantDashboardData();
  }
  getPlantDashboardData() {
    let formData = {};
    formData = this.filterForm.value;
    formData['startDate'] = this.commonService.dateTimestamp(this.filterForm.value.startDate);
    formData['endDate'] = this.commonService.dateTimestamp(this.filterForm.value.endDate);
    this.apiMappingsService.getPlantDashboardData(formData).subscribe((data) => {
      if (data) {
        this.loadGraphs(data);
      }
    });
  }
  loadGraphs(data) {
    //this.http.get(this.apiMappingsService.getSchedulingGraphData(this.ssoId)).subscribe(data => {
    this.freqChart = [];
    this._freqChart = [];
    // let graphData = Mock.getAllAvailableColumns['columnData']['plantLOBStatus'];
    let graphData = data;
    this.freqChart = graphData;
    this._freqChart = _.cloneDeep(this.freqChart);

    this.initChart1(this.freqChart);
    this.initChart2([]);
    //});
  }

  @ViewChild("chart1El", { read: ElementRef }) chart1El: ElementRef;
  //chart1Options: Highcharts.Options;
  //chart1Options: Chart.Options;
  initChart1(chartData) {
    let seriesName: any = [];
    let seriesData: any = [];
    if (chartData.series.length) {
      seriesName = chartData.series[0].name;
      seriesData = chartData.series[0].data;
    }
    if (this.chart1 != undefined) {
      if (this.chart1['dataTableDiv'] != undefined) {
        this.chart1['dataTableDiv'].remove();
      }
    }

    this.chart1Options = {
      chart: {
        type: 'column'
      },
      credits: {
        enabled: false
      },
      title: {
        text: chartData.title
      },
      xAxis: {
        type: 'category',
        // categories: [
        //   '2021W18',
        //   '2021W19',
        //   '2021W20',
        //   '2021W21',
        //   '2021W22',
        //   '2021W23',
        //   '2021W24',
        //   '2021W25'
        // ],
        title: {
          text: chartData.xaxisTitle
        },
        crosshair: true
      },
      yAxis: [{
        min: 0,
        title: {
          text: chartData.yaxisTitle
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color: 'black',
            formatter: function () {
              if (this.total !== 0) {
                return this.total + '';
              } else {
                return null;
              }
            }
            // color: ( // theme
            //   Highcharts.defaultOptions.title.style &&
            //   Highcharts.defaultOptions.title.style.color
            // ) || 'gray'
          }
        },
        labels: {
          format: '{value}',
          style: {
            color: Highcharts.getOptions().colors[1]
          }
        }
      }],
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          // pointPadding: 0.2,
          // borderWidth: 0,
          opacity: 0.8,
          dataLabels: {
            enabled: true,
            // style: {
            //   color: Highcharts.getOptions().colors[1]
            // },
            formatter: function () {
              if (this.y != null && this.y > 0) {
                //return Math.round(100 * this.y / this.total) + ' %';
                return this.y;
              }
            }
          }
        }
      },
      series: chartData.series
      //[
      //   {
      //   name: 'On Time',
      //   type: undefined,
      //   data: [49.9, 71.5, 26.4, 89.2, 54.0, 66.0, 75.6, 58.5]
      // },
      // {
      //   name: 'On Time Early',
      //   type: undefined,
      //   data: [59.9, 67.5, 76.4, 59.2, 44.0, 76.0, 35.6, 48.5]
      // },
      // {
      //   name: 'OVD',
      //   type: undefined,
      //   data: [64.9, 51.5, 86.4, 79.2, 64.0, 56.0, 45.6, 38.5]
      // },
      // {
      //   name: 'Cancelled',
      //   type: undefined,
      //   data: [76.9, 64.5, 56.4, 42.2,44.0, 57.0, 73.6, 34.5]
      // },
      // ]

    }
    //this.chart1 = Highcharts.chart(this.chart1El.nativeElement, this.chart1Options);
    this.chart1 = new Chart(this.chart1Options);
  }


  //Plant dashboard Resource graph

  userList: any = [];
  onFilterSelect(formdata, filterType) {
    this.initChart2([]);
    if (filterType === 'plant') {
      if (formdata.value != undefined) {
        this.apiMappingsService.getPlantUsersData({ "plantName": formdata.value }).subscribe((data) => {
          if (data) {
            this.userList = data['users'];
          }
        });
      }
      else {
        this.userList = [];
      }
    }
  }

  onplotUserGraph(users, plant) {
    let ssolist = [];
    if (users) {
      ssolist = users.map(user => user.sso);
      this.apiMappingsService.getPlantUserFiltersData({ "plantName": plant, "sso": ssolist }).subscribe((data) => {
        if (data) {
          this.initChart2(data);
        }
      });
    }
  }
  initChart2(chartData) {

    if (this.chart2 !== undefined) {

      delete this.chart2;

    }

    let _chartdata = chartData;



    this.chart2Options = {

      chart: {

        type: 'column',

        zoomType: 'xy'

      },

      credits: {

        enabled: false

      },

      title: {

        text: _chartdata.maintitle

      },

      xAxis: {

        categories: _chartdata.categories,

        type: 'category',

      },

      yAxis: {

        min: 0,

        title: {

          text: _chartdata.title

        },

        stackLabels: {

          style: {

            color: 'black',

            fontWeight: 'bold',

          },

          enabled: true,

          formatter: function () {

            if (this.total !== 0) {

              return this.total + '';

            } else {

              return null;

            }

          }

        }

      },

      tooltip: {

        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',

        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +

          '<td style="padding:0"><b>{point.y}</b></td></tr>',

        footerFormat: '</table>',

        shared: true,

        useHTML: true

      },

      plotOptions: {

        column: {

          stacking: 'normal',

          opacity: 0.8,

          dataLabels: {

            enabled: true,

            formatter: function () {

              if (this.y != null && this.y > 0) {

                return this.y;

              }

            }

          }

        }

      },

      series: _chartdata.columnData,

      lang: {

        noData: "No data to display"

      },

      noData: {

        style: {

          fontWeight: 'bold',

          fontSize: '12px',

          color: '#303030'

        }

      }

    };



    this.chart2 = new Chart(this.chart2Options);

  }
  // initChart2(chartData) {
  //   if (this.chart2 !== undefined) {
  //     delete this.chart2;
  //   }
  //   let _chartdata =chartData;

  //   this.chart2Options = {
  //     chart: {
  //       type: 'column',
  //       zoomType: 'xy'
  //     },
  //     credits: {
  //       enabled: false
  //     },
  //     title: {
  //       text: _chartdata.maintitle
  //     },
  //     xAxis: {
  //       categories: _chartdata.categories,
  //       type: 'category',
  //     },
  //     yAxis: {
  //       min: 0,
  //       title: {
  //         text: _chartdata.title
  //       },
  //       stackLabels: {
  //         style: {
  //           color: 'black',
  //           fontWeight: 'bold',
  //         },
  //         enabled: true,
  //         formatter: function () {
  //           if (this.total !== 0) {
  //             return this.total + '';
  //           } else {
  //             return null;
  //           }
  //         }
  //       }
  //     },
  //     tooltip: {
  //       headerFormat: '<span style="font-size:10px">{point.key}: {point.y}</span>',
  //       pointFormat: '',
  //       footerFormat: '',
  //       shared: true,
  //       useHTML: true
  //     },
  //     plotOptions: {
  //       column: {
  //         stacking: 'normal',
  //         opacity: 0.8,
  //         dataLabels: {
  //           enabled: true,
  //           formatter: function () {
  //             if (this.y != null && this.y > 0) {
  //               return this.y;
  //             }
  //           }
  //         }
  //       }
  //     },
  //     series: _chartdata.columnData
  //   };

  //   this.chart2 = new Chart(this.chart2Options);
  // }

  //Plant dashboard Resource graph

  //
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("PlantDashboard");
  }
  // exportArray() {
  //   const onlyNameAndSymbolArr: Partial<PlantDashboardInterface>[] = this.erMasterTableData.map(erMaster => ({
  //     orderNumber: erMaster.orderNumber,
  //     soli: erMaster.soli,
  //     erNumber: erMaster.erNumber,
  //     tagNumber: erMaster.tagNumber,
  //     plant: erMaster.plant,
  //     complexity: erMaster.complexity,
  //     customerName: erMaster.customerName,
  //     sapHeader: erMaster.sapHeader,
  //     sapHeaderDesc: erMaster.sapHeaderDesc,
  //     erStatus: erMaster.erStatus,
  //     erCompletionDate: new Date(erMaster.erCompletionDate),//erCompletionDate,
  //     creator: erMaster.creator,
  //     reviewer: erMaster.reviewer,
  //     release: erMaster.release,
  //     orderBookedDate: new Date(erMaster.orderBookedDate),//orderBookedDate,
  //     shipDate: new Date(erMaster.orderBookedDate),//shipDate,
  //     enggCompletionDate: new Date(erMaster.enggCompletionDate),//enggCompletionDate,
  //     supportTeam: erMaster.supportTeam,
  //     erRevisionNumber: erMaster.erRevisionNumber,
  //     costOfTheLine: erMaster.costOfTheLine,
  //     enggBlocks: erMaster.enggBlocks
  //   }));
  //   ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "Master Dashboard");
  //   //F&PT_MasterDashboardData
  // }
}

export interface PlantDashboardInterface {
  orderNumber: string;
  soli: string;
  erNumber: string;
  tagNumber: string;
  plant: string;
  complexity: string;
  customerName: string;
  sapHeader: string;
  sapHeaderDesc: string;
  erStatus: string;
  erCompletionDate: any;
  creator: string;
  reviewer: string;
  release: string;
  orderBookedDate: any;
  shipDate: any;
  enggCompletionDate: any;
  supportTeam: string;
  erRevisionNumber: number,
  costOfTheLine: number,
  enggBlocks: string
}
let ELEMENT_DATA: PlantDashboardInterface[] = [];
