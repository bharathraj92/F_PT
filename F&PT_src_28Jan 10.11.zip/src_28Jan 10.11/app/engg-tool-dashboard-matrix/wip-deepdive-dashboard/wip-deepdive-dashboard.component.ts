import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
@Component({
  selector: 'app-wip-deepdive-dashboard',
  templateUrl: './wip-deepdive-dashboard.component.html',
  styleUrls: ['./wip-deepdive-dashboard.component.scss']
})
export class WIPDeepdiveComponent implements OnInit {

  filterForm: FormGroup;
  soLiList: any;
  complexityList: any;
  statusList: any;
  activityList: any;
  navRoute: any;
  datePipe = new DatePipe("en-US");
  //filterEntity: MyDashboardInterface;//FilterNew
  matrixTypeList: any;
  plantTypeList: any;
  //year: any;
  month: any;
  week: any;
  yearList: any;
  monthList: any;
  weekList: any;
  weekFilter: any;
  weekDefault: any;
  endUserTypeList: any;
  productFamilyList: any;
  chart1Options: any;
  //chart1: Chart;
  masterFilters: any;
  //Additional Filters
  doneStartDate: any;
  doneEndDate: any;
  dueStartDate: any;
  dueEndDate: any;
  productType: any;
  enggComplete: any;
  dueStatus: any;
  //doneWeekList: any;
  //dueWeekList: any;
  productTypeList: ["Flow", "Project"];
  enggCompleteList: any;
  dueStatusList: any;
  //filterType: MatTableFilter;
  displayedColumns: string[] = [
    'saleorder',
    'soli',//'itemNo',
    'erNumber',
    'dueWeek',
    'year',
    'csrProjectManager',
    'customerName',//'soldToName',
    'createdDate',
    'enggDueDate',
    'enggCompletionDate',
    'creator',
    'reviewer',
    'release',//'configurationEngg',
    'shipDate',
    'headerStatusProfile',
    'leadTime',
    'supportTeam',
    'tagNumber',
    'erStatus',
    'endUserTypeName',
    'productBrandName'
  ];
  logginUserFirstName: any;
  currentDate: Date;
  wipDashboardTableData: any;
  erTotalCount = null;
  erOpenCount = null;
  erWipCount = null;
  erHoldCount = null;
  erClosedCount = null;
  filterSelectObj = [];//
  filterList = [];
  statusMaster = [];
  taskList = [];
  subTaskList = [];
  roleNameList = [];
  filteredSubTask: any;
  supportTeamMaster = [];
  allFiltersSelected = true;
  filterValues = {};
  isExpanded = false;
  // 
  saleorder = null;
  soli = null;
  erNumber = null;
  dueWeek = null;
  year = null;
  csrProjectManager = null;
  customerName = null;
  createdDate = null;
  enggDueDate = null;
  enggCompletionDate = null;
  creator = null;
  reviewer = null;
  release = null;
  shipDate = null;
  headerStatusProfile = null;
  leadTime = null;
  supportTeam = null;
  tagNumber = null;
  erStatus = null;
  endUserTypeName = null;
  productBrandName = null;
  // 'Id',
  filterEntity = new MatTableDataSource<MyDashboardInterface>(ELEMENT_DATA);
  filterType = MatTableFilter.ANYWHERE;
  dataSource = new MatTableDataSource<MyDashboardInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<MyDashboardInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('wipDashboard') wipDashboardTable: MatTable<MyDashboardInterface>;
  @ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  routesArray = [{ task: "PRECONFIG", route: "enggTool/preConfig" }, { task: "BOMCONFIG", route: "enggTool/bomConfig" },
  { task: "DESIGN", route: "enggTool/bomConfig" }, { task: "NPC", route: "enggTool/bomConfig" },
  { task: "Calculation", route: "enggTool/configuration" }, { task: "Tests", route: "enggTool/configuration" },
  { task: "External Deliverables", route: "enggTool/configuration" }, { task: "Other Engg Activities", route: "enggTool/configuration" },
  { task: "Quality Activities", route: "enggTool/qualityDoc" }]
  userPlant: string;

  //selection = new SelectionModel<MyDashboardInterface>(true, []);
  //selectedRowIndex: number;

  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder, private http: HttpClient, public router: Router, private element: ElementRef) {
    // 
    this.commonService.userDetails.subscribe(val => {
      this.logginUserFirstName = val['firstName'];
      this.currentDate = new Date();
      //Get User Details Plant
    this.commonService.userDetails.subscribe(val => {
      this.userPlant = '';
      if (val['plantName'] != null && val['plantName'] != undefined) {
        this.userPlant = val['plantName'];
      }
    });
    });
    // Object to create Filter for
    // this.filterSelectObj = [
    //   {
    //     name: 'Sale Order',
    //     columnProp: 'saleorder',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Soli',
    //     columnProp: 'soli',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   },
    //   {
    //     name: 'ER Number',
    //     columnProp: 'erNumber',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Due Week',
    //     columnProp: 'dueWeek',
    //     isChecked: true,
    //     type: 'date',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Year',
    //     columnProp: 'year',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Project Manager',
    //     columnProp: 'csrProjectManager',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   },
    //   {
    //     name: 'Customer Name',
    //     columnProp: 'customerName',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Created Date',
    //     columnProp: 'createdDate',
    //     isChecked: true,
    //     type: 'date',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Engg. Due Date',
    //     columnProp: 'enggDueDate',
    //     isChecked: true,
    //     type: 'date',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Engg. Completion Date',
    //     columnProp: 'enggCompletionDate',
    //     isChecked: true,
    //     type: 'date',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Creator',
    //     columnProp: 'creator',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Reviewer',
    //     columnProp: 'reviewer',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Release',
    //     columnProp: 'release',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Ship Date',
    //     columnProp: 'shipDate',
    //     isChecked: true,
    //     type: 'date',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Header Status Profile',
    //     columnProp: 'headerStatusProfile',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Lead Time',
    //     columnProp: 'leadTime',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Support Team',
    //     columnProp: 'supportTeam',
    //     isChecked: true,
    //     type: 'select',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Tag Number',
    //     columnProp: 'tagNumber',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Due Status',
    //     columnProp: 'erStatus',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'EndUserType',
    //     columnProp: 'endUserTypeName',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }, {
    //     name: 'Product Brand',
    //     columnProp: 'productBrandName',
    //     isChecked: true,
    //     type: 'text',
    //     value: '',
    //     options: []
    //   }
    // ]
    // // 
  }

  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }
  ngOnInit(): void {
    this.commonService.currentview.next('Dashboad > My Dashboard');
    //this.getMyDashboardData();
    this.createForm();
    //this.dataSource.filterPredicate = this.createFilter();//
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      console.log(data);
      console.log(filter);
      let matchFound = false;
      for (let column of this.displayedColumns) {
        if (column in data) {
          if (data[column]) {
            matchFound = (matchFound || data[column].toString().trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1)
          }
        }
      }
      return matchFound;
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.allFiltersSelected = true;
    //this.toggleAllSelection()
  }
  resetSearchFilters() {
    this.filterSelectObj.forEach(item => {
      item.value = '';
    });
    this.onSearch();
  }
  onFilterListSelection() {
    console.log(this.filterList);
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes('all')) {
        this.filterList.push(item.columnProp);
      }
    });
    this.filterSelectObj.forEach(item => {
      if (this.filterList.includes(item.columnProp)) {
        item.isChecked = true;
      } else {
        item.isChecked = false;
      }

    });
  }
  toggleAllSelection() {
    if (this.allFiltersSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
  optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allFiltersSelected = newStatus;
  }
  openClick() {
    this.toggleAllSelection();
  }
  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }
  updateList(value) {
    console.log(value);
    this.filteredSubTask = this.subTaskList;
    this.filteredSubTask = this.subTaskList.filter(option => option.toLowerCase().includes(value));
    console.log(this.filteredSubTask);
    //this.filteredOptions = rfilteredOptions;
  }
  //
  createForm() {
    this.filterForm = this.formBuilder.group({
      // filterList: [''],
      // filterConfig: [''],
      // saleorder: [''],
      // soli: [''],
      // erNumber: [''],
      // dueWeek: [''],
      // year: [''],
      // csrProjectManager: [''],
      // customerName: [''],
      // createdDate: [''],
      // enggDueDate: [''],
      // enggCompletionDate: [''],
      // creator: [''],
      // reviewer: [''],
      // release: [''],
      // shipDate: [''],
      // headerStatusProfile: [''],
      // leadTime: [''],
      // supportTeam: [''],
      // tagNumber: [''],
      // erStatus: [''],
      // endUserTypeName: [''],
      // productBrandName: [''],
      matrixType: [null],
      plantType: [null],
      year: [[null], [Validators.required]],
      month: [null],
      endUserType: [null],
      productFamilyType: [null],
      //Additional Filters
      doneStartDate: [null],
      doneEndDate: [null],
      dueStartDate: [null],
      dueEndDate: [null],
      productType: [null],
      enggComplete: [null],
      dueStatus: [null]
    })
    this.getMatrixFiltersData();
    // const group = this.formBuilder.group({});
    //  filterList.forEach(element => {
    //   const control = this.formBuilder.control(
    //     element.value,
    //     );
    //     group.addControl(element.columnProp, control);
    //   });
    //   return group;
  }

  onSearch() {
    let formData = {};
    formData = this.filterForm.value;
    formData['doneStartDate'] = this.commonService.dateTimestamp(this.filterForm.value.doneStartDate);
    formData['doneEndDate'] = this.commonService.dateTimestamp(this.filterForm.value.doneEndDate);
    formData['dueStartDate'] = this.commonService.dateTimestamp(this.filterForm.value.dueStartDate);
    formData['dueEndDate'] = this.commonService.dateTimestamp(this.filterForm.value.dueEndDate);
    const searchType = [];
    this.filterSelectObj.forEach(field => {
      if (field.value != null && field.value != '') {
        //formData.push({
        if (field.type === 'date') {
          let selectedDate = new Date(field.value).getTime();
          const DateStr = selectedDate + '';
          selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
          formData[field.columnProp] = selectedDate;
          searchType.push(field.columnProp);
        }
        if (field.type === 'text' || field.type === 'select') {
          formData[field.columnProp] = field.value;
          searchType.push(field.columnProp);
        }
        //})
      }
    });
    formData['searchType'] = searchType;
    console.log(formData);
    this.apiMappingsService.getWipDeepdiveReportData(formData).subscribe((data) => {
      if (data) {
        console.log(data);
        // this.masterData = data;
        // this.erTotalCount = data['erCount'];
        // this.erOpenCount = data['openCount'];
        // this.erWipCount = data['wipCount'];
        // this.erHoldCount = data['holdCount'];
        // this.erClosedCount = data['closedCount'];
        this.wipDashboardTableData = data['wipDeepDriveReport']
        this.prepareTableData(this.wipDashboardTableData);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }
  getMatrixFiltersData() {

    this.apiMappingsService.getMatrixFiltersData().subscribe((data) => {
      if (data) {
        this.matrixTypeList = data['matrixType'];
        this.plantTypeList = data['plantType'];
        this.yearList = data['year'];
        this.monthList = data['month'];
        // this.weekList = data['week'];
        // this.weekFilter = data['week'];
        this.endUserTypeList = data['endUserType'];
        this.productFamilyList = data['productFamilyType'];
        this.enggCompleteList = data['enggComplete'];
        this.dueStatusList = data['dueStatus'];
        this.loadDefaultFilters();
      }
    });
  }
  loadDefaultFilters() {
    this.filterForm.get('matrixType').patchValue(this.matrixTypeList[0]);
    ///this.filterForm.get('plantType').patchValue([...this.plantTypeList.map(item => item)]);
    this.filterForm.get('plantType').patchValue([this.userPlant]);
    this.filterForm.get('year').patchValue([this.year]);
    this.filterForm.get('endUserType').patchValue(['Commercial']);
    this.filterForm.get('productFamilyType').patchValue(['Masoneilan']);
    //this.filterForm.get('month').patchValue([this.month]);
    //this.onMonthSelect();
    //const weekSelect = _.filter(this.weekFilter, { 'week': this.weekDefault });
    //this.filterForm.get('week').patchValue(weekSelect);
    this.expandAction();
    this.getWipDeepdiveReportData();
  }
  getWipDeepdiveReportData() {
    let formData = {};
    formData = this.filterForm.value;
    formData['doneStartDate'] = this.commonService.dateTimestamp(this.filterForm.value.doneStartDate);
    formData['doneEndDate'] = this.commonService.dateTimestamp(this.filterForm.value.doneEndDate);
    formData['dueStartDate'] = this.commonService.dateTimestamp(this.filterForm.value.dueStartDate);
    formData['dueEndDate'] = this.commonService.dateTimestamp(this.filterForm.value.dueEndDate);
    this.apiMappingsService.getWipDeepdiveReportData(formData).subscribe((data) => {
      if (data) {
        this.statusMaster = data['statusMaster'];
        this.taskList = data['taskMaster'];
        this.subTaskList = data['subTaskMaster'];
        this.filteredSubTask = data['subTaskMaster'];
        this.roleNameList = data['roleNameMaster'];
        //this.supportTeamMaster = data['supportTeamMaster'];
        this.wipDashboardTableData = data['wipDeepDriveReport']
        this.prepareTableData(this.wipDashboardTableData);
      }
    });
  }

  prepareTableData(wipDashboardTableData) {
    ELEMENT_DATA = [];
    wipDashboardTableData.forEach(wipDashboard => {
      ELEMENT_DATA.push({

        saleorder: wipDashboard.saleorder,
        soli: wipDashboard.soli,
        erNumber: wipDashboard.erNumber,
        dueWeek: wipDashboard.dueWeek,
        year: wipDashboard.year,
        csrProjectManager: wipDashboard.csrProjectManager,
        customerName:  wipDashboard.customerName,
        createdDate:  this.dateFormatter(wipDashboard.createdDate),
        enggDueDate:  this.dateFormatter(wipDashboard.enggDueDate),
        enggCompleteDate:  this.dateFormatter(wipDashboard.enggCompleteDate),
        creator: wipDashboard.creator,
        reviewer: wipDashboard.reviewer,
        release: wipDashboard.release,
        shipDate:  this.dateFormatter(wipDashboard.shipDate),
        headerStatusProfile: wipDashboard.headerStatusProfile,
        leadTime: wipDashboard.leadTime,
        supportTeam: wipDashboard.supportTeam,
        tagNumber: wipDashboard.tagNumber,
        erStatus: wipDashboard.erStatus,
        endUserTypeName: wipDashboard.endUserTypeName,
        productBrandName: wipDashboard.productBrandName,
        searchType: wipDashboard.searchType

        //         preConfigId: wipDashboard.preConfigId,
        //         indicator: wipDashboard.indicator,
        //         orderNumber: wipDashboard.orderNumber,
        //         soli: myDashboard.soli,
        //         erNumber: myDashboard.erNumber,
        //         task: myDashboard.task,
        //         subTask: myDashboard.subTask,
        //         roleName: myDashboard.roleName,
        //         roleId: myDashboard.roleId,
        // tagNumber: myDashboard.tagNumber,
        //         assignee: myDashboard.assignee,
        //         hoursAssign: myDashboard.hoursAssign,
        //         hoursSpent: myDashboard.hoursSpent,
        //         progress: myDashboard.progress,
        //         startDate: this.dateFormatter(myDashboard.startDate),//startDate,
        //         endDate: this.dateFormatter(myDashboard.endDate),//endDate,
        //         searchType: myDashboard.searchType
      });
      // id: erRequest.id,
    });
    this.dataSource.data = ELEMENT_DATA;
    // 
    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(ELEMENT_DATA, o.columnProp);
    });
    // 
  }
  // 
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);

  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      console.log(searchTerms);

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }


  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }
  // 
  dateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');
      return result;
    }
  }
  //excel Date Formatter
  excelDateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      //const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');//String
      const result = new Date(value * 1000);
      return result;
    }
  }
  onSearchERRequest(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onClickWorkFLowRedirection(navItem: any, saleOrder: any, erNumber: any, soLiNumber: any, task: any, subTask: any) {
    this.commonService.saleOrderNumber.next('');
    this.commonService.erNumber.next('');
    sessionStorage.setItem('erNumber', '');
    sessionStorage.setItem('soLiNumber', '');
    if (Helpers.isLowerCaseEquals(navItem, 'soLi')) {
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.saleOrderNumber.next(saleOrder);
      sessionStorage.setItem('saleOrderNumber', saleOrder);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      let task = this.routesArray.filter(item => item.task == task);
      let row = this.routesArray.filter(item => item.task == task);
      if (row && row.length > 0) {
        this.router.navigate([row[0].route]);
      }
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
      // this.navRoute = 'enggTool/preConfig';
      this.navRoute = 'enggTool/summaryInfo';
      this.commonService.erNumber.next(erNumber);
      sessionStorage.setItem('erNumber', erNumber);
      sessionStorage.setItem('soLiNumber', soLiNumber);
      let row = this.routesArray.filter(item => item.task == task);
      if (row && row.length > 0) {
        sessionStorage.setItem("subTask", subTask);
        sessionStorage.setItem("task", task);
        this.router.navigate([row[0].route]);
      }
      //ActivitiTree Data
      if (soLiNumber) {
        this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
          if (data) {
            //this.commonService.activitiTreeData.next(data);
            sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          }
        });
      }
    }
  }
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("wip-deepdive report");
  }
  exportArray() {
    const onlyNameAndSymbolArr: Partial<MyDashboardInterface>[] = this.wipDashboardTableData.map(wipDashboard => ({
      saleorder: wipDashboard.saleorder,
      soli: wipDashboard.soli,
      erNumber: wipDashboard.erNumber,
      dueWeek: wipDashboard.dueWeek,
      year: wipDashboard.year,
      csrProjectManager: wipDashboard.csrProjectManager,
      customerName: wipDashboard.customerName,
      createdDate: this.excelDateFormatter(wipDashboard.createdDate),
      enggDueDate: this.excelDateFormatter(wipDashboard.enggDueDate),
      enggCompleteDate: this.excelDateFormatter(wipDashboard.enggCompleteDate),
      creator: wipDashboard.creator,
      reviewer: wipDashboard.reviewer,
      release: wipDashboard.release,
      shipDate: this.excelDateFormatter(wipDashboard.shipDate),
      headerStatusProfile: wipDashboard.headerStatusProfile,
      leadTime: wipDashboard.leadTime,
      supportTeam: wipDashboard.supportTeam,
      tagNumber: wipDashboard.tagNumber,
      erStatus: wipDashboard.erStatus,
      endUserTypeName: wipDashboard.endUserTypeName,
      productBrandName: wipDashboard.productBrandName,
      searchType: wipDashboard.searchType
    }));
    ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "WIP-Deepdive Report");
    //F&PT_MyDashboardData
  }
}

export interface MyDashboardInterface {

  saleorder: string,
  soli: string,
  erNumber: string,
  dueWeek: string,
  year: string,
  csrProjectManager: string,
  customerName: string,
  createdDate: any,
  enggDueDate: any,
  enggCompleteDate: any,
  creator: string,
  reviewer: string,
  release: string,
  shipDate: any,
  headerStatusProfile: string,
  leadTime: string,
  supportTeam: string,
  tagNumber: string,
  erStatus: string,
  endUserTypeName: string,
  productBrandName: string,
  searchType: string
}
let ELEMENT_DATA: MyDashboardInterface[] = [];