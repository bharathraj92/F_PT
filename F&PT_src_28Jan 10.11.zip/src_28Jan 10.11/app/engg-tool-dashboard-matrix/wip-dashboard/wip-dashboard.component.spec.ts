import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WIPDashboardComponent } from './wip-dashboard.component';

describe('WIPDashboardComponent', () => {
  let component: WIPDashboardComponent;
  let fixture: ComponentFixture<WIPDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WIPDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WIPDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
