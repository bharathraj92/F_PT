import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasoneilanDashboardComponent } from './masoneilan-dashboard.component';

describe('MasoneilanDashboardComponent', () => {
  let component: MasoneilanDashboardComponent;
  let fixture: ComponentFixture<MasoneilanDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasoneilanDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasoneilanDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
