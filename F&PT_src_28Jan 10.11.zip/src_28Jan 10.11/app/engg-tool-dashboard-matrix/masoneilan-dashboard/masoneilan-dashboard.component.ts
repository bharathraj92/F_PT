import { Component, OnInit, Inject, ViewChild, ElementRef, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import * as Mock from 'src/app/mock/scheduling-graph.mock';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ExportExcel } from "src/app/util/exportExcel";
import { BarGraphComponentComponent } from "src/app/util/bar-graph-component/bar-graph-component.component";
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import exportingtable from 'highcharts/modules/export-data';
import offlineexporting from 'highcharts/modules/offline-exporting'
@Component({
  selector: 'app-masoneilan-dashboard',
  templateUrl: './masoneilan-dashboard.component.html',
  styleUrls: ['./masoneilan-dashboard.component.scss']
})
export class MasoneilanDashboardComponent implements OnInit, OnDestroy, OnChanges {
  //Chart: Chart;
  filterForm: FormGroup;
  isExpanded = false;
  loaded = false;
  graphData: any;
  _graphData: any;
  freqChart: any;
  _freqChart: any;
  matrixTypeList: any;
  plantType:any;
  plantTypeList: any;  
  startDate: any;
  endDate: any;
  masoneilanTypeList: any;
  // year: any;
  // month: any;
  // week: any;
  // weekDefault: any;
  // yearList: any;
  // monthList: any;
  // weekList: any;
  // weekFilter: any;
  endUserTypeList: any;
  productFamilyList: any;
  chart1Options: any;
  chart2Options: any;
  chart1: Chart;
  chart2: Chart;
  masterFilters: any;
  userPlant: string;
  constructor(
    //public dialogRef: MatDialogRef<any>,
    //@Inject(MAT_DIALOG_DATA) 
    //public graphData,
    public formBuilder: FormBuilder,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, ) {
    //this.getMasoneilanDashboardData();
     //Get User Details Plant
     this.commonService.userDetails.subscribe(val => {
      this.userPlant = '';
      if (val['plantName'] != null && val['plantName'] != undefined) {
        this.userPlant = val['plantName'];
      }
    });
  }

  ngOnInit(): void {
    //this.masterFilters = Mock.getAllAvailableColumns['MasterFilters'];
    //this.filterForm = this.createFilterControls(this.masterFilters);
    this.filterForm = this.formBuilder.group({
      matrixType: [null],
      plantType: [null],
      startDate: [null],
      endDate: [null],
      // year: [[null], [Validators.required]],
      // month: [null],
      // week: [null],
      endUserType: [null],
      productFamilyType: [null]
    });
    //this.getYearMonthWeek(new Date());
    this.getMatrixFiltersData();
    //this.getGraphData();
  }

  ngOnDestroy(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    let cdata = changes.graphData.currentValue;
    if (this.loaded === true && cdata !== undefined) {
      this.loadGraphs(cdata);
    }
  }
  // getYearMonthWeek(d: any) {
  //   d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  //   d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  //   const yearStart: any = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  //   const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  //   console.log([d.getUTCFullYear(), d.getMonth(), weekNo]);
  //   this.year = d.getUTCFullYear();
  //   this.month = (d.getMonth() + 1).toString();
  //   this.weekDefault = weekNo;
  //   return [d.getUTCFullYear(), d.getMonth(), weekNo];
  // }

  // loadDefaultFilters() {
  //   this.filterForm.get('matrixType').patchValue(this.matrixTypeList[0]);
  //   this.filterForm.get('masoneilanType').patchValue(['COMMERCIAL']);
  //   this.expandAction();
  //   this.getMasoneilanDashboardData();
  // }
  expandAction() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded === true) {
      document.getElementById('filterbar').style.height = 'auto';
    } else {
      document.getElementById('filterbar').style.height = '120px';
    }
  }

  getMatrixFiltersData() {
    this.apiMappingsService.getMatrixFiltersData().subscribe((data) => {
      if (data) {
        this.matrixTypeList = data['matrixType'];
        this.plantTypeList = data['plantType'];
        // this.yearList = data['year'];
        // this.monthList = data['month'];
        // this.weekList = data['week'];
        // this.weekFilter = data['week'];
        this.endUserTypeList = data['endUserType'];
        this.productFamilyList = data['productFamilyType'];
        this.loadDefaultFilters();
      }
    });
  }
  loadDefaultFilters() {
    this.filterForm.get('matrixType').patchValue(this.matrixTypeList[0]);
    ///this.filterForm.get('plantType').patchValue([...this.plantTypeList.map(item => item)]);
    this.filterForm.get('plantType').patchValue([this.userPlant]);
    //this.filterForm.get('year').patchValue([this.year]);
    //this.filterForm.get('month').patchValue([this.month]);
    this.filterForm.get('endUserType').patchValue(['Commercial']);
    this.filterForm.get('productFamilyType').patchValue(['Masoneilan']);
    // this.onMonthSelect();
    // const weekSelect = _.filter(this.weekFilter, { 'week': this.weekDefault });
    // this.filterForm.get('week').patchValue(weekSelect);
    this.expandAction();
    this.getMasoneilanDashboardData();
  }
  // onMonthSelect() {
  //   const months = this.filterForm.get('month').value;
  //   this.weekFilter = [];
  //   this.week = [];
  //   if (months != null && months.length > 0) {
  //     months.forEach(month => {
  //       this.weekList.forEach(week => {
  //         if ((week.month.toString()) === month) {
  //           this.weekFilter.push(week);
  //           this.week.push(week);
  //         }
  //       });
  //     });
  //   }
  //   this.filterForm.get('week').patchValue(this.week);
  // }
  resetFilters() {
    this.filterForm.reset();
    this.getMasoneilanDashboardData();
  }

  getMasoneilanDashboardData() {
    //const data = Mock.getAllAvailableColumns['columnData'];
    let formData = {};
    formData = this.filterForm.value;
    formData['startDate'] = this.commonService.dateTimestamp(this.filterForm.value.startDate);
    formData['endDate'] = this.commonService.dateTimestamp(this.filterForm.value.endDate);
    //const data1 = Mock.getAllAvailableColumns;
    this.apiMappingsService.getMasoneilanDashboardData(formData).subscribe((data) => {
      if (data) {
        this.graphData = [];
        this._graphData = [];
        this.graphData = data;
        this._graphData = _.cloneDeep(this.graphData)
        this.loadGraphs(data);
      }
    });
  }

  loadGraphs(data) {
    this.freqChart = [];
    this._freqChart = [];
    //let graphData = Mock.getAllAvailableColumns['columnData'];
    let graphData = data;
    this.freqChart = graphData;
    this._freqChart = _.cloneDeep(this.freqChart);

    this.initChart1(this.freqChart['masoneilanTotalBacklog']);
    this.initChart2(this.freqChart['masoneilanOverdue']);
  }

  @ViewChild("chart1El", { read: ElementRef }) chart1El: ElementRef;
  //chart1Options: Highcharts.Options;
  //chart1Options: Chart.Options;
  initChart1(chartData) {
    let seriesName: any = [];
    let seriesData: any = [];
    if (chartData.series.length) {
      seriesName = chartData.series[0].name;
      seriesData = chartData.series[0].data;
    }
    if (this.chart1 != undefined) {
      if (this.chart1['dataTableDiv'] != undefined) {
        this.chart1['dataTableDiv'].remove();
      }
    }

    this.chart1Options = {
      chart: {
        type: 'column'
      },
      credits: {
        enabled: false
      },
      title: {
        text: chartData.maintitle
      },
      xAxis: {
        type: 'category',
        // categories: [
        //   '2021W18',
        //   '2021W19',
        //   '2021W20',
        //   '2021W21',
        //   '2021W22',
        //   '2021W23',
        //   '2021W24',
        //   '2021W25'
        // ],
        title: {
          text: chartData.xaxisTitle
        },
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: chartData.yaxisTitle
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0,
          opacity: 0.8,
          dataLabels: {
            enabled: true,
            // style: {
            //   color: Highcharts.getOptions().colors[1]
            // },
            formatter: function () {
              if (this.y != null && this.y > 0) {
                //return Math.round(100 * this.y / this.total) + ' %';
                return this.y;
              }
            }
          }
        }
      },
      series: //chartData.series
        [
          {
            name: chartData.series[0].name,
            type: undefined,
            //type: 'spline',
            data: chartData.series[0].data
          },
          {
            name: chartData.series[1].name,
            type: undefined,
            data: chartData.series[1].data
          },
          {
            name: chartData.series[2].name,
            type: 'spline',
            data: chartData.series[2].data
          },
        ]

    }
    //this.chart1 = Highcharts.chart(this.chart1El.nativeElement, this.chart1Options);
    this.chart1 = new Chart(this.chart1Options);
  }

  initChart2(chartData) {
    let seriesName: any = [];
    let seriesData: any = [];
    if (chartData.series.length) {
      seriesName = chartData.series[0].name;
      seriesData = chartData.series[0].data;
    }
    if (this.chart2 != undefined) {
      if (this.chart2['dataTableDiv'] != undefined) {
        this.chart2['dataTableDiv'].remove();
      }
    }

    this.chart2Options = {
      chart: {
        type: 'column'
      },
      credits: {
        enabled: false
      },
      title: {
        text: chartData.maintitle
      },
      xAxis: {
        type: 'category',
        // categories: [
        //   '2021W18',
        //   '2021W19',
        //   '2021W20',
        //   '2021W21',
        //   '2021W22',
        //   '2021W23',
        //   '2021W24',
        //   '2021W25'
        // ],
        title: {
          text: chartData.xaxisTitle
        },
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: chartData.yaxisTitle
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0,
          opacity: 0.8,
          dataLabels: {
            enabled: true,
            // style: {
            //   color: Highcharts.getOptions().colors[1]
            // },
            formatter: function () {
              if (this.y != null && this.y > 0) {
                //return Math.round(100 * this.y / this.total) + ' %';
                return this.y;
              }
            }
          }
        }
      },
      series: //chartData.series
        [
          {
            name: chartData.series[0].name,
            type: 'spline',
            data: chartData.series[0].data
          },
        ]
    }
    this.chart2 = new Chart(this.chart2Options);
  }
  // 
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("MasoneilanDashboard");
  }
  // exportArray() {
  //   const onlyNameAndSymbolArr: Partial<MasoneilanDashboardInterface>[] = this.erMasterTableData.map(erMaster => ({
  //     orderNumber: erMaster.orderNumber,
  //     soli: erMaster.soli,
  //     erNumber: erMaster.erNumber,
  //     tagNumber: erMaster.tagNumber,
  //     plant: erMaster.plant,
  //     complexity: erMaster.complexity,
  //     customerName: erMaster.customerName,
  //     sapHeader: erMaster.sapHeader,
  //     sapHeaderDesc: erMaster.sapHeaderDesc,
  //     erStatus: erMaster.erStatus,
  //     erCompletionDate: new Date(erMaster.erCompletionDate),//erCompletionDate,
  //     creator: erMaster.creator,
  //     reviewer: erMaster.reviewer,
  //     release: erMaster.release,
  //     orderBookedDate: new Date(erMaster.orderBookedDate),//orderBookedDate,
  //     shipDate: new Date(erMaster.orderBookedDate),//shipDate,
  //     enggCompletionDate: new Date(erMaster.enggCompletionDate),//enggCompletionDate,
  //     supportTeam: erMaster.supportTeam,
  //     erRevisionNumber: erMaster.erRevisionNumber,
  //     costOfTheLine: erMaster.costOfTheLine,
  //     enggBlocks: erMaster.enggBlocks
  //   }));
  //   ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "Master Dashboard");
  //   //F&PT_MasterDashboardData
  // }
}

export interface MasoneilanDashboardInterface {
  orderNumber: string;
  soli: string;
  erNumber: string;
  tagNumber: string;
  plant: string;
  complexity: string;
  customerName: string;
  sapHeader: string;
  sapHeaderDesc: string;
  erStatus: string;
  erCompletionDate: any;
  creator: string;
  reviewer: string;
  release: string;
  orderBookedDate: any;
  shipDate: any;
  enggCompletionDate: any;
  supportTeam: string;
  erRevisionNumber: number,
  costOfTheLine: number,
  enggBlocks: string
}
let ELEMENT_DATA: MasoneilanDashboardInterface[] = [];