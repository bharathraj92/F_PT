
import { Component, OnInit, Inject } from '@angular/core';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as Mock from 'src/app/mock/attachments.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { DesignDialogData } from '../external-deliverables/external-deliverables.component';
import { BhAlertService } from 'bh-theme';
import { saveAs } from "file-saver";
import { Logs } from 'selenium-webdriver';
@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {
  comments: any;
  fileToUpload: File = null;
  selectedAttachments: any;
  displayedColumns: string[] = ['moduleType', 'lastLevelDesc', 'erNumber', 'status', 'createdDate', 'userName', 'transactedBy', 'modifiedBy', 'comments', 'holdComments', 'supportTeam','info' ];
  preConfigId: any;
  moduleName: any;
  enableDelete: any;
  taskList: any[] = [];

  ERLogInterface
  dataSource = new MatTableDataSource<ERLogInterface>(ELEMENT_DATA);

  constructor(
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {

  }

  ngOnInit(): void {
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.getTimelog();
  }

  getTimelog() {
    // const data = Mock.attachmentsData['attachmentsDto'];
    // this.prepareTableData(data);
    this.apiMappingsService.getTimelog(this.preConfigId).subscribe((data) => {
      if (data) {
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }
  //   comments: "888888"
  // createdDate: 1628774234.023
  // creatorId: 52
  // erNumber: "ER-1229741-7000-73"
  // hold: false
  // holdComments: "88888888"
  // info: "SAVE action has beem performed by user BHARATH at 2021-08-12T13:17:13.997Z"
  // lastLevelDesc: "Nut_Body"
  // moduleType: "DESIGN"
  // preConfigId: 73
  // reviewerId: null
  // sso: "503073700"
  // startDate: 1580551441
  // status: "SAVE"
  // statusId: 0
  // transactedBy: "CREATOR"
  // userName: "Rajadurai"
  prepareTableData(logTableData) {
    ELEMENT_DATA = [];
    logTableData.forEach(log => {
      ELEMENT_DATA.push({
        moduleType: log.moduleType,
        status: log.status,
        erNumber: log.erNumber,
        lastLevelDesc: log.lastLevelDesc,
        createdDate: log.createdDate,
        userName: log.userName,
        sso: log.sso,
        transactedBy: log.transactedBy,
        creatorFirstName: log.creatorFirstName,
        creatorSso: log.creatorSso,
        comments: log.comments,
        holdComments: log.holdComments,
        info: log.info,
        supportUserFirstName: log.supportUserFirstName,
supportUserSso: log.supportUserSso
      });
      // id: erRequest.id,
      this.dataSource.data = ELEMENT_DATA;
    });
    // 
  }

}
export interface ERLogInterface {
  moduleType: string;
  status: string;
  erNumber: string;
  lastLevelDesc: string;
  createdDate: any;
  userName: string;
  sso: string;
  transactedBy: string;
  creatorFirstName: string;
  creatorSso: string;
  comments: string;
  holdComments: string;
  info: string;
  supportUserFirstName: string;
  supportUserSso: string;
}
let ELEMENT_DATA: ERLogInterface[] = [];