import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ERHistoryComponent } from './er-history.component';

describe('ERHistoryComponent', () => {
  let component: ERHistoryComponent;
  let fixture: ComponentFixture<ERHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ERHistoryComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ERHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
