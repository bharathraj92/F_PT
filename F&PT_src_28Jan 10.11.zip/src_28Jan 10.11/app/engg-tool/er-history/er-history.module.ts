import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//export * from './manage-access/manage-access.component';
//export * from './suggestions/suggestions.component';
export * from '../../app.module';
//export * from '../engg-tool.module';
export { ERHistoryComponent } from './er-history.component';
export * from '../history/history.component';
export * from '../activity-tree-history/activity-tree-history.component';

//import { ManageAccessComponent } from './manage-access/manage-access.component';
import { ThemeLibModule, NavService } from 'bh-theme';
import { BhAlertService } from 'bh-theme';
import { MatSortModule } from '@angular/material/sort';
import { BrowserModule } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';
//import { SuggestionsComponent } from './suggestions/suggestions.component';
import { from } from 'rxjs';
import { TranslateLoader, TranslateModule, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ERHistoryComponent } from './er-history.component';
import { HistoryComponent } from '../history/history.component';
import { ActivityTreeHistoryComponent } from '../activity-tree-history/activity-tree-history.component';
//import { MCodeComponent } from './m-code-data/m-code-data.component';
//import { DemoteComponent } from './demote-data/demote-data.component';
//import { McodeHistoryModalComponent } from './mcode-history-modal/mcode-history-modal.component';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { MatTabsModule } from '@angular/material/tabs';
//import { ModalComponent } from '../components/modal/modal.component';
@NgModule({
  declarations: [
    //ModalComponent,
    ERHistoryComponent,
    HistoryComponent,
    ActivityTreeHistoryComponent
    //McodeHistoryModalComponent
  ],
  imports: [
    CommonModule,
    //MatTabsModule,
    ThemeLibModule,
    FormsModule,
    BrowserModule,
    MatTableModule,
    MatSortModule,
    ReactiveFormsModule,
    //BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ],
  exports: [
    ERHistoryComponent,
    HistoryComponent,
    ActivityTreeHistoryComponent
    //McodeHistoryModalComponent
  ],
  providers: [NavService, BhAlertService]
})
export class ERHistoryModule { }

// AOT compilation support
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, "assets/i18n/", ".json");
}
