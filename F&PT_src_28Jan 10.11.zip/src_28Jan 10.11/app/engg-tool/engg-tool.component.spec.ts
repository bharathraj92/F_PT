import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnggToolComponent } from './engg-tool.component';

describe('EnggToolComponent', () => {
  let component: EnggToolComponent;
  let fixture: ComponentFixture<EnggToolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnggToolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnggToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
