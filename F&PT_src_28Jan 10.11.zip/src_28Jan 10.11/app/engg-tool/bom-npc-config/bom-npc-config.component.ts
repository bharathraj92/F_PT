import { Component, OnInit, ViewChild, Inject, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { CommonService } from 'src/app/Services/common.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import * as Helpers from 'src/app/util/helper';
import { BhAlertService } from 'bh-theme';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as Mock from 'src/app/mock/npc.mock';
import { TranslateService } from '@ngx-translate/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NPCSearchModalComponent } from '../npc-search-modal/npc-search-modal.component';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { EnggToolComponent } from '../engg-tool.component';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../util/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-bom-npc-config',
  templateUrl: './bom-npc-config.component.html',
  styleUrls: ['./bom-npc-config.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ]
})
export class BomNpcConfigComponent implements OnInit {
  npcForm: FormGroup;
  npcdisplayedColumns = ['drawingNumber', 'mcode', 'qcode', 'partNumber', 'erNPCReference', 'childErNumber'];
  // columnsToDisplay: string[] = ['Department', 'SAPStatus', 'EnggCoordinator', 'RequestedDate', 'CompletionDate'];
  columnsToDisplay: string[] = ['department', 'sapMaterialStatus', 'sapDistributionMaterialStatus', 'plantSpecificMaterialStatus', 'procurementType', 'requestedDate', 'completedDate'];
  expandedElement: NPCInterface | null;
  dataSource = new MatTableDataSource<NPCInterface>();
  partStatusDataSource = new MatTableDataSource<PartStatusInterface>();
  expendedDataSource = new MatTableDataSource<ExpendedNPCInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('npc') npcTable: MatTable<NPCInterface>;
  //Release Fix:loadBomConfig after NPC Promote
  selection = new SelectionModel<NPCInterface>(true, []);
  npcSearchModal: MatDialogRef<NPCSearchModalComponent>;
  selectedRowIndex: number;
  npcListData: any = [];
  subNpcListData: any = [];
  refFormDisabled: boolean;
  npcFormDisable: boolean;
  activityTreeValid: boolean;
  refFormValid: boolean;
  npcFormValid: boolean;
  filteredOptions: any;
  npcComponentList: any;
  npcCategoryList: any;
  preConfigId: any;
  soLiNumber: any;
  plantMasterList: any;
  plantCode: any;
  datePipe = new DatePipe("en-US");
  @Input() disableFlag: boolean;
  @Output("loadBomConfig") loadBomConfig: EventEmitter<any> = new EventEmitter();
  @Input() count: any;
  @Output() countChanged: EventEmitter<any> = new EventEmitter();
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;
  partStatusData: any;
  sapErrorMessage: any;

  constructor(private apiMappingsService: ApiMappingsService,
    public commonService: CommonService,
    private bhAlertService: BhAlertService,
    public translate: TranslateService,
    public formBuilder: FormBuilder,
    private http: HttpClient,
    private enggToolComponent: EnggToolComponent,
    public dialog: MatDialog) {

  }

  ngOnInit() {
    this.getPreConfigMasterData();
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.plantCode = localStorage.getItem("userPlant");
    if (this.preConfigId != null && this.preConfigId != undefined && this.preConfigId != "") {
      this.getNpcData(this.preConfigId);
      this.getsubNpcList(this.preConfigId);
    }
    this.getOnInitData();
    this.npcForm = this.formBuilder.group({
    })
  }
  //show Message History Modal popup
  showMessageHistoryModal(task, user, item, field) {
    this.enggToolComponent.showMessageHistoryModal(task, user, item, field);
  }

  //Get sub NPC Data
  getsubNpcList(preConfigId: any) {
    this.apiMappingsService.getSubNpcData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.formatDateforSubNpc(data);
      }
    });
  }

  //Get NPC Data
  getNpcData(preConfigId: any) {
    this.apiMappingsService.getNpcData(preConfigId).subscribe((data: any) => {
      if (data && data['npcTransactionList']) {
        this.count = data;
        this.countChanged.emit(this.count);
        this.npcListData = data['npcTransactionList'];
        this.formatNpcData(this.npcListData);
        this.dataSource.data = this.npcListData;
      }
    });
  }
  //Get Part Status Data
  getPartStatusData(element) {
    let formData = {};
    element["sapErrorMessage"] = null;
    formData["id"] = element.id,
    formData["partNumber"] = element.partNumber,
    formData["plant"] = element.plantCode
    // formData["id"] = null,
    // formData["partNumber"] = '720028395-888-0000',
    // formData["plant"] = '7150',
    //this.partStatusData = Mock.svcGetNPCData;//Mock data
    //this.partStatusDataSource.data = this.partStatusData['npcPartStatus'];//Mock data
    this.partStatusDataSource.data = [];
    if (formData["partNumber"] != null && formData["plant"] != null) {
      this.apiMappingsService.getPartStatusData(formData).subscribe((data: any) => {
        if (data) {
          console.log(data);
          this.partStatusData = data;
          this.partStatusDataSource.data = this.partStatusData['npcPartStatus'];
          element["sapErrorMessage"] = this.partStatusDataSource.data[0].sapErrorMessage;
        }
      });
    }
  }
  // 
  formatNpcData(data: any) {
    data.forEach((row: any) => {
      row['subNpcResponseDto'].forEach((item: any) => {
        item.formattedRequestDate = this.datePipe.transform((item.requestDate * 1000), 'dd-MMM-yyyy hh:mm aa');
      })
      // 
      //if(row['mcodeDesc'] == null || row['mcodeDesc']  ==''){
      this.onMcodeChange(row);
      //}
      // 
    });
  }

  formatDateforSubNpc(data: any) {
    data.forEach((item: any) => {
      item.formattedRequestDate = this.datePipe.transform((item.requestDate * 1000), 'dd-MMM-yyyy hh:mm aa');
    });
    this.subNpcListData = data;
  }

  getPreConfigMasterData() {
    this.apiMappingsService.getPreConfigMasterData().subscribe((data: []) => {
      if (data) {
        this.npcCategoryList = data['npcSubCategory'];
        this.npcComponentList = data['npcSubComponent'];
        this.plantMasterList = data['plantMaster'];
        this.filteredOptions = this.npcComponentList;
      }
    });
  }

  getOnInitData() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createFormArray(): FormArray {
    return new FormArray(
      this.dataSource.data.map(
        item =>
          new FormGroup({
            npcCategory: new FormControl(item.npcCategory),
            npcComponent: new FormControl(item.npcComponent),
            makeBuy: new FormControl(item.makeBuy)
          })
      )
    );
  }

  onCategogyChange(item: any) {
    if (!item.npcSubCategoryId) {
      item.npcSubCategory = null;
      item.npcSubCategoryId = null;
    }
    if (item.npcSubCategoryId != 5) {
      item.partNumber = null;
    } else if (item.npcSubCategoryId === 5) {
      item.drawingNumber = null;
      item.mcode = null;
      item.qcode = null;
    }
  }

  change(value: any) {
    let obj = this.filteredOptions.filter((row: any) => row.id == value.subLevelComponentId);
    if (obj && obj[0]) {
      value.subLevelComponent = obj[0].levelName;
    }
  }

  ngOnDestroy() {
    sessionStorage.setItem('navigateFromNPCDashboard', "false");
  }

  validate(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromNPCDashboard') == "true" && sessionStorage.getItem('npcId')) {
      return sessionStorage.getItem('npcId') == row.id;
    }
  }

  disable() {
    let roles = JSON.parse(localStorage.getItem("roles"));
    let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Tool Administrator' || obj.roleId == 9)//9-NPC Approver Engineering
    if ((role && role.length > 0)) {
      return false;
    } else {
      return true;
    }
  }


  updateList(value: any) {
    this.filteredOptions = this.npcComponentList;
    this.filteredOptions = this.npcComponentList.filter(option => option.levelName.toLowerCase().includes(value));
  }

  showNPCSearchModal(element) {
    this.npcSearchModal = this.dialog.open(NPCSearchModalComponent, { data: { dwg: element.drawingNumber, mCode: element.mcode, qCode: element.qcode, creatorId: element.id } });
    this.npcSearchModal.afterClosed().subscribe(value => {
      if (value) {
        const id = element.id;
        const preConfigId = element.preConfigId;
        const levelTwoId = element.levelTwoId;
        element['id'] = id;
        element['preConfigId'] = preConfigId;
        element['childEr'] = value.id;
        //element['levelTwoId'] = levelTwoId;
        // const npcRefMappingId = value['id'];
        // const erNpc = value['npcNumber'];
        // // const result = Object.assign(element, value);
        // // element['id'] = null;
        // element['npcReferenceMappingId'] = npcRefMappingId;
        // element['erNpc'] = erNpc;
        element['soli'] = this.soLiNumber;
        ////this.npcFormDisable = true;
        //New
        // element['childEr'] = value.id;
        // element['childErNumber'] = value.npcNumber;
        // element['childDrawingNumber'] = value.drawingNumber;
        // element['calculationChildRefStatus'] = value.calculationCreatorStatus;
        element['childMcode'] = value.mcode;
        element['childQcode'] = value.qcode;
        element['drawingNumber'] = value.drawingNumber;
        // element['calculationChildRefStatus'] = value.calculationCreatorStatus;
        element['mcode'] = value.mcode;
        element['qcode'] = value.qcode;
        element['status'] = "NOT STARTED";
        this.saveNpc(element, 'SAVE');
      }
    });
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "NPC" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  resetNPCForm(NPC: any) {
    NPC['drawingNumber'] = '',
      NPC['npcReferenceId'] = '',
      NPC['subLevelComponent'] = '',
      NPC['subLevelComponentId'] = '',
      NPC['npcSubCategory'] = '',
      NPC['npcSubCategoryId'] = '',
      NPC['mcode'] = '',
      NPC['qcode'] = '',
      NPC['soli'] = this.soLiNumber,
      NPC['npcReferenceMappingId'] = '',
      NPC['npcReferenceId'] = '',
      NPC['npcNumber'] = '',
      NPC['makeBuy'] = '',
      NPC['erNpc'] = null,
      NPC['dwgHeader'] = '',
      NPC['mcodeDesc'] = '',
      NPC['qcodeDesc'] = '',
      NPC['generalComments'] = '',
      NPC['holdFlag'] = false,
      NPC['holdComments'] = ''
  }

  resetChildEr(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.childEr = item.childErNumber = item.childDrawingNumber
          = item.drawingNumber = item.mcode = item.qcode = null;
        this.delinkCreator(item.id);
      }
    });
  }
  delinkCreator(creatorId) {
    const moduleName = 'NPC'
    this.apiMappingsService.delinkCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.getNpcData(this.preConfigId);
        //this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
      } else {
        this.getNpcData(this.preConfigId);
        //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
      }
    });
  }
  addNpc() {
    this.npcListData.unshift({
      drawingNumber: null,
      dwgHeader: null,
      ecmNumber: null,
      enggCoordinator: null,
      enggCoordinatorFirstName: null,
      enggCoordinatorLastName: null,
      erNpc: null,
      generalComments: null,
      holdComments: null,
      holdFlag: null,
      id: null,
      levelFourMasterId: null,
      makeBuy: null,
      mcode: null,
      mcodeComments: null,
      mcodeDesc: null,
      npcNumber: null,
      npcReferenceId: null,
      npcReferenceMappingId: null,
      npcSubCategory: null,
      npcSubCategoryId: null,
      npcSubLevels: null,
      npcWorkFlowStatus: "NOT STARTED",
      parentId: this.preConfigId,
      qcode: null,
      qcodeComments: null,
      qcodeDesc: null,
      soli: this.soLiNumber,
      status: null,
      subLevelComponent: null,
      subLevelComponentId: null,
      subNpcResponseDto: this.subNpcListData,
      plantCode: this.plantCode,
      preConfigId: this.preConfigId
    });
    this.dataSource.data = this.npcListData;
  }

  deleteNpc(item: any) {
    const index = this.npcListData.indexOf(item);
    if (index > -1) {
      this.npcListData.splice(index, 1);
    }
    this.dataSource.data = this.npcListData;
  }
  validateNPC(element) {
    if (element !== null && element !== undefined) {
      if (element.holdFlag === true && (element.holdComments === '' || element.holdComments === null)) {
        this.npcFormValid = false;
        this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill Hold Comments');
      }

      if (element.subLevelComponentId === null || element.subLevelComponentId === undefined || element.subLevelComponentId === '') {
        this.npcFormValid = false;
        this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill NPC Component');
      }
      //npc SubCategory no equalto Legacy/Others
      if (element.npcSubCategoryId != 5) {
        if (element.drawingNumber === null || element.mcode === null || element.qcode === null) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill "DWG no/M-code/Q-code" fields..!');
        } else if (element.drawingNumber.length < 9 || element.mcode.length < 4 || element.qcode.length < 4) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, '"DWG no" should contain 9 characters and "M-code/Q-code" should contain 4 characters');
        }
      }
      if (element.npcSubCategoryId === 5) {
        if (element.plantCode === null || element.partNumber === null) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Plant and Part Number fileds are required ..!');
        } else if (element.partNumber.length < 4) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Part Number should contain min 4 characters..!');
        }
      }
    }
  }
  saveNpc(item: any, action: any) {
    item['npcReferenceId'] = null;
    item['npcReferenceMappingId'] = null;
    item['orphanFlag'] = false;
    //NPC Validation
    this.npcFormValid = true;
    this.validateNPC(item);
    if (this.npcFormValid === true) {
      if (action === 'SAVE') {
        item['status'] = 'SAVE';
        this.apiMappingsService.saveNpcData(item).subscribe((data: []) => {
          if (data) {
            if (this.preConfigId != null && this.preConfigId != undefined && this.preConfigId != "") {
              this.getNpcData(this.preConfigId);
            }
            //Release Fix:load BomConfig after NPC Promote
            this.loadBomConfig.emit();
            this.bhAlertService.showAlert('success', 'top', 5000, 'NPC Saved Successfully!');
          } else {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save NPC!');
          }
        });
      } else if (action === 'PROMOTE') {
        item['status'] = 'PROMOTE';
        this.apiMappingsService.saveNpcData(item).subscribe((data: []) => {
          if (data) {
            if (this.preConfigId != null && this.preConfigId != undefined && this.preConfigId != "") {
              this.getNpcData(this.preConfigId);
            }
            //Release Fix:loadBomConfig after NPC Promote
            this.loadBomConfig.emit();
            this.bhAlertService.showAlert('success', 'top', 5000, 'NPC Promoted Successfully!');
          } else {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote NPC!');
          }
        });
      }
    }
  }
  //Mcode Description Auto Populate
  onMcodeChange(element) {
    element['disableMcodeDesc'] = false;
    //element.mcodeDesc = null;
    let mCodeValue = element.mcode;
    if (mCodeValue != null && mCodeValue.length === 4) {
      this.apiMappingsService.getMcodeDesc(mCodeValue).subscribe((data) => {
        if (data && data != null) {
          if (data['mcode_flag'] === true) {
            element.mcodeDesc = data['mcodeDesc'];
            element['disableMcodeDesc'] = true;
          } else if (data['mcode_flag'] === false) {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'M-code-' + element.mcode + ' is Disabled!');
            element.mcode = null;
            element.mcodeDesc = null;
          }
        } else {
          element.mcodeDesc = null;
        }
      });
    }
  }
  npcCombinationCheck(element, orphanFlag) {
    if (element.drawingNumber != null && element.mcode != null && element.qcode != null) {
      if (element.drawingNumber.length === 9 && element.mcode.length === 4 && element.qcode.length === 4) {
        if (element.parentId) {
          element['preConfigId'] = element.parentId;
        }
        this.enggToolComponent.npcCombinationCheck(element, orphanFlag);
      }
    }
  }
  partNumberValidation(element, orphanFlag) {
    if (element.npcSubCategoryId === 5) {
      if (element.partNumber != null && element.partNumber != '' && element.partNumber.length > 3) {
        if (element.parentId) {
          element['preConfigId'] = element.parentId;
        }
        this.enggToolComponent.partNumberValidation(element, orphanFlag);
      }
    }
  }
  //
}
export interface PartStatusInterface {
  // Department: string;
  // SAPStatus: string;
  // EnggCoordinator: string;
  // RequestedDate: any; 
  // CompletionDate: any;

  department: string;
  sapMaterialStatus: string;
  sapDistributionMaterialStatus: string;
  plantSpecificMaterialStatus: string;
  procurementType: string;
  requestedDate: any;
  completedDate: any;
  sapErrorMessage: any;

}
export interface NPCInterface {
  id: number;
  status?: number;
  erNpc?: string;
  npcCategory?: string;
  npcComponent?: string;
  makeBuy?: string;
  npcCategoryList?: [];
  npcComponentList?: [];
  makeBuyList?: [];
  drawingNumber: string;
  npcReferenceId: number;
  subLevelComponent: string;
  subLevelComponentId: number;
  npcSubCategory: string,
  npcSubCategoryId: number,
  soli: number;
  mcode: number;
  qcode: number;
  npcReferenceMappingId: number;
  npcNumber: number;
  holdFlag: boolean;
  dwgHeader: string;
  mcodeDesc: string;
  generalComments: string;
  holdComments: string;
  qcodeDesc: string;
  ecmNumber: number;
  enggCoordinator: string;
  enggCoordinatorFirstName: string;
  enggCoordinatorLastName: string;
  levelFourMasterId: number;
  mcodeComments: string;
  npcSubLevels?: string;
  npcWorkFlowStatus: string;
  parentId: number;
  qcodeComments: string
}

export interface ExpendedNPCInterface {
  id: number;
  department: string;
  sapStatus: string;
  enggCoordinator: string;
  requestDate: Date;
  completionDate: Date;
  generalComments: string;
  holdComments: string;
  isHold: boolean;
  enggCoordinatorList: [];
}
let EXPENDED_ELEMENT_DATA: ExpendedNPCInterface[] = [];
