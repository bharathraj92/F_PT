import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BomNpcConfigComponent } from './bom-npc-config.component';

describe('BomNpcConfigComponent', () => {
  let component: BomNpcConfigComponent;
  let fixture: ComponentFixture<BomNpcConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BomNpcConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BomNpcConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
