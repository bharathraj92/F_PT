import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
//import * as Mock from 'src/app/mock/my-workplan-mock';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as Mock from 'src/app/mock/activityTree.mock';
import { EnggToolComponent } from '../engg-tool.component';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { MessageHistoryModalComponent } from '../message-history-modal/message-history-modal.component';
import { ChangeBomTypeModalComponent } from '../change-bom-type-modal/change-bom-type-modal.component';

@Component({
  selector: 'app-bom-configuration',
  templateUrl: './bom-configuration.component.html',
  styleUrls: ['./bom-configuration.component.scss']
})
export class BomConfigurationComponent implements OnInit {
  bomConfigForm: FormGroup;
  //Accordion Steps
  isOpen = false;
  step = 0;
  task: any;
  subTask: any;
  subSteps = 0;
  saveDisabled: boolean;
  fieldDisabled: boolean;
  bomCountData: any = [];
  designCountData: any = [];
  npcCountData: any = [];
  preConfigData: any = [];
  bomCreatorData: any = [];
  bomReviewerData: any = [];
  bomReleaseData: any = [];
  bomConfigCreatorId;
  bomConfigReviewerId;
  saleOrder = sessionStorage.getItem('saleOrderNumber');
  erNumber = sessionStorage.getItem('erNumber');
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;
  ChangeBomTypeModal: MatDialogRef<ChangeBomTypeModalComponent>;
  disableAdd: boolean = false;
  setStep(index: number) {
    this.subSteps = index;
  }

  setSubStep(index: number) {
    this.subSteps = index;
  }

  constructor(public formBuilder: FormBuilder,
    private http: HttpClient,
    private apiMappingsService: ApiMappingsService,
    public commonservice: CommonService,
    private bhAlertService: BhAlertService,
    private enggToolComponent: EnggToolComponent,
    public dialog: MatDialog) {

    this.saveDisabled = true;
    this.fieldDisabled = true;
    this.saleOrder = sessionStorage.getItem('saleOrderNumber');
    this.erNumber = sessionStorage.getItem('erNumber');
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    if (this.preConfigId != null && this.preConfigId != undefined) {
      this.loadBomConfig();
    }
  }

  ngOnInit(): void {
    this.task = sessionStorage.getItem('task');
    this.subTask = sessionStorage.getItem('subTask');
    // this.bomConfigForm = this.formBuilder.group({
    //   designPoint: [null, [Validators.required]],
    //   valveSupportTeam: [null, [Validators.required]],
    //   clarificationPoint: [null, [Validators.required]],
    //   isValveHold: [null, [Validators.required]],
    // })
    if(this.erNumber != null && this.erNumber != '' && this.erNumber != undefined){
    this.enggToolComponent.isSchedulingAndPlanningDone(this.erNumber);
  }
  }
  //show Message History Modal popup
  showMessageHistoryModal(task,user,item,field){
    this.enggToolComponent.showMessageHistoryModal(task,user,item,field);
  }
  
  getSubTask(levelTwo: any) {
      return this.subTask == levelTwo;
  }

  validate(levelTwo: any) {
    if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId') && sessionStorage.getItem('roleName') == "Config. Engineer") {
      return sessionStorage.getItem('levelTwoId') == levelTwo;
    }
  }

  validateReviewer(levelTwo: any) {
    if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId') && sessionStorage.getItem('roleName') == "Reviewer") {
      return sessionStorage.getItem('levelTwoId') == levelTwo;    
    }
  }

  validateRelease() {
    if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('roleName') == "Project Leader / EPL") {
      return true;
    }
  }

  setSubTask(levelTwo: any) {
    this.subTask = levelTwo;
  }
  countDesignHandler(count: any) {
    this.designCountData = count;
  }
  countNPCHandler(count: any) {
    this.npcCountData = count;
  }
  loadBomConfig() {
    this.getBomStatusCounts(this.preConfigId);
    this.getDesignStatusCounts(this.preConfigId);
    this.getNpcStatusCounts(this.preConfigId);
    this.getpreConfigCommentData(this.preConfigId);
    this.getBomCreatorData(this.preConfigId);
    this.getBomReviewerData(this.preConfigId, this.bomConfigCreatorId);
    this.getBomReleaseData(this.preConfigId);
  }
  //get PreConfig Info
  getERPreConfigInfo(erNumber) {
    this.apiMappingsService.getERPreConfigInfo(erNumber).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.preConfigId = data['id'];
        if (this.preConfigId != null && this.preConfigId != undefined) {
          this.loadBomConfig();
        }
      }
    });
  }
  //get Bom Status Counts
  getBomStatusCounts(preConfigId) {
    this.http.get(this.apiMappingsService.getBomStatusCounts(preConfigId)).subscribe((data: []) => {
      if (data) {
        //this.bomCountData = data['BomStatusCount'];
        //console.log(this.preConfigData);
      }
    });
  }
  //get Design Status Counts
  getDesignStatusCounts(preConfigId) {
    this.http.get(this.apiMappingsService.getDesignStatusCounts(preConfigId)).subscribe((data: []) => {
      if (data) {
        //this.designCountData = data['DesignStatusCount'];
        //console.log(this.preConfigData);
      }
    });
  }
  //Get preConfig Data
  getpreConfigCommentData(preConfigId) {
    // this.apiMappingsService.getpreConfigCommentData(preConfigId).subscribe((data: []) => {
    this.http.get(this.apiMappingsService.getpreConfigCommentData(preConfigId)).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.preConfigData = data;
        //console.log(this.preConfigData);
      }
    });
  }
  //Get Creator Data
  getBomCreatorData(preConfigId) {
    this.apiMappingsService.getBomCreatorData(preConfigId).subscribe((data: []) => {
      //const data = Mock.getBomCreatorClone;///MOCK DATA for Clone
      if (data && data['bomCreatorDtoList'] && data['bomCreatorDtoList'].length > 0) {        
      this.bomCountData = data;
        this.bomCreatorData = data['bomCreatorDtoList'];
        this.bomConfigCreatorId = this.bomCreatorData[0]['id'];
        //console.log(this.bomCreatorData);
      }
    });
  }
  //Get Reviewer Data
  getBomReviewerData(preConfigId, bomConfigCreatorId) {
    this.apiMappingsService.getBomReviewerData(preConfigId, bomConfigCreatorId).subscribe((data: []) => {
      //const data = Mock.getBomReviewerClone;///MOCK DATA for Clone
      if (data && data.length > 0) {
        this.bomReviewerData = data;
        this.bomConfigReviewerId = this.bomReviewerData[0]['id'];
        //console.log(this.bomReviewerData);
      }
    });
  }
  //Get preConfig Data
  getBomReleaseData(preConfigId) {
    this.http.get(this.apiMappingsService.getBomReleaseData(preConfigId)).subscribe((data: any) => {
      if (data) {
        this.bomReleaseData = data;
        if (data && data.status == "PROMOTE") {
          this.disableAdd = true;
        } else {
          this.disableAdd = false;
        }
      }
    });
  }
  chkCreatorChkList(listItem) {
    const arr = [];
    arr.push(listItem);
    //console.log(arr);

    //   const selectedOrderIds = this.form.value.orders
    //   .map((checked, i) => checked ? this.ordersData[i] : null)
    //   .filter(v => v !== null);
    // console.log(selectedOrderIds);
  }
  resetBomCreatorForm(i, item) {
    item.bomChecklistMaster.forEach(listItem => { listItem.comments = ''; });
    this.bomCreatorData[i]['comments'] = '';
    this.bomCreatorData[i]['hold'] = false;
    this.bomCreatorData[i]['holdComments'] = '';
    this.bomCreatorData[i]['hoursAssigned'] = 0;
    this.bomCreatorData[i]['hourSpent'] = 0;
    this.bomCreatorData[i]['percentageCompleted'] = 0;
  }

  resetBomReviewerForm(j, item) {
    item.bomChecklistMaster.forEach(listItem => { listItem.checked = false; });
    this.bomReviewerData[j]['comments'] = '';
    this.bomReviewerData[j]['hold'] = false;
    this.bomReviewerData[j]['holdComments'] = '';
    this.bomReviewerData[j]['percentageCompleted'] = 0;
  }
  resetBomReleaseForm(item) {
    this.bomReleaseData['comments'] = '';
    item.bomChecklistMaster.forEach(listItem => { listItem.checked = false; });
  }
  //save/Update Bom Creator
  saveUpdatePreConfigData(k, preConfigItem) {
    //item['bomCreatorStatus'] ='PROMOTE';
    //item['bomCreatorStatusId'] =2;
    //console.log(preConfigItem);
    this.apiMappingsService.saveUpdatePreConfigData(preConfigItem).subscribe((data: []) => {
      if (data) {
        this.loadBomConfig();
        this.bomConfigCreatorId = data['id'];
        this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Promoted Successfully!');
        //this.bomConfigForm.form.disable();
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote BOM!');
      }
    });
  }
  //save Bom Creator
  saveBomCreator(i, item, action) {
    if (action === 'SAVE') {//Save
      item['bomCreatorStatus'] = 'SAVE';
      item['bomCreatorStatusId'] = 1;
      item['bomChecklistCreatorTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveBomCreator(item).subscribe((data: []) => {
        if (data) {
         //console.log(data);
          this.bomConfigCreatorId = data['id'];          
          this.loadBomConfig();
          this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Saved Successfully!');
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save BOM!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      // if (item.percentageCompleted === 100) {
        item['bomCreatorStatus'] = 'PROMOTE';
        item['bomCreatorStatusId'] = 2;
        item['bomChecklistCreatorTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
        item['percentageCompleted'] = 100;
        this.apiMappingsService.saveBomCreator(item).subscribe((data: []) => {
          if (data) {
           // console.log(data);
            this.bomConfigCreatorId = data['id'];
            this.loadBomConfig();
            this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Promoted Successfully!');
          } else {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote BOM!');
          }
        });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }
  }

  // save Bom Reviewer
  saveBomReviewer(i, item, action) {
    //SAVE
    if (action === 'SAVE') {
      item['bomReviewerStatus'] = 'SAVE';
      item['bomReviewerStatusId'] = 1;
      const bomCreator = this.bomCreatorData.filter(element => element.levelTwo === item.levelTwo && element.preConfigId === item.preConfigId);
      item['bomConfigCreatorId'] = bomCreator[0]['id'];
      const Reviewer = this.bomReviewerData.filter(element => element.levelTwo === item.levelTwo && element.preConfigId === item.preConfigId);
      item['id'] = Reviewer[0]['id'];
      //item['id'] = this.bomConfigReviewerId;
      item['bomChecklistReviewerTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveBomReviewer(item).subscribe((data: []) => {
        if (data) {
          //console.log(data);
          this.bomConfigReviewerId = data['id'];
          this.loadBomConfig();
          this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Saved Successfully!'
          );
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Saved BOM!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      // if (item.percentageCompleted === 100) {
        item['bomReviewerStatus'] = 'PROMOTE';
        item['bomReviewerStatusId'] = 2;
        item['percentageCompleted'] = 100;
        const bomCreator = this.bomCreatorData.filter(element => element.levelTwo === item.levelTwo && element.preConfigId === item.preConfigId);
      item['bomConfigCreatorId'] = bomCreator[0]['id'];
      const Reviewer = this.bomReviewerData.filter(element => element.levelTwo === item.levelTwo && element.preConfigId === item.preConfigId);
      item['id'] = Reviewer[0]['id'];
        //item['id'] = this.bomConfigReviewerId;
        item['bomChecklistReviewerTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
        this.apiMappingsService.saveBomReviewer(item).subscribe((data: []) => {
          if (data) {
            //console.log(data);
          this.bomConfigReviewerId = data['id'];
            this.loadBomConfig();
            this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Promoted Successfully!'
            );
          } else {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote BOM!');
          }
        });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }
    //DEMOTE
    if (action === 'DEMOTE') {
      item['bomReviewerStatus'] = 'DEMOTE';
      item['bomReviewerStatusId'] = 3;
      const bomCreator = this.bomCreatorData.filter(element => element.levelTwo === item.levelTwo && element.preConfigId === item.preConfigId);
      item['bomConfigCreatorId'] = bomCreator[0]['id'];
      const Reviewer = this.bomReviewerData.filter(element => element.levelTwo === item.levelTwo && element.preConfigId === item.preConfigId);
      item['id'] = Reviewer[0]['id'];
      this.apiMappingsService.saveBomReviewer(item).subscribe((data: []) => {
        if (data) {
          //console.log(data);          
          this.bomConfigReviewerId = data['id'];
          this.loadBomConfig();
          this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Demoted Successfully!'
          );
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Demote BOM!');
        }
      });
    }
  }
  saveBomRelease(action: any, item: any) {
    if (action == 'SAVE') {
      item['status'] = 'SAVE';
      item['bomChecklistReleaseTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveUpdateBomReleaseData(item).subscribe((data: []) => {
        if (data) {
          this.loadBomConfig();
          this.bhAlertService.showAlert('success', 'top', 5000, 'BOM saved Successfully!');
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Release BOM!');
        }
      });
    }
    else if (action == 'PROMOTE') {
      item['status'] = 'PROMOTE';
      item['bomChecklistReleaseTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveUpdateBomReleaseData(item).subscribe((data: []) => {
        if (data) {
          this.loadBomConfig();
          this.bhAlertService.showAlert('success', 'top', 5000, 'BOM Released Successfully!');
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Release BOM!');
        }
      });
    }
  }

  enableTask() {
    if ((this.task != 'DESIGN' && this.task != 'NPC') || this.task == '' || this.task == 'BOMCONFIG') {
      return true;
    } else {
      return false;
    }
  }


  //get NPC Status Counts
  getNpcStatusCounts(preConfigId) {
    this.http.get(this.apiMappingsService.getNpcStatusCounts(preConfigId)).subscribe((data: []) => {
      if (data) {
        //this.npcCountData = data['NpcStatusCount'];
      }
    });
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "BOMConfig" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  ngOnDestroy() {
    // sessionStorage.setItem("task", 'BOMCONFIG');
    sessionStorage.setItem('navigateFromDashboard', "false");
  }

  getDisableFlag() {
    return sessionStorage.getItem('disableBom');
  }

  changeBomType(data: any){
    this.ChangeBomTypeModal = this.dialog.open(ChangeBomTypeModalComponent, { data: { data: data } });
    this.ChangeBomTypeModal.afterClosed().subscribe(value => {
      this.getBomReleaseData(this.preConfigId);
    });
  }
}

export interface changeBomData {
  animal: string;
  name: string;
}
