import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualityDocComponent } from './quality-doc.component';

describe('QualityDocComponent', () => {
  let component: QualityDocComponent;
  let fixture: ComponentFixture<QualityDocComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualityDocComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualityDocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
