import { Component, OnInit, OnDestroy} from '@angular/core';

@Component({
  selector: 'app-quality-doc',
  templateUrl: './quality-doc.component.html',
  styleUrls: ['./quality-doc.component.scss']
})
export class QualityDocComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  ngOnDestroy(){
    sessionStorage.setItem("task", 'External Deliverables');
  }

}
