import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherEnggActivitiesComponent } from './other-engg-activities.component';

describe('OtherEnggActivitiesComponent', () => {
  let component: OtherEnggActivitiesComponent;
  let fixture: ComponentFixture<OtherEnggActivitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherEnggActivitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherEnggActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
