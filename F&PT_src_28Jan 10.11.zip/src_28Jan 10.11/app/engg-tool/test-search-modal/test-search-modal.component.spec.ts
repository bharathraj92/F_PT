import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSearchModalComponent } from './test-search-modal.component';

describe('TestSearchModalComponent', () => {
  let component: TestSearchModalComponent;
  let fixture: ComponentFixture<TestSearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
