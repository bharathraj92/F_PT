import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { TestDialogData } from '../test/test.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-test-search-modal',
  templateUrl: './test-search-modal.component.html',
  styleUrls: ['./test-search-modal.component.scss']
})
export class TestSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['npcNumber', 'soli','description'];
  designDataSource = new MatTableDataSource<testSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('testSearch') myDashboardTable: MatTable<testSearchInterface>;
  selectedRowIndex: number;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  testSearchForm: FormGroup;
  selectedTest: any;
  levelTwoId: any;
  creatorId : any;
  designSearchResult: any[];
  constructor(public formBuilder: FormBuilder,
    public testDialogRef: MatDialogRef<TestSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: TestDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.testSearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    this.levelTwoId = this.data['levelTwoId'];
    this.creatorId =this.data['creatorId'];
    this.designDataSource.paginator = this.paginator;
    this.designDataSource.sort = this.sort;
  }

  prepareTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(designRequest => {
      ELEMENT_DATA.push({
        id: designRequest.id,
        erDesignNumber: designRequest.erDesignNumber,
        soli: designRequest.soli,
        description:designRequest.description,
        testCreatorDto:designRequest.testLevelTwoCreatorDto,
        testReviewerDto:designRequest.testLeDtReviewerDto,
      });
    });
    this.designDataSource.data = ELEMENT_DATA;
  }

  searchDesignRef() {
    ELEMENT_DATA = [];
    let formvalue = this.testSearchForm.value;
    formvalue['levelTwoId'] = this.levelTwoId;
    formvalue['creatorId']= this.creatorId;
    // formvalue['reviewerId']= null,
    formvalue['task']= "Tests";
    this.apiMappingsService.getReferenceTest(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.designSearchResult = data;
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectTest(element) {
    this.testDialogRef.close(element);
  }

  onClickERNumber(value: any) {

  }

}

export interface testSearchInterface {
  id: number;
  erDesignNumber: string;
  soli: string;
  description: string;
  testCreatorDto:testCreatorDto[];
  testReviewerDto:testReviewerDto[];
}

let ELEMENT_DATA: testSearchInterface[] = [];

export interface testCreatorDto {
aging: number;
generalComments: string;
testCreatedByFirstname: string;
testCreatedByLastname: string;
testCreatedBySso: string;
testCreatorStatus: string;
testCreatorStatusId: number;
testProgressStatus: string;
floatingDays: number;
hold: boolean;
holdComments: string;
hourSpent: number;
hoursAssigned: number;
id: number;
levelTwoId: number;
levelTwo: string;
percentageCompleted: number;
preConfigId: number;
supportTeamId: number;
targetDate: number;
childEr: string;
currentStatus: string;
currentStatusId: number
}
export interface testReviewerDto {
  generalComments: string;
  testCreatedByFirstname: string;
  testCreatedByLastname: string;
  testCreatedBySso: string;
  testCreatorStatus: string;
  testCreatorStatusId: number;
  testProgressStatus: string;
  floatingDays:  number;
  hold: true
  holdComments: string;
  id:  number;
  levelTwoId:  number;
  levelTwo: string;
  percentageCompleted:  number;
  preConfigId:  number;
  reviewedByFirstname: string;
  reviewedByLastname: string;
  reviewedBySso:  number
}

