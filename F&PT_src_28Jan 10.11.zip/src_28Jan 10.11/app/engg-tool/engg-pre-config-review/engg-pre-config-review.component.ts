import { Component, OnInit, ViewChild, ViewChildren, QueryList, ChangeDetectorRef, ElementRef } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators, FormControl, NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Injectable } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { BehaviorSubject } from 'rxjs';
import { ApiMappingsService } from 'src/app/Services/api-mappings.service';
import { CommonService } from 'src/app/Services/common.service';
import { BhAlertService } from 'bh-theme';
import { Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ERSearchModalComponent } from '../er-search-modal/er-search-modal.component';
import { NPCSearchModalComponent } from '../npc-search-modal/npc-search-modal.component';
import { EnggToolComponent } from '../engg-tool.component';
import * as Mock from 'src/app/mock/activityTree.mock';
import * as _ from 'lodash';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
//import * as CommonMock from 'src/app/mock/commonOptions.mock';
import { DataSource } from '@angular/cdk/collections';
import { Observable, of } from 'rxjs';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { ConfirmDialogComponent, ConfirmDialogModel } from 'src/app/util/confirm-dialog/confirm-dialog.component';


@Component({
  selector: 'app-engg-pre-config-review',
  templateUrl: './engg-pre-config-review.component.html',
  styleUrls: ['./engg-pre-config-review.component.scss'],
  //Table
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  //

})

//
export class EnggPreConfigReviewComponent implements OnInit {
  saveDisabled = true;
  submitDisabled = true;
  panelOpenState = true;
  panelOpenState1 = true;
  panelOpenState2 = true;
  showFiller: boolean;
  sapId;
  productHierarchyId;
  productHierarchy;
  actuatorModelDescription;
  sapActuatorDesc = false;
  actuatorDescRequired = false;
  preConfigRefId;
  tagNumber;
  productBrand;
  erRevisionNo;
  erRequestDate;
  eplPE;
  soLI;
  customerName;
  enggPlannedCompDate;
  projectManager;
  enggCompletionDate;
  sapHeader;
  sapHeaderDesc;
  noOfLineItems;
  productClass;
  customerPoNum;
  bomLT;
  manufacturingLT;
  procurementLT;
  endUserCountry;
  orderClassification;
  erStatus;
  currentStatus;
  csrProjectManager;
  totalNoofItemsinER;
  isValveHold: boolean;
  status = '';
  //preConfigRefNum = null;
  ERid = null;
  //Popup
  erSearchModal: MatDialogRef<ERSearchModalComponent>;
  npcSearchModal: MatDialogRef<NPCSearchModalComponent>;
  isTestsHold = false;
  //NPC
  npcdisplayedColumns = ['drawingNumber', 'mcode', 'qcode', 'partNumber'];
  NpcDefaultDataSource;
  NpcDataSource = new NpcDataSource();
  npcData: any = [];
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  expandedElement: any;

  //Reference
  refFormDisabled: boolean;
  npcFormDisable: boolean;
  activityTreeValid: boolean;
  refFormValid: boolean;
  npcFormValid: any;
  npcCombination: any;
  //Table
  tableDataSource: any = [];
  preConfigForm: FormGroup;
  displayedColumns: string[] = ['levelName', 'generalComments', 'holdFlag', 'holdComments'];
  referencedataSource = new MatTableDataSource<TreeDataTableInterface>();
  treeLevelData: TreeDataTableInterface[] = [];
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  //@ViewChild('outerSort', { static: true }) sort: MatSort;
  @ViewChildren('innerSort') innerSort: QueryList<MatSort>;
  @ViewChild('schedulingPlanning') schedulingPlanningTable: MatTable<TreeDataTableInterface>;
  @ViewChildren('innerTables') innerTables: QueryList<MatTable<SubLevel>>;
  @ViewChild('flowContentContainer', { static: false }) flowContentContainer: ElementRef;
  //@ViewChild('flowContentContainer', { static: false }) flowContentContainer: NgForm;
  selection = new SelectionModel<TreeDataTableInterface>(true, []);
  selectedRowIndex: number;
  schedulingPlanningList: any = [];
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;

  TREE_DATA: any = [];
  masterItemList: [];
  copyItemsList: any;
  erMasterNoList: [];
  configurationTypeList: any;
  valveTypeList: any;
  endUserTypeList: any;
  projectClassificationList: any;
  soLiClassificationList: any;
  etoClassificationList: any;
  supportTeamList: any;
  npcCategoryList: any;
  npcComponentList: any;
  bomTypeList: any;
  taskFamilyList: any;
  preConfigData: [];
  complexityLevel;
  totalAssignedHrs;
  trsList: any;
  actuatorDescList: any;
  filteredOptions: any;
  treeData: any;
  ERTreeData: any = [];
  resultTreeData: any = [];
  defaultTreeData: any = [];
  duplicateEtoClassificationList: any;
  plantMasterList: any;
  //  plantMasterList=[
  //   {
  //     "id": 1,
  //     "siteName": "DVI",
  //     "siteCode": "5500",
  //   },
  //   {
  //     "id": 2,
  //     "siteName": "JAX",
  //     "siteCode": "1811",
  //   },
  //   {
  //     "id": 4,
  //     "siteName": "DJL -KARWIA",
  //     "siteCode": "7150",
  //   },
  //   {
  //     "id": 5,
  //     "siteName": "GRE -GLOBAL COE",
  //     "siteCode": "1111",
  //   },
  //   {
  //     "id": 3,
  //     "siteName": "CONDE",
  //     "siteCode": "6260",
  //   }
  // ];

  saleOrder = sessionStorage.getItem('saleOrderNumber');
  erNumber = sessionStorage.getItem('erNumber');
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  cloneFlag = sessionStorage.getItem('cloneER');
  complexityList: any = [];
  complexityFilterList: any = [];
  etoArrList: any = [];
  ETOcheckList: any = [];
  //Accordion Steps
  step = 0;
  setStep(index: number) {
    this.step = index;
  }
  //Task check list
  task: Task = {
    name: 'TRS',
    checked: false,
    subtasks: [
      { name: 'Valve', checked: false },
      { name: 'Actuator', checked: false },
      { name: 'Accessories', checked: false }
    ]
  };

  //NPC
  npcReferenceId;
  npcReferenceMappingId;
  //npcData: any = [];
  datePipe = new DatePipe("en-US");
  addNpc() {
    NPC_ELEMENT_DATA.push({
      id: null,
      drawingNumber: null,
      npcReferenceId: null,
      subLevelComponent: null,
      subLevelComponentId: null,
      npcSubCategory: null,
      npcSubCategoryId: null,
      soli: this.soLiNumber,
      mcode: null,
      qcode: null,
      npcReferenceMappingId: null,
      npcNumber: null,
      erNpc: null,
      holdFlag: false,
      dwgHeader: null,
      mcodeDesc: null,
      makeBuy: null,
      generalComments: null,
      holdComments: null,
      qcodeDesc: null,
      //plantCode:this.plantCode
    })
    this.NpcDataSource = new NpcDataSource();
  }
  resetNPCForm(NPC) {
    NPC['drawingNumber'] = '',
      NPC['npcReferenceId'] = '',
      NPC['subLevelComponent'] = '',
      NPC['subLevelComponentId'] = '',
      NPC['npcSubCategory'] = '',
      NPC['npcSubCategoryId'] = '',
      NPC['mcode'] = '',
      NPC['qcode'] = '',
      NPC['soli'] = this.soLiNumber,
      NPC['npcReferenceMappingId'] = '',
      NPC['npcReferenceId'] = '',
      NPC['npcNumber'] = '',
      NPC['makeBuy'] = '',
      NPC['erNpc'] = '',
      NPC['dwgHeader'] = '',
      NPC['mcodeDesc'] = '',
      NPC['qcodeDesc'] = '',
      NPC['generalComments'] = '',
      NPC['holdFlag'] = false,
      NPC['holdComments'] = '',
      NPC['childErNumber'] = '',
      NPC['childEr'] = '',
      this.npcFormDisable = false;
    this.NpcDataSource = new NpcDataSource();
  }
  allComplete: boolean = false;
  updateAllComplete() {
    this.allComplete = this.task.subtasks != null && this.task.subtasks.every(t => t.checked);
    this.task.checked = this.task.subtasks != null && this.task.subtasks.filter(t => t.checked).length > 0 && !this.allComplete;
    if (this.allComplete) {
      this.task.checked = true;
    }
    //Task List
    const list = [];
    this.task.subtasks.filter((item, index) => {
      if (item.checked == true) {
        list.push(item.name);
      } else {
        list.splice(list.indexOf(item), 0)
      }
    });
    this.trsList = list;
    //
  }
  someComplete(): boolean {
    if (this.task.subtasks == null) {
      return false;
    }
    return this.task.subtasks.filter(t => t.checked).length > 0 && !this.allComplete;
  }

  setAll(checked: boolean) {
    this.allComplete = checked;
    if (this.task.subtasks == null) {
      return;
    }
    this.task.subtasks.forEach(t => t.checked = checked);
    this.task.checked = checked;
    //Task List
    const list = [];
    this.task.subtasks.filter((item, index) => {
      if (item.checked == true) {
        list.push(item.name);
      } else {
        list.splice(list.indexOf(item), 0)
      }
    });
    this.trsList = list;
  }
  //
  constructor(
    public formBuilder: FormBuilder,
    private http: HttpClient,
    private apiMappingsService: ApiMappingsService,
    private commonservice: CommonService,
    private bhAlertService: BhAlertService,
    private enggToolComponent: EnggToolComponent,
    private fb: FormBuilder,//Table
    private cd: ChangeDetectorRef,
    public dialog: MatDialog,
    public router: Router) {
    this.saleOrder = sessionStorage.getItem('saleOrder');
    this.erNumber = sessionStorage.getItem('erNumber');
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.cloneFlag = sessionStorage.getItem('cloneER');
    //ActivitiTree Data
    //if(!this.erNumber){
    // this.defaultTreeData = JSON.parse(localStorage.getItem('activitiTreeData'));
    // this.loadActivitiTree(this.defaultTreeData);
    //}
    // Clone ER
    if (this.cloneFlag === 'true' && this.soLiNumber) {
      // this.apiMappingsService.getFilteredLevelDetails(this.soLiNumber).subscribe((data: []) => {
      //   if (data) {
      //     //this.commonService.activitiTreeData.next(data);
      //     localStorage.setItem('activitiTreeData', JSON.stringify(data));
      //     this.loadActivitiTree(data);
      //   }
      // });
      this.enggToolComponent.bannerForm.reset();
      this.getERSummaryInfo(this.soLiNumber);

      const defaultTreeData = JSON.parse(sessionStorage.getItem('activitiTreeData'));
      this.loadActivitiTree(defaultTreeData);
      this.getCloneSequenceData(this.soLiNumber);
      this.getClonePreConfigMasterData();
      this.getCloneActuatorModelData();
      this.getCloneERSummaryInfo(this.soLiNumber);
    } else {// Not Clone
      this.defaultTreeData = JSON.parse(sessionStorage.getItem('activitiTreeData'));
      this.loadActivitiTree(this.defaultTreeData);
      this.getPreConfigMasterEndUserType(this.soLiNumber);
      this.getActuatorModelData();
      if (this.erNumber) {
        this.getERPreConfigInfo(this.erNumber);
      } else if (this.soLiNumber) {
        this.getERSummaryInfo(this.soLiNumber);
        const defaultTreeData = JSON.parse(sessionStorage.getItem('activitiTreeData'));
        this.loadActivitiTree(defaultTreeData);
      }
      ////
    }
  }
  //product Hierarchy Validation
  productHierarchyValidation(soLiNumber) {
    if (soLiNumber) {
      this.preConfigForm.get('copyItems').enable();
      this.apiMappingsService.getPhAuditTrail(soLiNumber).subscribe((data) => {
        if (data && data === false) {
          //Disable Copy line items
          this.preConfigForm.get('copyItems').enable();
        } else if (data && data === true) {
          //enable Copy line items
          this.preConfigForm.get('copyItems').disable();
        }
      });
    }
  }
  //
  deleteNpc(npcItem) {
    if (npcItem.id != null) {
      this.apiMappingsService.deletePreConfigNPC(npcItem, npcItem.id).subscribe((data: []) => {
        if (data) {
          this.getERPreConfigInfo(this.erNumber);
          this.deleteNpcUI(npcItem);
          this.bhAlertService.showAlert('success', 'top', 5000, 'NPC Deleted Successfully!');
        } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Delete NPC!'); }
      });
    } else {
      this.deleteNpcUI(npcItem);
    }
  }

  deleteNpcUI(npcItem) {
    NPC_ELEMENT_DATA.forEach((element, index) => {
      if (element.drawingNumber === npcItem.drawingNumber && element.npcNumber === npcItem.npcNumber) {
        NPC_ELEMENT_DATA.splice(index, 1);
      }
    });
    this.NpcDataSource = new NpcDataSource();
    //this.dataSource = new MatTableDataSource(NPC_ELEMENT_DATA);
    console.log(this.NpcDataSource);
    return true;
  }


  refreshRefInfo() {
    this.cd.detectChanges();
  }

  change(value: any) {
    let obj = this.filteredOptions.filter((row: any) => row.id == value.subLevelComponentId);
    if (obj && obj[0]) {
      value.subLevelComponent = obj[0].levelName;
    }
  }



  prepareTableData() {
    REF_ELEMENT_DATA = [];
    this.tableDataSource.forEach(node => {
      REF_ELEMENT_DATA.push({
        levelName: node.levelName,
        id: node.id,
        levelNo: node.levelNo,
        isChecked: node.isChecked,
        holdFlag: node.holdFlag,
        holdComments: node.holdComments,
        generalComments: node.generalComments,
        siteLevelMapping: node.siteLevelMapping,
        parentData: node.parentData,
      });
    });
    this.tableDataSource = REF_ELEMENT_DATA;
  }
  private _transformer = (node: FoodNode, level: number) => {
    return {
      expandable: !!node.subLevel && node.subLevel.length > 0,
      levelName: node.levelName,
      id: node.id,
      level: level,
      //isExpanded: node.isExpanded,
      levelNo: node.levelNo,
      isChecked: node.isChecked,
      holdFlag: node.holdFlag,
      holdComments: node.holdComments,
      generalComments: node.generalComments,
      siteLevelMapping: node.siteLevelMapping,
      parentData: node.parentData,
    };
  }
  ////
  loadActivitiTree(ERTreeData) {
    if (ERTreeData != null) {
      if (ERTreeData.length > 0) {
        this.treeData = ERTreeData['levelData'];
        const ER_TREE_DATA: FoodNode[] = ERTreeData['levelData'];
        this.normalizeTreeNodes(ER_TREE_DATA);
        this.treeDataSource.data = ER_TREE_DATA;
        //this.treeDataSource.data = JSON.parse(JSON.stringify(ER_TREE_DATA));
        this.tableDataSource = ER_TREE_DATA;
        this.loadSelectedNodes(ER_TREE_DATA);
      } else {
        if (ERTreeData['levelData']) {
          this.treeData = ERTreeData['levelData'];
          const TREE_DATA: FoodNode[] = ERTreeData['levelData'];
          this.normalizeTreeNodes(TREE_DATA);
          this.treeDataSource.data = TREE_DATA;
          // this.treeDataSource.data = JSON.parse(JSON.stringify(TREE_DATA));
          this.tableDataSource = TREE_DATA;
          this.loadSelectedNodes(TREE_DATA);
        }
      }
      this._selectedItems = this.checklistSelection.selected.map(s => s);
    }
  }
  //Filter TreeNodes By SiteMappings
  normalizeTreeNodes(data) {
    if (data !== undefined && data.length > 0) {
      data.forEach((element, index) => {
        //Filter by SiteMappings
        if (element.siteLevelMapping.length === 0) {
          data.splice(index, 1);
        }//
        (element.subLevel || []).forEach(ChildElement => {
          // ChildElement['parentData'] = element;
          if (element.subLevel && element.subLevel.length) {
            this.normalizeTreeNodes(element.subLevel);
            return;
          }
        });
      });
    }
    //console.log(data);
  }
  /** The selection for checklist */
  checklistSelection = new SelectionModel<ExampleFlatNode>(true /* multiple */);
  _selectedItems: any[];

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
    this._transformer, node => node.level, node => node.expandable, node => node.subLevel);

  treeDataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  uncheckAllNodes(data) {
    for (let i = 0; i < data.length; i++) {
      if (this.checklistSelection.isSelected(data[i]))
        this.checklistSelection.toggle(data[i]);
      this.treeControl.expand(data[i])
    }
    data.forEach((element, index) => {
      if (element.isChecked === true) {
        if (!this.checklistSelection.isSelected(element)) {
          this.checklistSelection.deselect(element);
          this.treeControl.expand(element);
        }
      }
      (element.subLevel || []).forEach(ChildElement => {
        ChildElement['parentData'] = element;
        if (element.subLevel && element.subLevel.length) {
          this.uncheckAllNodes(element.subLevel);
          return;
        }
      });
    });
  }

  /** Whether all the descendants of the node are selected */
  descendantsAllSelected(node: ExampleFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    //this._selectedItems = this.checklistSelection.selected.map(s => s);
    //console.log(this._selectedItems);
    //
    return descendants.every(child => this.checklistSelection.isSelected(child));
    // ? child.isChecked = node.isChecked = true : child.isChecked = node.isChecked = false);
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: ExampleFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    //? child.isChecked = node.isChecked = true : child.isChecked = node.isChecked = false);

    // if (this.descendantsAllSelected(node)) {
    //   node.isChecked = true;
    // }
    //
    //this._selectedItems = this.checklistSelection.selected.map(s => s);
    //console.log(this._selectedItems);
    return result && !this.descendantsAllSelected(node);

  }
  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: ExampleFlatNode): void {
    // HERE IS WHERE THE PART OF THE MODEL RELATED TO THE CLICKED CHECKBOX IS UPDATED
    this.checklistSelection.toggle(node);
    // this.checklistSelection.isSelected(node)
    // ? this.checklistSelection.select(node)
    // : this.checklistSelection.deselect(node);
    // HERE WE GET POTENTIAL subLevel OF THE CLICKED NODE
    const descendants = this.treeControl.getDescendants(node);

    // HERE IS WHERE THE REST OF THE MODEL (POTENTIAL subLevel OF THE CLICKED NODE) IS UPDATED
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);

    //Check /Uncheck nodes
    // this.checklistSelection.isSelected(node)
    //   ? node.isChecked = true : node.isChecked = false;

    this._selectedItems = this.checklistSelection.selected.map(s => s);
    //console.log(this._selectedItems);
    //   console.log(this.treeData);
    //  this.checklistSelection.isSelected(node)
    //  ? this.treeData.levelData
    //node.isChecked=true;//test

  }
  ////

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;
  // //tree

  expandNode() {
    //this.treeControl.expandAll();
    const tree = this.treeControl.dataNodes;
    if (tree && tree.length) {
      for (let node of tree) {
        if (node.levelNo === "One" && (node.id === 3 || node.id === 4 || node.id === 5 || node.id === 6 || node.id === 7)) {
          this.treeControl.collapse(node);
        } else {
          this.treeControl.expand(node);
          //this.treeControl.collapse(node);
        }
      }
    }
  }
  //
  loadSelectedNodes(data) {
    data.forEach((element, index) => {
      if (element.isChecked === true) {
        if (!this.checklistSelection.isSelected(element)) {
          const descendants = this.treeControl.getDescendants(element);
          this.checklistSelection.select(element);
          this.checklistSelection.select(...descendants);
          //this.checklistSelection.select(element);
          this.treeControl.expand(element);
        }
      }
      (element.subLevel || []).forEach(ChildElement => {
        ChildElement['parentData'] = element;
        if (element.subLevel && element.subLevel.length) {
          this.loadSelectedNodes(element.subLevel);
          return;
        }
      });
    });
    //console.log(this.svcGetActivityTreeData);
    // for (let i = 0; i < data.dataNodes.length; i++) {
    //   if(!this.checklistSelection.isSelected(data.dataNodes[i]))
    //     this.checklistSelection.toggle(this.treeControl.dataNodes[i]);
    //   this.treeControl.expand(this.treeControl.dataNodes[i])
    // }
  }
  valueLevelCheck(node) {
    //UnCheck Level
    if (node.levelName === 'Valve' || node.levelName === 'BOM CONFIGURATION') {
      const item = _.filter(this._selectedItems, { 'levelName': 'Level' });
      if (item.length > 0) {
        this.checklistSelection.deselect(item[0]);
        item[0].isChecked = false;
      }
      //UnCheck Level Design
      const design_item = _.filter(this._selectedItems, { 'levelName': 'Level Design' });
      if (design_item.length > 0) {
        const descendants = this.treeControl.getDescendants(design_item[0]);
        this.checklistSelection.deselect(design_item[0]);
        this.checklistSelection.deselect(...descendants);
        design_item[0].isChecked = false;
      }
      //Level-3 UnCheck Level Design
      this._selectedItems.forEach(item => {
        if (item.parentData && item.parentData.levelName === 'Level Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
      });
      ////UnCheck Valve
    } else if (node.levelName == 'Level') {
      const item = _.filter(this._selectedItems, { 'levelName': 'Valve' });
      if (item.length > 0) {
        this.checklistSelection.deselect(item[0]);
        item[0].isChecked = false;
      }
      ////UnCheck Valve Design
      const design_item = _.filter(this._selectedItems, { 'levelName': 'Valve Design' });
      if (design_item.length > 0) {
        const descendants = this.treeControl.getDescendants(design_item[0]);
        this.checklistSelection.deselect(design_item[0]);
        this.checklistSelection.deselect(...descendants);
        design_item[0].isChecked = false;
      }
      //Level-3 UnCheck Valve Design
      this._selectedItems.forEach(item => {
        if (item.parentData && item.parentData.levelName === 'Valve Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
      });
    }
    //Valve Design:
    if (node.levelName === 'Valve Design' || node.levelName === 'Design') {
      //Uncheck Level
      const bom_item = _.filter(this._selectedItems, { 'levelName': 'Level' });
      if (bom_item.length > 0) {
        const descendants = this.treeControl.getDescendants(bom_item[0]);
        this.checklistSelection.deselect(bom_item[0]);
        this.checklistSelection.deselect(...descendants);
        bom_item[0].isChecked = false;
      }
      //Uncheck Level Design
      const item = _.filter(this._selectedItems, { 'levelName': 'Level Design' });
      if (item.length > 0) {
        const descendants = this.treeControl.getDescendants(item[0]);
        this.checklistSelection.deselect(item[0]);
        this.checklistSelection.deselect(...descendants);
        item[0].isChecked = false;
      }
      // Level-3 Uncheck Level Design
      this._selectedItems.forEach(item => {
        if (item.parentData && item.parentData.levelName === 'Level Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
      });
    } else if (node.levelName === 'Level Design') {
      //Uncheck Valve
      const bom_item = _.filter(this._selectedItems, { 'levelName': 'Valve' });
      if (bom_item.length > 0) {
        const descendants = this.treeControl.getDescendants(bom_item[0]);
        this.checklistSelection.deselect(bom_item[0]);
        this.checklistSelection.deselect(...descendants);
        bom_item[0].isChecked = false;
      }
      //Uncheck Valve Design
      const item = _.filter(this._selectedItems, { 'levelName': 'Valve Design' });
      if (item.length > 0) {
        const descendants = this.treeControl.getDescendants(item[0]);
        this.checklistSelection.deselect(item[0]);
        this.checklistSelection.deselect(...descendants);
        item[0].isChecked = false;
      }
      //Level-3 UnCheck Valve Design
      this._selectedItems.forEach(item => {
        if (item.parentData && item.parentData.levelName === 'Valve Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
      });
    }
    //check level 3 with parent
    if (node.parentData && node.parentData.levelName === 'Valve Design') {
      this._selectedItems.forEach(item => {
        //Uncheck Level/Level Design
        if (item.levelName === 'Level' || item.levelName === 'Level Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
        //Uncheck Level-3 Level Design
        if (item.parentData && item.parentData.levelName === 'Level Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
      });
    } else if (node.parentData && node.parentData.levelName === 'Level Design') {
      this._selectedItems.forEach(item => {
        //Uncheck Level/Level Design
        if (item.levelName === 'Valve' || item.levelName === 'Valve Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
        //Uncheck Level-3 Level Design
        if (item.parentData && item.parentData.levelName === 'Valve Design') {
          const descendants = this.treeControl.getDescendants(item);
          this.checklistSelection.deselect(item);
          this.checklistSelection.deselect(...descendants);
          item.isChecked = false;
        }
      });
    }
    //
  }
  treeNodeCheck(node) {
    this._selectedItems = [];
    this._selectedItems = this.checklistSelection.selected.map(s => s);
    this.saveNodes(this.treeDataSource.data);
    this.resetReferenceInfo(node);
    console.log(this.treeDataSource.data);
    //ETO Logic
    // const ETOCheck = _.filter(this._selectedItems, { 'levelName': 'Design' });
    this.ETOcheckList = [];
    //this._selectedItems.forEach(node => {

    this.actuatorDescRequired = false;
    this.treeDataSource.data.forEach(node => {
      if ((node.levelName == 'Design' || node.levelName == 'New Part Creation') && node.isChecked == true) {
        this.ETOcheckList.push(node);
        // Actuator Desc Mandate Check
        node.subLevel.forEach(subLevel => {
          if ((subLevel.levelName == 'Actuator Design') && subLevel.isChecked == true) {
            this.actuatorDescRequired = true;
          }
        });////
      }
    });
    //this.actuatorMandateCheck(this.treeDataSource.data);//actuatorMandateCheck
    this.valueLevelCheck(node);
    this.onEtoChange();
    console.log(this._selectedItems);
    //
  }
  resetReferenceInfo(node) {
    if (node.isChecked == false) {
      node.generalComments = '';
      node.holdComments = '';
    }
    if (node.levelName == 'New Part Creation') {
      NPC_ELEMENT_DATA = [];
      this.addNpc();
    }
  }
  //
  ngOnInit(): void {
    this.showFiller = false;
    this.preConfigForm = this.formBuilder.group({
      masterItem: [null, [Validators.required]],
      copyItems: [null],
      preConfigRefNum: [null],
      erMasterNo: [null],
      configurationTypeId: [null, [Validators.required]],
      valveTypeId: [null, [Validators.required]],
      endUserTypeId: [null, [Validators.required]],
      // projectClassificationId: [null, [Validators.required]],
      soLineClassificationId: [null, [Validators.required]],
      etoClassification: [null],
      primaryEnggTeam: [null],
      supportTeamId: [null, [Validators.required]],
      bomTypeId: [null, [Validators.required]],
      taskFamilyId: [null, [Validators.required]],
      complexityId: [null, [Validators.required]],
      totalAssignedHrs: [null, [Validators.required, Validators.pattern("^[0-9]*$")]],
      actuatorModelDescription: [null],
      generalComments: [null],
      trs: [null],
      Valve: [null],
      Actuator: [null],
      Accessories: [null],
    });
    this.refFormDisabled = false;
    this.npcFormDisable = false;
    this.activityTreeValid = true;
    this.refFormValid = true;
    this.npcFormValid = true;
    this.npcCombination = false;
    // this.getPreConfigMasterEndUserType();
    // this.getActuatorModelData();
    this.preConfigForm.get('complexityId').patchValue(1);//L0
    this.preConfigForm.get('taskFamilyId').patchValue(1);//Default 
    this.expandNode();
    // 
    // this.actuatorDescFilterList = this.actuatorModelDescription.valueChanges
    //   .pipe(startWith(''),map(value => this._filter(value)));
    // 
  }
  // private _filter(value: string): string[] {
  //   const filterValue = value.toLowerCase();

  //   return this.actuatorDescList.filter(option => option.toLowerCase().includes(filterValue));
  // }
  //Reset Form
  resetForm() {
    //this.uncheckAllNodes(this.treeDataSource.data);
    // this.preConfigForm.enable();
    // this.preConfigForm.reset();
    // this.refFormDisabled = false;
    // this.treeDataSource.data= [];
    // this.treeDataSource.data= this.defaultTreeData['levelData'];
    // NPC_ELEMENT_DATA =[];
    // this.addNpc();
    location.reload();
    //this.NpcDataSource=null;
    //this.NpcDataSource=this.NpcDefaultDataSource;
  }
  spliceParentNodes(data) {
    if (data !== undefined && data.length > 0) {
      data.forEach((element, index) => {
        if (element.parentData) {
          // data.splice(index, 1);
          delete element['parentData'];
          //data.splice(data.indexOf(element.parentData), 0)
        }//
        (element.subLevel || []).forEach(ChildElement => {
          ChildElement['parentData'] = element;
          if (element.subLevel && element.subLevel.length) {
            this.spliceParentNodes(element.subLevel);
            return;
          }
        });
      });
    }
    //console.log(data);
  }
  //
  updateList(value) {
    console.log(value);
    this.filteredOptions = this.npcComponentList;
    this.filteredOptions = this.npcComponentList.filter(option => option.levelName.toLowerCase().includes(value));
    console.log(this.filteredOptions);
    //this.filteredOptions = rfilteredOptions;
  }
  getActuatorModelData() {
    this.apiMappingsService.getActuatorModelData().subscribe((data: []) => {
      if (data) {
        this.actuatorDescList = data;
      }
    });
  }
  actuatorMandateCheck(treeData) {
    this.actuatorDescRequired = false;
    treeData = treeData['levelData'];
    treeData.forEach(node => {
      if ((node.levelName == 'Design') && node.isChecked == true) {
        this.ETOcheckList.push(node);
        //Actuator Desc Mandate Check
        node.subLevel.forEach(subLevel => {
          if ((subLevel.levelName == 'Actuator Design') && subLevel.isChecked == true) {
            this.actuatorDescRequired = true;
          }
        });////
      }
    });
  }
  //common options
  getPreConfigMasterEndUserType(soLiNumber) {
    //const data = CommonMock.commonOptionData;
    this.apiMappingsService.getPreConfigMasterEndUserType(soLiNumber).subscribe((data: []) => {
      //this.http.get(this.apiMappingsService.getPreConfigMasterEndUserType(soLiNumber)).subscribe((data:[]) => {
      if (data) {
        this.configurationTypeList = data['configurationType'];
        this.valveTypeList = data['valveType'];
        this.endUserTypeList = data['endUserType'];
        this.projectClassificationList = data['projectClassification'];
        this.soLiClassificationList = data['soLineClassification'];
        this.etoClassificationList = data['etoClassification'];
        this.duplicateEtoClassificationList = data['etoClassification'];
        this.supportTeamList = data['supportTeam'];
        this.bomTypeList = data['bomType'];
        this.trsList = data['trs'];
        this.taskFamilyList = data['taskFamily'];
        this.complexityList = data['complexity'];
        this.complexityFilterList = this.complexityList;
        //NPC
        this.npcCategoryList = data['npcSubCategory'];
        this.npcComponentList = data['npcSubComponent'];
        this.filteredOptions = this.npcComponentList;
        data['npcForm'][0]['soli'] = this.soLiNumber;
        if (NPC_ELEMENT_DATA.length == 0) {
          NPC_ELEMENT_DATA = data['npcForm'];
        }
        //NPC_ELEMENT_DATA['soli']=this.soli;
        this.plantMasterList = data['plantMaster'];
      }
    });
  }

  onSoliChange(soli: any) {
    if (soli.value) {
      this.etoClassificationList = this.duplicateEtoClassificationList.filter((row: any) => row.etoComplexity.substring(1, 2) == (soli.value - 1));
    } else {
      this.etoClassificationList = this.duplicateEtoClassificationList;
    }
  }
  // getMasterErs() {
  //   this.apiMappingsService.getMasterErs().subscribe((data: []) => {
  //     if (data) {
  //       this.erMasterNoList = data;
  //     }
  //   });
  // }

  //get ER Summary Info
  getERSummaryInfo(soLiNumber) {
    this.apiMappingsService.getERSummaryInfo(soLiNumber).subscribe((data: []) => {
      if (data) {
        //Update Banner Data
        this.enggToolComponent.bannerForm.patchValue(data);
        // this.enggToolComponent.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy'));
        //this.enggToolComponent.bannerForm.get('enggCompletionDate').patchValue(this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy'));
        this.enggToolComponent.bannerForm.get('erRequestDate').patchValue(data['erRequestDate'] != null ? this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy') : null);
        this.enggToolComponent.bannerForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        // 
        this.preConfigForm.get('masterItem').patchValue(data['lineItem']);
        this.preConfigForm.get('primaryEnggTeam').patchValue(data['primaryEnggTeam']);
        this.preConfigForm.get('generalComments').patchValue(data['generalComments']);//generalComments
        this.masterItemList = data['lineItemsList'];
        this.onMasterItemSelect(data['lineItem']);//Get CopyItemList
        // this.copyItemsList = data['lineItemsList'];
        sessionStorage.setItem('saleOrder', data['saleOrder']);
        this.saleOrder = data['saleOrder'];
        this.sapId = data['id'];
        this.soLiNumber = data['soli'];
        this.productHierarchy = data['productHierarchy'];
        this.productHierarchyId = data['productHierarchyId'];
        this.productBrand = data['productBrand'];
        this.tagNumber = data['tagNumber'];
        this.sapActuatorDesc = false;
        if (data['actuatorDescription'] != null && data['actuatorDescription'] != '') {
          this.preConfigForm.get('actuatorModelDescription').patchValue(data['actuatorDescription']);
          this.sapActuatorDesc = true;
        }
        if (data['activitiTree']) {
          this.ERTreeData = data['activitiTree'];
          this.loadActivitiTree(this.ERTreeData);
          this.actuatorMandateCheck(this.ERTreeData);//actuatorMandateCheck
        }
        // NPC_ELEMENT_DATA['soli'] = data['soli'];
        //this.summaryData = data;
        //this.summaryInfoForm.patchValue(this.summaryData);
        //Date format change
        //this.summaryInfoForm.get('enggCompletionDate').patchValue(this.datePipe.transform(data['enggCompletionDate'], 'dd-MMM-yyyy'));
        //this.summaryInfoForm.get('enggPlannedCompletionDate').patchValue(this.datePipe.transform(data['enggPlannedCompletionDate'], 'dd-MMM-yyyy'));
        // Disabling Copy lines for productHierarchy not found
        this.productHierarchyValidation(this.soLiNumber);
        //
      }
    });
  }
  //get ER Summary Info
  getERPreConfigInfo(erNumber) {
    this.apiMappingsService.getERPreConfigInfo(erNumber).subscribe((data: []) => {
      if (data && data['lineItemsList'] != null) {
        //Update Banner Data
        this.enggToolComponent.bannerForm.patchValue(data);
        //this.enggToolComponent.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy'));
        //this.enggToolComponent.bannerForm.get('enggCompletionDate').patchValue(this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy'));
        this.enggToolComponent.bannerForm.get('erRequestDate').patchValue(data['erRequestDate'] != null ? this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy') : null);
        this.enggToolComponent.bannerForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        // 
        // this.masterItemList = data['lineItemsList'];
        // this.onMasterItemSelect(data['masterItem']);
        //Clone flag
        this.cloneFlag = data['isCloned'];
        sessionStorage.setItem('cloneER',this.cloneFlag);
// 
        this.copyItemsList = data['copyItems'];
        // if (data['lineItemsList'].indexOf(data['masterItem']) == -1) {
        //   data['lineItemsList'].push(data['masterItem']);
        //   this.onMasterItemSelect(data['masterItem']);
        // }
        this.status = data['status'];
        //this.preConfigRefNum = data['preConfigRefNum'];
        this.productBrand = data['productBrand'];
        this.productHierarchy = data['productHierarchy'];
        this.productHierarchyId = data['productHierarchyId'];
        this.preConfigData = data;
        this.preConfigForm.patchValue(this.preConfigData);
        //localStorage.setItem('saleOrder', data['saleOrder']);
        this.saleOrder = data['saleOrder']
        this.preConfigForm.get('masterItem').patchValue(data['masterItem']);

        this.preConfigForm.get('copyItems').patchValue(data['copyItems']);
        const trsArr = data['trs']
        this.ERid = data['id'];
        this.sapId = data['sapId'];
        this.tagNumber = data['tagNumber'];
        //Actuator Desc
        if (data['userEditedActuatorData'] != null && data['userEditedActuatorData'] != undefined) {
          if (data['userEditedActuatorData'] === true) {
            this.sapActuatorDesc = false;
          }
          if (data['userEditedActuatorData'] === false) {
            this.sapActuatorDesc = true;
          }
        }
        if (trsArr !== null && trsArr.length > 0) {
          trsArr.forEach(element => {
            this.preConfigForm.get(element).patchValue(true);
          });
        }
        this.ERTreeData = data['activitiTree'];
        this.loadActivitiTree(this.ERTreeData);
        this.actuatorMandateCheck(this.ERTreeData);//actuatorMandateCheck
        if (data['npcData'] != null) {
          if (data['npcData'].length === 0) {
            NPC_ELEMENT_DATA = [];
            this.addNpc();
          } else {
            // M-Code Desc Auto population
            data['npcData'].forEach((row: any) => {
              //if(row['mcodeDesc'] == null || row['mcodeDesc']  ==''){
              this.onMcodeChange(row);
              //}
            });
            //
            NPC_ELEMENT_DATA = data['npcData'];
            this.NpcDataSource = new NpcDataSource();
          }
        }
        if (data['preConfigRefNum'] != null) {
          this.preConfigForm.disable();
          this.refFormDisabled = true;
          this.preConfigForm.get('masterItem').enable();
          this.preConfigForm.get('copyItems').enable();
        }
        if (this.status === 'SUBMIT') {
          this.preConfigForm.disable();
          this.refFormDisabled = true;
        }
        if (this.status == "SAVE") {
          this.submitDisabled = false;
        }
        this.expandNode();
        this.productHierarchyValidation(this.soLiNumber);
      }
    });
  }
  //on Master Item Select
  onMasterItemSelect(selectedMasterItem) {
    if (selectedMasterItem != null && selectedMasterItem != undefined) {
      this.copyItemsList = this.masterItemList.filter((item) => item !== selectedMasterItem)
    }
  }
  //on ER Master Reference Number Change
  onErMasterNoChange(selectedERmaster) {
    this.preConfigForm.enable();
    const _masterItem = this.preConfigForm.get('masterItem').value;
    const _copyItems = this.preConfigForm.get('copyItems').value;
    const _erMasterNo = this.preConfigForm.get('erMasterNo').value;
    if (selectedERmaster != null && selectedERmaster != undefined) {
      this.apiMappingsService.getERPreConfigInfo(selectedERmaster).subscribe((data: []) => {
        if (data) {
          this.preConfigData = data;
          this.preConfigForm.patchValue(this.preConfigData);
          this.preConfigForm.get('masterItem').patchValue(_masterItem);
          this.preConfigForm.get('copyItems').patchValue(_copyItems);
          this.preConfigForm.get('erMasterNo').patchValue(_erMasterNo);
          this.preConfigForm.disable();
          this.refFormDisabled = true;
          this.preConfigForm.get('masterItem').enable();
          this.preConfigForm.get('copyItems').enable();
          this.preConfigForm.get('erMasterNo').enable();
          //this.saveDisabled = false;
          //Actuator Desc
          if (data['userEditedActuatorData'] != null && data['userEditedActuatorData'] != undefined) {
            if (data['userEditedActuatorData'] === true) {
              this.sapActuatorDesc = false;
            }
            if (data['userEditedActuatorData'] === false) {
              this.sapActuatorDesc = true;
            }
          }
          this.preConfigRefId = data['id'];
          const trsArr = data['trs']
          if (trsArr != null && trsArr.length > 0) {
            trsArr.forEach(element => {
              this.preConfigForm.get(element).patchValue(true);
            });
          }
          this.treeDataSource.data = data['activitiTree']['levelData'];
          this.loadActivitiTree(data['activitiTree']);
          this.actuatorMandateCheck(data['activitiTree']);//actuatorMandateCheck
          // if (data['npcData'] != null) {
          //   this.NpcDefaultDataSource = data['npcData'];
          //   this.NpcDataSource = this.NpcDefaultDataSource;
          // }
          if (data['npcData'] != null) {
            if (data['npcData'].length === 0) {
              NPC_ELEMENT_DATA = [];
              this.addNpc();
            } else {
              // M-Code Desc Auto population
              data['npcData'].forEach((row: any) => {
                //if(row['mcodeDesc'] == null || row['mcodeDesc']  ==''){
                this.onMcodeChange(row);
                //}
              });
              //
              NPC_ELEMENT_DATA = data['npcData'];
              this.NpcDataSource = new NpcDataSource();
            }
          }
          this.expandNode();
        }
      });
    }
  }
  //Cloned Services
  getCloneSequenceData(soLiNumber) {
    this.http.get(this.apiMappingsService.getCloneSequenceData(soLiNumber)).subscribe(data => {
      if (data) {
        this.erRevisionNo = data;
      }
    });
  }
  //common options
  getCloneActuatorModelData() {
    this.apiMappingsService.getCloneActuatorModelData().subscribe((data: []) => {
      if (data) {
        this.actuatorDescList = data;
      }
    });
  }
  getClonePreConfigMasterData() {
    //const data = CommonMock.commonOptionData;getPreConfigMasterData
    //this.apiMappingsService.getClonePreConfigMasterData().subscribe((data: []) => {
    this.apiMappingsService.getPreConfigMasterData().subscribe((data: []) => {
      if (data) {
        this.configurationTypeList = data['configurationType'];
        this.valveTypeList = data['valveType'];
        this.endUserTypeList = data['endUserType'];
        this.projectClassificationList = data['projectClassification'];
        this.soLiClassificationList = data['soLineClassification'];
        this.etoClassificationList = data['etoClassification'];
        this.duplicateEtoClassificationList = data['etoClassification'];
        this.supportTeamList = data['supportTeam'];
        this.bomTypeList = data['bomType'];
        this.trsList = data['trs'];
        this.taskFamilyList = data['taskFamily'];
        this.complexityList = data['complexity'];
        this.complexityFilterList = this.complexityList;
        //NPC
        this.npcCategoryList = data['npcSubCategory'];
        this.npcComponentList = data['npcSubComponent'];
        this.filteredOptions = this.npcComponentList;
        data['npcForm'][0]['soli'] = this.soLiNumber;
        if (NPC_ELEMENT_DATA.length == 0) {
          NPC_ELEMENT_DATA = data['npcForm'];
        }
        //NPC_ELEMENT_DATA['soli']=this.soli;
        this.plantMasterList = data['plantMaster'];
      }
    });
  }
  getCloneERSummaryInfo(soLiNumber) {
    this.apiMappingsService.getCloneERSummaryInfo(soLiNumber).subscribe((data: []) => {
      if (data) {
        this.preConfigForm.get('masterItem').patchValue(data['lineItem']);
        this.masterItemList = data['lineItemsList'];
        this.onMasterItemSelect(data['lineItem']);//Get CopyItemList
        // this.copyItemsList = data['lineItemsList'];
        sessionStorage.setItem('saleOrder', data['saleOrder']);
        this.saleOrder = data['saleOrder'];
        this.sapId = data['id'];
        this.soLiNumber = data['soli'];
        this.productHierarchy = data['productHierarchy'];
        this.productHierarchyId = data['productHierarchyId'];
        this.productBrand = data['productBrand'];
        this.tagNumber = data['tagNumber'];
        this.sapActuatorDesc = false;
        if (data['actuatorDescription'] != null && data['actuatorDescription'] != '') {
          this.preConfigForm.get('actuatorModelDescription').patchValue(data['actuatorDescription']);
          this.sapActuatorDesc = true;
        }
        if (data['activitiTree']) {
          this.ERTreeData = data['activitiTree'];
          this.loadActivitiTree(this.ERTreeData);
          this.actuatorMandateCheck(this.ERTreeData);//actuatorMandateCheck
        }
      }
    });
  }
  //Cloned Services END
  //SaveCheckNodes
  saveNodes(data) {
    data.forEach((element, index) => {
      const item = _.filter(this._selectedItems, { 'levelName': element.levelName });
      if (item.length > 0) {
        element.isChecked = true;
        if (element.parentData) {
          element.parentData.isChecked = true;
          if (element.parentData.parentData) {//Level-3
            element.parentData.parentData.isChecked = true;
          }
        }
      } else {
        element.isChecked = false;
        element.generalComments = null;
        element.holdFlag = false;
        element.holdComments = null;

      }
      (element.subLevel || []).forEach(ChildElement => {
        ChildElement['parentData'] = element;
        if (element.subLevel && element.subLevel.length) {
          this.saveNodes(element.subLevel);
          return;
        }
      });
    });
    //console.log(this.svcGetActivityTreeData);
  }
  //Reset Node values
  // resetNodeValues{

  // }

  // submitform() {
  //   this.refFormValid = true;
  //   this.npcFormValid = true;
  //   this.validateReferenceInfo(this.treeDataSource.data);
  //   this.validateNPC(NPC_ELEMENT_DATA);
  //   if (this.refFormValid === true && this.npcFormValid === true) {
  //     this.bhAlertService.showAlert('success','top',10000,'success!');
  //   }
  // }
  validateActivityTree(data) {
    //
    const selectedNodes = [];
    if (data !== undefined && data.length > 0) {
      data.forEach((element, index) => {
        if (element.isChecked === true) {
          selectedNodes.push(element);
        }
        // (element.subLevel || []).forEach(ChildElement => {
        //   if (element.subLevel && element.subLevel.length) {
        //     this.validateReferenceInfo(element.subLevel);
        //     return;
        //   }
        // });
      });
    }
    //
    if (selectedNodes != null && selectedNodes != undefined && selectedNodes.length) {
      this.activityTreeValid = true;
    } else {
      this.activityTreeValid = false;
      this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill "ActivitiTree"..!');
    }
  }

  validateReferenceInfo(data) {
    if (data !== undefined && data.length > 0) {
      data.forEach((element, index) => {
        if (element.holdFlag === true && (element.holdComments === '' || element.holdComments === null)) {
          this.refFormValid = false;
        }
        (element.subLevel || []).forEach(ChildElement => {
          if (element.subLevel && element.subLevel.length) {
            this.validateReferenceInfo(element.subLevel);
            return;
          }
        });
      });
    }
    if (!this.refFormValid) {
      this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill "Hold Comments" for Reference information..!');
    }
  }
  check(data) {
    this.treeDataSource.data.forEach(node => {
      if (node.levelName == 'New Part Creation' && node.isChecked == true) {
        this.validateNPC(NPC_ELEMENT_DATA);
      }
    });
  }
  validateNPC(data) {
    if (data !== null && data !== undefined && data.length > 0) {
      data.forEach((element, index) => {
        if (element.holdFlag === true && (element.holdComments === '' || element.holdComments === null)) {
          this.npcFormValid = false;
        }

        if (element.subLevelComponentId === null) {
          this.npcFormValid = false;
          this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill NPC Component');
        }
        //npc SubCategory no equalto Legacy/Others
        if (element.npcSubCategoryId != 5) {
          if (element.drawingNumber === null || element.mcode === null || element.qcode === null) {
            this.npcFormValid = false;
            this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill "DWG no/M-code/Q-code" fields..!');
          } else if (element.drawingNumber.length < 9 || element.mcode.length < 4 || element.qcode.length < 4) {
            this.npcFormValid = false;
            this.bhAlertService.showAlert('warning', 'top', 10000, '"DWG no" should contain 9 characters and "M-code/Q-code" should contain 4 characters');
          }
        }
        if (element.npcSubCategoryId === 5) {
          if (element.plantCode === null || element.partNumber === null) {
            this.npcFormValid = false;
            this.bhAlertService.showAlert('warning', 'top', 10000, 'Plant and Part Number fileds are required ..!');
          } else if (element.partNumber.length < 4) {
            this.npcFormValid = false;
            this.bhAlertService.showAlert('warning', 'top', 10000, 'Part Number should contain min 4 characters..!');
          }
        }
        //npc DWG no/M-code/Q-code Combination Check
        // if (this.npcFormValid === true) {
        //   let npcValid = true;
        //   this.npcCombinationCheck(element, false, npcValid);
        //   if (npcValid === true) {
        //     this.npcCombination = true;
        //   } else {
        //     this.npcCombination = false;
        //   }
        // }


      });
    }
    // if (!this.npcFormValid) {
    //   this.bhAlertService.showAlert('warning', 'top', 10000, 'Please fill "all the required fields" for NPC..!');
    // }
  }
  ///
  npcCombinationCheck(element, orphanFlag) {
    if (element.drawingNumber != null && element.mcode != null && element.qcode != null) {
      if (element.drawingNumber.length === 9 && element.mcode.length === 4 && element.qcode.length === 4) {
        this.enggToolComponent.npcCombinationCheck(element, orphanFlag);
      }
    }
  }
  partNumberValidation(element, orphanFlag) {
    if (element.npcSubCategoryId === 5) {
      if (element.partNumber != null && element.partNumber != '' && element.partNumber.length > 3) {
        this.enggToolComponent.partNumberValidation(element, orphanFlag);
      }
    }
  }
  // npcCombinationCheck(element, orphanFlag) {
  //   if (element.drawingNumber.length === 9 && element.mcode.length === 4 && element.qcode.length === 4) {
  //     let formData = {};
  //     let userPlant = localStorage.getItem("userPlant");
  //     formData["mcode"] = element.mcode,
  //       formData["qcode"] = element.qcode,
  //       formData["drawingNumber"] = element.drawingNumber,
  //       formData["preConfigId"] = element.preConfigId,
  //       formData["soli"] = element.soli,
  //       formData["orphanFlag"] = orphanFlag,
  //       formData["plant"] = userPlant
  //     this.apiMappingsService.npcValidation(formData).subscribe((data: []) => {
  //       if (data && data['validationFlag'] === true) {
  //         const message = data['info'];
  //         const dialogData = new ConfirmDialogModel("Confirm Action on Combination", message);
  //         const dialogRef = this.dialog.open(ConfirmDialogComponent, {
  //           data: dialogData
  //         });
  //         dialogRef.afterClosed().subscribe(dialogResult => {
  //            if (dialogResult === true) {
  //             // npcValid = true;
  //             // this.savePreConfig();
  //           }
  //         });
  //       } else if (data && data['validationFlag'] === false) {
  //         //npcValid = true;
  //       }
  //     });
  //   }
  // }

  //Save
  save(data) {
    if (this.preConfigForm.valid) {
      //Validate RefenceInfo & NPC
      this.refFormValid = true;
      this.npcFormValid = true;
      this.activityTreeValid = true;
      this.validateActivityTree(this.treeDataSource.data)
      this.validateReferenceInfo(this.treeDataSource.data);
      //this._selectedItems.forEach(node => {
      this.treeDataSource.data.forEach(node => {
        if (node.levelName == 'New Part Creation' && node.isChecked == true) {
          this.validateNPC(NPC_ELEMENT_DATA);
        }
      });
      //if (this.npcCombination === false) {
      if (this.activityTreeValid === true && this.refFormValid === true && this.npcFormValid === true) {
        this.savePreConfig();
      }
      //}
    } else {
      this.bhAlertService.showAlert(
        'warning',
        'top',
        5000,
        'Please fill all the required fields!'
      );
    }
  }
  savePreConfig() {
    let formData = this.preConfigForm.getRawValue();
    //formData['id'] = this.sapId;//
    formData['sapId'] = this.sapId;
    formData['saleOrder'] = this.saleOrder;
    formData['soli'] = this.soLiNumber;
    formData['productHierarchy'] = this.productHierarchy;
    formData['productHierarchyId'] = this.productHierarchyId;
    formData['tagNumber'] = this.tagNumber;
    formData['trs'] = this.trsList;
    formData['preConfigRefId'] = this.preConfigRefId;
    //Actuator Description
    formData['userEditedActuatorData'] = false;
    if (this.sapActuatorDesc === false) {
      const selectedValue = this.preConfigForm.get('actuatorModelDescription').value;
      if (selectedValue != null && selectedValue != '') {
        formData['userEditedActuatorData'] = true;
      }
    }
    formData['id'] = null;
    if (this.ERid != null) {
      formData['id'] = this.ERid;
    }
    if (this.status == "SAVE") {
      this.submitDisabled = false;
      formData['status'] = "UPDATE";
    } else {

      formData['status'] = "SAVE";
    }
    //   let Acitivitytree1 = this.treeControl.dataNodes;
    //   formData['activitiTree']=  Acitivitytree1  ;
    //   console.log("json :"+formData['activitiTree']);
    //  let Acitivitytree= JSON.stringify(this.treeControl.dataNodes)
    //   formData['activitiTree'] = Acitivitytree ;
    //   console.log("json :"+formData['activitiTree']['levelData']);
    //formData['activitiTree'] = Mock.svcGetActivityTreeData;
    this.saveNodes(this.treeDataSource.data);
    this.spliceParentNodes(this.treeDataSource.data);
    //this.saveRefenceInfo();
    const levelData = {};
    levelData['levelData'] = this.treeDataSource.data;
    formData['activitiTree'] = levelData;
    //formData['activitiTree'] = this.treeData;
    //Push NPC if Selected
    formData['npcData'] = null;
    this.treeDataSource.data.forEach(node => {
      if (node.levelName == 'New Part Creation' && node.isChecked == true) {
        formData['npcData'] = NPC_ELEMENT_DATA;
      }
    });

    //Check isCloned
    formData['isCloned'] = false;
    formData['is_delinked'] = false;
    formData['erRevisionNo'] = 0;
    if (this.cloneFlag === 'true') {
      formData['isCloned'] = true;
      formData['is_delinked'] = true;
      formData['erRevisionNo'] = this.erRevisionNo;
    }

    //console.log("json :" + formData['activitiTree']);
    this.apiMappingsService.saveERPreConfigInfo(formData).subscribe((data: []) => {
      if (data) {
        this.preConfigData = data;
        this.preConfigForm.patchValue(this.preConfigData);
        //this.commonservice.erNumber = data['erNumber'];
        this.status = data['status'];
        this.submitDisabled = false;
        this.enggToolComponent.bannerForm.get('erNumber').patchValue(data['erNumber']);
        this.enggToolComponent.bannerForm.get('complexity').patchValue(data['complexity']);
        sessionStorage.setItem('erNumber', data['erNumber']);
        sessionStorage.setItem('preConfigId', data['id']);
        this.ERid = data['id'];
        this.preConfigForm.get('erMasterNo').patchValue(data['erMasterNo']);
        //Npc Details
        // this.npcReferenceId = data['npcData']['npcReferenceId'];
        // this.npcReferenceMappingId = data['npcData']['npcReferenceMappingId'];
        this.bhAlertService.showAlert(
          'success',
          'top',
          5000,
          'Pre-Configuration Saved Successfully!'
        );
        //this.preConfigForm.disable(); 
        // M-Code Desc Auto population
        if(data['npcData'] && data['npcData'].length>0){
        data['npcData'].forEach((row: any) => {
          //if(row['mcodeDesc'] == null || row['mcodeDesc']  ==''){
          this.onMcodeChange(row);
          //}
        });
      }
        //       
        NPC_ELEMENT_DATA = data['npcData'];
        this.NpcDataSource = new NpcDataSource();
      }
    });
  }
  //Submit
  submit() {
    if (this.preConfigForm.valid) {
      this.refFormValid = true;
      this.npcFormValid = true;
      this.activityTreeValid = true;
      this.validateActivityTree(this.treeDataSource.data)
      this.validateReferenceInfo(this.treeDataSource.data);
      // this._selectedItems.forEach(node => {
      this.treeDataSource.data.forEach(node => {
        if (node.levelName == 'New Part Creation' && node.isChecked == true) {
          this.validateNPC(NPC_ELEMENT_DATA);
        }
      });
      if (this.npcCombination === false) {
        if (this.activityTreeValid === true && this.refFormValid === true && this.npcFormValid === true) {
          let formData = this.preConfigForm.getRawValue();
          formData['id'] = this.ERid;//
          formData['sapId'] = this.sapId;
          formData['saleOrder'] = this.saleOrder;
          formData['soli'] = this.soLiNumber;
          formData['productHierarchy'] = this.productHierarchy;
          formData['productHierarchyId'] = this.productHierarchyId;
          formData['tagNumber'] = this.tagNumber;
          formData['trs'] = this.trsList;
          formData['preConfigRefId'] = this.preConfigRefId;
          //Actuator Description
          formData['userEditedActuatorData'] = false;
          if (this.sapActuatorDesc === false) {
            const selectedValue = this.preConfigForm.get('actuatorModelDescription').value;
            if (selectedValue != null && selectedValue != '') {
              formData['userEditedActuatorData'] = true;
            }
          }
          formData['id'] = null;
          if (this.ERid != null) {
            formData['id'] = this.ERid;
          }
          formData['status'] = "SUBMIT";
          this.saveNodes(this.treeDataSource.data);
          this.spliceParentNodes(this.treeDataSource.data);
          const levelData = {};
          levelData['levelData'] = this.treeDataSource.data;
          formData['activitiTree'] = levelData;
          //Push NPC if Selected
          formData['npcData'] = null;
          // this._selectedItems.forEach(node => {
          this.treeDataSource.data.forEach(node => {
            if (node.levelName == 'New Part Creation' && node.isChecked == true) {
              formData['npcData'] = NPC_ELEMENT_DATA;
            }
          });
          //
          //Check isCloned
          formData['isCloned'] = false;
          formData['is_delinked'] = false;
          formData['erRevisionNo'] = 0;
          if (this.cloneFlag === 'true') {
            formData['isCloned'] = true;
            formData['is_delinked'] = true;
            formData['erRevisionNo'] = this.erRevisionNo;
          }
          //console.log("json :" + formData['activitiTree']);
          this.apiMappingsService.submitERPreConfigInfo(formData, this.ERid).subscribe((data: []) => {
            if (data) {
              this.preConfigData = data;
              this.preConfigForm.patchValue(this.preConfigData);
              this.status = data['status'];
              this.submitDisabled = false;
              this.enggToolComponent.bannerForm.get('erNumber').patchValue(data['erNumber']);
              this.enggToolComponent.bannerForm.get('complexity').patchValue(data['complexity']);
              sessionStorage.setItem('erNumber', data['erNumber']);
              sessionStorage.setItem('preConfigId', data['id']);
              this.ERid = data['id'];
              //Npc Details
              // this.npcReferenceId = data['npcData']['npcReferenceId'];
              // this.npcReferenceMappingId = data['npcData']['npcReferenceMappingId'];
              // NPC_ELEMENT_DATA['npcData']['npcReferenceId'] = this.npcReferenceId;
              // NPC_ELEMENT_DATA['npcData']['npcReferenceMappingId'] = this.npcReferenceMappingId;
              this.bhAlertService.showAlert(
                'success',
                'top',
                5000,
                'Pre-Configuration Submitted Successfully!'
              );
              this.preConfigForm.disable();
              this.submitDisabled = true;
              this.refFormDisabled = true;
              // M-Code Desc Auto population
              data['npcData'].forEach((row: any) => {
                //if(row['mcodeDesc'] == null || row['mcodeDesc']  ==''){
                this.onMcodeChange(row);
                //}
              });
              //
              NPC_ELEMENT_DATA = data['npcData'];
              this.router.navigate(['enggTool/schedulingPlanning']);
            }
          });
        }
      }
    } else {
      this.bhAlertService.showAlert(
        'warning',
        'top',
        5000,
        'Please fill all the required fields!'
      );
    }
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "PreConfig" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  //ER REFERENCE Dialog Search
  //
  showERSearchModal(element) {
    this.erSearchModal = this.dialog.open(ERSearchModalComponent, { data: "sendModaldat" });
    this.erSearchModal.afterClosed().subscribe(value => {
      if (value) {
        //this.submitAccessRequest(value);
        console.log(value);
        this.preConfigForm.get(element).patchValue(value);
        this.onErMasterNoChange(value);
      }
    });
  }
  //
  //NPC REFERENCE Dialog Search
  //
  showNPCSearchModal(element) {
    this.npcSearchModal = this.dialog.open(NPCSearchModalComponent, { data: { dwg: element.drawingNumber, mCode: element.mcode, qCode: element.qcode } });
    this.npcSearchModal.afterClosed().subscribe(value => {
      if (value) {
        //element['npcDetails'][0]['erNpc']=value['npcNumber'];
        // this.commonservice.npcSearchData.subscribe((npcSearchData) => {
        // if (npcSearchData) {
        // console.log(npcSearchData);
        //const selectedNPC = _.filter(npcSearchData, { 'npcNumber': value['npcNumber'] });
        //if (selectedNPC.length > 0) {
        //element = selectedNPC[0];
        // element.map((key, index) => {
        //   return Object.assign(key, selectedNPC[0][index]);
        // })
        const npcRefMappingId = value['id'];
        const erNpc = value['npcNumber'];
        const result = Object.assign(element, value);
        element['id'] = null;
        element['npcReferenceMappingId'] = null;
        element['erNpc'] = erNpc;
        element['soli'] = this.soLiNumber;
        element['childEr'] = value.id;
        element['childErNumber'] = erNpc;
        //this.npcFormDisable = true;
        console.log(element);
        console.log(result);
        //}

        //element['npcDetails'][0]['erNpc']=value;
        //}
        //});
        this.NpcDataSource = new NpcDataSource();
        //this.submitAccessRequest(value);

        //this.preConfigForm.get(element).patchValue(value);
        //this.onErMasterNoChange(value);
      }
    });
  }
  //
  onEtoChange() {
    //this.preConfigForm.get('complexity').patchValue('');
    const node = this.preConfigForm.get('etoClassification').value;
    console.log(node);
    this.etoArrList = []
    if (node != null && node.length > 0) {
      node.forEach(element => {
        const etoList = _.filter(this.etoClassificationList, { 'id': element });
        this.etoArrList.push(etoList[0].etoComplexity);
      });
    }
    this.complexityFilterList = this.complexityList;
    if (this.etoArrList.includes("L3")) {
      this.complexityFilterList = this.complexityList.filter((item) => item.complexity === 'L3');
      this.preConfigForm.get('complexityId').patchValue(4);//L3
    } else if (this.etoArrList.includes("L2")) {
      this.complexityFilterList = this.complexityList.filter((item) => item.complexity === 'L2' || item.complexity === 'L3');
      this.preConfigForm.get('complexityId').patchValue(3);//L2
    } else if (this.ETOcheckList.length > 0) {
      this.complexityFilterList = this.complexityList.filter((item) => item.complexity !== 'L0');
      this.preConfigForm.get('complexityId').patchValue(2);//L1
    } else {
      this.complexityFilterList = this.complexityList;
      this.preConfigForm.get('complexityId').patchValue(1);//L0
    }

    console.log(this.etoArrList);
  }
  //Mcode Description Auto Populate
  onMcodeChange(element) {
    element['disableMcodeDesc'] = false;
    //element.mcodeDesc = null;
    let mCodeValue = element.mcode;
    if (mCodeValue != null && mCodeValue.length === 4) {
      this.apiMappingsService.getMcodeDesc(mCodeValue).subscribe((data) => {
        if (data && data != null) {
          if (data['mcode_flag'] === true) {
            element.mcodeDesc = data['mcodeDesc'];
            element['disableMcodeDesc'] = true;
          } else if (data['mcode_flag'] === false) {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'M-code-' + element.mcode + ' is Disabled!');
            element.mcode = null;
            element.mcodeDesc = null;
          }
        } else {
          element.mcodeDesc = null;
        }
      });
    }
  }
  //NPC  on CategogyChang
  onCategogyChange(item: any) {
    if (!item.npcSubCategoryId) {
      item.npcSubCategory = null;
      item.npcSubCategoryId = null;
    }
    if (item.npcSubCategoryId != 5) {
      item.partNumber = null;
    } else if (item.npcSubCategoryId === 5) {
      item.drawingNumber = null;
      item.mcode = null;
      item.qcode = null;
    }
  }
  //
  ///
}
//Task check list 
export interface Task {
  name: string;
  checked: boolean;
  subtasks?: Task[];
}
//
export interface DialogData {
  animal: string;
  name: string;
}
export interface NpcDialogData {
  animal: string;
  name: string;
}

//Table
export interface TableData {
  from: Date;
  to: Date;
}
//NPC
export interface Npc {
  id: number;
  drawingNumber: string;
  npcReferenceId: number;
  subLevelComponent: string;
  subLevelComponentId: number;
  npcSubCategory: string;
  npcSubCategoryId: number;
  soli: string;
  mcode: string;
  qcode: string;
  npcReferenceMappingId: number;
  npcNumber: string;
  //npcDetails: NPCDetails[];
  makeBuy: string;
  erNpc: string;
  dwgHeader: string;
  mcodeDesc: string;
  qcodeDesc: string;
  generalComments: string;
  holdFlag: boolean;
  holdComments: string;
}
// export interface NPCDetails {
//   makeBuy: string;
//   erNpc: string;
//   dwgHeader: string;
//   mcodeDesc: string;
//   qcodeDesc: string;
//   generalComments: string;
//   holdFlag: boolean;
//   holdComments: string;
// }
let NPC_ELEMENT_DATA: Npc[] = [];
// const data = Mock.getcomplexityList;
// const NPC_ELEMENT_DATA: Npc[] = data['npcData'];

export class NpcDataSource extends DataSource<any> {
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<Npc[]> {
    const rows = [];
    NPC_ELEMENT_DATA.forEach(element => {
      //const npcDetails = element.npcDetails;
      //rows.push(element, { detailRow: true, npcDetails })
      rows.push(element)
    }
    );
    console.log(rows);
    return of(rows);
  }

  disconnect() { }
}
//
export interface TreeDataTableInterface {
  levelName: string;
  id: number;
  levelNo: string;
  subLevel?: SubLevel[] | MatTableDataSource<SubLevel>
  isChecked: boolean;
  holdFlag: boolean;
  holdComments: string;
  generalComments: string;
  siteLevelMapping: [];
  parentData: [];
}
let REF_ELEMENT_DATA: TreeDataTableInterface[] = [];
export interface SubLevel {
  levelName: string;
  id: number;
  levelNo: string;
  subLevel?: SubLevel[] | MatTableDataSource<SubLevel>
  isChecked: boolean;
  holdFlag: boolean;
  holdComments: string;
  generalComments: string;
  siteLevelMapping: [];
  parentData: [];
}
export interface PeriodicElement {
  id: number;
  levelName: string;
  levelNo: string;
}

interface FoodNode {
  levelName: string;
  id: number;
  levelNo: string;
  subLevel?: FoodNode[];
  isChecked: boolean;
  holdFlag: boolean;
  holdComments: string;
  generalComments: string;
  siteLevelMapping: [];
  parentData: [];
}

//const data = Mock.svcGetActivityTreeData;
//const TREE_DATA1: FoodNode[] = data['levelData'];
let TREE_DATA: FoodNode[] = [];
////Tree

/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  levelName: string;
  id: number;
  level: number;
  levelNo: string;
  isChecked: boolean;
  holdFlag: boolean;
  holdComments: string;
  generalComments: string;
  siteLevelMapping: [];
  parentData: [];
}




