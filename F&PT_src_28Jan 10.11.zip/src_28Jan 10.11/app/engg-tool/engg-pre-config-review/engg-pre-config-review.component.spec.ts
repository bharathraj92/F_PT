import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnggPreConfigReviewComponent } from './engg-pre-config-review.component';

describe('EnggPreConfigReviewComponent', () => {
  let component: EnggPreConfigReviewComponent;
  let fixture: ComponentFixture<EnggPreConfigReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnggPreConfigReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnggPreConfigReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
