import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivityTreeHistoryComponent } from './activity-tree-history.component';

describe('ActivityTreeHistoryComponent', () => {
  let component: ActivityTreeHistoryComponent;
  let fixture: ComponentFixture<ActivityTreeHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivityTreeHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityTreeHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
