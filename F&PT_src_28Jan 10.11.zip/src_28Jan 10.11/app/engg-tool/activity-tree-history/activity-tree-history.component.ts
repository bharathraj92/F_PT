
import { Component, OnInit, Inject } from '@angular/core';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as Mock from 'src/app/mock/attachments.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { DesignDialogData } from '../external-deliverables/external-deliverables.component';
import { BhAlertService } from 'bh-theme';
import { saveAs } from "file-saver";
import { Logs } from 'selenium-webdriver';
@Component({
  selector: 'app-activity-tree-history',
  templateUrl: './activity-tree-history.component.html',
  styleUrls: ['./activity-tree-history.component.scss']
})
export class ActivityTreeHistoryComponent implements OnInit {
  comments: any;
  fileToUpload: File = null;
  selectedAttachments: any;
  displayedColumns: string[] = ['erRevisionNum', 'module', 'subModule', 'status', 'assigneeFirstName', 'role'];
  preConfigId: any;
  moduleName: any;
  enableDelete: any;
  taskList: any[] = [];

  ERTreeLogInterface
  dataSource = new MatTableDataSource<ERTreeLogInterface>(ELEMENT_DATA);

  constructor(
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {

  }

  ngOnInit(): void {
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.getTimelog();
  }

  getTimelog() {
    // const data = Mock.attachmentsData['attachmentsDto'];
    // this.prepareTableData(data);
    this.apiMappingsService.getActivityTreeTimelog(this.preConfigId).subscribe((data) => {
      if (data) {
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'No Data Found!');
      }
    });
  }
  prepareTableData(logTableData) {
    ELEMENT_DATA = [];
    logTableData.forEach(log => {
      ELEMENT_DATA.push({
        erRevisionNum: log.erRevisionNum,
        module: log.module,
        subModule: log.subModule,
        status: log.status,
        assigneeFirstName: log.assigneeFirstName,
        role: log.role
      });
      // id: erRequest.id,
      this.dataSource.data = ELEMENT_DATA;
    });
    // 
  }
  //
  getStatusClass(status) {
    let statusClass = 'status';
    switch (status) {
      case 'NOT STARTED':
        statusClass = 'status notStarted';
        break;
      case 'HOLD':
        statusClass = 'status hold';
        break;
      case 'IN PROGRESS':
        statusClass = 'status inProgress';
        break;
      case 'WIP':
        statusClass = 'status inProgress';
        break;
      case 'COMPLETED':
        statusClass = 'status completed';
        break;
      case 'CANCELLED':
        statusClass = 'status cancelled';
        break;
      default:
        statusClass = 'status';
        break;
    }
    return statusClass;
  }

}
export interface ERTreeLogInterface {
  erRevisionNum: string;
  module: string;
  subModule: string;
  status: string;
  assigneeFirstName: string;
  role: any;
}
let ELEMENT_DATA: ERTreeLogInterface[] = [];