import { Component, OnInit } from '@angular/core';

import { MatToolbarModule } from '@angular/material/toolbar';
import { Router } from '@angular/router';///
import { FormGroup, FormBuilder } from '@angular/forms';
import { ApiMappingsService } from '../Services/api-mappings.service';
import { CommonService } from '../Services/common.service';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MessageHistoryModalComponent } from './message-history-modal/message-history-modal.component';
import { ConfirmDialogComponent, ConfirmDialogModel } from '../util/confirm-dialog/confirm-dialog.component';
@Component({
  selector: 'app-engg-tool',
  templateUrl: './engg-tool.component.html',
  styleUrls: ['./engg-tool.component.scss']
})
export class EnggToolComponent implements OnInit {
  panelOpenState = true;
  navLinks: any[];
  activeLinkIndex = -1;
  bannerForm: FormGroup;
  bannerData: any;
  //InfoFields
  task;
  subTask;
  saleOrder;
  soLiNumber;
  erNumber;
  preConfigId;
  erStatus;
  erRequestDate;
  customerName;
  enggCompletionDate;
  soli;
  complexity;
  datePipe = new DatePipe("en-US");
  enableFlag: any;
  messageHistoryModal: MatDialogRef<MessageHistoryModalComponent>;
  cloneFlag: any;
  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private apiMappingsService: ApiMappingsService,
    private commonservice: CommonService,
    public dialog: MatDialog
  ) {
    //this.enableFlag = localStorage.getItem("EnableTabs");//disableBom
    this.enableFlag = sessionStorage.getItem("disableBom");//disableBom

    ///Getting ER Number and  SaleOrder from DashBoard
    this.commonservice.saleOrderNumber.subscribe((data) => {
      this.saleOrder = data;
    });
    this.commonservice.erNumber.subscribe((data) => {
      this.erNumber = data;
    });
    if (this.saleOrder === '') {
      this.saleOrder = sessionStorage.getItem('saleOrderNumber');
    }

    this.soLiNumber = sessionStorage.getItem('soLiNumber');

    if (this.erNumber === '') {
      this.erNumber = sessionStorage.getItem('erNumber');
    }
    if (this.preConfigId === '') {
      this.preConfigId = sessionStorage.getItem('preConfigId');
    }
    this.task = sessionStorage.getItem('task');
    this.subTask = sessionStorage.getItem('subTask');
  }
  ngOnInit(): void {
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });
    this.bannerForm = this.formBuilder.group({
      saleOrder: [null],
      erNumber: [null],
      erStatus: [null],
      erRequestDate: [null],
      customerName: [null],
      enggCompletionDate: [null],
      soli: [null],
      complexity: [null],
    })
    this.bannerForm.reset();
    // if (this.erNumber && this.router.url === '/enggTool/summaryInfo') {
    //   // else if (this.erNumber && this.router.url === '/enggTool/preConfig') {
    //   this.getERPreConfigInfo(this.erNumber);
    // }else if ((this.soLiNumber && this.router.url === '/enggTool/summaryInfo') || this.erNumber === '') {
    //   this.getERSummaryInfo(this.soLiNumber);
    // } 
    if (this.erNumber) {
      this.getERPreConfigInfo(this.erNumber);
    } else if (this.soLiNumber) {
      this.getERSummaryInfo(this.soLiNumber);
    }
    this.bannerForm.disable();
    this.isSchedulingAndPlanningDone(sessionStorage.getItem("erNumber"));

  }
  getActiveClass(indexOfRouteLink) {
    let tabsclass = 'mat-tab-link';
    if (this.activeLinkIndex === indexOfRouteLink) {
      tabsclass = 'mat-tab-link mat-tab-label-active';
    }
    return tabsclass;
  }

  prepareNavLink(enableFlag: any) {
    this.navLinks = [
      {
        label: 'SUMMARY',
        link: './summaryInfo',
        index: 0,
        enabled: true
      }, {
        label: 'PRE-CONFIGURATION',
        link: './preConfig',
        index: 1,
        enabled: true
      }, {
        label: 'SCHEDULING & PLANNING',
        link: './schedulingPlanning',
        index: 2,
        enabled: true
      },
      {
        label: 'BOM',
        link: './bomConfig',
        index: 3,
        enabled: enableFlag
      }, {
        label: 'ENGINEERING-DOC',
        link: './configuration',
        index: 4,
        enabled: enableFlag
      }, {
        label: 'QUALITY-DOC',
        link: './qualityDoc',
        index: 5,
        enabled: enableFlag
      },
      {
        label: 'ATTACHMENTS',
        link: './attachments',
        index: 6,
        enabled: enableFlag
      }, {
        label: 'HISTORY',
        link: './history',
        index: 7,
        enabled: true
      },
    ];
  }

  isSchedulingAndPlanningDone(erNumber: any) {
    if (erNumber) {
      let preConfigId = erNumber.split("-")[3];
      this.apiMappingsService.isSchedulingAndPlanningDone(preConfigId).subscribe((data: any) => {
        if (data) {
          sessionStorage.setItem("disableBom", "false");
          this.prepareNavLink(data);
        } else {
          if (erNumber.split("-")[4] && erNumber.split("-")[4] == 'NPC') {
            sessionStorage.setItem("disableBom", "true");
          } else {
            sessionStorage.setItem("disableBom", "false");
          }
          this.prepareNavLink(data);
        }
      });
    } else {
      sessionStorage.setItem("disableBom", "false");
      this.prepareNavLink(false);
    }
  }

  //get ER Summary Info
  getERSummaryInfo(soLiNumber) {
    this.apiMappingsService.getERSummaryInfo(soLiNumber).subscribe((data: []) => {
      if (data) {
        this.bannerData = data;
        this.bannerForm.patchValue(this.bannerData);
        //Date format change
        this.bannerForm.get('erRequestDate').patchValue(data['erRequestDate'] != null ? (this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy')) : null);
        this.bannerForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
      }
    });
  }
  //get ER Summary Info
  getERPreConfigInfo(erNumber) {
    this.apiMappingsService.getERPreConfigInfo(erNumber).subscribe((data: []) => {
      if (data) {
        this.bannerData = data;
        this.bannerForm.patchValue(this.bannerData);
        sessionStorage.setItem('soLiNumber', this.bannerData['soli']);
        sessionStorage.setItem('preConfigId', this.bannerData['id']);
        // this.cloneFlag = this.bannerData['isCloned'];
        // sessionStorage.setItem('cloneER',this.cloneFlag);
        //Date format change
        // this.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'], 'dd-MMM-yyyy'));
        this.bannerForm.get('erRequestDate').patchValue(data['erRequestDate'] != null ? (this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy')) : null);
        this.bannerForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);

      }
    });
  }
  //show Message History Modal 
  showMessageHistoryModal(task, user, item, field) {
    if (field !== null) {
      this.messageHistoryModal = this.dialog.open(MessageHistoryModalComponent, { data: { task: task, user: user, item: item, fieldName: field } });
      this.messageHistoryModal.afterClosed().subscribe(value => {
        if (value) {
        }
      });
    } else {
      //this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select field.!');
    }
  }
  //
  //npc DWG no/M-code/Q-code Combination Check
  npcCombinationCheck(element, orphanFlag) {
    let formData = {};
    let orphanNPCPlant;
    //let userPlant = localStorage.getItem("userPlant");
    if(orphanFlag === true){
      orphanNPCPlant = element.plantCode;
    }
    let drawingNumber = null;
    if (element.drawingNumber) {
      drawingNumber = element.drawingNumber
    } else if (element.geometry) {
      drawingNumber = element.geometry
    }
      formData["drawingNumber"] = drawingNumber,
      formData["mcode"] = element.mcode,
      formData["qcode"] = element.qcode,
      formData["preConfigId"] = element.preConfigId,
      formData["soli"] = element.soli,
      formData["orphanFlag"] = orphanFlag,
      formData["plant"] = orphanNPCPlant,
    this.apiMappingsService.npcValidation(formData).subscribe((data: []) => {
      if (data && data['validationFlag'] === true) {
        const message = data['info'];
        const dialogData = new ConfirmDialogModel("Confirm Action on Combination", message);
        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: dialogData
        });
        dialogRef.afterClosed().subscribe(dialogResult => {
          if (dialogResult === true) {
            // npcValid = true;
            // this.savePreConfig();
          }
        });
      } else if (data && data['validationFlag'] === false) {
        //npcValid = true;
      }
    });
  }
   //npc DWG no/M-code/Q-code Combination Check
   partNumberValidation(element, orphanFlag) {
    let formData = {};
    let orphanNPCPlant;
    //let userPlant = localStorage.getItem("userPlant");
    if(orphanFlag === true){
      orphanNPCPlant = element.plantCode;
    }
    // "mcode": "0000",
    // "qcode": "0000",  
    // "drawingNumber": "123456789",  
    // "preConfigId": 20,  
    // "soli": null,  
    // "orphanFlag": false,  
    // "plant" :"5500",  
    // "partNum" :"1234"

      // formData["drawingNumber"] ='xxxxxxxxx' ,
      // formData["mcode"] = 'xxxx',
      // formData["qcode"] = 'xxxx',
      formData["preConfigId"] = element.preConfigId,
      formData["soli"] = element.soli,
      formData["orphanFlag"] = orphanFlag,
      formData["plant"] = orphanNPCPlant,
      formData["partNum"] = element.partNumber,
      
    this.apiMappingsService.partNumberValidation(formData).subscribe((data: []) => {
      if (data && data['validationFlag'] === true) {
        const message = data['info'];
        const dialogData = new ConfirmDialogModel("Confirm Action on Combination", message);
        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: dialogData
        });
        dialogRef.afterClosed().subscribe(dialogResult => {
          if (dialogResult === true) {
            // npcValid = true;
            // this.savePreConfig();
          }
        });
      } else if (data && data['validationFlag'] === false) {
        //npcValid = true;
      }
    });
  }
}
