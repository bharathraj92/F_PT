import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatAutocomplete } from '@angular/material/autocomplete';
import { CommonService } from '../../Services/common.service';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { OtherEngineeringActivitiesDialogData } from '../other-engg-activities/other-engg-activities.component';
import { BhAlertService } from 'bh-theme';

  @Component({
    selector: 'app-other-engg-activities-search-modal',
    templateUrl: './other-engg-activities-search-modal.component.html',
    styleUrls: ['./other-engg-activities-search-modal.component.scss']
  })
  export class OtherEnggActivitiesSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['erNumber', 'soli','description'];
  designDataSource = new MatTableDataSource<testSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('testSearch') myDashboardTable: MatTable<testSearchInterface>;
  selectedRowIndex: number;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  otherEnggActivitiesSearchForm: FormGroup;
  selectedTest: any;
  levelTwoId: any;
  designSearchResult: any[];
  creatorId: any;
  constructor(public formBuilder: FormBuilder,
    public testDialogRef: MatDialogRef<OtherEnggActivitiesSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: OtherEngineeringActivitiesDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.otherEnggActivitiesSearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    this.levelTwoId = this.data['levelTwoId'];
    this.creatorId = this.data['creatorId'];
    this.designDataSource.paginator = this.paginator;
    this.designDataSource.sort = this.sort;
  }

  prepareTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(designRequest => {
      ELEMENT_DATA.push({
        id: designRequest.id,
        erDesignNumber: designRequest.erDesignNumber,
        soli: designRequest.soli,
        description:designRequest.description,
        otherEnggActivitiesCreatorDto:designRequest.otherEngineeringActivitiesLevelTwoCreatorDto,
        otherEnggActivitiesReviewerDto:designRequest.otherEngineeringActivitiesLevelTwoReviewerDto,
      });
    });
    this.designDataSource.data = ELEMENT_DATA;
  }

  searchDesignRef() {
    ELEMENT_DATA = [];
    let formvalue = this.otherEnggActivitiesSearchForm.value;
    formvalue['levelTwoId'] = this.levelTwoId;
    formvalue['creatorId'] = this.creatorId;
    formvalue['task'] = "Other Engg Activities";
    this.apiMappingsService.getReferenceOtherengineeringActivities(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.designSearchResult = data;
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectTest(element) {
    this.testDialogRef.close(element);
  }

  onClickERNumber(value: any) {

  }

}

export interface testSearchInterface {
  id: number;
  erDesignNumber: string;
  soli: string;
  description: string;
  otherEnggActivitiesCreatorDto:otherEnggActivitiesCreatorDto[];
  otherEnggActivitiesReviewerDto:otherEnggActivitiesReviewerDto[];
}

let ELEMENT_DATA: testSearchInterface[] = [];

export interface otherEnggActivitiesCreatorDto {
aging: number;
generalComments: string;
testCreatedByFirstname: string;
testCreatedByLastname: string;
testCreatedBySso: string;
testCreatorStatus: string;
testCreatorStatusId: number;
testProgressStatus: string;
floatingDays: number;
hold: boolean;
holdComments: string;
hourSpent: number;
hoursAssigned: number;
id: number;
levelTwoId: number;
levelTwo: string;
percentageCompleted: number;
preConfigId: number;
supportTeamId: number;
targetDate: number;
childEr: string;
currentStatus: string;
currentStatusId: number
}
export interface otherEnggActivitiesReviewerDto {
  generalComments: string;
  testCreatedByFirstname: string;
  testCreatedByLastname: string;
  testCreatedBySso: string;
  testCreatorStatus: string;
  testCreatorStatusId: number;
  testProgressStatus: string;
  floatingDays:  number;
  hold: true
  holdComments: string;
  id:  number;
  levelTwoId:  number;
  levelTwo: string;
  percentageCompleted:  number;
  preConfigId:  number;
  reviewedByFirstname: string;
  reviewedByLastname: string;
  reviewedBySso:  number
}


