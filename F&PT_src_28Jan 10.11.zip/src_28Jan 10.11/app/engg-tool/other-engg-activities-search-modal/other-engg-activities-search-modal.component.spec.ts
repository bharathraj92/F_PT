import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherEnggActivitiesSearchModalComponent } from './other-engg-activities-search-modal.component';

describe('OtherEnggActivitiesSearchModalComponent', () => {
  let component: OtherEnggActivitiesSearchModalComponent;
  let fixture: ComponentFixture<OtherEnggActivitiesSearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherEnggActivitiesSearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherEnggActivitiesSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
