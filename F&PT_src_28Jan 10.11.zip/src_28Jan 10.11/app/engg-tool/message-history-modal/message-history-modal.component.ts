import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
//import { EnggPreConfigReviewComponent } from './engg-pre-config-review/engg-pre-config-review.component';
import { DesignDialogData } from '../bom-design/bom-design.component';
import { BhAlertService } from 'bh-theme';
import { animate, state, style, transition, trigger } from '@angular/animations';
@Component({
  selector: 'app-message-history-modal',
  templateUrl: './message-history-modal.component.html',
  styleUrls: ['./message-history-modal.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ]
})
export class MessageHistoryModalComponent implements OnInit {

  columnsToDisplay: string[] = ['userName', 'timeStamp', 'action'];
  expandedElement: NPCInterface | null;
  msgHistoryDataSource = new MatTableDataSource<msgHistoryInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('designSearch') myDashboardTable: MatTable<msgHistoryInterface>;
  // selection = new SelectionModel<msgHistoryInterface>(true, []);
  selectedRowIndex: number;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  designSearchForm: FormGroup;
  msgHistoryData: any;
  preConfigId = sessionStorage.getItem('preConfigId');
  task;
  user;
  userId;
  field;
  constructor(public formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<MessageHistoryModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DesignDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.designSearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    this.msgHistoryDataSource.paginator = this.paginator;
    this.msgHistoryDataSource.sort = this.sort;
    this.field = this.data['fieldName'];
    this.user = this.data['user'];
    this.task = this.data['task'];
    this.getMessageHistory(this.data);
  }

  getMessageHistory(data) {
    //this.erSearchForm.enable();
    ELEMENT_DATA = [];
    const user = data['user'];
    const field = data['field'];
    const formvalue = {};
    if (data['task'] === 'NPC') {
      formvalue['preConfigId'] = data['item']['parentId'];
    }
    //External Deliverables // Start
    else if (data['task'] === 'External Deliverables' || data['task'] === 'DESIGN') {
      if (data['item']['levelThreeId']) {
        formvalue['preConfigId'] = data['item']['preConfigId'];
        formvalue['levelTwoId'] = null;
        formvalue['levelThreeId'] = data['item']['levelThreeId'];
      } else {
        formvalue['preConfigId'] = data['item']['preConfigId'];
        formvalue['levelTwoId'] = data['item']['levelTwoId'];
        formvalue['levelThreeId'] = null;
      }
    }//External Deliverables // END
    else {
      formvalue['preConfigId'] = data['item']['preConfigId'];
    }
    formvalue['task'] = data['task'];
    if (data['user'] === 'creator') {
      formvalue['creatorId'] = data['item']['id'];
      formvalue['reviewerId'] = null;
    } else {
      formvalue['creatorId'] = null;
      formvalue['reviewerId'] = data['item']['id'];
    }
    this.apiMappingsService.getMessageHistoryData(formvalue).subscribe((msgData: []) => {
      if (msgData) {
        this.msgHistoryData = msgData[user];
        let filteredHistoryData=[];
        if(this.field === 'general'){
        filteredHistoryData = this.msgHistoryData.filter(item=>item.generalComments !=null && item.generalComments != "");
        }else if(this.field === 'hold'){
          filteredHistoryData = this.msgHistoryData.filter(item=>item.holdComments !=null && item.holdComments !="");
          }
        this.prepareTableData(filteredHistoryData);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  prepareTableData(msgHistoryData) {
    ELEMENT_DATA = [];
    msgHistoryData.forEach(msgHistory => {
      ELEMENT_DATA.push({
        action: msgHistory.action,
        generalComments: msgHistory.generalComments,
        holdComments: msgHistory.holdComments,
        timeStamp: msgHistory.timeStamp,
        userName: msgHistory.userName,
        field: this.field,
      });
    });
    this.msgHistoryDataSource.data = ELEMENT_DATA;
  }
}

export interface NPCInterface {
  comment: string;
}
export interface msgHistoryInterface {
  action: string;
  generalComments: string;
  holdComments: string;
  timeStamp: Date;
  userName: string;
  field: string;
}

let ELEMENT_DATA: msgHistoryInterface[] = [];