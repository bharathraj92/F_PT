import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable  } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
//import { EnggPreConfigReviewComponent } from './engg-pre-config-review/engg-pre-config-review.component';
import { DialogData } from '../engg-pre-config-review/engg-pre-config-review.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-er-search-modal',
  templateUrl: './er-search-modal.component.html',
  styleUrls: ['./er-search-modal.component.scss']
})
export class ERSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['ERNumber'];
  dataSource = new MatTableDataSource<ERSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('erSearch') myDashboardTable: MatTable<ERSearchInterface>;
  // selection = new SelectionModel<ERSearchInterface>(true, []);
  selectedRowIndex: number;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  erSearchForm: FormGroup;
  selectedER;
  // visible = true;
  // selectable = true;
  // removable = true;
  // // roleChipsList: {}[] = [];
  // roleList: any = [];
  // productSubCategoryList: any;
  // productModelList: any
  // productTypeList: any
  // productBrandList: any;
  // productDepartmentList: any;
  // disabled: boolean = true;
  // allRoleList;
  // filteredRoleList: Observable<string[]>;
  // userDetails;
  // siteList;
  constructor(public formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<ERSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
    //private preConfigReviewService:EnggPreConfigReviewComponent
    ) {
  }
  
  ngOnInit() {
    this.erSearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineNumber: [null],
      tagNumber: [null]
    })
    //const data = Mock.svcGetERDashboardData;
    //this.prepareTableData(data['erMasterData']);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    //this.createForm();
    // this.erSearchForm.patchValue({
    //   userName: `${this.userDetails.firstName} ${this.userDetails.lastName}`,
    //   userSso: `${this.userDetails.sso}`
    // })
    // this.erSearchForm.get('role').valueChanges.subscribe(val => {
    //   this._filter(val);
    // })
  }
  // getMasterErs(data) {
  //   this.apiMappingsService.getMasterErs(data).subscribe((data: []) => {
  //     if (data) {
  //       //this.erMasterNoList = data;
  //     }
  //   });
  // }
  prepareTableData(erRequestData) {
    ELEMENT_DATA = [];
    erRequestData.forEach(erRequest => {
      ELEMENT_DATA.push({
        //erNumber: erRequest.erNumber,
        erNumber: erRequest,
      });
      // id: erRequest.id,
    });
    this.dataSource.data = ELEMENT_DATA;
  }
  // createForm() {
   
  // }
  searchMasterErs() {
    //this.erSearchForm.enable();
    let formvalue = this.erSearchForm.value;
    console.log(formvalue);
    this.apiMappingsService.getMasterErs(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        //this.erMasterNoList = data;
        //this.dataSource.data = data;
        this.prepareTableData(data);
      }else{
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectER(element){
    console.log(this.selectedER)
    this.dialogRef.close(this.selectedER);
  }
 
  onClickERNumber(value: any) {
    //this.preConfigReviewService.
    // this.commonService.saleOrderNumber.next('');
    // this.commonService.erNumber.next('');
    // if (Helpers.isLowerCaseEquals(navItem, 'SaleOrder')) {
    //   this.navRoute = 'enggTool/summaryInfo';
    //   this.commonService.saleOrderNumber.next(value);
    //   this.router.navigate([this.navRoute]);
    // } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
    //   this.navRoute = 'enggTool/preConfig';
    //   this.commonService.erNumber.next(value);
    //   this.router.navigate([this.navRoute]);
    // }
  }

}
export interface ERSearchInterface {
  // id: number;
  erNumber: string;
}
let ELEMENT_DATA: ERSearchInterface[] = [];