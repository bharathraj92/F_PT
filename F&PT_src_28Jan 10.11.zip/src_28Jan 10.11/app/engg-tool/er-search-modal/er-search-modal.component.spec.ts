import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ERSearchModalComponent } from './er-search-modal.component';

describe('ERSearchModalComponent', () => {
  let component: ERSearchModalComponent;
  let fixture: ComponentFixture<ERSearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ERSearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ERSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
