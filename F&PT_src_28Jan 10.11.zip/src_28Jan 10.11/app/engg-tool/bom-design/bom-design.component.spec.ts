import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BomDesignComponent } from './bom-design.component';

describe('BomDesignComponent', () => {
  let component: BomDesignComponent;
  let fixture: ComponentFixture<BomDesignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BomDesignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BomDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
