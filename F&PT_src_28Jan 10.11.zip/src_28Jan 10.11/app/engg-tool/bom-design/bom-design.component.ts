import { Component, OnInit, ViewChild, ChangeDetectionStrategy, ChangeDetectorRef, Inject, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
//import * as Mock from 'src/app/mock/my-workplan-mock';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as Mock from 'src/app/mock/activityTree.mock';
import { Observable, of } from 'rxjs';
import { trigger, state, style, animate, transition } from '@angular/animations';
import * as _ from 'lodash';
import { DatePipe } from '@angular/common';
import { DesignSearchModalComponent } from '../design-search-modal/design-search-modal.component';
import { MessageHistoryModalComponent } from '../message-history-modal/message-history-modal.component';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { EnggToolComponent } from '../engg-tool.component';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../util/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-bom-design',
  templateUrl: './bom-design.component.html',
  styleUrls: ['./bom-design.component.scss'],
  //Table
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  // 
})
export class BomDesignComponent implements OnInit, OnDestroy {
  bomConfigForm: FormGroup;
  allowAddDesign: boolean;
  //Accordion Steps
  step = 0;
  subSteps = 0;
  task: any;
  subTask: any;
  saveDisabled: boolean;
  designFormDisabled: boolean;
  fieldDisabled: boolean;
  datePipe = new DatePipe("en-US");
  designSearchModal: MatDialogRef<DesignSearchModalComponent>;
  //designData: any = [];
  levelOneData: any = [];
  levelTwoData: any = [];
  levelThreeData: any = [];
  levelFourData: any = [];
  levelFourFilterData: any = [];
  item: [];
  designData: any[] = [];
  designCreatorData: any[] = [];
  designReviewerData: any[] = [];
  SubComponentSelectedList: any = [];
  designCreatorId;
  profileSso;
  profileFirstName;
  profileLastName;
  supportTeamList;
  saleOrder = sessionStorage.getItem('saleOrderNumber');
  erNumber = sessionStorage.getItem('erNumber');
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  hasAdminRole = localStorage.getItem('hasAdminRole');
  //hasAdminRole = 'false';
  //NPC
  npcdisplayedColumns = ['subcomponent', 'childER', 'targetDate', 'designProgress', 'createdBy'];
  NpcDefaultDataSource;
  NpcDataSource = new NpcDataSource();
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  expandedElement: any;
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;
  @Input() disableFlag: boolean;

  @Output("loadBomConfig") loadBomConfig: EventEmitter<any> = new EventEmitter();
  @Input() count: any;
  @Output() countChanged: EventEmitter<any> = new EventEmitter();

  setStep(index: number) {
    this.subSteps = index;
  }

  setSubStep(index: number) {
    this.subSteps = index;
  }
  creatorResourceList = [];
  reviewerResourceList = [];
  filteredCreatorResourceList = [];
  filteredReviewerResourceList = [];
  // [{ ssoId: "212792986", firstName: "Krish ", lastName: "Vijay ", selected: false, admin: false },
  // { ssoId: "223019670", firstName: "Imran", lastName: "Khan", selected: false, admin: false },
  // { ssoId: "223020158", firstName: "Shakthi Sree", lastName: "-", selected: false, admin: false },
  // { ssoId: "212719618", firstName: "Isha", lastName: " Jain", selected: false, admin: false },
  // { ssoId: "212813395", firstName: "Sindhuja", lastName: "-", selected: false, admin: false }
  // ]
  // sitesList = [{ "id": 1, "supportTeam": "Jax" },
  // { "id": 2, "supportTeam": "Conde" },
  // { "id": 3, "supportTeam": "DVI" },
  // { "id": 4, "supportTeam": "Global CoE" },
  // { "id": 5, "supportTeam": "Multiple Plants" },
  // { "id": 6, "supportTeam": "Djl -Karwia" }]

  //   ngOnChanges(changes: SimpleChanges) {
  //     for (const propName in changes) {
  //       if (changes.hasOwnProperty(propName)) {
  // console.log(propName);
  //       }
  //     }
  //   }

  constructor(public formBuilder: FormBuilder,
    private http: HttpClient,
    private apiMappingsService: ApiMappingsService,
    public commonservice: CommonService,
    private bhAlertService: BhAlertService,
    private changeDetectorRef: ChangeDetectorRef,
    private enggToolComponent: EnggToolComponent,
    public dialog: MatDialog,
    @Inject(DOCUMENT) private _document: Document,
    private router: Router) {
    // this.saveDisabled = true;
    // this.designFormDisabled = false;
    // this.fieldDisabled = true;
    // //this.preConfigId = 1;
    // this.saleOrder = localStorage.getItem('saleOrderNumber');
    // this.erNumber = localStorage.getItem('erNumber');
    // this.soLiNumber = localStorage.getItem('soLiNumber');
    // this.preConfigId = localStorage.getItem('preConfigId');
    // if (this.preConfigId != null && this.preConfigId != undefined) {
    //   this.getDesignLevelOneData(this.preConfigId);
    //   this.getDesignLevelFourData(this.preConfigId);
    //   this.loadBomDesign();
    // }

  }

  ngOnInit(): void {
    // this.bomConfigForm = this.formBuilder.group({
    //   designPoint: [null, [Validators.required]],
    //   valveSupportTeam: [null, [Validators.required]],
    //   clarificationPoint: [null, [Validators.required]],
    //   isValveHold: [null, [Validators.required]],
    // })

    // this.designData = data['bomDesign']['designCreatorDtoList'];
    //this.getlevelFouritems();
    this.saveDisabled = true;
    this.designFormDisabled = false;
    this.fieldDisabled = true;
    //this.preConfigId = 1;
    this.saleOrder = sessionStorage.getItem('saleOrderNumber');
    this.erNumber = sessionStorage.getItem('erNumber');
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.task = sessionStorage.getItem('task');
    this.subTask = sessionStorage.getItem('subTask');
    // if (this.preConfigId != null && this.preConfigId != undefined) {
    //   this.getBomRelease();
    // }
    this.getLoggedInUserDetails();
    this.loadBomDesign();
    this.allowAddComponent();
  }
  //show Message History Modal popup
  showMessageHistoryModal(task, user, item, field) {
    this.enggToolComponent.showMessageHistoryModal(task, user, item, field);
  }
  allowAddComponent() {
    this.allowAddDesign = false;
    let admin = localStorage.getItem("admin");
    let roles = JSON.parse(localStorage.getItem("roles"));
    let allowRoles = [
      'Admin',
      'Tool Administrator',
      'Site Administrator',
      'Config. Engineer',
      'Design Engineer',
      'Engineer',
      'Project Leader / EPL',
      'Reviewer'] //Config. Engineer
    let role = roles.filter((obj: any) => allowRoles.includes(obj.roleName));
    // let roleess = [
    //   {"requestId":54,
    //   "roleName":"Config. Engineer",
    //   "roleId":4,
    //   "roleDesc":["Project Management"],
    //   "siteId":1,"siteName":"DVI",
    //   "requestorComments":null,
    //   "requstedBy":"Bharath Pitla (503196033)",
    //   "requestedDate":1625567989.749958000,
    //   "producTypeId":null,
    //   "producTypeName":null,
    //   "productModelId":null,
    //   "productModelName":null,
    //   "productSubCategoryId":null,
    //   "productSubCategoryName":null,
    //   "departmentId":9,
    //   "departmentName":"ER Tool",
    //   "productBrandId":1,
    //   "productBrandName":"Masoneilan",
    //   "productVariantId":null,
    //   "productVariantName":null,
    //   "productKnowledgeId":21,
    //   "productKnowledgeName":"L1",
    //   "endUserTypeId":1,
    //   "endUserTypeName":"Commercial",
    //   "enggSiteId":null,
    //   "enggSiteName":null,
    //   "activeStatus":"Approved",
    //   "workflowStatus":"Active"}
    // ]
    // let role = roleess.filter((obj: any) => allowRoles.includes(obj.roleId));
    //
    if ((role && role.length > 0) || admin === 'true') {
      this.allowAddDesign = true;
    }
  }
  loadBomDesign() {
    if (this.preConfigId != null && this.preConfigId != undefined) {
      this.getDesignLevelFourData(this.preConfigId);
      this.getDesignCreatorData(this.preConfigId);
      this.getDesignLevelOneData(this.preConfigId);
    }
  }
  addComponent(levelThreeId: any) {
    const levelThreecreator = _.filter(this.levelThreeData, { 'levelThreeId': levelThreeId });
    const levelThreeReviewer = _.filter(this.designReviewerData, { 'levelThreeId': levelThreeId });
    let creator = JSON.parse(JSON.stringify(levelThreecreator));
    let reviewer = JSON.parse(JSON.stringify(levelThreeReviewer));
    creator[0].designCreatorStatus = "NOT STARTED";
    creator[0].designCreatorStatusId = 4;
    creator[0].designProgress = "WIP";
    creator[0].designProgressId = 1;
    creator[0].id = 0;
    creator[0].childEr = null;//
    creator[0].childErNumber = null;//
    creator[0].designCurrentStatus = "WIP";//
    creator[0].floatingDays = 0; //
    creator[0].levelFour = null;
    creator[0].levelFourRefId = null;
    creator[0].levelFourRefNum = null;
    creator[0].levelFourRefTransactionId = null;
    creator[0].levelFourTransactionId = 0;
    creator[0].levelThreeComments = null;
    creator[0].levelThreeHold = false;
    creator[0].levelThreeHoldComments = null;
    creator[0].supportSite = null;
    creator[0].supportUserSsoId = null;
    creator[0].supportUserFirstName = null;
    creator[0].maunualAdd = true;

    this.resetDesignCreatorForm(creator[0]);
    Design_ELEMENT_DATA.push(creator[0]);
    // Reviewer
    reviewer[0].childEr = null;//
    reviewer[0].floatingDays = 0; //
    reviewer[0].designCreatorId = 0;
    reviewer[0].designCurrentStatus = "NOT STARTED";
    reviewer[0].designCurrentStatusId = 4;
    reviewer[0].designProgressStatus = "WIP";
    reviewer[0].designProgressStatusId = 1;
    reviewer[0].designReviewerStatus = "NOT STARTED";
    reviewer[0].designReviewerStatusId = 4;
    reviewer[0].id = 0;
    reviewer[0].levelFour = null;
    reviewer[0].levelFourId = 0;
    reviewer[0].levelFourRefId = null;
    reviewer[0].levelFourRefNum = null;
    reviewer[0].levelFourRefTransactionId = null;
    reviewer[0].levelFourTransactionId = 0;
    reviewer[0].supportSite = null;
    reviewer[0].supportUserSsoId = null;
    reviewer[0].supportUserFirstName = null;
    this.designReviewerData.push(reviewer);
    this.NpcDataSource = new NpcDataSource();
  }
  addNpc() {
    Design_ELEMENT_DATA.push({
      "id": 0,
      "geometry": null,
      "mcode": null,
      "qcode": null,
      "levelThreeId": 0,
      "levelTwoId": 0,
      "levelFourId": 0,
      "levelFour": null,
      "levelFourTransactionId": 0,
      "comments": null,
      "holdComments": null,
      "targetDate": null,
      "aging": 0,
      "hoursAssigned": 0,
      "floatingDays": 0,
      "hourSpent": 0,
      "percentageCompleted": 0,
      "designProgressId": 1,
      "designProgress": null,
      "designCreatorStatusId": 4,
      "designCreatorStatus": null,
      "designCreatedByFirstname": null,
      "supportSite": null,
      "supportUserSsoId": null,
      "supportUserFirstName": null,
      "designChecklistMaster": [],
      "hold": false
    })
    // this.NpcDataSource = new NpcDataSource();
    this.NpcDataSource = new NpcDataSource();
  }
  deleteNpc(element) {
    //Design_ELEMENT_DATA.forEach((element, index) => {
    //if (element.levelFourId === levelFourId) {
    //Design_ELEMENT_DATA.splice(index, 1);
    //}
    //});
    Design_ELEMENT_DATA.splice(element, 1);
    this.NpcDataSource = new NpcDataSource();
    //this.dataSource = new MatTableDataSource(Design_ELEMENT_DATA);
    // console.log(this.NpcDataSource);
    return true;
  }
  //Get Level One Data
  getDesignLevelOneData(preConfigId) {
    this.apiMappingsService.getDesignLevelOneData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.levelOneData = data;
      }
    });
  }
  //Get Level Four Data
  getLoggedInUserDetails() {
    this.commonservice.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [] }) => {
      this.profileFirstName = data.firstName;
      this.profileLastName = data.lastName;
      this.profileSso = data.sso;
    });
  }
  getDesignLevelFourData(preConfigId) {
    //this.http.get(this.apiMappingsService.getDesignLevelFourData(preConfigId)).subscribe((data: []) => {
    this.apiMappingsService.getDesignLevelFourData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.levelFourData = data;
        this.levelFourFilterData = this.levelFourData;
      }
    });
  }
  getDesignLevelFourDatafilter(preConfigId){
    // this.apiMappingsService.getDesignLevelFourData(preConfigId).subscribe((data: []) => {
    //   if (data) {
    //     //this.levelFourData = data;
    //     //this.levelFourFilterData = this.levelFourData;
    //     return data;
    //   }
    // });
    
  }
  //SupportTeam Level-4 
  getCreatorResourceList(element) {
    const siteId = element.supportSite;
    element.supportUserSsoId = null;
    this.filteredCreatorResourceList = this.creatorResourceList.filter(item => item.siteId === siteId);
    this.filteredCreatorResourceList = [...this.filteredCreatorResourceList];
    return this.filteredCreatorResourceList;
  }
  getReviewerResourceList(element) {
    const siteId = element.supportSite;
    element.supportUserSsoId = null;
    this.filteredReviewerResourceList = this.reviewerResourceList.filter(item => item.siteId === siteId);
    this.filteredReviewerResourceList = [...this.filteredReviewerResourceList];
    return this.filteredReviewerResourceList;
  }
  // filteredCreatorResourceList = [];
  // filteredReviewerResourceList = [];
  //Get Creator Data
  getDesignCreatorData(preConfigId) {
    this.apiMappingsService.getDesignCreatorData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.count = data;
        this.countChanged.emit(this.count);
        this.supportTeamList = data['supportTeamList'];
        this.creatorResourceList = data['supportTeamUserListCreator'];
        this.reviewerResourceList = data['supportTeamUserListReviewer'];
        this.filteredCreatorResourceList = data['supportTeamUserListCreator'];
        this.filteredReviewerResourceList = data['supportTeamUserListReviewer'];
        // this.creatorResourceList = Mock.getDesignCreator['supportTeamUserListCreator'];
        // this.reviewerResourceList = Mock.getDesignCreator['supportTeamUserListCreator'];
        // this.filteredCreatorResourceList = Mock.getDesignCreator['supportTeamUserListCreator'];
        // this.filteredCreatorResourceList = Mock.getDesignCreator['supportTeamUserListCreator'];//filteredCreatorResourceList
        this.designCreatorData = JSON.parse(JSON.stringify(data['designCreatorDtoList']));
        //this.designCreatorId = this.designCreatorData['id'];
        this.levelTwoData = _.uniqBy(this.designCreatorData, 'levelTwoId');
        this.levelThreeData = _.uniqBy(this.designCreatorData, 'levelThreeId');
        // console.log("Two" + this.levelTwoData);
        // console.log("Three" + this.levelThreeData);
        if (Design_ELEMENT_DATA.length == 0) {
          this.addNpc();
          //
          data['designCreatorDtoList'].forEach((row: any) => {
            this.onMcodeChange(row);
          });
          //
          Design_ELEMENT_DATA = data['designCreatorDtoList'];
          this.NpcDataSource = new NpcDataSource();
        }
        this.getDesignReviewerData(this.preConfigId);
      }
    });
  }
  //Get Reviewer Data
  getDesignReviewerData(preConfigId) {
    this.apiMappingsService.getDesignReviewerData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.designReviewerData = JSON.parse(JSON.stringify(data));
        // console.log(this.designReviewerData);
        Design_ELEMENT_DATA = this.designCreatorData;
        this.NpcDataSource = new NpcDataSource();
      }
    });
  }

  validate(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId')) {
      return sessionStorage.getItem('levelTwoId') == row.levelTwoId;
    }
  }


  validatelevelThree(row: any) {
    if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelThreeId')) {
      return sessionStorage.getItem('levelThreeId') == row.levelThreeId;
    } else {
      return false;
    }
  }
  onSubComponentSelect(item) {
    const selectedItem = _.filter(this.levelFourFilterData, { 'ssoId': item.supportUserSsoId });

  }
  // onSubComponentSelect(item) {
  //   this.SubComponentSelectedList.push(item.value);
  //   const myFilter = this.SubComponentSelectedList;
  //   // console.log(this.SubComponentSelectedList);
  //   if (myFilter.length) {
  //     //this.levelFourFilterData = this.levelFourData.filter((item) => item !== item);
  //     this.levelFourFilterData = this.levelFourData.filter(filter => myFilter.every(array => array !== filter.levelFourId));
  //     // console.log(this.levelFourFilterData);
  //     // const myArrayFiltered = myArray.filter(array => myFilter.some(filter => filter.userid === array.userid && filter.projectid === array.projectid));
  //   }
  // }
  chkCreatorChkList(listItem) {
    const arr = [];
    arr.push(listItem);
    //console.log(arr);

    //   const selectedOrderIds = this.form.value.orders
    //   .map((checked, i) => checked ? this.ordersData[i] : null)
    //   .filter(v => v !== null);
    // console.log(selectedOrderIds);
  }
  //saved Design Level One Data
  savedDesignLevelOne(designLevelOne) {
    this.apiMappingsService.savedDesignLevelOne(designLevelOne).subscribe((data: []) => {
      if (data) {
        // console.log(data);
        //this.designCreatorId = data['id'];
        this.bhAlertService.showAlert('success', 'top', 5000, 'Design Saved Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Design!');
      }
    });
  }
  // designValidation(item,validation){


  // }
  //save Bom Creator
  savedDesignCreator(i, item, action) {
    const supportTeam = _.filter(this.creatorResourceList, { 'ssoId': item.supportUserSsoId });
    const selectedSubComponent = _.filter(this.levelFourFilterData, { 'levelFourId': item.levelFourId });
    //this.creatorResourceList.filter(element => element.ssoId === item.ssoId)
    if (action === 'SAVE') {//Save
      //item = Design_ELEMENT_DATA;
      item['designCreatorStatus'] = 'SAVE';
      item['designCreatorStatusId'] = 1;
      item['designCreatorId'] = item['id'];
      if (supportTeam.length > 0) {
        item['supportUserFirstName'] = supportTeam[0].firstName;
      }
      if (selectedSubComponent.length > 0) {
        item['levelFour'] = selectedSubComponent[0].levelFourName;
      }
      //item['designCreatorId'] = this.designCreatorId;
      //item['levelFourRefId'] = 1; HardCode
      //item['bomChecklistCreatorTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveDesignCreator(item).subscribe((data: []) => {
        if (data) {
          // console.log(data);
          this.designCreatorId = data['id'];
          this.loadBomDesign();
          if (item.childEr != null) {
            this.saveChildReviewer(data);
          }
          //this.refreshPage();
          //Release Fix:load BomConfig after NPC Promote
          this.loadBomConfig.emit();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Design Saved Successfully!');
        } else {
          this.loadBomDesign();
          //this.refreshPage();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Design!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      // const validation = false;
      // this.designValidation(item,validation);
      if (item.levelFourId !== 0 &&
        item.geometry !== null && item.mcode !== null && item.mcode !== null &&
        item.geometry !== '' && item.mcode !== '' && item.mcode !== '' &&
        item.geometry.length === 9 && item.mcode.length === 4 && item.mcode.length === 4) {
        // if (item.percentageCompleted === 100) {
        item['designCreatorStatus'] = 'PROMOTE';
        item['designCreatorStatusId'] = 2;
        item['designCreatorId'] = item['id'];
        item['percentageCompleted'] = 100;
        if (supportTeam.length > 0) {
          item['supportUserFirstName'] = supportTeam[0].firstName;
        }
        if (selectedSubComponent.length > 0) {
          item['levelFour'] = selectedSubComponent[0].levelFourName;
        }
        //item['bomChecklistCreatorTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
        this.apiMappingsService.saveDesignCreator(item).subscribe((data: []) => {
          if (data) {
            // console.log(data);
            this.designCreatorId = data['id'];
            this.loadBomDesign();
            //this.refreshPage();
            //Release Fix:load BomConfig after NPC Promote
            this.loadBomConfig.emit();
            this.bhAlertService.showAlert('success', 'top', 5000, 'Design Promoted Successfully!');

          } else {
            this.loadBomDesign();
            //this.refreshPage();
            this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote Design!');
          }
        });
        // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
      } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Geometry should contain 9 characters and M-code/Q-code should contain 4 characters'); }
    }
    //}
    //else { this.bhAlertService.showAlert('warning', 'top', 5000, 'This field is required!!'); }
  }
  // save Bom Reviewer
  saveDesignReviewer(creator, item, action) {
    // console.log(action);
    const supportTeam = _.filter(this.reviewerResourceList, { 'ssoId': item.supportUserSsoId });
    //SAVE 
    if (action === 'SAVE') {
      item['designReviewerStatus'] = 'SAVE';
      item['designReviewerStatusId'] = 1;
      item['designCreatorId'] = creator.id;
      item['levelFourId'] = creator.levelFourId;
      item['levelFourTransactionId'] = creator.levelFourTransactionId;
      if (supportTeam.length > 0) {
        item['supportUserFirstName'] = supportTeam[0].firstName;
      }
      //item['soli'] = '115420-1000';
      //item['tagNumber'] = '1234-56';
      //item['designCurrentStatusId'] = 1;/////Test HardCode
      //item['bomChecklistReviewerTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveDesignReviewer(item).subscribe((data: []) => {
        if (data) {
          this.loadBomDesign();
          //this.refreshPage();
          //Release Fix:load BomConfig after NPC Promote
          this.loadBomConfig.emit();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!'
          );
        } else {
          this.loadBomDesign();
          //this.refreshPage();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Saved!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      // if (item.percentageCompleted === 100) {
      item['designReviewerStatus'] = 'PROMOTE';
      item['designReviewerStatusId'] = 2;
      item['designCreatorId'] = creator.id;
      item['levelFourId'] = creator.levelFourId;
      item['levelFourTransactionId'] = creator.levelFourTransactionId;
      item['percentageCompleted'] = 100;
      if (supportTeam.length > 0) {
        item['supportUserFirstName'] = supportTeam[0].firstName;
      }
      //item['bomChecklistReviewerTransaction'] = item.bomChecklistMaster.filter((listItem) => listItem.checked === true);
      this.apiMappingsService.saveDesignReviewer(item).subscribe((data: []) => {
        if (data) {
          // console.log(data);
          this.loadBomDesign();
          //this.refreshPage();
          //Release Fix:load BomConfig after NPC Promote
          this.loadBomConfig.emit();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Promoted Successfully!'
          );

        } else {
          this.loadBomDesign();
          //this.refreshPage();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote!');

        }
      });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }
    //DEMOTE
    if (action === 'DEMOTE') {
      item['designReviewerStatus'] = 'DEMOTE';
      item['designReviewerStatusId'] = 3;
      item['designCreatorId'] = creator.id;
      item['levelFourId'] = creator.levelFourId;
      item['levelFourTransactionId'] = creator.levelFourTransactionId;
      if (supportTeam.length > 0) {
        item['supportUserFirstName'] = supportTeam[0].firstName;
      }
      this.apiMappingsService.saveDesignReviewer(item).subscribe((data: []) => {
        if (data) {
          this.loadBomDesign();
          this.getDesignCreatorData(this.preConfigId);
          //this.refreshPage();
          //Release Fix:load BomConfig after NPC Promote
          this.loadBomConfig.emit();

          this.bhAlertService.showAlert('success', 'top', 5000, 'Demoted Successfully!'
          );
        } else {
          this.loadBomDesign();
          //this.refreshPage();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Demote!');
        }
      });
    }

  }

  refreshPage() {
    // let currentUrl = this.router.url;
    // this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    // this.router.onSameUrlNavigation = 'reload';
    // this.router.navigate([currentUrl]);
    // this.changeDetectorRef.detectChanges();
    // location.reload();
    // localStorage.setItem("task", "DESIGN");
  }

  resetChildEr(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.childEr = item.childErNumber = item.childEr = item.designChildComments = item.designChildRefStatus =
          item.designChildHoldComments = item.geometry = item.mcode = item.qcode = null;
        this.delinkCreator(item.id);
      }
    });
  }

  resetDesignCreatorForm(item) {
    //item.bomChecklistMaster.forEach(listItem => { listItem.checked = false; });
    item.levelFourId = item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
    item.geometry = item.mcode = item.qcode = item.geometryDesc = item.mcodeDesc = item.comments = item.holdComments = '';
    item.hold = false;
    item.designChecklistMaster.forEach(element => {
      element.value = '';
    });
  }

  resetDesignReviewerForm(item) {
    //item.bomChecklistMaster.forEach(listItem => { listItem.checked = false; });
    item.comments = '';
    item.hold = false;
    item.holdComments = '';
    item.percentageCompleted = 0;
    item.designChecklistMaster.forEach(element => {
      element.value = '';
    });
  }
  dateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');
      //console.log(result);
      return result;
    }
  }

  getDisableFlag() {
    return sessionStorage.getItem('disableBom');
  }

  ngOnDestroy() {
    //   localStorage.setItem("task", 'BOMCONFIG');
    sessionStorage.setItem('navigateFromDashboard', "false");
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "Design" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  getSubTask(levelTwo: any) {
    return this.subTask == levelTwo;
  }

  setSubTask(levelTwo: any) {
    this.subTask = levelTwo;
  }

  //Design REFERENCE Dialog Search
  //
  resetForm(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });
    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
        item.generalComments = item.holdComments = '';
        item.hold = false;
        item.childEr = item.childErNumber = item.childEr = item.designChildComments = item.designChildRefStatus = item.designChildHoldComments = null;
        item.supportSite = item.supportUserSsoId = item.supportUserFirstName = null;
        //this.delinkCreator(item.id); 
      }
    });
  }
  delinkCreator(creatorId) {
    const moduleName = 'DESIGN'
    this.apiMappingsService.delinkCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.loadBomDesign();
      } else {
        this.loadBomDesign();
      }
    });
  }
  showDesignSearchModal(element) {
    if (element.levelFourId !== null && element.levelFourId !== 0) {
      this.designSearchModal = this.dialog.open(DesignSearchModalComponent, { data: { levelFourId: element.levelFourId, creatorId: element.id } });
      this.designSearchModal.afterClosed().subscribe(value => {
        if (value) {
          const id = element.id;
          const preConfigId = element.preConfigId;
          const levelTwoId = element.levelTwoId;
          //element['npcDetails'][0]['erNpc']=value['npcNumber'];
          // this.commonservice.npcSearchData.subscribe((npcSearchData) => {
          // if (npcSearchData) {
          // console.log(npcSearchData);
          //const selectedNPC = _.filter(npcSearchData, { 'npcNumber': value['npcNumber'] });
          //if (selectedNPC.length > 0) {
          //element = selectedNPC[0];
          // element.map((key, index) => {
          //   return Object.assign(key, selectedNPC[0][index]);
          // })

          // const npcRefMappingId = value['id'];
          // const erNpc = value['npcNumber'];
          /// const result = Object.assign(element, value.designCreatorDto);
          element['id'] = id;
          element['preConfigId'] = preConfigId;
          element['levelTwoId'] = levelTwoId;
          //const result = value.designCreatorDto;
          element['childEr'] = value.designCreatorDto.id;
          //element['childErNumber'] = value.erDesignNumber;
          //element['designChildComments'] = result.comments;
          //element['designChildRefStatus'] = result.designCreatorStatus;
          //element['designChildHoldComments'] = result.holdComments;
          //element['childGeometry'] = result.geometry;
          //element['childMcode'] = result.mcode;
          //element['childQcode'] = result.qcode;
          element['designCreatorStatus'] = "NOT STARTED";
          //Editable fields
          //element['geometry'] = result.geometry;
          //element['mcode'] = result.mcode;
          //element['qcode'] = result.qcode;
          // element['npcReferenceMappingId'] = npcRefMappingId;
          // element['erNpc'] = erNpc;
          // element['soli'] = this.soLiNumber;
          // const Reviewer = value.designReviewerDto;
          // element['designReviewerStatus'] = "SAVE"
          // this.designReviewerData.push(value.designReviewerDto);
          //this.npcFormDisable = true;
          // console.log(element);
          // console.log(result);
          //}

          //element['npcDetails'][0]['erNpc']=value;
          //}
          //});
          // this.NpcDataSource = new NpcDataSource();
          //this.submitAccessRequest(value);

          //this.preConfigForm.get(element).patchValue(value);
          //this.onErMasterNoChange(value);
          this.savedDesignCreator('i', element, 'SAVE');
        }
      });
    } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select Sub-Component.!'); }
  }
  //
  saveChildReviewer(creatorData) {
    const formData = {};
    // childErPreConfigId;
    // preconfigId;
    // childErCreatorId;
    // creatorId;
    // childErLevelTwoId;
    // levelTwoId;
    // childErLevelThreeId;
    // levelThreeId;
    // childErLevelFourId;
    // levelFourId;
    // user;
    // module;
    formData['childErPreConfigId'] = creatorData.designChildPreConfigId,
      formData['childErCreatorId'] = creatorData.childEr,
      formData['childErLevelTwoId'] = creatorData.designChildLevelTwoId,
      formData['childErLevelThreeId'] = creatorData.designChildLevelThreeId,
      formData['childErLevelFourId'] = creatorData.designChildLevelFourId,
      formData['preconfigId'] = creatorData.preConfigId,
      formData['creatorId'] = creatorData.id,
      formData['levelTwoId'] = creatorData.levelTwoTransactionId,
      formData['levelThreeId'] = creatorData.levelThreeTransactionId,
      formData['levelFourId'] = creatorData.levelFourTransactionId,
      formData['module'] = 'DESIGN',
      formData['user'] = {
        'sso': this.profileSso,
        'firstName': this.profileFirstName,
        'lastName': this.profileLastName
      }
    this.apiMappingsService.saveChildReviewer(formData).subscribe((data: []) => {
      if (data) {
        this.loadBomDesign();
      } else {
        this.loadBomDesign();
      }
    });
  }
  //Support Team Level 4
  //   getResourceList(element,moduleName){
  //     // if(element.supportSite != null){
  // this.onsupportTeamSelect(element,moduleName);
  // if(moduleName == "Creator"){
  //   //this.creatorResourceList = [];
  //   list=this.creatorResourceList;
  // }else if(moduleName == "Reviewer"){
  //   //this.reviewerResourceList = [];
  //   list=this.reviewerResourceList;
  // }
  //     //}
  // return list;
  //   }
  onsupportTeamSelect(element, moduleName) {
    let preConfigId = element.preConfigId,
      siteId = element.supportSite,
      levelThreeTransactionId = element.levelThreeTransactionId
    if (siteId != null) {
      this.apiMappingsService.getSupportUserList(preConfigId, siteId, moduleName, levelThreeTransactionId).subscribe((data: []) => {
        if (data) {
          if (moduleName == "Creator") {
            this.creatorResourceList = [];
            this.creatorResourceList = data;
          } else if (moduleName == "Reviewer") {
            this.reviewerResourceList = [];
            this.reviewerResourceList = data;
          }

          //this.loadBomDesign();
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'No Resources found for the selected site.!');
        }
      });
    }
  }
  //Mcode Description Auto Populate
  onMcodeChange(element) {
    element['disableMcodeDesc'] = false;
    //element.mcodeDesc = null;
    let mCodeValue = element.mcode;
    if (mCodeValue != null && mCodeValue.length === 4) {
      this.apiMappingsService.getMcodeDesc(mCodeValue).subscribe((data) => {
        if (data && data != null) {
          if (data['mcode_flag'] === true) {
            element.mcodeDesc = data['mcodeDesc'];
            element['disableMcodeDesc'] = true;
          } else if (data['mcode_flag'] === false) {
            this.bhAlertService.showAlert('warning', 'top', 5000, 'M-code-' +element.mcode+ ' is Disabled!');
            element.mcode = null;
            element.mcodeDesc=null;
          }
        }else{
          element.mcodeDesc = null;
        }
      });
    }
  }
  //npc Combination Check
  npcCombinationCheck(element, orphanFlag) {
    if (element.geometry !=null && element.mcode !=null && element.qcode !=null) {
    if (element.geometry.length === 9 && element.mcode.length === 4 && element.qcode.length === 4) {
    this.enggToolComponent.npcCombinationCheck(element, orphanFlag);
    }
  }
  }
  //
}
//Design
export interface Design {
  id: number;
  geometry: string;
  mcode: string;
  qcode: string;
  levelTwoId: number;
  levelThreeId: number;
  levelFourId: number;
  levelFour: string;
  levelFourTransactionId: number;
  comments: string;
  holdComments: string;
  targetDate: string;
  aging: number;
  hoursAssigned: number;
  floatingDays: number;
  hourSpent: number;
  percentageCompleted: number;
  designProgressId: number;
  designProgress: string;
  designCreatorStatusId: number;
  designCreatorStatus: string;
  designCreatedByFirstname: string;
  hold: boolean;
  supportSite: string;
  supportUserSsoId: string;
  supportUserFirstName: string;
  designChecklistMaster: designChecklistMaster[]
}
export interface DesignDialogData {
  animal: string;
  name: string;
}
export interface designChecklistMaster {
  id: number;
  name: string;
  type: string;
  value: string;
}
let Design_ELEMENT_DATA: Design[] = [];
// const data = Mock.getcomplexityList;
// const Design_ELEMENT_DATA: Design[] = data['bomDesign']['design'];
export class NpcDataSource extends DataSource<any> {
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<Design[]> {
    const rows = [];
    Design_ELEMENT_DATA.forEach(element => {
      //const checklist =element.designChecklistMaster;
      rows.push(element)
    }
    );
    // console.log(rows);
    return of(rows);
  }

  disconnect() { }
}
//