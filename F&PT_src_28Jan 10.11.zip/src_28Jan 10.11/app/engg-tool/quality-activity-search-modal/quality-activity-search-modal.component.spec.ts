import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualityActivitySearchModalComponent } from './quality-activity-search-modal.component';

describe('QualityActivitySearchModalComponent', () => {
  let component: QualityActivitySearchModalComponent;
  let fixture: ComponentFixture<QualityActivitySearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualityActivitySearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualityActivitySearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
