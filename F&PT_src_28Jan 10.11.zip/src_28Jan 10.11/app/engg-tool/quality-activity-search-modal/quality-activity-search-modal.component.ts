import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatAutocomplete } from '@angular/material/autocomplete';
import { CommonService } from '../../Services/common.service';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { QualityActivityComponent } from '../quality-activity/quality-activity.component';
import { BhAlertService } from 'bh-theme';


@Component({
  selector: 'app-quality-activity-search-modal',
  templateUrl: './quality-activity-search-modal.component.html',
  styleUrls: ['./quality-activity-search-modal.component.scss']
})
export class QualityActivitySearchModalComponent implements OnInit  {

  displayedColumns: string[] = ['erNumber', 'soli','description'];
  designDataSource = new MatTableDataSource<testSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('testSearch') myDashboardTable: MatTable<testSearchInterface>;
  selectedRowIndex: number;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  qualityActivitySearchForm: FormGroup;
  selectedTest: any;
  levelTwoId: any;
  qualityActivitySearchResult: any[];
  creatorId: any;
  constructor(public formBuilder: FormBuilder,
    public testDialogRef: MatDialogRef<QualityActivitySearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: QualityActivityComponent,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.qualityActivitySearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    this.levelTwoId = this.data['levelTwoId'];
    this.creatorId = this.data['creatorId'];
    this.designDataSource.paginator = this.paginator;
    this.designDataSource.sort = this.sort;
  }

  prepareTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(designRequest => {
      ELEMENT_DATA.push({
        id: designRequest.id,
        erDesignNumber: designRequest.erDesignNumber,
        soli: designRequest.soli,
        description:designRequest.description,
        qualityActivitiesLevelTwoCreatorDto:designRequest.qualityActivitiesLevelTwoCreatorDto,
        qualityActivitiesLevelTwoReviewerDto:designRequest.qualityActivitiesLevelTwoReviewerDto,
      });
    });
    this.designDataSource.data = ELEMENT_DATA;
  }

  searchQualityActivityRef() {
    ELEMENT_DATA = [];
    let formvalue = this.qualityActivitySearchForm.value;
    formvalue['levelTwoId'] = this.levelTwoId;
    formvalue['creatorId'] = this.creatorId;
    formvalue['task'] = "Quality Activities";
    this.apiMappingsService.getReferenceQualityActivities(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.qualityActivitySearchResult = data;
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectTest(element) {
    this.testDialogRef.close(element);
  }

  onClickERNumber(value: any) {

  }

}

export interface testSearchInterface {
  id: number;
  erDesignNumber: string;
  soli: string;
  description: string;
  qualityActivitiesLevelTwoCreatorDto:qualityActivitiesLevelTwoCreatorDto[];
  qualityActivitiesLevelTwoReviewerDto:qualityActivitiesLevelTwoReviewerDto[];
}

let ELEMENT_DATA: testSearchInterface[] = [];

export interface qualityActivitiesLevelTwoCreatorDto {
aging: number;
generalComments: string;
qaCreatedByFirstname: string;
qaCreatedByLastname: string;
qaCreatedBySso: string;
qaCreatorStatus: string;
qaCreatorStatusId: number;
qaProgressStatus: string;
floatingDays: number;
hold: boolean;
holdComments: string;
hourSpent: number;
hoursAssigned: number;
id: number;
levelTwoId: number;
levelTwo: string;
percentageCompleted: number;
preConfigId: number;
supportTeamId: number;
targetDate: number;
childEr: string;
currentStatus: string;
currentStatusId: number
qaCreatorId: number
}
export interface qualityActivitiesLevelTwoReviewerDto {
  generalComments: string;
  testCreatedByFirstname: string;
  testCreatedByLastname: string;
  testCreatedBySso: string;
  testCreatorStatus: string;
  testCreatorStatusId: number;
  testProgressStatus: string;
  floatingDays:  number;
  hold: true
  holdComments: string;
  id:  number;
  levelTwoId:  number;
  levelTwo: string;
  percentageCompleted:  number;
  preConfigId:  number;
  reviewedByFirstname: string;
  reviewedByLastname: string;
  reviewedBySso:  number
}



