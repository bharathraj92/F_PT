import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalDeliverablesSearchModalComponent } from './external-deliverables-search-modal.component';

describe('ExternalDeliverablesSearchModalComponent', () => {
  let component: ExternalDeliverablesSearchModalComponent;
  let fixture: ComponentFixture<ExternalDeliverablesSearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalDeliverablesSearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalDeliverablesSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
