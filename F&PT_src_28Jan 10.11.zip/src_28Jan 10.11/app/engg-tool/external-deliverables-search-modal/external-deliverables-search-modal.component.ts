import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { DesignDialogData } from '../external-deliverables/external-deliverables.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-external-deliverables-search-modal',
  templateUrl: './external-deliverables-search-modal.component.html',
  styleUrls: ['./external-deliverables-search-modal.component.scss']
})
export class ExternalDeliverablesSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['npcNumber', 'soli', 'description'];
  designDataSource = new MatTableDataSource<externalDeliverableSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('externalDeliverableSearch') myDashboardTable: MatTable<externalDeliverableSearchInterface>;
  selectedRowIndex: number;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  externalDeliverableForm: FormGroup;
  selectedDesign: any;
  levelThreeId: any;
  levelTwoId: any;
  designSearchResult: any[];
  creatorId: any;
  constructor(public formBuilder: FormBuilder,
    public externalDeliverableDialogRef: MatDialogRef<ExternalDeliverablesSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DesignDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.externalDeliverableForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    this.levelThreeId = this.data['levelThreeId'];
    this.levelTwoId = this.data['levelTwoId'];
    this.creatorId = this.data['creatorId'];
    this.designDataSource.paginator = this.paginator;
    this.designDataSource.sort = this.sort;
  }
  prepareLevelTwoTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(levelTwo => {
      //   if(designRequest.externalCreatorDto.edLevelThreeCreator.length > 0){
      //     designRequest.externalCreatorDto.edLevelThreeCreator.forEach(levelThree => {
      //   ELEMENT_DATA.push({
      //     id: levelThree.id,
      //     erDesignNumber: levelThree.erChildNumber,
      //     soli: designRequest.soli,
      //     description: levelThree.comments,
      //     externalDeliverableCreatorDto: levelThree.externalCreatorDto,
      //     externalDeliverableReviewerDto: levelThree.externalReviewerDto,
      //   });
      // });
      // }else if(designRequest.externalCreatorDto.edLevelThreeCreator.length == 0){
      //designRequest.forEach(levelTwo => {
        ELEMENT_DATA.push({
          id: levelTwo.id,
          erDesignNumber: levelTwo.erDesignNumber,
          soli: levelTwo.soli,
          description: levelTwo.description,
          externalDeliverableCreatorDto: levelTwo.externalCreatorDto,
          externalDeliverableReviewerDto: levelTwo.externalReviewerDto,
        });
      //});
      //}
    });
    this.designDataSource.data = ELEMENT_DATA;
  }
  prepareTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(designRequest => {
      if (designRequest.externalCreatorDto.edLevelThreeCreator.length > 0) {
        designRequest.externalCreatorDto.edLevelThreeCreator.forEach(levelThree => {
          ELEMENT_DATA.push({
            id: levelThree.id,
            erDesignNumber: levelThree.erChildNumber,
            soli: designRequest.soli,
            description: levelThree.comments,
            externalDeliverableCreatorDto: levelThree.externalCreatorDto,
            externalDeliverableReviewerDto: levelThree.externalReviewerDto,
          });
        });
      } else if (designRequest.externalCreatorDto.edLevelThreeCreator.length == 0) {
        designRequest.forEach(levelTwo => {
          ELEMENT_DATA.push({
            id: levelTwo.id,
            erDesignNumber: levelTwo.erDesignNumber,
            soli: levelTwo.soli,
            description: levelTwo.description,
            externalDeliverableCreatorDto: levelTwo.externalCreatorDto,
            externalDeliverableReviewerDto: levelTwo.externalReviewerDto,
          });
        });
      }
    });
    this.designDataSource.data = ELEMENT_DATA;
  }

  searchDesignRef() {
    ELEMENT_DATA = [];
    let formvalue = this.externalDeliverableForm.value;
    if (this.levelThreeId) {
      formvalue['levelThreeId'] = this.levelThreeId;
      formvalue['creatorId'] = this.creatorId;
      formvalue['task'] = "External Deliverables";

      this.apiMappingsService.getReferenceExternalDeliverable(formvalue).subscribe((data: []) => {
        if (data && data.length > 0) {
          this.designSearchResult = data;
          this.prepareTableData(data);
        } else {
          this.bhAlertService.showAlert(
            'warning',
            'top',
            5000,
            'No data found !'
          );
        }
      });
    } else if (this.levelTwoId) {
      formvalue['levelTwoId'] = this.levelTwoId;
      formvalue['creatorId'] = this.creatorId;
      formvalue['task'] = "External Deliverables";
      this.apiMappingsService.getReferenceExternalLevelTwoDeliverable(formvalue).subscribe((data: []) => {
        if (data && data.length > 0) {
          this.designSearchResult = data;
          this.prepareLevelTwoTableData(data);
        } else {
          this.bhAlertService.showAlert(
            'warning',
            'top',
            5000,
            'No data found !'
          );
        }
      });
    }
  }

  selectDesign(element) {
    this.externalDeliverableDialogRef.close(element);
  }

}

export interface externalDeliverableSearchInterface {
  id: number;
  erDesignNumber: string;
  soli: string;
  description: string;
  externalDeliverableCreatorDto: externalDeliverableCreatorDto[];
  externalDeliverableReviewerDto: externalDeliverableReviewerDto[];
}

let ELEMENT_DATA: externalDeliverableSearchInterface[] = [];

export interface externalDeliverableCreatorDto {
  aging: number;
  comments: string;
  designChecklistMaster: designChecklistMaster[];
  designCreatedByFirstname: string;
  designCreatedByLastname: string;
  designCreatedBySso: number;
  designCreatorStatus: string;
  designCreatorStatusId: number;
  designProgress: string;
  designProgressId: number;
  floatingDays: number;
  geometry: string;
  geometryDesc: string;
  hold: boolean;
  holdComments: string;
  hourSpent: number;
  hoursAssigned: number;
  id: number;
  levelFour: string;
  levelFourId: number;
  levelFourRefId: number;
  levelFourRefNum: string;
  levelFourRefTransactionId: number;
  levelFourTransactionId: number;
  levelOneId: number;
  levelOneName: string;
  levelOneTransactionId: number;
  levelThreeComments: string;
  levelThreeHold: boolean;
  levelThreeHoldComments: string;
  levelThreeId: number;
  levelThreeName: string;
  levelThreeTransactionId: number;
  levelTwoId: number;
  levelTwoName: string;
  levelTwoTransactionId: number;
  mcode: string;
  mcodeDesc: string;
  percentageCompleted: number;
  preConfigId: number;
  qcode: string;
  soli: string;
  tagNumber: string;
  targetDate: number;
}
export interface externalDeliverableReviewerDto {
  comments: string;
  designChecklistMaster: designChecklistMaster[];
  designCreatorId: number;
  designCurrentStatus: string;
  designCurrentStatusId: number;
  designProgressStatus: string;
  designProgressStatusId: number;
  designReviewerStatus: string;
  designReviewerStatusId: number;
  floatingDays: number;
  geometry: string;
  geometryDesc: string;
  hold: true
  holdComments: string;
  id: number;
  levelFour: string;
  levelFourId: number;
  levelFourRefId: number;
  levelFourRefNum: string;
  levelFourRefTransactionId: number;
  levelFourTransactionId: number;
  levelOneId: number;
  levelOneName: string;
  levelOneTransactionId: number;
  levelThreeComments: string;
  levelThreeHold: boolean;
  levelThreeHoldComments: string;
  levelThreeId: number;
  levelThreeName: string;
  levelThreeTransactionId: number;
  levelTwoId: number;
  levelTwoName: string;
  levelTwoTransactionId: number;
  mcode: string;
  mcodeDesc: string;
  percentageCompleted: number;
  preConfigId: number;
  qcode: string;
  reviewedByFirstname: string;
  reviewedByLastname: string;
  reviewedBySso: number;
  soli: string;
  tagNumber: string;
  erDesignNumber: string;
}
export interface designChecklistMaster {
  id: number;
  name: string;
  type: string;
  value: string;
}
