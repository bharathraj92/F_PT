import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as Mock from 'src/app/mock/attachments.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { DesignDialogData } from '../external-deliverables/external-deliverables.component';
import { BhAlertService } from 'bh-theme';
import { saveAs } from "file-saver";
declare var $: any;
@Component({
  selector: 'app-view-attachments',
  templateUrl: './view-attachments.component.html',
  styleUrls: ['./view-attachments.component.scss']
})
export class ViewAttachmentsComponent implements OnInit {
  comments: any;
  fileToUpload: File = null;
  selectedAttachments: any;
  displayedColumns: string[] = ['Attachment', 'Comments', 'moduleName', 'action', 'download'];
  dataSource: any[] = [];
  preConfigId: any;
  moduleName: any;
  enableDelete: any;

  constructor(
    public viewAttachmentsDialogRef: MatDialogRef<ViewAttachmentsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DesignDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit(): void {
    this.preConfigId = sessionStorage.getItem('preConfigId');
    // this.dataSource = Mock.attachmentsData['attachmentsDto'][0]['allAttachments'];
    this.moduleName = this.data['moduleName'];
    this.getAllAttachments();
    this.getRoles();
  }

  getAllAttachments() {
    this.apiMappingsService.getAllAttachments(this.preConfigId, this.moduleName).subscribe((data: any) => {
      if (data) {
        this.dataSource = [];
        data.forEach((row: any) => {
          row.allAttachments.forEach((attachment: any) => {
            this.dataSource.push(attachment);
          });
        });
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to load Attachments!');
      }
    });
  }

  getRoles() {
    this.commonService.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [] }) => {
      if ((data.roles || []).length > 0) {
        // const admin = _.find(data.roles, ['roleName', 'Site Administrator']);
        let role = _.find(data.roles, function (obj: any) {
          if (obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' || obj.roleName == 'Approver' || obj.roleName == 'Reviewer') {
            return true;
          } else {
            return false;
          }
        });
        if (role) {
          this.enableDelete = true;
        }
      }
    });
  }

  cancel() {
    this.comments = "";
    this.fileToUpload = null;
    var file = (<HTMLInputElement>document.getElementById('file'));
    file.value = "";
  }

  uploadAttachments() {
    if (this.dataSource && this.dataSource.length >= 25) {
      this.bhAlertService.showAlert('warning', 'top', 5000, 'Only 25 Attachments are allowed to be uploaded!');
    } else {
      this.apiMappingsService.uploadAttachments(this.preConfigId, this.fileToUpload, this.comments, this.moduleName).subscribe((data: any) => {
        if (data) {
          this.getAllAttachments();
          this.cancel();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Attachments uploaded Successfully!');
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to upload Attachments!');
        }
      });
    }
  }


  handleFileInput(event: any) {
    if (event.target.files.length > 0) {
      let files = Array.from(event.target.files).filter((row: any) => (row.type != "application/pdf" && row.type != "application/vnd.ms-excel" && row.type != "image/gif" && row.type != "image/jpeg" &&
       row.type != "image/tif" && row.type != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" && row.type != ".csv"  && row.type != "application/vnd.ms-excel.sheet.macroEnabled.12" &&
       row.type != "application/vnd.openxmlformats-officedocument.wordprocessingml.document" && row.type != "application/msword"));
      if (files && files.length > 0) {
        this.fileToUpload = null;
        var file = (<HTMLInputElement>document.getElementById('file'));
        file.value = "";
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to upload Attachments as File type is not supported!');
      } else {
        this.fileToUpload = event.target.files;
      }
    }
  }

  selectAttachements(element: any) {
    this.viewAttachmentsDialogRef.close(element);
  }

  deleteAttachment(attachmentId: any) {
    this.apiMappingsService.deleteAttachments(this.preConfigId, attachmentId).subscribe((data: []) => {
      if (data) {
        this.getAllAttachments();
        this.bhAlertService.showAlert('success', 'top', 5000, 'Attachment deleted Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to delete Attachment!');
      }
    });
  }

  downloadAttachment(attachmentId: any) {
    this.apiMappingsService.downloadAttachments(this.preConfigId, attachmentId).subscribe((data: any) => {
      if (data) {
        var blob = this.base64ToBlob(data.encodedResponse, data.fileType);
        saveAs(blob, data.fileName);
        this.bhAlertService.showAlert('success', 'top', 5000, 'Attachment downloaded Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to download Attachment!');
      }
    });
  }


  download() {
    let response = Mock.downloadResponse;
    var blob = this.base64ToBlob(response.encodedResponse, response.fileType);
    saveAs(blob, response.fileName);
  }

  base64ToBlob(b64Data: any, contentType = '', sliceSize = 512) {
    b64Data = b64Data.replace(/\s/g, '');
    let byteCharacters = atob(b64Data);
    let byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      let slice = byteCharacters.slice(offset, offset + sliceSize);

      let byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      let byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    return new Blob(byteArrays, { type: contentType });
  }
}
