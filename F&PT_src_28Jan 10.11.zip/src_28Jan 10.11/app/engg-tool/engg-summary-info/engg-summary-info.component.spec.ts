import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnggSummaryInfoComponent } from './engg-summary-info.component';

describe('EnggSummaryInfoComponent', () => {
  let component: EnggSummaryInfoComponent;
  let fixture: ComponentFixture<EnggSummaryInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnggSummaryInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnggSummaryInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
