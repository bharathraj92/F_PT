import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Injectable } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { BehaviorSubject } from 'rxjs';
import { ApiMappingsService } from 'src/app/Services/api-mappings.service';
import { CommonService } from 'src/app/Services/common.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { EnggToolComponent } from '../engg-tool.component';


/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  checked: boolean;
  level: number;
}

@Component({
  selector: 'app-engg-summary-info',
  templateUrl: './engg-summary-info.component.html',
  styleUrls: ['./engg-summary-info.component.scss'],
  //tree
  //providers: [ChecklistDatabase]
})

export class EnggSummaryInfoComponent implements OnInit {

  showFiller: boolean;
  summaryInfoForm: FormGroup;
  //InfoFields
  erNumber;
  erRevisionNo;
  eplPe;
  saleOrder;
  soLiNumber;
  enggPlannedCompletionDate;
  projectManager;
  enggCompletionDate;
  sapHeader;
  sapHeaderDesc;
  noOfLineItems;
  productClass;
  customerPoNo;
  bomLt;
  manufacturingLt;
  procurementLt;
  endUserCountry;
  orderClassification;
  csrProjectManager;
  totalNoOfErItems;
  summaryData = [];
  datePipe = new DatePipe("en-US");
  showSchedulingClick: boolean;
  soliValue: any;
  defaultTreeData: any = [];
  productBrand;
  disableCloneER: boolean;
  isCloned: boolean;
  cloneFlag: any;
  isDataLoaded: boolean;

  name: any;

  private _transformer = (node: FoodNode, level: number) => {
    return {
      expandable: !!node.subLevel && node.subLevel.length > 0,
      levelName: node.levelName,
      id: node.id,
      level: level,
      //isExpanded: node.isExpanded,
      levelNo: node.levelNo,
      isChecked: node.isChecked,
      holdFlag: node.holdFlag,
      holdComments: node.holdComments,
      generalComments: node.generalComments,
      siteLevelMapping: node.siteLevelMapping,
      parentData: node.parentData,
      status: node.status,
    };
  }
  /** The selection for checklist */
  checklistSelection = new SelectionModel<ExampleFlatNode>(true /* multiple */);
  _selectedItems: any[];

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
    this._transformer, node => node.level, node => node.expandable, node => node.subLevel);

  treeDataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  /** Whether all the descendants of the node are selected */
  descendantsAllSelected(node: ExampleFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);

    return descendants.every(child => this.checklistSelection.isSelected(child));
    // ? child.isChecked = node.isChecked = true : child.isChecked = node.isChecked = false);
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: ExampleFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));

    return result && !this.descendantsAllSelected(node);

  }
  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: ExampleFlatNode): void {
    // HERE IS WHERE THE PART OF THE MODEL RELATED TO THE CLICKED CHECKBOX IS UPDATED
    this.checklistSelection.toggle(node);

    // HERE WE GET POTENTIAL subLevel OF THE CLICKED NODE
    const descendants = this.treeControl.getDescendants(node);

    // HERE IS WHERE THE REST OF THE MODEL (POTENTIAL subLevel OF THE CLICKED NODE) IS UPDATED
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);

    //Check /Uncheck nodes
    // this.checklistSelection.isSelected(node)
    //   ? node.isChecked = true : node.isChecked = false;

    this._selectedItems = this.checklistSelection.selected.map(s => s);
  }
  ////

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;
  // //tree

  expandNode() {
    //this.treeControl.expandAll();
    const tree = this.treeControl.dataNodes;
    if (tree && tree.length) {
      for (let node of tree) {
        if (node.levelNo === "One" && (node.id === 3 || node.id === 4 || node.id === 5 || node.id === 6 || node.id === 7)) {
          this.treeControl.collapse(node);
        } else {
          this.treeControl.expand(node);
          //this.treeControl.collapse(node);
        }
      }
    }
  }
  //
  ////
  constructor(
    public formBuilder: FormBuilder,
    private http: HttpClient,
    //private _database: ChecklistDatabase,
    private apiMappingsService: ApiMappingsService,
    private commonservice: CommonService,
    private enggToolComponent: EnggToolComponent,
    private route: Router
  ) {
    //this.dataSource.data = TREE_DATA;
    this.showSchedulingClick = false;
    // console.log(this.dataSource.data);
    // this.commonservice.saleOrderNumber.subscribe((data) => {
    //   this.saleOrder = data;
    // });
    ////this.name = this.route.getCurrentNavigation().extras.state.example;
   
// Start
// const saleOrderNumber = localStorage.getItem('saleOrderNumber');
// const soLiNumber = localStorage.getItem('soLiNumber');
// const cloneER = localStorage.getItem('cloneER');
// const erNumber = localStorage.getItem('erNumber');

// console.log(sessionStorage.getItem('soLiNumber'));
// console.log(sessionStorage.getItem('cloneER'));
// console.log(sessionStorage.getItem('erNumber'));

// sessionStorage.setItem("saleOrderNumber", saleOrderNumber != '' ? saleOrderNumber : this.saleOrder );
// sessionStorage.setItem("soLiNumber", soLiNumber != '' ? erNumber : this.soLiNumber);
// sessionStorage.setItem("cloneER",cloneER != '' ? cloneER : this.cloneFlag);
// sessionStorage.setItem("erNumber",erNumber != '' ? erNumber : this.erNumber);

// this.saleOrder = sessionStorage.getItem('saleOrderNumber');
// this.soLiNumber = sessionStorage.getItem('soLiNumber');
// this.cloneFlag = sessionStorage.getItem('cloneER');
// this.erNumber = sessionStorage.getItem('erNumber');

// localStorage.setItem("saleOrderNumber", '');
// localStorage.setItem("soLiNumber",'');
// localStorage.setItem("cloneER",'');
// localStorage.setItem("erNumber",'');
//END
    //localStorage.setItem('cloneER','false');
    // this.commonservice.erNumber.subscribe((data) => {
    //   this.erNumber = data;
    // });
    ///New
    this.defaultTreeData = JSON.parse(sessionStorage.getItem('activitiTreeData'));
    this.loadActivitiTree(this.defaultTreeData);
    // if (this.erNumber) {
    //   this.getERPreConfigInfo(this.erNumber);
    // } else if (this.soLiNumber) {
    //   this.getERSummaryInfo(this.soLiNumber);
    //   const defaultTreeData = JSON.parse(localStorage.getItem('activitiTreeData'));
    //   this.loadActivitiTree(defaultTreeData);
    // }
  }
  ngOnInit(): void {
    this.showFiller = false;
    this.summaryInfoForm = this.formBuilder.group({
      erRevisionNo: [null],
      eplPe: [null],
      saleOrder: [null],
      enggPlannedCompletionDate: [null],
      projectManager: [null],
      enggCompletionDate: [null],
      sapHeader: [null],
      sapHeaderDesc: [null],
      noOfLineItems: [null],
      productClass: [null],
      customerPoNo: [null],
      bomLt: [null],
      manufacturingLt: [null],
      procurementLt: [null],
      endUserCountry: [null],
      orderClassification: [null],
      csrProjectManager: [null],
      totalNoOfErItems: [null],
      productHierarchy: [null],
      productHierarchyId: [null],
      tagNumber: [null]
    })
    //this.treeControl.expandAll();
    //this.getcommonoptions();
    //New
    // if (this.soLiNumber) {
    //   this.getERSummaryInfo(this.soLiNumber);
    // } else if (this.erNumber) {
    //   this.getERPreConfigInfo(this.erNumber);
    // }
    //New Tab Start
    // this.commonservice.getERInfo().map(info => {
    //   this.soLiNumber = info;
    //   //this.erNumber = info.erNumber;
    //   console.log(this.soLiNumber);
    //   //console.log(this.erNumber );
    //     console.log(info);
    // })
//New Tab Start
    this.soLiNumber = this.enggToolComponent.soLiNumber;
    this.erNumber = this.enggToolComponent.erNumber;
    //New TAb End
    this.disableCloneER = true;
    if (this.erNumber) {
      this.getERPreConfigInfo(this.erNumber);
    } else if (this.soLiNumber) {
      this.getERSummaryInfo(this.soLiNumber);
      if (this.cloneFlag !== 'true') {
        this.disableCloneER = true;
      }
      //const defaultTreeData = JSON.parse(localStorage.getItem('activitiTreeData'));
      this.loadActivitiTree(this.defaultTreeData);
    }
    this.summaryInfoForm.disable();
    if (this.summaryInfoForm.get('projectManager').value === null) {
      this.showSchedulingClick = true;
    }
  }
  loadActivitiTree(ERTreeData) {
    if (ERTreeData != null) {
      if (ERTreeData.length > 0) {
        //this.treeData = ERTreeData['levelData'];
        const ER_TREE_DATA: FoodNode[] = ERTreeData['levelData'];
        //this.normalizeTreeNodes(ER_TREE_DATA);
        this.treeDataSource.data = ER_TREE_DATA;
        // this.treeDataSource.data = JSON.parse(JSON.stringify(ER_TREE_DATA));
        //this.tableDataSource = ER_TREE_DATA;
        this.loadSelectedNodes(ER_TREE_DATA);
      } else {
        if (ERTreeData['levelData']) {
          //this.treeData = ERTreeData['levelData'];
          const TREE_DATA: FoodNode[] = ERTreeData['levelData'];
          //this.normalizeTreeNodes(TREE_DATA);
          this.treeDataSource.data = TREE_DATA;
          // this.treeDataSource.data = JSON.parse(JSON.stringify(TREE_DATA));
          //this.tableDataSource = TREE_DATA;
          this.loadSelectedNodes(TREE_DATA);
        }
      }
      this._selectedItems = this.checklistSelection.selected.map(s => s);
    }
    this.expandNode();
  }
  loadSelectedNodes(data) {
    data.forEach((element, index) => {
      if (element.isChecked === true) {
        if (!this.checklistSelection.isSelected(element)) {
          const descendants = this.treeControl.getDescendants(element);
          this.checklistSelection.select(element);
          this.checklistSelection.select(...descendants);
          //this.checklistSelection.select(element);
          this.treeControl.expand(element);
        }
      }
      (element.subLevel || []).forEach(ChildElement => {
        ChildElement['parentData'] = element;
        if (element.subLevel && element.subLevel.length) {
          this.loadSelectedNodes(element.subLevel);
          return;
        }
      });
    });
  }
  //common options
  getcommonoptions() {
    this.apiMappingsService.getcommonoptions().subscribe((data: []) => {
      if (data) {
        this.summaryData = data;
        this.summaryInfoForm.patchValue(this.summaryData);
        this.summaryInfoForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        this.summaryInfoForm.get('enggPlannedCompletionDate').patchValue(data['enggPlannedCompletionDate'] != null ? this.datePipe.transform((data['enggPlannedCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
      }
    });
  }
  //get ER Summary Info
  getERSummaryInfo(soLiNumber) {
    this.isDataLoaded = false;
    this.apiMappingsService.getERSummaryInfo(soLiNumber).subscribe((data: []) => {
      if (data) {
        this.summaryData = data;
        this.productBrand = data['productBrand'];
        sessionStorage.setItem('soLiNumber', this.summaryData['soli']);
        this.summaryInfoForm.patchValue(this.summaryData);
        //Date format change
        this.summaryInfoForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        this.summaryInfoForm.get('enggPlannedCompletionDate').patchValue(data['enggPlannedCompletionDate'] != null ? this.datePipe.transform((data['enggPlannedCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        if (this.summaryInfoForm.get('projectManager').value === null) {
          this.showSchedulingClick = true;
        } else {
          this.showSchedulingClick = false;
        }
        this.getDefaultActivityTree(soLiNumber);
        this.isDataLoaded = true;
      }
    });

  }
  //ActivitiTree Data
  getDefaultActivityTree(soLiNumber) {
    this.apiMappingsService.getFilteredLevelDetails(soLiNumber).subscribe((data: []) => {
      if (data) {
        //this.commonService.activitiTreeData.next(data);
        //localStorage.setItem('activitiTreeData', JSON.stringify(data));
        this.defaultTreeData = data;
        this.loadActivitiTree(this.defaultTreeData);
      }
    });
  }
  //get ER Summary Info
  getERPreConfigInfo(erNumber) {
    this.showSchedulingClick = false;
    this.isDataLoaded = false;
    this.apiMappingsService.getERPreConfigInfo(erNumber).subscribe((data: []) => {
      if (data) {
        this.summaryData = data;
        this.productBrand = data['productBrand'];
        this.disableCloneER = true;
        this.isCloned = data['isCloned'];
        if (this.isCloned === false) {
          this.disableCloneER = false;
        }
        sessionStorage.setItem('soLiNumber', this.summaryData['soli']);
        this.summaryInfoForm.patchValue(this.summaryData);
        //Date format change
        //this.summaryInfoForm.get('erRequestDate').patchValue(this.datePipe.transform(data['erRequestDate'], 'dd-MMM-yyyy'));
        //Date format change
        this.summaryInfoForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        this.summaryInfoForm.get('enggPlannedCompletionDate').patchValue(data['enggPlannedCompletionDate'] != null ? this.datePipe.transform((data['enggPlannedCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
        if (this.summaryInfoForm.get('projectManager').value === null) {
          this.showSchedulingClick = true;
        } else {
          this.showSchedulingClick = false;
        }
        //Load Tree
        const ERTreeData = data['activitiTree'];
        sessionStorage.setItem('activitiTreeData', JSON.stringify(ERTreeData));
        this.loadActivitiTree(ERTreeData);
        this.isDataLoaded = true;
        ////
      }
    });
  }
  nextSummary() {
    this.route.navigate(['enggTool/preConfig']);
  }
  cloneER() {
    sessionStorage.setItem('erNumber', '');
    sessionStorage.setItem('cloneER', 'true');
    if (this.soLiNumber) {
      this.apiMappingsService.getFilteredLevelDetails(this.soLiNumber).subscribe((data: []) => {
        if (data) {
          //this.commonService.activitiTreeData.next(data);
          sessionStorage.setItem('activitiTreeData', JSON.stringify(data));
          this.defaultTreeData = data;
          this.loadActivitiTree(this.defaultTreeData);

          this.getERSummaryInfo(this.soLiNumber);
          // Clone
          this.cloneFlag = sessionStorage.getItem('cloneER');
          if (this.cloneFlag === 'true') {
            this.route.navigate(['enggTool/preConfig']);
          }
        }
      });
    }
  }
  schedulingPlanningRouting() {
    this.route.navigate(['enggTool/schedulingPlanning'], { state: { form: 'preConfig' } });
  }
}
export interface FoodNode {
  levelName: string;
  id: number;
  levelNo: string;
  subLevel?: FoodNode[];
  isChecked: boolean;
  holdFlag: boolean;
  holdComments: string;
  generalComments: string;
  siteLevelMapping: [];
  parentData: [];
  status: string;
}
let TREE_DATA: FoodNode[] = [];
/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  levelName: string;
  id: number;
  level: number;
  levelNo: string;
  isChecked: boolean;
  holdFlag: boolean;
  holdComments: string;
  generalComments: string;
  siteLevelMapping: [];
  parentData: [];
  status: string;
}