import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
//import { EnggPreConfigReviewComponent } from './engg-pre-config-review/engg-pre-config-review.component';
import { NpcDialogData } from '../engg-pre-config-review/engg-pre-config-review.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-npc-search-modal',
  templateUrl: './npc-search-modal.component.html',
  styleUrls: ['./npc-search-modal.component.scss']
})
export class NPCSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['npcNumber', 'soli', 'generalComments'];
  npcDataSource = new MatTableDataSource<NPCSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('npcSearch') myDashboardTable: MatTable<NPCSearchInterface>;
  // selection = new SelectionModel<NPCSearchInterface>(true, []);
  selectedRowIndex: number;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  npcSearchForm: FormGroup;  
  creatorId: any;
  selectedNPC;
  npcSearchResult: any[];
  constructor(public formBuilder: FormBuilder,
    public npcDialogRef: MatDialogRef<NPCSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: NpcDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.npcSearchForm = this.formBuilder.group({
      drawingNumber: [null, [Validators.required]],
      mcode: [null, [Validators.required]],
      qcode: [null, [Validators.required]]
    })
this.npcSearchForm.get('drawingNumber').patchValue(this.data['dwg']);
this.npcSearchForm.get('mcode').patchValue(this.data['mCode']);
this.npcSearchForm.get('qcode').patchValue(this.data['qCode']);
this.creatorId = this.data['creatorId'];
    this.npcDataSource.paginator = this.paginator;
    this.npcDataSource.sort = this.sort;
  }

  prepareTableData(npcRequestData) {
    ELEMENT_DATA = [];
    npcRequestData.forEach(npcRequest => {
      ELEMENT_DATA.push({
        //npcNumber: npcRequest.npcNumber,//npcRequest.erNpc
        // soli:npcRequest.soli,
        //drawingNumber: null,
        id: npcRequest.id,
        drawingNumber: npcRequest.drawingNumber,
        npcReferenceId: npcRequest.npcReferenceId,
        subLevelComponent: npcRequest.subLevelComponent,
        subLevelComponentId: npcRequest.subLevelComponentId,
        npcSubCategory: npcRequest.npcSubCategory,
        npcSubCategoryId: npcRequest.npcSubCategoryId,
        mcode: npcRequest.mcode,
        qcode: npcRequest.qcode,
        soli: npcRequest.soli,
        npcReferenceMappingId: npcRequest.id,
        npcNumber: npcRequest.npcNumber,

        makeBuy: npcRequest.makeBuy,
        erNpc: npcRequest.erNpc,
        dwgHeader: npcRequest.dwgHeader,
        mcodeDesc: npcRequest.mcodeDesc,
        qcodeDesc: npcRequest.qcodeDesc,
        generalComments: npcRequest.generalComments,
        holdFlag: npcRequest.holdFlag,
        holdComments: npcRequest.holdComments,

        // npcDetails: [{
        //   makeBuy: npcRequest.npcDetails[0].makeBuy,
        //   erNpc: npcRequest.npcNumber,
        //   dwgHeader: npcRequest.npcDetails[0].dwgHeader,
        //   mcodeDesc: npcRequest.npcDetails[0].mcodeDesc,
        //   qcodeDesc: npcRequest.npcDetails[0].qcodeDesc,
        //   generalComments: npcRequest.npcDetails[0].generalComments,
        //   holdFlag: npcRequest.npcDetails[0].holdFlag,
        //   holdComments: npcRequest.npcDetails[0].holdComments
        // }]
        });
      // id: erRequest.id,
    });
    this.npcDataSource.data = ELEMENT_DATA;
  }
  // createForm() {

  // }
  searchNpc() {
    //this.erSearchForm.enable();
    let formvalue = this.npcSearchForm.value;    
    formvalue['creatorId'] = this.creatorId;
    formvalue['task'] = "NPC";
    console.log(formvalue);
    this.apiMappingsService.getReferenceNpc(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.npcSearchResult = data;
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectNPC(element) {
    console.log(this.selectedNPC)
    this.npcDialogRef.close(element);
  }

  onClickERNumber(value: any) {
    //this.preConfigReviewService.
    // this.commonService.saleOrderNumber.next('');
    // this.commonService.erNumber.next('');
    // if (Helpers.isLowerCaseEquals(navItem, 'SaleOrder')) {
    //   this.navRoute = 'enggTool/summaryInfo';
    //   this.commonService.saleOrderNumber.next(value);
    //   this.router.navigate([this.navRoute]);
    // } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
    //   this.navRoute = 'enggTool/preConfig';
    //   this.commonService.erNumber.next(value);
    //   this.router.navigate([this.navRoute]);
    // }
  }

}
// export interface NPCSearchInterface {
//   // id: number;
//   npcNumber: string;
//   soli:string;
// }
export interface NPCSearchInterface {
   id: number;
  drawingNumber: string;
  npcReferenceId: number;
  subLevelComponent: string;
  subLevelComponentId: number;
  npcSubCategory: string;
  npcSubCategoryId: number;
  soli: string;
  mcode: string;
  qcode: string;
  npcReferenceMappingId: number;
  npcNumber: string;

  makeBuy: string;
  erNpc: string;
  dwgHeader: string;
  mcodeDesc: string;
  qcodeDesc: string;
  generalComments: string;
  holdFlag: boolean;
  holdComments: string;

  //npcDetails: NPCDetails[]
}
// export interface NPCDetails {
//   makeBuy: string;
//   erNpc: string;
//   dwgHeader: string;
//   mcodeDesc: string;
//   qcodeDesc: string;
//   generalComments: string;
//   holdFlag: boolean;
//   holdComments: string;
// }
let ELEMENT_DATA: NPCSearchInterface[] = [];