import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NPCSearchModalComponent } from './npc-search-modal.component';

describe('NPCSearchModalComponent', () => {
  let component: NPCSearchModalComponent;
  let fixture: ComponentFixture<NPCSearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NPCSearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NPCSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
