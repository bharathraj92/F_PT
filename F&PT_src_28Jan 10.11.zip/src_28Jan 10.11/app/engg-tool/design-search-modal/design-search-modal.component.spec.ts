import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignSearchModalComponent } from './design-search-modal.component';

describe('DesignSearchModalComponent', () => {
  let component: DesignSearchModalComponent;
  let fixture: ComponentFixture<DesignSearchModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesignSearchModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
