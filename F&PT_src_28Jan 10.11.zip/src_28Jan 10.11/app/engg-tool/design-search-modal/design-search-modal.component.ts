import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
//import { EnggPreConfigReviewComponent } from './engg-pre-config-review/engg-pre-config-review.component';
import { DesignDialogData } from '../bom-design/bom-design.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-design-search-modal',
  templateUrl: './design-search-modal.component.html',
  styleUrls: ['./design-search-modal.component.scss']
})
export class DesignSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['npcNumber', 'soli', 'description'];
  designDataSource = new MatTableDataSource<DesignSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('designSearch') myDashboardTable: MatTable<DesignSearchInterface>;
  // selection = new SelectionModel<DesignSearchInterface>(true, []);
  selectedRowIndex: number;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  designSearchForm: FormGroup;
  selectedDesign;
  levelFourId;
  creatorId: any;
  designSearchResult: any[];
  constructor(public formBuilder: FormBuilder,
    public designDialogRef: MatDialogRef<DesignSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DesignDialogData,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.designSearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    // this.designSearchForm.get('saleOrder').patchValue(this.data['saleOrder']);
    // this.designSearchForm.get('lineItem').patchValue(this.data['mCode']);
    // this.designSearchForm.get('erRevisionNo').patchValue(this.data['qCode']);
    this.levelFourId = this.data['levelFourId'];
    this.creatorId = this.data['creatorId'];
    this.designDataSource.paginator = this.paginator;
    this.designDataSource.sort = this.sort;
  }

  prepareTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(designRequest => {
      ELEMENT_DATA.push({
        id: designRequest.id,
        erDesignNumber: designRequest.erDesignNumber,
        soli: designRequest.soli,
        description: designRequest.description,
        //
        designCreatorDto: designRequest.designCreatorDto,
        designReviewerDto: designRequest.designReviewerDto,
        // generalComments: designRequest.generalComments,
        // geometry: designRequest.geometry,
        // geometryDesc: designRequest.geometryDesc,
        // holdComments: designRequest.holdComments,
        // isHold: designRequest.isHold,
        // levelFourRefId: designRequest.levelFourRefId,
        // levelFourRefNum: designRequest.levelFourRefNum,
        // levelFourRefTransactionId: designRequest.levelFourRefTransactionId,
        // levelFourTaskId: designRequest.levelFourTaskId,
        // levelFourTaskName: designRequest.levelFourTaskName,
        // levelThreeTaskId: designRequest.levelThreeTaskId,
        // levelThreeTaskName: designRequest.levelThreeTaskName,
        // mcode: designRequest.mcode,
        // mcodeDesc: designRequest.mcodeDesc,
        // parentErId: designRequest.parentErId,
        // qcode: designRequest.qcode
      });
      // id: erRequest.id,
    });
    this.designDataSource.data = ELEMENT_DATA;
  }
  // createForm() {

  // }
  searchDesignRef() {
    //this.erSearchForm.enable();
    ELEMENT_DATA = [];
    let formvalue = this.designSearchForm.value;
    formvalue['levelFourId'] = this.levelFourId;
    formvalue['creatorId'] = this.creatorId;
    formvalue['task'] = "DESIGN";
    console.log(formvalue);
    this.apiMappingsService.getReferenceDesign(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.designSearchResult = data;
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectDesign(element) {
    console.log(this.selectedDesign)
    this.designDialogRef.close(element);
  }

  onClickERNumber(value: any) {
    //this.preConfigReviewService.
    // this.commonService.saleOrderNumber.next('');
    // this.commonService.erNumber.next('');
    // if (Helpers.isLowerCaseEquals(navItem, 'SaleOrder')) {
    //   this.navRoute = 'enggTool/summaryInfo';
    //   this.commonService.saleOrderNumber.next(value);
    //   this.router.navigate([this.navRoute]);
    // } else if (Helpers.isLowerCaseEquals(navItem, 'ERNumber')) {
    //   this.navRoute = 'enggTool/preConfig';
    //   this.commonService.erNumber.next(value);
    //   this.router.navigate([this.navRoute]);
    // }
  }

}
// export interface DesignSearchInterface {
//   // id: number;
//   npcNumber: string;
//   soli:string;
// }
export interface DesignSearchInterface {
  id: number;
  erDesignNumber: string;
  soli: string;
  description: string;
  designCreatorDto: designCreatorDto[];
  designReviewerDto: designReviewerDto[];
}

let ELEMENT_DATA: DesignSearchInterface[] = [];

export interface designCreatorDto {
  // generalComments: string;
  // geometry: string;
  // geometryDesc: string;
  // holdComments: string;
  // isHold: null
  // levelFourRefId: number;
  // levelFourRefNum: number;
  // levelFourRefTransactionId: number;
  // levelFourTaskId: number;
  // levelFourTaskName: string;
  // levelThreeTaskId: number;
  // levelThreeTaskName: string;
  // mcode: string;
  // mcodeDesc: string;
  // parentErId: number;
  // qcode: string;

  aging: number;
  comments: string;
  designChecklistMaster: designChecklistMaster[];
  designCreatedByFirstname: string;
  designCreatedByLastname: string;
  designCreatedBySso: number;
  designCreatorStatus: string;
  designCreatorStatusId: number;
  designProgress: string;
  designProgressId: number;
  floatingDays: number;
  geometry: string;
  geometryDesc: string;
  hold: boolean;
  holdComments: string;
  hourSpent: number;
  hoursAssigned: number;
  id: number;
  levelFour: string;
  levelFourId: number;
  levelFourRefId: number;
  levelFourRefNum: string;
  levelFourRefTransactionId: number;
  levelFourTransactionId: number;
  levelOneId: number;
  levelOneName: string;
  levelOneTransactionId: number;
  levelThreeComments: string;
  levelThreeHold: boolean;
  levelThreeHoldComments: string;
  levelThreeId: number;
  levelThreeName: string;
  levelThreeTransactionId: number;
  levelTwoId: number;
  levelTwoName: string;
  levelTwoTransactionId: number;
  mcode: string;
  mcodeDesc: string;
  percentageCompleted: number;
  preConfigId: number;
  qcode: string;
  soli: string;
  tagNumber: string;
  targetDate: number;
}
export interface designReviewerDto {
  comments: string;
  designChecklistMaster: designChecklistMaster[];
  designCreatorId: number;
  designCurrentStatus: string;
  designCurrentStatusId: number;
  designProgressStatus: string;
  designProgressStatusId: number;
  designReviewerStatus: string;
  designReviewerStatusId: number;
  floatingDays: number;
  geometry: string;
  geometryDesc: string;
  hold: true
  holdComments: string;
  id: number;
  levelFour: string;
  levelFourId: number;
  levelFourRefId: number;
  levelFourRefNum: string;
  levelFourRefTransactionId: number;
  levelFourTransactionId: number;
  levelOneId: number;
  levelOneName: string;
  levelOneTransactionId: number;
  levelThreeComments: string;
  levelThreeHold: boolean;
  levelThreeHoldComments: string;
  levelThreeId: number;
  levelThreeName: string;
  levelThreeTransactionId: number;
  levelTwoId: number;
  levelTwoName: string;
  levelTwoTransactionId: number;
  mcode: string;
  mcodeDesc: string;
  percentageCompleted: number;
  preConfigId: number;
  qcode: string;
  reviewedByFirstname: string;
  reviewedByLastname: string;
  reviewedBySso: number;
  soli: string;
  tagNumber: string;
  erDesignNumber: string;
}
export interface designChecklistMaster {
  id: number;
  name: string;
  type: string;
  value: string;
}