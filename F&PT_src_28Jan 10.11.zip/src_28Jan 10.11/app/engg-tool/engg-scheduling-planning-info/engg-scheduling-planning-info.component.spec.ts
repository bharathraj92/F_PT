import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnggSchedulingPlanningInfoComponent } from './engg-scheduling-planning-info.component';

describe('EnggSchedulingPlanningInfoComponent', () => {
  let component: EnggSchedulingPlanningInfoComponent;
  let fixture: ComponentFixture<EnggSchedulingPlanningInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnggSchedulingPlanningInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnggSchedulingPlanningInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
