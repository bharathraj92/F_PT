import { Component, OnInit } from '@angular/core';
import * as Mock from 'src/app/mock/externalDeliverable.mock';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { CalculationsSearchModalComponent } from '../calculations-search-modal/calculations-search-modal.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { CommonService } from '../../Services/common.service';
import { RouterLinkWithHref } from '@angular/router';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { first } from 'lodash';
import { EnggToolComponent } from '../engg-tool.component';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../util/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-calculations',
  templateUrl: './calculations.component.html',
  styleUrls: ['./calculations.component.scss'],
  //Table
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CalculationsComponent implements OnInit {
  task: any;
  subTask: any;
  step = 0;
  creatorData: any[] = [];
  refFormDisabled: boolean = false;
  displayedColumns: string[] = ['levelName', 'generalComments', 'holdFlag', 'holdComments'];
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  level2displayedColumns = ['childER', 'targetDate', 'designProgress', 'aging', 'engineeringTeam'];
  expandedElement: any;
  fieldDisabled: boolean;
  levelThree: any;
  calculationsReviewerData: any;
  calculationsSearchModel: MatDialogRef<CalculationsSearchModalComponent>;
  levelFourFilterData: any[] = [];
  levelFourData: any[] = [];
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  leveleTwoData: any[] = [];
  profileFirstName: any;
  profileLastName: any;
  profileSso: any;
  levelOneData: any = {};
  supportTeamList: any[] = [];
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;
  constructor(
    private bhAlertService: BhAlertService,
    public dialog: MatDialog,
    private apiMappingsService: ApiMappingsService,
    private enggToolComponent: EnggToolComponent,
    public commonService: CommonService) {
    // this.dataSource = Mock.externalDeliverableData;
    // this.calculationsReviewerData = Mock.reviewerData;
    // this.leveleTwoData= this.dataSource.filter(item=>item.edLevelThreeCreator.length==0);
  }

  ngOnInit(): void {
    this.fieldDisabled = true;
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.task = sessionStorage.getItem('task');
    this.subTask = sessionStorage.getItem('subTask');
    this.getLoggedInUserDetails();
    this.loadData();
  }

  loadData() {
    if (this.preConfigId != null && this.preConfigId != undefined) {
      this.getLevelOneData(this.preConfigId);
      this.getCreatorData(this.preConfigId);
      this.getReviewerData(this.preConfigId);
    }
  }

  showMessageHistoryModal(task, user, item, field) {
    this.enggToolComponent.showMessageHistoryModal(task, user, item, field);
  }

  getLevelOneData(preConfigId: any) {
    this.apiMappingsService.getCalculationsLevelOneData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.levelOneData = data;
      }
    });
  }

  getSubTask(levelTwo: any) {
    return this.subTask == levelTwo;
  }

  setSubTask(levelTwo: any) {
    this.subTask = levelTwo;
  }

  getLoggedInUserDetails() {
    this.commonService.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [] }) => {
      this.profileFirstName = data.firstName;
      this.profileLastName = data.lastName;
      this.profileSso = data.sso;
    });
  }

  //Get Creator Data
  getCreatorData(preConfigId: any) {
    this.apiMappingsService.getCalculationsCreatorData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.leveleTwoData = data['calculationsCreatorDtoList'];
        // this.leveleTwoData = this.creatorData.filter(item => item.edLevelThreeCreator.length == 0);
        this.supportTeamList = data['supportTeamList'];
      }
    });
  }

  //Get Reviewer Data
  getReviewerData(preConfigId) {
    this.apiMappingsService.getCalculationsReviewerData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.calculationsReviewerData = data;
      }
    });
  }

  getloggeInUserSso() {
    return localStorage.getItem("loggedInUser");
  }

  setStep(index: number) {
    this.step = index;
  }

  setSubStep(index: number) {
    this.step = index;
  }

  saveReviewer(creator: any, detail: any, action: any) {
    //SAVE 
    if (action === 'SAVE') {
      detail['calculationsCreatorStatus'] = 'SAVE';
      detail['calculationsCreatorStatusId'] = 1;
      detail['calculationsCreatorId'] = creator['calculationCreatorId'];
      detail['calcChecklistReviewerTransaction'] = detail.calcChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['calculationsCreatedBySso'] = this.profileSso;
      // detail['calculationsCreatedByFirstname'] = this.profileFirstName;
      // detail['calculationsCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveCalculationsReviewerData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Saved!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      detail['calculationsCreatorStatus'] = 'PROMOTE';
      detail['calculationsCreatorStatusId'] = 2;
      detail['calculationsCreatorId'] = creator['calculationCreatorId'];
      detail['calcChecklistReviewerTransaction'] = detail.calcChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['calculationsCreatedBySso'] = this.profileSso;
      // detail['calculationsCreatedByFirstname'] = this.profileFirstName;
      // detail['calculationsCreatedByLastname'] = this.profileLastName;
      detail['percentageCompleted'] = 100;
      this.apiMappingsService.saveCalculationsReviewerData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Promoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote!');
        }
      });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }
    //DEMOTE
    if (action === 'DEMOTE') {
      detail['calculationsCreatorStatus'] = 'DEMOTE';
      detail['calculationsCreatorStatusId'] = 3;
      detail['calculationsCreatorId'] = creator['calculationCreatorId'];
      detail['calcChecklistReviewerTransaction'] = detail.calcChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['calculationsCreatedBySso'] = this.profileSso;
      // detail['calculationsCreatedByFirstname'] = this.profileFirstName;
      // detail['calculationsCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveCalculationsReviewerData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Demoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Demote!');
        }
      });
    }

  }

  resetReviewer(item: any) {
    item.calcChecklistMaster.forEach(listItem => { listItem.checked = false; });
  }

  //save Bom Creator
  saveCreator(i: any, action: any, detail: any) {
    // SAVE
    if (action === 'SAVE') {
      detail['calculationCreatorStatus'] = 'SAVE';
      detail['calculationCreatorStatusId'] = 1;
      // detail['calculationCreatedBySso'] = this.profileSso;
      // detail['calculationCreatedByFirstname'] = this.profileFirstName;
      // detail['calculationCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveCalculationsCreator(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          if (detail.childEr != null) {
            this.saveChildReviewer(data);
          }
          this.bhAlertService.showAlert('success', 'top', 5000, 'Calculations Saved Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Calculations !');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      detail['calculationCreatorStatus'] = 'PROMOTE';
      detail['calculationCreatorStatusId'] = 2;
      // detail['calculationCreatedBySso'] = this.profileSso;
      // detail['calculationCreatedByFirstname'] = this.profileFirstName;
      // detail['calculationCreatedByLastname'] = this.profileLastName;
      detail['percentageCompleted'] = 100
      this.apiMappingsService.saveCalculationsCreator(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Calculations Promoted Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote Calculations!');
        }
      });
    }

  }

  validate(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId')) {
      return sessionStorage.getItem('levelTwoId') == row.levelTwoId;
    }
  }

  ngOnDestroy() {
    // localStorage.setItem("task", 'BOMCONFIG');
    sessionStorage.setItem('navigateFromDashboard', "false");
  }

  resetCreator(item: any) {
    item.levelTwoId = item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
    item.generalComments = item.holdComments = '';
    item.hold = false;
    // item.designChecklistMaster.forEach(element => {
    // element.value = '';
    // });
  }

  deleteRow(item: any) {

  }

  resetForm(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
        item.generalComments = item.holdComments = '';
        item.hold = false;
        item.childEr = item.childErNumber = item.childEr = item.calculationChildComments = item.calculationChildRefStatus = item.calculationChildHoldComments = null;
        this.delinkCreator(item.id);
      }
    });
  }
  delinkCreator(creatorId) {
    const moduleName = 'Calculation'
    this.apiMappingsService.delinkCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.loadData();
      } else {
        this.loadData();
      }
    });
  }
  showcalculationsSearchModel(element: any) {
    if (element.levelTwoId !== null && element.levelTwoId !== 0) {
      this.calculationsSearchModel = this.dialog.open(CalculationsSearchModalComponent, { data: { levelTwoId: element.levelTwoId, creatorId: element.id } });
      this.calculationsSearchModel.afterClosed().subscribe(value => {
        if (value) {
          const id = element.id;
          const preConfigId = element.preConfigId;
          const levelTwoId = element.levelTwoId;
          //const result = Object.assign(element, value.calculationsCreatorDto);           
          element['id'] = id;
          element['preConfigId'] = preConfigId;
          element['levelTwoId'] = levelTwoId;
          // const result = value.calculationsCreatorDto;
          element['childEr'] = value.calculationsCreatorDto.id;
          //element['childErNumber'] = value.erDesignNumber;
          //element['calculationChildComments'] = result.comments;
          //element['calculationChildRefStatus'] = result.calculationCreatorStatus;
          //element['calculationChildHoldComments'] = result.holdComments;
          element['calculationCreatorStatus'] = "NOT STARTED";
          //element['calculationCreatorId'] = result.calculationCreatorId;
          //element['id'] = 0;
          //element['calculationCreatorId'] = result.id;
          // element['childEr'] = "SAVE"
          // const Reviewer = value.calculationsReviewerDto;
          // this.calculationsReviewerData = value.calculationsReviewerDto;
          this.saveCreator('i', 'SAVE', element);
        }
      });
    } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select Sub-Component.!'); }
  }
  saveChildReviewer(creatorData) {
    const formData = {};
    formData['childErPreConfigId'] = creatorData.calculationChildPreConfigId,
      formData['childErCreatorId'] = creatorData.childEr,
      formData['childErLevelTwoId'] = creatorData.calculationChildLevelTwoId,
      formData['preconfigId'] = creatorData.preConfigId,
      formData['levelTwoId'] = creatorData.levelTwoId,
      formData['creatorId'] = creatorData.id,
      formData['module'] = 'Calculation',
      formData['user'] = {
        'sso': this.profileSso,
        'firstName': this.profileFirstName,
        'lastName': this.profileLastName
      }
    this.apiMappingsService.saveChildReviewer(formData).subscribe((data: []) => {
      if (data) {
        this.loadData();
      } else {
        this.loadData();
      }
    });
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "Calculation" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  saveLevelOneData(data: any) {
    let levelOneCommentsData = {};
    levelOneCommentsData['transactionId'] = data['id'];
    levelOneCommentsData['comments'] = data['generalComments'];
    levelOneCommentsData['hasHold'] = data['isHold'];
    levelOneCommentsData['holdComments'] = data['holdComments'];
    this.apiMappingsService.savedCalculationsLevelOneData(levelOneCommentsData).subscribe((data: []) => {
      if (data) {
        this.bhAlertService.showAlert('success', 'top', 5000, 'Calculations Saved Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Calculations!');
      }
    });
  }

  convertToArray(obj: any) {
    return [obj];
  }

}
export interface DesignDialogData {
  animal: string;
  name: string;
}

