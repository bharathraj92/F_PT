import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualityActivityComponent } from './quality-activity.component';

describe('QualityActivityComponent', () => {
  let component: QualityActivityComponent;
  let fixture: ComponentFixture<QualityActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualityActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualityActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
