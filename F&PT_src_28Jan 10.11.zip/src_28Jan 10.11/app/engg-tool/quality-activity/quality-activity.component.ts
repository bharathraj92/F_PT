import { Component, OnInit } from '@angular/core';
import * as Mock from 'src/app/mock/externalDeliverable.mock';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { QualityActivitySearchModalComponent } from '../quality-activity-search-modal/quality-activity-search-modal.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { CommonService } from '../../Services/common.service';
import { RouterLinkWithHref } from '@angular/router';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { EnggToolComponent } from '../engg-tool.component';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../util/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-quality-activity',
  templateUrl: './quality-activity.component.html',
  styleUrls: ['./quality-activity.component.scss'],
  //Table
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class QualityActivityComponent implements OnInit {
  step = 0;
  task: any;
  subTask: any;
  creatorData: any[] = [];
  refFormDisabled: boolean = false;
  displayedColumns: string[] = ['levelName', 'generalComments', 'holdFlag', 'holdComments'];
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  level2displayedColumns = ['childER', 'targetDate', 'designProgress', 'aging', 'engineeringTeam'];
  expandedElement: any;
  fieldDisabled: boolean;
  levelThree: any;
  qualityActivitiesReviewerData: any;
  qualityActivitySearchModal: MatDialogRef<QualityActivitySearchModalComponent>;
  levelFourFilterData: any[] = [];
  levelFourData: any[] = [];
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  leveleTwoData: any[] = [];
  profileFirstName: any;
  profileLastName: any;
  profileSso: any;
  levelOneData: any = {};
  supportTeamList: any[] = [];
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;
  constructor(
    private bhAlertService: BhAlertService,
    public dialog: MatDialog,
    private apiMappingsService: ApiMappingsService,
    private enggToolComponent: EnggToolComponent,
    public commonService: CommonService) {
    // this.dataSource = Mock.externalDeliverableData;
    // this.qualityActivitiesReviewerData = Mock.reviewerData;
    // this.leveleTwoData= this.dataSource.filter(item=>item.edLevelThreeCreator.length==0);
  }

  ngOnInit(): void {
    this.fieldDisabled = true;
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.subTask = sessionStorage.getItem('subTask');
    this.getLoggedInUserDetails();
    this.loadData();
  }



  validate(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId')) {
      return sessionStorage.getItem('levelTwoId') == row.levelTwoId;
    }
  }

  ngOnDestroy() {
    // sessionStorage.setItem("task", 'BOMCONFIG');
    sessionStorage.setItem('navigateFromDashboard', "false");
  }


  loadData() {
    if (this.preConfigId != null && this.preConfigId != undefined) {
      this.getLevelOneData(this.preConfigId);
      this.getCreatorData(this.preConfigId);
      this.getReviewerData(this.preConfigId);
    }
  }
  //show Message History Modal popup
  showMessageHistoryModal(task, user, item, field) {
    this.enggToolComponent.showMessageHistoryModal(task, user, item, field);
  }
  getLevelOneData(preConfigId: any) {
    this.apiMappingsService.getQualityactivitiesLevelOneData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.levelOneData = data;
      }
    });
  }

  getLoggedInUserDetails() {
    this.commonService.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [] }) => {
      this.profileFirstName = data.firstName;
      this.profileLastName = data.lastName;
      this.profileSso = data.sso;
    });
  }

  //Get Creator Data
  getCreatorData(preConfigId) {
    this.apiMappingsService.getQualityActivitiesCreatorData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.leveleTwoData = data['qaCreatorDtoList'];
        this.supportTeamList = data['supportTeamList'];
      }
    });
  }

  //Get Reviewer Data
  getReviewerData(preConfigId) {
    this.apiMappingsService.getQualityActivitiesReviewerData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.qualityActivitiesReviewerData = data;
      }
    });
  }

  setStep(index: number) {
    this.step = index;
  }

  setSubStep(index: number) {
    this.step = index;
  }

  saveReviewer(creator: any, detail: any, action: any) {
    //SAVE 
    if (action === 'SAVE') {
      detail['qaCreatorStatus'] = 'SAVE';
      detail['qaCreatorStatusId'] = 1;
      detail['qaCreatorId'] = creator['qaCreatorId'];
      detail['qaChecklistReviewerTransaction'] = detail.qaChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['qaCreatedBySso']= this.profileSso;
      // detail['qaCreatedByFirstname'] = this.profileFirstName;
      // detail['qaCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveQualityActivitiesReviewer(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Saved!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      detail['qaCreatorStatus'] = 'PROMOTE';
      detail['qaCreatorStatusId'] = 2;
      detail['qaCreatorId'] = creator['qaCreatorId'];
      detail['qaChecklistReviewerTransaction'] = detail.qaChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['qaCreatedBySso']= this.profileSso;
      // detail['qaCreatedByFirstname'] = this.profileFirstName;
      // detail['qaCreatedByLastname'] = this.profileLastName;
      detail['percentageCompleted'] = 100
      this.apiMappingsService.saveQualityActivitiesReviewer(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Promoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote!');
        }
      });
    }
    //DEMOTE
    if (action === 'DEMOTE') {
      detail['qaCreatorStatus'] = 'DEMOTE';
      detail['qaCreatorStatusId'] = 3;
      detail['qaCreatorId'] = creator['qaCreatorId'];
      detail['qaChecklistReviewerTransaction'] = detail.qaChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['qaCreatedBySso']= this.profileSso;
      // detail['qaCreatedByFirstname'] = this.profileFirstName;
      // detail['qaCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveQualityActivitiesReviewer(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Demoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Demote!');
        }
      });
    }

  }

  resetReviewer(item: any) {
    item.qaChecklistMaster.forEach(listItem => { listItem.checked = false; });
  }

  getSubTask(levelTwo: any) {
    return this.subTask == levelTwo;
  }

  setSubTask(levelTwo: any) {
    this.subTask = levelTwo;
  }

  //save Bom Creator
  saveCreator(i: any, action: any, detail: any) {
    // SAVE
    if (action === 'SAVE') {
      detail['qaCreatorStatus'] = 'SAVE';
      detail['qaCreatorStatusId'] = 1;
      // detail['qaCreatedBySso']= this.profileSso;
      // detail['qaCreatedByFirstname'] = this.profileFirstName;
      // detail['qaCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveQualityActivitiesCreatorData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          if (detail.childEr != null) {
            this.saveChildReviewer(data);
          }
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Quality Activities !');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      detail['qaCreatorStatus'] = 'PROMOTE';
      detail['qaCreatorStatusId'] = 2;
      // detail['qaCreatedBySso']= this.profileSso;
      // detail['qaCreatedByFirstname'] = this.profileFirstName;
      // detail['qaCreatedByLastname'] = this.profileLastName;
      detail['percentageCompleted'] = 100;
      this.apiMappingsService.saveQualityActivitiesCreatorData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Quality Activities Promoted Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote Quality Activities!');
        }
      });
    }

  }

  resetCreator(item: any) {
    item.levelTwoId = item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
    item.generalComments = item.holdComments = '';
    item.hold = false;
    // item.designChecklistMaster.forEach(element => {
    // element.value = '';
    // });
  }

  deleteRow(item: any) {

  }

  resetForm(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
        item.generalComments = item.holdComments = '';
        item.hold = false;
        item.childEr = item.childErNumber = item.qualityChildComments = item.qualityChildHoldComments = item.qualityChildRefStatus = null;
        this.delinkCreator(item.id);
      }
    });
  }
  delinkCreator(creatorId) {
    const moduleName = 'Quality Activities'
    this.apiMappingsService.delinkCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.loadData();
      } else {
        this.loadData();
      }
    });
  }
  showQualityActivitySearchModal(element: any) {
    if (element.levelTwoId !== null && element.levelTwoId !== 0) {
      this.qualityActivitySearchModal = this.dialog.open(QualityActivitySearchModalComponent, { data: { levelTwoId: element.levelTwoId, creatorId: element.id } });
      this.qualityActivitySearchModal.afterClosed().subscribe(value => {
        if (value) {
          const id = element.id;
          const preConfigId = element.preConfigId;
          const levelTwoId = element.levelTwoId;
          element['id'] = id;
          element['preConfigId'] = preConfigId;
          element['levelTwoId'] = levelTwoId;
          //const result = value.qualityActivitiesLevelTwoCreatorDto;
          // element['id'] = null;
          element['childEr'] = value.qualityActivitiesLevelTwoCreatorDto.id;
          //element['childErNumber'] = value.erDesignNumber;
          element['qaCreatorStatus'] = "NOT STARTED";
          // this.fieldDisabled = true;
          // const Reviewer = value.qualityActivitiesLevelTwoReviewerDto;
          // element['qaCreatorStatus'] = "SAVE"
          // this.qualityActivitiesReviewerData.push(value.qualityActivitiesLevelTwoReviewerDto);
          this.saveCreator('i', 'SAVE', element);
        }
      });
    } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select Sub-Component.!'); }
  }
  saveChildReviewer(creatorData) {
    const formData = {};
    formData['childErPreConfigId'] = creatorData.qualityChildPreConfigId,
      formData['childErCreatorId'] = creatorData.childEr,
      formData['childErLevelTwoId'] = creatorData.qualityChildLevelTwoId,
      formData['preconfigId'] = creatorData.preConfigId,
      formData['levelTwoId'] = creatorData.levelTwoId,
      formData['creatorId'] = creatorData.id,
      formData['module'] = 'Quality Activities',
      formData['user'] = {
        'sso': this.profileSso,
        'firstName': this.profileFirstName,
        'lastName': this.profileLastName
      }
    this.apiMappingsService.saveChildReviewer(formData).subscribe((data: []) => {
      if (data) {
        this.loadData();
      } else {
        this.loadData();
      }
    });
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "Quality Activities" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  saveLevelOneData(data: any) {
    let levelOneCommentsData = {};
    levelOneCommentsData['transactionId'] = data['id'];
    levelOneCommentsData['comments'] = data['generalComments'];
    levelOneCommentsData['hasHold'] = data['isHold'];
    levelOneCommentsData['holdComments'] = data['holdComments'];
    this.apiMappingsService.saveQualityactivitiesLevelOneData(levelOneCommentsData).subscribe((data: []) => {
      if (data) {
        this.bhAlertService.showAlert('success', 'top', 5000, 'Quality Activity Saved Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Quality Activity!');
      }
    });
  }

  convertToArray(obj: any) {
    return [obj];
  }

}
export interface DesignDialogData {
  animal: string;
  name: string;
}



