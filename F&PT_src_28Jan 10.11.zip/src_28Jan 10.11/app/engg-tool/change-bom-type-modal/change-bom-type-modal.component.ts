import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../Services/common.service';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import * as Mock from 'src/app/mock/attachments.mock';
import * as _ from 'lodash';
import { BhAlertService } from 'bh-theme';
import { changeBomData } from '../bom-configuration/bom-configuration.component';
import { TOUCH_BUFFER_MS } from '@angular/cdk/a11y';

@Component({
  selector: 'app-change-bom-type-modal',
  templateUrl: './change-bom-type-modal.component.html',
  styleUrls: ['./change-bom-type-modal.component.scss']
})
export class ChangeBomTypeModalComponent implements OnInit {
  bomTypeList: any[]=[];
  bomType: any;
  constructor(public ChangeBomTypeModalRef: MatDialogRef<ChangeBomTypeModalComponent>,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    @Inject(MAT_DIALOG_DATA) public data: changeBomData,) { }

  ngOnInit(): void {
    this.getBomTypes();
  }

  getBomTypes() {
    this.apiMappingsService.getBomTypes().subscribe((data: []) => {
      if (data) {
        this.bomTypeList=data;
      }
    });
  }


  changeBomType(){
  let obj=  {
    "bomTypeId":this.bomType,
    "preConfigId": this.data["data"]["preConfigId"]
    }
    this.apiMappingsService.saveBomType(obj).subscribe((data: []) => {
      this.ChangeBomTypeModalRef.close()
    });
  }


}
