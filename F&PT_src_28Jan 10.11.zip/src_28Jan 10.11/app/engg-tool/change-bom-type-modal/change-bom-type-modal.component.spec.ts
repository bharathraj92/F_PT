import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeBomTypeModalComponent } from './change-bom-type-modal.component';

describe('ChangeBomTypeModalComponent', () => {
  let component: ChangeBomTypeModalComponent;
  let fixture: ComponentFixture<ChangeBomTypeModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeBomTypeModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeBomTypeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
