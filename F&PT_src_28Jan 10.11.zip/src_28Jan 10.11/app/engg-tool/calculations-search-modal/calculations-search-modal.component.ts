import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { CalculationsComponent } from '../calculations/calculations.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-calculations-search-modal',
  templateUrl: './calculations-search-modal.component.html',
  styleUrls: ['./calculations-search-modal.component.scss']
})
export class CalculationsSearchModalComponent implements OnInit {

  displayedColumns: string[] = ['npcNumber', 'soli', 'description'];
  designDataSource = new MatTableDataSource<calculationsSearchInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('testSearch') myDashboardTable: MatTable<calculationsSearchInterface>;
  selectedRowIndex: number;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  calculationsSearchForm: FormGroup;
  selectedTest: any;
  levelTwoId: any;
  creatorId: any;
  designSearchResult: any[];
  constructor(public formBuilder: FormBuilder,
    public calculationsDialogRef: MatDialogRef<CalculationsSearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CalculationsComponent,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.calculationsSearchForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    this.levelTwoId = this.data['levelTwoId'];
    this.creatorId = this.data['creatorId'];
    this.designDataSource.paginator = this.paginator;
    this.designDataSource.sort = this.sort;
  }

  prepareTableData(designRequestData) {
    ELEMENT_DATA = [];
    designRequestData.forEach(designRequest => {
      ELEMENT_DATA.push({
        id: designRequest.id,
        erDesignNumber: designRequest.erDesignNumber,
        soli: designRequest.soli,
        description: designRequest.description,
        calculationsCreatorDto: designRequest.calculationsCreatorDto,
        calculationsReviewerDto: designRequest.calculationsReviewerDto,
      });
    });
    this.designDataSource.data = ELEMENT_DATA;
  }

  searchCalculationsRef() {
    ELEMENT_DATA = [];
    let formvalue = this.calculationsSearchForm.value;
    formvalue['levelTwoId'] = this.levelTwoId;
    formvalue['creatorId'] = this.creatorId;
    // formvalue['reviewerId']= null,
    formvalue['task'] = "Calculation";
    this.apiMappingsService.getReferenceCalculationsData(formvalue).subscribe((data: []) => {
      if (data && data.length > 0) {
        this.designSearchResult = data;
        this.prepareTableData(data);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  selectTest(element: any) {
    this.calculationsDialogRef.close(element);
  }

  onClickERNumber(value: any) {

  }

}

export interface calculationsSearchInterface {
  id: number;
  erDesignNumber: string;
  soli: string;
  description: string;
  calculationsCreatorDto: CalcultionsCreatorData[];
  calculationsReviewerDto: CalcultionsReviewerData[];
}

let ELEMENT_DATA: calculationsSearchInterface[] = [];

export interface CalcultionsCreatorData {
  aging: number;
  generalComments: string;
  calculationCreatedByFirstname: string;
  calculationCreatedByLastname: string;
  calculationCreatedBySso: string;
  calculationCreatorStatus: string;
  calculationCreatorStatusId: number;
  calculationProgress: string;
  floatingDays: number;
  hold: boolean;
  holdComments: string;
  hourSpent: number;
  hoursAssigned: number;
  id: number;
  levelTwoId: number;
  levelTwo: string;
  percentageCompleted: number;
  preConfigId: number;
  supportTeamId: number;
  targetDate: number;
  childEr: string;
  currentStatus: string;
  currentStatusId: number
}
export interface CalcultionsReviewerData {
  generalComments: string;
  testCreatedByFirstname: string;
  testCreatedByLastname: string;
  testCreatedBySso: string;
  testCreatorStatus: string;
  testCreatorStatusId: number;
  testProgressStatus: string;
  floatingDays: number;
  hold: true
  holdComments: string;
  id: number;
  levelTwoId: number;
  levelTwo: string;
  percentageCompleted: number;
  preConfigId: number;
  reviewedByFirstname: string;
  reviewedByLastname: string;
  reviewedBySso: number
}


