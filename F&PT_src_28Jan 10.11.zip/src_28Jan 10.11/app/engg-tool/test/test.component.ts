import { Component, OnInit } from '@angular/core';
import * as Mock from 'src/app/mock/externalDeliverable.mock';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { TestSearchModalComponent } from '../test-search-modal/test-search-modal.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { CommonService } from '../../Services/common.service';
import { RouterLinkWithHref } from '@angular/router';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { EnggToolComponent } from '../engg-tool.component';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../util/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss'],
  //Table
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class TestComponent implements OnInit {
  step = 0;
  task: any;
  subTask: any;
  creatorData: any[] = [];
  refFormDisabled: boolean = false;
  displayedColumns: string[] = ['levelName', 'generalComments', 'holdFlag', 'holdComments'];
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  level2displayedColumns = ['childER', 'targetDate', 'designProgress', 'aging', 'engineeringTeam']
  expandedElement: any;
  fieldDisabled: boolean;
  levelThree: any;
  testReviewerData: any;
  testSearchModal: MatDialogRef<TestSearchModalComponent>;
  levelFourFilterData: any[] = [];
  levelFourData: any[] = [];
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  leveleTwoData: any[] = [];
  profileFirstName: any;
  profileLastName: any;
  profileSso: any;
  levelOneData: any = {};
  supportTeamList: any[] = [];
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;
  constructor(
    private bhAlertService: BhAlertService,
    public dialog: MatDialog,
    private apiMappingsService: ApiMappingsService,
    private enggToolComponent: EnggToolComponent,
    public commonService: CommonService) {
    // this.dataSource = Mock.externalDeliverableData;
    // this.testReviewerData = Mock.reviewerData;
    // this.leveleTwoData= this.dataSource.filter(item=>item.edLevelThreeCreator.length==0);
  }

  ngOnInit(): void {
    this.fieldDisabled = true;
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.task = sessionStorage.getItem('task');
    this.subTask = sessionStorage.getItem('subTask');
    this.getLoggedInUserDetails();
    this.loadData();
  }

  loadData() {
    if (this.preConfigId != null && this.preConfigId != undefined) {
      this.getLevelOneData(this.preConfigId);
      this.getCreatorData(this.preConfigId);
      this.getReviewerData(this.preConfigId);
    }
  }
  //show Message History Modal popup
  showMessageHistoryModal(task, user, item, field) {
    this.enggToolComponent.showMessageHistoryModal(task, user, item, field);
  }
  getLevelOneData(preConfigId: any) {
    this.apiMappingsService.getTestLevelOneData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.levelOneData = data;
      }
    });
  }

  getLoggedInUserDetails() {
    this.commonService.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [] }) => {
      this.profileFirstName = data.firstName;
      this.profileLastName = data.lastName;
      this.profileSso = data.sso;
    });
  }

  //Get Creator Data
  getCreatorData(preConfigId) {
    this.apiMappingsService.getTestCreatorData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.leveleTwoData = data['testCreatorDtoList'];
        this.supportTeamList = data['supportTeamList'];
      }
    });
  }

  //Get Reviewer Data
  getReviewerData(preConfigId) {
    this.apiMappingsService.getTestReviewerData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.testReviewerData = data;
      }
    });
  }

  getSubTask(levelTwo: any) {
    return this.subTask == levelTwo;
  }

  setSubTask(levelTwo: any) {
    this.subTask = levelTwo;
  }

  setStep(index: number) {
    this.step = index;
  }

  setSubStep(index: number) {
    this.step = index;
  }

  saveReviewer(creator: any, detail: any, action: any) {
    //SAVE 
    if (action === 'SAVE') {
      detail['testCreatorStatus'] = 'SAVE';
      detail['testCreatorStatusId'] = 1;
      detail['testCreatorId'] = creator['testCreatorId'];
      detail['testChecklistReviewerTransaction'] = detail.testChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['testCreatedBySso']= this.profileSso;
      // detail['testCreatedByFirstname'] = this.profileFirstName;
      // detail['testCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveTestReviewerData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Saved!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      // if (detail.percentageCompleted === 100) {
      detail['testCreatorStatus'] = 'PROMOTE';
      detail['testCreatorStatusId'] = 2;
      detail['testCreatorId'] = creator['testCreatorId'];
      detail['testChecklistReviewerTransaction'] = detail.testChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['testCreatedBySso']= this.profileSso;
      // detail['testCreatedByFirstname'] = this.profileFirstName;
      // detail['testCreatedByLastname'] = this.profileLastName;
      detail['percentageCompleted'] = 100;
      this.apiMappingsService.saveTestReviewerData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Promoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote!');
        }
      });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }
    //DEMOTE
    if (action === 'DEMOTE') {
      detail['testCreatorStatus'] = 'DEMOTE';
      detail['testCreatorStatusId'] = 3;
      detail['testCreatorId'] = creator['testCreatorId'];
      detail['testChecklistReviewerTransaction'] = detail.testChecklistMaster.filter((listItem) => listItem.checked === true);
      // detail['testCreatedBySso']= this.profileSso;
      // detail['testCreatedByFirstname'] = this.profileFirstName;
      // detail['testCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveTestReviewerData(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Demoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Demote!');
        }
      });
    }

  }

  resetReviewer(item: any) {
    item.testChecklistMaster.forEach(listItem => { listItem.checked = false; });
  }

  //save Test Creator
  saveTestCreator(i: any, action: any, detail: any) {
    // SAVE
    if (action === 'SAVE') {
      detail['testCreatorStatus'] = 'SAVE';
      detail['testCreatorStatusId'] = 1;
      // detail['testCreatedBySso']= this.profileSso;
      // detail['testCreatedByFirstname'] = this.profileFirstName;
      // detail['testCreatedByLastname'] = this.profileLastName;
      this.apiMappingsService.saveTestCreator(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          if(detail.childEr != null){
          this.saveChildReviewer(data);
          }
          this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      // if (detail.percentageCompleted === 100) {
      detail['testCreatorStatus'] = 'PROMOTE';
      detail['testCreatorStatusId'] = 2;
      // detail['testCreatedBySso']= this.profileSso;
      // detail['testCreatedByFirstname'] = this.profileFirstName;
      // detail['testCreatedByLastname'] = this.profileLastName;
      detail['percentageCompleted'] = 100;
      this.apiMappingsService.saveTestCreator(detail).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Test Promoted Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote Test!');
        }
      });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }

  }

  validate(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId')) {
      return sessionStorage.getItem('levelTwoId') == row.levelTwoId;
    }
  }

  ngOnDestroy() {
    // sessionStorage.setItem("task", 'BOMCONFIG');
    sessionStorage.setItem('navigateFromDashboard', "false");
  }

  resetCreator(item: any) {
    item.levelTwoId = item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
    item.generalComments = item.holdComments = '';
    item.hold = false;
  }

  deleteRow(item: any) {

  }

  resetForm(item: any) {

    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.childEr = item.childErNumber = item.childEr = item.testChildComments = item.testChildRefStatus = item.testChildHoldComments = null;
        this.delinkCreator(item.id);
        //this.delinkReviewer(reviewerId);
      }
    });
  }
  delinkCreator(creatorId) {
    const moduleName ='Tests'
    this.apiMappingsService.delinkCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.loadData();
        //this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
      } else {
        this.loadData();
        //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
      }
    });
  }
  delinkReviewer(reviewerId) {
    const moduleName ='Tests'
    this.apiMappingsService.delinkReviewer(moduleName, reviewerId).subscribe((data: []) => {
      if (data) {
        this.loadData();
        //this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
      } else {
        this.loadData();
        //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
      }
    });
  }
  showTestSearchModal(element: any) {
    if (element.levelTwoId !== null && element.levelTwoId !== 0) {
      this.testSearchModal = this.dialog.open(TestSearchModalComponent, { data: { levelTwoId: element.levelTwoId, creatorId: element.id } });
      this.testSearchModal.afterClosed().subscribe(value => {
        if (value) {
          const id = element.id;
          const preConfigId = element.preConfigId;
          const levelTwoId = element.levelTwoId;
          // const result = Object.assign(element, value.testCreatorDto);////testCreatorDto
          element['id'] = id;
          element['preConfigId'] = preConfigId;
          element['levelTwoId'] = levelTwoId;
          //const result = value.testCreatorDto;
          element['childEr'] = value.testCreatorDto.id;
          //element['childErNumber'] = value.erDesignNumber;
          //element['testChildComments'] = result.generalComments;
         // element['testChildRefStatus'] = result.testCreatorStatus;
         // element['testChildHoldComments'] = result.holdComments;
          element['testCreatorStatus'] = "NOT STARTED"
          // const Reviewer = value.testReviewerDto;
          // this.testReviewerData = value.testReviewerDto;
          this.saveTestCreator('i', 'SAVE', element);
          // this.saveChildReviewer(element, id, preConfigId, levelTwoId);
        }
      });
    } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select Sub-Component.!'); }
  }
  //Automate child ER Linking
  // saveChildReviewer(creatorData, id, preConfigId, levelTwoId) {
    saveChildReviewer(creatorData) {
    const formData = {};
    formData['childErPreConfigId'] = creatorData.testChildPreConfigId,
      formData['childErCreatorId'] = creatorData.childEr,
      formData['childErLevelTwoId'] = creatorData.testChildLevelTwo,
      formData['preconfigId'] = creatorData.preConfigId,
      formData['levelTwoId'] = creatorData.levelTwoId,
      formData['creatorId'] = creatorData.id,
      formData['module'] = 'Tests',
      formData['user'] = {
        'sso': this.profileSso,
        'firstName': this.profileFirstName,
        'lastName': this.profileLastName
      }
    this.apiMappingsService.saveChildReviewer(formData).subscribe((data: []) => {
      if (data) {
        this.loadData();
        //this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
      } else {
        this.loadData();
        //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
      }
    });
  }
  //
  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "Tests" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  savedTestLevelOneData(data: any) {
    let levelOneCommentsData = {};
    levelOneCommentsData['transactionId'] = data['id'];
    levelOneCommentsData['comments'] = data['generalComments'];
    levelOneCommentsData['hasHold'] = data['isHold'];
    levelOneCommentsData['holdComments'] = data['holdComments'];
    this.apiMappingsService.savedTestLevelOneData(levelOneCommentsData).subscribe((data: []) => {
      if (data) {
        this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test!');
      }
    });
  }

  convertToArray(obj: any) {
    return [obj];
  }

}
export interface TestDialogData {
  animal: string;
  name: string;
}


