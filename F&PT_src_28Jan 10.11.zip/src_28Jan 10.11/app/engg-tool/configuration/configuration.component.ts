import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.scss']
})
export class ConfigurationComponent implements OnInit, OnDestroy {

  constructor() {
    
   }

  ngOnInit(): void {
  }

  ngOnDestroy(){
    sessionStorage.setItem("task", 'External Deliverables');
  }

}
