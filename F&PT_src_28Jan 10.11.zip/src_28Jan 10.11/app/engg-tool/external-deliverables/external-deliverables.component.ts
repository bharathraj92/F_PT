import { Component, OnInit } from '@angular/core';
import * as Mock from 'src/app/mock/externalDeliverable.mock';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { ExternalDeliverablesSearchModalComponent } from '../external-deliverables-search-modal/external-deliverables-search-modal.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { CommonService } from '../../Services/common.service';
import { RouterLinkWithHref } from '@angular/router';
import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import * as _ from 'lodash';
import { iteratee } from 'lodash';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../util/confirm-dialog/confirm-dialog.component';
import { EnggToolComponent } from '../engg-tool.component';

@Component({
  selector: 'app-external-deliverables',
  templateUrl: './external-deliverables.component.html',
  styleUrls: ['./external-deliverables.component.scss'],
  //Table
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ExternalDeliverablesComponent implements OnInit {
  step = 0;
  task: any;
  subTask: any;
  creatorData: any[] = [];
  refFormDisabled: boolean = false;
  displayedColumns: string[] = ['levelName', 'generalComments', 'holdFlag', 'holdComments'];
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  npcdisplayedColumns = ['subcomponent', 'childER', 'aging', 'targetDate', 'designProgress'];
  level2displayedColumns = ['childER', 'targetDate', 'designProgress', 'aging', 'engineeringTeam'];
  expandedElement: any;
  fieldDisabled: boolean;
  levelThree: any;
  designReviewerData: any;
  externalDeliverableSearchModal: MatDialogRef<ExternalDeliverablesSearchModalComponent>;
  levelFourFilterData: any[] = [];
  levelFourData: any[] = [];
  soLiNumber = sessionStorage.getItem('soLiNumber');
  preConfigId = sessionStorage.getItem('preConfigId');
  leveleTwoData: any[] = [];
  profileFirstName: any;
  profileLastName: any;
  profileSso: any;
  levelOneData: any = {};
  supportTeamList: any[] = [];
  viewAttachmentsModal: MatDialogRef<ViewAttachmentsComponent>;


  constructor(
    private bhAlertService: BhAlertService,
    public dialog: MatDialog,
    private apiMappingsService: ApiMappingsService,
    private enggToolComponent: EnggToolComponent,
    public commonService: CommonService) {
    // this.dataSource = Mock.externalDeliverableData;
    // this.designReviewerData = Mock.reviewerData;
    // this.leveleTwoData= this.dataSource.filter(item=>item.edLevelThreeCreator.length==0);
  }

  ngOnInit(): void {
    this.fieldDisabled = true;
    this.soLiNumber = sessionStorage.getItem('soLiNumber');
    this.preConfigId = sessionStorage.getItem('preConfigId');
    this.task = sessionStorage.getItem('task');
    this.subTask = sessionStorage.getItem('subTask');
    this.getLoggedInUserDetails();
    this.loadData();
  }

  //show Message History Modal popup
  showMessageHistoryModalLevel2(task, user, item, details, field) {
    details['preConfigId'] = item.preConfigId;
    this.enggToolComponent.showMessageHistoryModal(task, user, details, field);
  }

  showMessageHistoryModal(task, user, item, field) {
    this.enggToolComponent.showMessageHistoryModal(task, user, item, field);
  }

  loadData() {
    if (this.preConfigId != null && this.preConfigId != undefined) {
      this.getLevelOneData(this.preConfigId);
      this.getCreatorData(this.preConfigId);
      this.getReviewerData(this.preConfigId);
    }
  }

  getSubTaskforLevelThree(levelTwo: any, levelThreeArray?: any) {
    if (levelThreeArray) {
      let levelThree = levelThreeArray.filter((item: any) => item.levelThree == this.subTask);
      if (levelThree && levelThree.length > 0) {
        return true;
      } else {
        return this.subTask == levelTwo;
      }
    }

  }

  getSubTask(levelTwo: any, levelThreeArray?: any) {
    return this.subTask == levelTwo;
  }

  setSubTask(levelTwo: any) {
    this.subTask = levelTwo;
  }

  getLevelOneData(preConfigId: any) {
    this.apiMappingsService.getExternalDeliverableLevelOneData(preConfigId).subscribe((data: any) => {
      if (data) {
        this.levelOneData = data;
      }
    });
  }

  getLoggedInUserDetails() {
    this.commonService.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [] }) => {
      this.profileFirstName = data.firstName;
      this.profileLastName = data.lastName;
      this.profileSso = data.sso;
    });
  }

  //Get Creator Data
  getCreatorData(preConfigId) {
    this.apiMappingsService.getCreatorData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.creatorData = data['externalCreatorDtoList'];
        this.leveleTwoData = this.creatorData.filter(item => item.edLevelThreeCreator.length == 0);
        this.supportTeamList = data['supportTeamList'];
      }
    });
  }

  //Get Reviewer Data
  getReviewerData(preConfigId) {
    this.apiMappingsService.getReviewerData(preConfigId).subscribe((data: []) => {
      if (data) {
        this.designReviewerData = data;
      }
    });
  }

  setStep(index: number) {
    this.step = index;
  }

  setSubStep(index: number) {
    this.step = index;
  }

  saveReviewer(creator: any, detail: any, action: any, levelTwoCreator: any, flag: any, item?: any) {
    //SAVE 
    if (action === 'SAVE') {
      if (flag == 1) {
        detail['status'] = 'SAVE';
        detail['statusId'] = 1;
        item['edCreatorId'] = levelTwoCreator.id;
        // item['edReviewedBySso'] = this.profileSso;
        // item['edReviewedByFirstname'] = this.profileFirstName;
        // item['edReviewedByLastname'] = this.profileLastName;
        // item.edLevelThreeReviewer.forEach((row: any) => {
        //   row['edReviewedBySso'] = this.profileSso;
        //   row['edReviewedByFirstname'] = this.profileFirstName;
        //   row['edReviewedByLastname'] = this.profileLastName;
        // });
      } else {
        item['edReviewerStatus'] = 'SAVE';
        item['edReviewerStatusId'] = 1;
        item['edCreatorId'] = creator.id;
        if (detail.edChecklistMaster) {
          detail['edChecklistLeveltwoReviewerTransaction'] = detail.edChecklistMaster.filter((listItem) => listItem.checked === true);
        }
        // item['edReviewedBySso'] = this.profileSso;
        // item['edReviewedByFirstname'] = this.profileFirstName;
        // item['edReviewedByLastname'] = this.profileLastName;
      }
      this.apiMappingsService.saveReviewer(item).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Saved!');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      if (flag == 1) {
        detail['status'] = 'PROMOTE';
        detail['statusId'] = 2;
        item['edCreatorId'] = levelTwoCreator.id;
        // item['edReviewedBySso'] = this.profileSso;
        // item['edReviewedByFirstname'] = this.profileFirstName;
        // item['edReviewedByLastname'] = this.profileLastName;
        detail['percentageCompleted'] = 100;
        // item.edLevelThreeReviewer.forEach((row: any) => {
        //   row['edReviewedBySso'] = this.profileSso;
        //   row['edReviewedByFirstname'] = this.profileFirstName;
        //   row['edReviewedByLastname'] = this.profileLastName;
        // });
      } else {
        item['edReviewerStatus'] = 'PROMOTE';
        item['edReviewerStatusId'] = 2;
        item['edCreatorId'] = creator.id;
        detail['edChecklistLeveltwoReviewerTransaction'] = detail.edChecklistMaster.filter((listItem) => listItem.checked === true);
        // item['edReviewedBySso'] = this.profileSso;
        // item['edReviewedByFirstname'] = this.profileFirstName;
        // item['edReviewedByLastname'] = this.profileLastName;
        item['percentageCompleted'] = 100;
      }
      this.apiMappingsService.saveReviewer(item).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Promoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote!');
        }
      });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }
    //DEMOTE
    if (action === 'DEMOTE') {

      if (flag == 1) {
        detail['status'] = 'DEMOTE';
        detail['statusId'] = 3;
        item['edCreatorId'] = levelTwoCreator.id;
        // item['edReviewedBySso'] = this.profileSso;
        // item['edReviewedByFirstname'] = this.profileFirstName;
        // item['edReviewedByLastname'] = this.profileLastName;
        // item.edLevelThreeReviewer.forEach((row: any) => {
        //   row['edReviewedBySso'] = this.profileSso;
        //   row['edReviewedByFirstname'] = this.profileFirstName;
        //   row['edReviewedByLastname'] = this.profileLastName;
        // });
      } else {
        item['edReviewerStatus'] = 'DEMOTE';
        item['edReviewerStatusId'] = 3;
        item['edCreatorId'] = creator.id;
        detail['edChecklistLeveltwoReviewerTransaction'] = detail.edChecklistMaster.filter((listItem) => listItem.checked === true);
        // item['edReviewedBySso'] = this.profileSso;
        // item['edReviewedByFirstname'] = this.profileFirstName;
        // item['edReviewedByLastname'] = this.profileLastName;
      }
      this.apiMappingsService.saveReviewer(item).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'Demoted Successfully!'
          );
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Demote!');
        }
      });
    }

  }

  resetReviewer(item: any) {
    item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
    item.generalComments = item.holdComments = '';
    item.hold = false;
  }

  enableTask() {
    if ((this.task != 'Calculation' && this.task != 'Tests' && this.task != 'Other Engg Activities') || this.task == '' || this.task == 'External Deliverables') {
      return true;
    } else {
      return false;
    }
  }

  //save Bom Creator
  saveCreator(i: any, item: any, action: any, detail: any, flag: any) {
    // SAVE
    if (action === 'SAVE') {
      if (flag == 1) {
        detail['status'] = 'SAVE';
        detail['statusId'] = 1;
        // item['edCreatedBySso'] = this.profileSso;
        // item['edCreatedByFirstname'] = this.profileFirstName;
        // item['edCreatedByLastname'] = this.profileLastName;
        // item.edLevelThreeCreator.forEach((row: any) => {
        //   row['edCreatedBySso'] = this.profileSso;
        //   row['edCreatedByFirstname'] = this.profileFirstName;
        //   row['edCreatedByLastname'] = this.profileLastName;
        // });
      } else {
        item['edCreatorStatus'] = 'SAVE';
        item['edCreatorStatusId'] = 1;
        // item['edCreatedBySso'] = this.profileSso;
        // item['edCreatedByFirstname'] = this.profileFirstName;
        // item['edCreatedByLastname'] = this.profileLastName;
      }
      this.apiMappingsService.saveCreator(item).subscribe((data: []) => {
        if (data) {
          this.loadData();
          if (item.childEr != null) {
            this.saveChildReviewer(data);
          }
          this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save External Deliverable !');
        }
      });
    }
    //PROMOTE
    if (action === 'PROMOTE') {
      if (flag == 1) {
        detail['status'] = 'PROMOTE';
        detail['statusId'] = 2;
        // item['edCreatedBySso'] = this.profileSso;
        // item['edCreatedByFirstname'] = this.profileFirstName;
        // item['edCreatedByLastname'] = this.profileLastName;
        detail['percentageCompleted'] = 100;
        // item.edLevelThreeCreator.forEach((row: any) => {
        //   row['edCreatedBySso'] = this.profileSso;
        //   row['edCreatedByFirstname'] = this.profileFirstName;
        //   row['edCreatedByLastname'] = this.profileLastName;
        // });
      } else {
        item['edCreatorStatus'] = 'PROMOTE';
        item['edCreatorStatusId'] = 2;
        // item['edCreatedBySso'] = this.profileSso;
        // item['edCreatedByFirstname'] = this.profileFirstName;
        // item['edCreatedByLastname'] = this.profileLastName;
        item['percentageCompleted'] = 100;
      }
      this.apiMappingsService.saveCreator(item).subscribe((data: []) => {
        if (data) {
          this.loadData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'External Deliverable Promoted Successfully!');
        } else {
          this.loadData();
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Promote External Deliverable!');
        }
      });
      // } else { this.bhAlertService.showAlert('warning', 'top', 5000, 'Completion precentage should be 100%'); }
    }

  }

  resetCreator(item: any) {
    item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
    item.generalComments = item.holdComments = '';
    item.hold = false;
    // item.designChecklistMaster.forEach(element => {
    // element.value = '';
    // });
  }

  deleteRow(item: any) {

  }

  validate(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelTwoId')) {
      return sessionStorage.getItem('levelTwoId') == row.levelTwoId;
    }
  }

  validateLevelThree(row: any, expandedElement: any) {
    if (expandedElement) {
      return row == expandedElement;
    } else if (sessionStorage.getItem('navigateFromDashboard') == "true" && sessionStorage.getItem('levelThreeId')) {
      return sessionStorage.getItem('levelThreeId') == row.levelThreeId;
    }
  }

  ngOnDestroy() {
    // sessionStorage.setItem("task", 'BOMCONFIG');
    sessionStorage.setItem('navigateFromDashboard', "false");
  }

  resetlevelThreeForm(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
        item.generalComments = item.holdComments = '';
        item.hold = false;
        item.childEr = item.childErNumber = item.externalLevelThreeChildComments = item.externalLevelThreeChildHoldComments = item.externalLevelThreeChildRefStatus = null;
        this.delinklevelThreeCreator(item.id);
      }
    });
  }

  resetlevelTwoForm(item: any) {
    const message = `Are you sure you want to Delink: ` + item.childErNumber + ` ?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult === true) {
        item.hoursAssigned = item.hourSpent = item.percentageCompleted = 0;
        item.generalComments = item.holdComments = '';
        item.hold = false;
        item.childEr = item.childErNumber = item.externalLevelTwoChildComments = item.externalLevelTwoChildHoldComments = item.externalLevelTwoChildRefStatus = null;
        this.delinklevelTwoCreator(item.id);
      }
    });

  }
  delinklevelTwoCreator(creatorId) {
    const moduleName = 'External Deliverables'
    this.apiMappingsService.delinklevelTwoCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.loadData();
        //this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
      } else {
        this.loadData();
        //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
      }
    });
  }
  delinklevelThreeCreator(creatorId) {
    const moduleName = 'External Deliverables'
    this.apiMappingsService.delinklevelThreeCreator(moduleName, creatorId).subscribe((data: []) => {
      if (data) {
        this.loadData();
        //this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!');
      } else {
        this.loadData();
        //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save !');
      }
    });
  }
  showexternalDeliverableSearchModal(item: any, element: any) {
    if (element.levelThreeId !== null && element.levelThreeId !== 0) {
      this.externalDeliverableSearchModal = this.dialog.open(ExternalDeliverablesSearchModalComponent, { data: { levelThreeId: element.levelThreeId, creatorId: element.id } });
      this.externalDeliverableSearchModal.afterClosed().subscribe(value => {
        if (value) {
          const result = value.externalDeliverableCreatorDto;
          element['childEr'] = value.id;
          const id = element.id;
          const preConfigId = element.preConfigId;
          const levelThreeId = element.levelThreeId;
          element['id'] = id;
          element['preConfigId'] = preConfigId;
          element['levelThreeId'] = levelThreeId;
          // element['childErNumber'] = value.erDesignNumber;
          // element['externalLevelThreeChildComments'] = result.comments;
          // element['externalLevelThreeChildRefStatus'] = result.status;
          // element['externalLevelThreeChildHoldComments'] = result.holdComments;
          element['status'] = "NOT STARTED";
          this.saveCreator('i', item, 'SAVE', element, 1);
        }
      });
    }
  }

  viewAttachments() {
    this.viewAttachmentsModal = this.dialog.open(ViewAttachmentsComponent, { data: { moduleName: "External Deliverables" } });
    this.viewAttachmentsModal.afterClosed().subscribe(value => {
    });
  }

  showexternalDeliverableLevelTwoSearchModal(item: any, element: any) {
    if (element.levelTwoId !== null && element.levelTwoId !== 0) {
      this.externalDeliverableSearchModal = this.dialog.open(ExternalDeliverablesSearchModalComponent, { data: { levelTwoId: element.levelTwoId, creatorId: element.id } });
      this.externalDeliverableSearchModal.afterClosed().subscribe(value => {
        if (value) {
          const id = element.id;
          const preConfigId = element.preConfigId;
          const levelTwoId = element.levelTwoId;
          // const result = Object.assign(element, value.externalDeliverableCreatorDto);
          // // element['id'] = null;
          // element['status'] = "SAVE"
          // element['childEr'] = value.erDesignNumber;
          // const Reviewer = value.externalDeliverableReviewerDto;
          // element['status'] = "SAVE"
          // this.designReviewerData.push(value.externalDeliverableReviewerDto);
          // this.fieldDisabled = true;
          element['id'] = id;
          element['preConfigId'] = preConfigId;
          element['levelTwoId'] = levelTwoId;
          element['childEr'] = value.externalDeliverableCreatorDto.id;
          // element['childErNumber'] = value.erDesignNumber;
          // element['externalLevelTwoChildComments'] = result.generalComments;
          // element['externalLevelThreeChildRefStatus'] = result.edCreatorStatus;
          // element['externalLevelTwoChildHoldComments'] = result.holdComments;
          element['edCreatorStatus'] = "NOT STARTED";
          this.saveCreator('i', item, 'SAVE', element, 2);
        }
      });
    }
  }
  //Automate child ER Linking
  // saveChildReviewer(creatorData, id, preConfigId, levelTwoId) {
  saveChildReviewer(creatorData) {
    if (creatorData.edLevelThreeCreator.length == 0) {
      const formData = {};
      formData['preconfigId'] = creatorData.preConfigId,
        formData['childErPreConfigId'] = creatorData.externalLevelTwoChildPreConfigId,
        formData['creatorId'] = creatorData.id,
        formData['childErCreatorId'] = creatorData.childEr,
        formData['levelTwoId'] = creatorData.levelTwoId,
        formData['childErLevelTwoId'] = creatorData.externalLevelTwoChildLevelTwoId,
        formData['module'] = 'External Deliverables',
        formData['user'] = {
          'sso': this.profileSso,
          'firstName': this.profileFirstName,
          'lastName': this.profileLastName
        }
      this.apiMappingsService.saveChildReviewer(formData).subscribe((data: []) => {
        if (data) {
          this.loadData();
          //this.bhAlertService.showAlert('success', 'top', 5000, 'Saved Successfully!');
        } else {
          this.loadData();
          //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save !');
        }
      });
    } else if (creatorData.edLevelThreeCreator.length > 0) {
      creatorData.edLevelThreeCreator.forEach(levelThree => {
        if (levelThree.childEr != null) {
          const formData = {};
          formData['preconfigId'] = levelThree.preConfigId,
            formData['childErPreConfigId'] = levelThree.externalLevelThreeChildPreConfigId,
            formData['creatorId'] = creatorData.id,
            formData['childErCreatorId'] = levelThree.externalLevelThreeChildLevelTwoCreatorId,
            formData['levelTwoId'] = creatorData.levelTwoId,
            formData['childErLevelTwoId'] = levelThree.externalLevelTwoChildLevelTwoId,
            formData['levelThreeId'] = levelThree.levelThreeId,
            formData['childErLevelThreeId'] = levelThree.externalLevelThreeChildLevelThreeId,
            formData['levelThreeCreatorId'] = levelThree.id,
            formData['childErlevelThreeCreatorId'] = levelThree.childEr,
            formData['module'] = 'External Deliverables',
            formData['user'] = {
              'sso': this.profileSso,
              'firstName': this.profileFirstName,
              'lastName': this.profileLastName
            }
          //Level 3
          // if (creatorData.edLevelThreeCreator.length > 0) {
          //   formData['levelThreeId'] = creatorData.levelThreeId,
          //     formData['childErLevelThreeId'] = creatorData.childErLevelThreeId,
          //     formData['levelThreeCreatorId'] = creatorData.levelThreeCreatorId,
          //     formData['childErlevelThreeCreatorId'] = creatorData.childErlevelThreeCreatorId
          // }
          //
          this.apiMappingsService.saveChildReviewer(formData).subscribe((data: []) => {
            if (data) {
              this.loadData();
              //this.bhAlertService.showAlert('success', 'top', 5000, 'Test Saved Successfully!');
            } else {
              this.loadData();
              //this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save Test !');
            }
          });
        }
      });

    }
  }
  //


  saveLevelOneData(data: any) {
    let levelOneCommentsData = {};
    levelOneCommentsData['transactionId'] = data['id'];
    levelOneCommentsData['comments'] = data['generalComments'];
    levelOneCommentsData['hasHold'] = data['isHold'];
    levelOneCommentsData['holdComments'] = data['holdComments'];
    this.apiMappingsService.savedExternalDeliverablesLevelOne(levelOneCommentsData).subscribe((data: []) => {
      if (data) {
        this.bhAlertService.showAlert('success', 'top', 5000, 'External Deliverables Saved Successfully!');
      } else {
        this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Save External Deliverables!');
      }
    });
  }

  convertToArray(obj: any) {
    return [obj];
  }

}
export interface DesignDialogData {
  animal: string;
  name: string;
}
