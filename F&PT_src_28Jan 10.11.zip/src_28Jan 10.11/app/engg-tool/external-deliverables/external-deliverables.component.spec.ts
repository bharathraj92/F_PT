import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalDeliverablesComponent } from './external-deliverables.component';

describe('ExternalDeliverablesComponent', () => {
  let component: ExternalDeliverablesComponent;
  let fixture: ComponentFixture<ExternalDeliverablesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalDeliverablesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalDeliverablesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
