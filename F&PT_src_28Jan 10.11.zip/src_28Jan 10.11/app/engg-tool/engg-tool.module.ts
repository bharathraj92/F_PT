import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeLibModule, NavService } from 'bh-theme';
import { BhAlertService } from 'bh-theme';
// import { ComponentsComponent } from './components/components.component';
import { ServicesComponent } from './services/services.component';

export { EnggToolComponent } from './engg-tool.component';

import { EnggPreConfigReviewComponent } from './engg-pre-config-review/engg-pre-config-review.component';
import { EnggSummaryInfoComponent } from './engg-summary-info/engg-summary-info.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTabsModule } from '@angular/material/tabs';
import { AppRoutingModule } from '../app-routing.module';
import { EnggToolComponent } from './engg-tool.component';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { ERSearchModalComponent } from './er-search-modal/er-search-modal.component';
import { BomConfigurationComponent } from './bom-configuration/bom-configuration.component';
import { EnggSchedulingPlanningInfoComponent } from './engg-scheduling-planning-info/engg-scheduling-planning-info.component';
import { NPCSearchModalComponent } from './npc-search-modal/npc-search-modal.component';
import { DesignSearchModalComponent } from './design-search-modal/design-search-modal.component';
import { MessageHistoryModalComponent } from './message-history-modal/message-history-modal.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BomNpcConfigComponent } from './bom-npc-config/bom-npc-config.component';
import { BomDesignComponent } from './bom-design/bom-design.component';
import {OnlyNumberDirective} from '../util/only-number.directive';
import { ERHistoryComponent } from './er-history/er-history.component';




@NgModule({
  declarations: [ServicesComponent,
    EnggToolComponent,
    EnggPreConfigReviewComponent,
    EnggSummaryInfoComponent,
    ERSearchModalComponent,
    NPCSearchModalComponent,
    DesignSearchModalComponent,
    MessageHistoryModalComponent,
    BomConfigurationComponent,
    EnggSchedulingPlanningInfoComponent,
    BomNpcConfigComponent,
    BomDesignComponent,
    OnlyNumberDirective,
    ERHistoryComponent
  ],
  imports: [
    CommonModule,
    MatTabsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ThemeLibModule,
    FormsModule,
    BrowserModule,
  ],
  exports: [EnggToolComponent,
    EnggPreConfigReviewComponent,
    EnggSummaryInfoComponent,
    ERSearchModalComponent,
    NPCSearchModalComponent,
    DesignSearchModalComponent,
    MessageHistoryModalComponent,
    BomConfigurationComponent,
    BomDesignComponent,
    EnggSchedulingPlanningInfoComponent,
    ERHistoryComponent
  ],
  providers: [NavService, BhAlertService]
})
export class EnggToolModule { }
