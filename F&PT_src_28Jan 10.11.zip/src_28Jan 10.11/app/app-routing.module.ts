import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import * as AdminPages from './admin/admin.module';
import * as DashboardPages from './engg-tool-dashboard/dashboard.module';
import * as DashboardMatrix from './engg-tool-dashboard-matrix/dashboard-matrix.module';
import { DashboardMatrixComponent } from './engg-tool-dashboard-matrix/engg-tool-dashboard-matrix.component';
import { AuthGuard } from './guards/auth-guard.guard';
import { ViewApproversComponent } from './admin/view-approvers/view-approvers.component';
import { EnggToolDashboardComponent } from './engg-tool-dashboard/engg-tool-dashboard.component';
import { EnggPreConfigReviewComponent } from './engg-tool/engg-pre-config-review/engg-pre-config-review.component';
import { EnggSummaryInfoComponent } from './engg-tool/engg-summary-info/engg-summary-info.component';
import { EnggToolComponent } from './engg-tool/engg-tool.component';
import { BomConfigurationComponent } from './engg-tool/bom-configuration/bom-configuration.component';
import { EnggSchedulingPlanningInfoComponent } from './engg-tool/engg-scheduling-planning-info/engg-scheduling-planning-info.component';
import { ConfigurationComponent } from './engg-tool//configuration/configuration.component';
import { QualityDocComponent } from './engg-tool/quality-doc/quality-doc.component';
import { AttachmentsComponent } from './engg-tool/attachments/attachments.component';
import { HistoryComponent } from './engg-tool/history/history.component';
import { ActivityTreeHistoryComponent } from './engg-tool/activity-tree-history/activity-tree-history.component';
import { AdminComponent } from './admin/admin.component';
import { from } from 'rxjs';
import { ERHistoryComponent } from './engg-tool/er-history/er-history.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard/myDashboard', pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'requestAccess', component: EnggToolDashboardComponent, canActivate: [AuthGuard] },
  { path: 'feedback', component: EnggToolDashboardComponent, canActivate: [AuthGuard] },
  {
    path: 'enggTool', component: EnggToolComponent, data: { breadcrumb: 'Engg Tool', disabled: true },
    children: [
      { path: 'summaryInfo', component: EnggSummaryInfoComponent, data: { breadcrumb: 'ER Information' } },
      { path: 'preConfig', component: EnggPreConfigReviewComponent, data: { breadcrumb: 'Pre-Configuration' } },
      { path: 'schedulingPlanning', component: EnggSchedulingPlanningInfoComponent, data: { breadcrumb: 'Scheduling & Planning' } },
      { path: 'bomConfig', component: BomConfigurationComponent, data: { breadcrumb: 'BOM' } },
      { path: 'configuration', component: ConfigurationComponent, data: { breadcrumb: 'configuration' } },
      { path: 'qualityDoc', component: QualityDocComponent, data: { breadcrumb: 'qualityDoc' } },
      { path: 'attachments', component: AttachmentsComponent, data: { breadcrumb: 'attachments' } },
      //{ path: 'history', component: HistoryComponent, data: { breadcrumb: 'history' } },
      //{ path: 'history', component: ActivityTreeHistoryComponent, data: { breadcrumb: 'Activity Tree History' } },
      {
        path: 'history', component: ERHistoryComponent, data: { breadcrumb: 'history', disabled: true },
        children: [
          { path: 'erHistory', component: HistoryComponent, data: { breadcrumb: 'history' } },
          { path: 'activityTreeHistory', component: ActivityTreeHistoryComponent, data: { breadcrumb: 'Activity Tree History' } },
          { path: '**', redirectTo: 'erHistory', pathMatch: 'full' }
        ]
      },
      { path: '**', redirectTo: 'summaryInfo', pathMatch: 'full' }
    ]
  },
  {
    path: 'dashboard', data: { breadcrumb: 'Dashboard', disabled: true },
    children: [
      { path: 'myDashboard', component: DashboardPages.MyDashboardComponent, data: { breadcrumb: 'My Dashboard' } },
      { path: 'masterDashboard', component: DashboardPages.ErDashboardComponent, data: { breadcrumb: 'ER Dashboard' } },
      //{ path: 'masterDashboard',
      //loadChildren:()=>import('./engg-tool-dashboard/er-dashboard/er-dashboard.module').then(m => m.ErDashboardModule), data: { breadcrumb: 'ER Dashboard' } },
      { path: 'childERDashboard', component: DashboardPages.ChildERDashboardComponent, data: { breadcrumb: 'Child ER Dashboard' } },
      { path: 'npcDashboard', component: DashboardPages.NpcDashboardComponent, data: { breadcrumb: 'NPC Dashboard' } },
      { path: 'holdDashboard', component: DashboardPages.HoldDashboardComponent, data: { breadcrumb: 'Hold Dashboard' } },
      { path: '**', redirectTo: 'myDashboard', pathMatch: 'full' }
    ]
  },
  //Dashboard Matrix
  {
    path: 'dashboardMatrix', component: DashboardMatrixComponent, data: { breadcrumb: 'DashboardMatrix', disabled: true },
    children: [
      { path: 'generalDashboard', component: DashboardMatrix.GeneralDashboardComponent, data: { breadcrumb: 'General Dashboard' } },
      { path: 'weekwiseDashboard', component: DashboardMatrix.WeekwiseDashboardComponent, data: { breadcrumb: 'Weekwise Dashboard' } },
      { path: 'masoneilanDashboard', component: DashboardMatrix.MasoneilanDashboardComponent, data: { breadcrumb: 'Masoneilan Dashboard' } },
      { path: 'plantDashboard', component: DashboardMatrix.PlantDashboardComponent, data: { breadcrumb: 'Plant Dashboard' } },
      { path: 'wipReport', component: DashboardMatrix.WIPDashboardComponent, data: { breadcrumb: 'WIP Report' } },
      { path: 'wipReportDeepdive', component: DashboardMatrix.WIPDeepdiveComponent, data: { breadcrumb: 'WIP Report Deepdive' } },
      { path: '**', redirectTo: 'generalDashboard', pathMatch: 'full' }
    ]
  },
  {
    path: 'viewApprovers', component: ViewApproversComponent, data: { breadcrumb: 'View Approvers' }
  },
  // Admin Page
  {
    path: 'admin', component: AdminComponent, data: { breadcrumb: 'Admin', disabled: true }, canActivate: [AuthGuard],
    children: [
      { path: 'manageAccess', component: AdminPages.ManageAccessComponent, data: { breadcrumb: 'Manage Access' } },
      { path: 'mCodeData', component: AdminPages.MCodeComponent, data: { breadcrumb: 'M-Code Data' } },
      { path: 'demoteData', component: AdminPages.DemoteComponent, data: { breadcrumb: 'Demote Data' } },
      // { path: '**', redirectTo: 'manageAccess', pathMatch: 'full' }
    ]
  }, {
    path: 'history', component: ERHistoryComponent, data: { breadcrumb: 'History', disabled: true },
    children: [
      { path: 'erHistory', component: HistoryComponent, data: { breadcrumb: 'history' } },
      { path: 'activityTreeHistory', component: ActivityTreeHistoryComponent, data: { breadcrumb: 'Activity Tree History' } },
      { path: '**', redirectTo: 'erHistory', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload', useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
