import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as Mock from 'src/app/mock/scheduling-graph.mock';
import * as _ from 'lodash';
import { HttpClient } from '@angular/common/http';
import { ApiMappingsService } from 'src/app/Services/api-mappings.service';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-scheduling-graph-modal',
  templateUrl: './scheduling-graph-modal.component.html',
  styleUrls: ['./scheduling-graph-modal.component.scss']
})
export class SchedulingGraphModalComponent implements OnInit {

  freqChart: any;
  _freqChart: any;
  ssoId: any;
  constructor(
    public dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public graphData, private apiMappingsService: ApiMappingsService,
    private http: HttpClient, private commonService: CommonService,) {
    this.ssoId = sessionStorage.getItem('ssoId');
  }

  ngOnInit(): void {
    this.getGraphData();
  }
  getGraphData() {
    this.http.get(this.apiMappingsService.getSchedulingGraphData(this.ssoId)).subscribe(data => {
      this.freqChart = [];
      this._freqChart = [];
      // let grpahData = Mock.getAllAvailableColumns;
      let graphData = data;
      this.freqChart = graphData;
      this._freqChart = _.cloneDeep(this.freqChart);
    });
  }
}
