import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedulingGraphModalComponent } from './scheduling-graph-modal.component';

describe('SchedulingGraphModalComponent', () => {
  let component: SchedulingGraphModalComponent;
  let fixture: ComponentFixture<SchedulingGraphModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchedulingGraphModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchedulingGraphModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
