import { AbstractControl } from '@angular/forms';


export function isLowerCaseEquals(str1, str2) {
    return ((str1 + '').toLowerCase() === (str2 + '').toLowerCase());
}
 
