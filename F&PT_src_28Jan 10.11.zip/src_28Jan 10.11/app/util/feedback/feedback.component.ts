import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from 'src/app/Services/api-mappings.service';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit {

  form: FormGroup;
  currentview: string;

  constructor(public formBuilder: FormBuilder, public dialogRef: MatDialogRef<any>, @Inject(MAT_DIALOG_DATA) public requestHeader,
    private apiMappingsService: ApiMappingsService, private commonService: CommonService) {
    this.commonService.currentview.subscribe((data) => {
      this.currentview = data || 'no module set';
    });
  }
  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.form = this.formBuilder.group({
      module: [{ value: this.currentview, disabled: true }],
      type: [null],
      comments: [null, [Validators.required]]
    });
  }
  submit() {
    this.form.enable();
    const formvalue = this.form.value;
    this.dialogRef.close({ formData: formvalue });
  }

}
