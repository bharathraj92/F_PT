import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/request-access';
import * as _ from 'lodash';
import { filter } from 'minimatch';
import * as Helpers from 'src/app/util/helper';
import { BhAlertService } from 'bh-theme';

@Component({
  selector: 'app-request-access-modal',
  templateUrl: './request-access-modal.component.html',
  styleUrls: ['./request-access-modal.component.scss']
})
export class RequestAccessModalComponent implements OnInit {

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  visible = true;
  selectable = true;
  removable = true;
  roleList: any = [];
  //productSubCategoryList: any;
  productModelList: any = [];
  productTypeList: any
  productBrandList: any;
  productDepartmentList: any;
  form: FormGroup;
  disabled: boolean = true;
  allRoleList;
  filteredRoleList: Observable<string[]>;
  userDetails;
  siteList;
  adminRoleCheck: boolean = false;
  //productKnowledgeCheck: boolean = false;
  enggSiteList: any;
  endUserList: any;
  filterProductTypeList: any = [];
  filterProductModelList: any = [];
  filterProductBrandList: any = [];
  //productKnowledgeList: any = [];
  //productVariantList: any = [];
  selectedLanguage: any = [];
  selectedSiteValue: any;
  selectedEnggSiteValue: any;
  masterEndUserTypeList: any = [];
  masterRoleDepartmentList: any = [];
  masterProductKnownledgeList: any = [];
  masterProductBrandList: any = [];
  selectedRoleDesc: any;
  selectedProductBrandName: any;
  selectedManufacturingSiteName: any;
  selectedEnggSiteName: any;
  selectedDeparmentName: any;
  selectedEndUserTypeName: any;
  selectedProductTypeName: any;
  selectedProductModelName: any;
  //selectedProductSubCategoryName: any;
  selectecProductVariantName: any;
  selectedPKLName: any;
  displayComplexity: boolean;
  // selectedComment: any;

  constructor(public formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public requestHeader,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService) {
    this.getUserDetails();
  }
  ngOnInit() {
    this.createForm();
    this.form.patchValue({
      userName: `${this.userDetails.firstName} ${this.userDetails.lastName}`,
      userSso: `${this.userDetails.sso}`
    })
    this.getAllProductBrandDetails();
  }

  createForm() {
    this.form = this.formBuilder.group({
      userName: [{ value: null, disabled: this.disabled }],
      userSso: [{ value: null, disabled: this.disabled }],
      productBrand: [null, Validators.required],
      productDepartment: [null, Validators.required],
      productType: [null, Validators.required],
      productModel: [null, Validators.required],
      complexity: [null, Validators.required],
      //productSubCategory: [null],
      //productKnowledge: [null],
      //productVariant: [null],
      role: [null, Validators.required],
      site: [{ value: null }],
      enggSite: [{ value: null, disabled: this.disabled },Validators.required],
      endUserType: [null, Validators.required],
      requestorComments: [null]
    })
  }
  submit() {
    this.form.enable();
    let formvalue = this.form.value;
    // const selectedProdModelVariant = _.filter(this.productModelList, { "productModelName": this.selectedProductModelName, "productSubCategoryName": this.selectedProductSubCategoryName });
    // if (selectedProdModelVariant.length > 0) {
    //   formvalue['productModel'] = selectedProdModelVariant[0]['productModelId'];
    //   formvalue['productSubCategory'] = selectedProdModelVariant[0]['productSubCategoryId'];
    // }
    this.dialogRef.close({ formData: formvalue });
  }
  getUserDetails() {
    this.commonService.userDetails.subscribe((data) => {
      this.userDetails = data;
    });

    this.commonService.selectedLanguage.subscribe((data) => {
      this.selectedLanguage = data;
      // console.log('request access----' + this.selectedLanguage);
    });
  }


  getAllProductBrandDetails() {
    this.apiMappingsService.getErtoolRolesData().subscribe((data: []) => {
      const roleData = data;
      this.adminRoleCheck = false;
      //this.productKnowledgeCheck = false;
      this.productBrandList = roleData['userAccessData'];
      this.siteList = roleData['site'];
      this.enggSiteList = roleData['enggSite'];
      this.masterRoleDepartmentList = roleData['roles'];
      this.masterProductKnownledgeList = roleData['pklMaster'];
      this.masterProductBrandList = roleData['roles'];
      this.masterProductBrandList = _.uniqBy(this.masterProductBrandList, 'productBrandId');
      if (this.enggSiteList.length === 1) {
        this.form.get('enggSite').patchValue(this.enggSiteList[0].enggSiteId);
      }
      if (this.siteList.length === 1) {
        this.form.get('site').patchValue(this.siteList[0].id);
        this.form.get('site').disable();
        this.form.get('enggSite').enable();
        const selectedMaunfacturing = new Object();
        selectedMaunfacturing['value'] = this.siteList[0].id;
        this.onManufacturingsiteChange(selectedMaunfacturing);
      }
    });
  }

  onManufacturingsiteChange(selectedManufacturingSite) {
    this.adminRoleCheck = false;
    //this.productKnowledgeCheck = false;
    this.form.get('endUserType').reset();
    this.form.get('productDepartment').reset();
    this.form.get('role').reset();
    this.form.get('productType').reset();
    this.form.get('productModel').reset();
    //this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    const selectedManufactureSite = _.filter(this.siteList, { "id": selectedManufacturingSite.value });
    this.selectedManufacturingSiteName = selectedManufactureSite[0]['siteName'];
    const selectedManuSite = this.form.get('site').value;
    this.masterProductBrandList = _.uniqBy(this.masterProductBrandList, 'productBrandId');
    if (this.masterProductBrandList.length === 1) {
      this.form.get('productBrand').patchValue(this.masterProductBrandList[0].productBrandId);
      const selectedBrand = new Object();
      selectedBrand['value'] = this.masterProductBrandList[0].productBrandId;
      this.onProductBrandChange(selectedBrand);
    }
    const filterProductBrand = _.filter(this.productBrandList, { 'siteId': selectedManuSite });
    this.filterProductBrandList = filterProductBrand;
    this.filterProductBrandList = _.uniqBy(this.filterProductBrandList, 'productBrandId');
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      const filterSiteList = _.filter(this.masterEndUserTypeList, { 'siteId': this.selectedSiteValue });
      this.endUserList = filterSiteList;
      if (this.endUserList.length === 1) {
        this.form.get('endUserType').patchValue(this.endUserList[0].endUserTypeId);
        const selectedEndUser = new Object();
        selectedEndUser['value'] = this.endUserList[0].endUserTypeId;
        this.onEndUserTypeChange(selectedEndUser);
      }
    }
  }

  onEnggSiteChange(selectedEnggSite) {
    this.adminRoleCheck = false;
    //this.productKnowledgeCheck = false;
    this.form.get('endUserType').reset();
    this.form.get('productDepartment').reset();
    this.form.get('role').reset();
    this.form.get('productType').reset();
    this.form.get('productModel').reset();
    //this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    this.endUserList = [];
    this.filterProductModelList = [];
    this.filterProductTypeList = [];
    this.productTypeList = [];
    this.productDepartmentList = [];
    this.productModelList = [];
    //this.productSubCategoryList = [];
    this.roleList = [];
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    const selectedEngSite = _.filter(this.enggSiteList, { "enggSiteId": selectedEnggSite.value });
    this.selectedEnggSiteName = selectedEngSite[0]['enggSiteName'];
    this.masterProductBrandList = _.uniqBy(this.masterProductBrandList, 'productBrandId');
    if (this.masterProductBrandList.length === 1) {
      this.form.get('productBrand').patchValue(this.masterProductBrandList[0].productBrandId);
      const selectedBrand = new Object();
      selectedBrand['value'] = this.masterProductBrandList[0].productBrandId;
      this.onProductBrandChange(selectedBrand);
    }
    const filterProductBrand = _.filter(this.productBrandList, { 'siteId': selectedEnggSite.value });
    this.filterProductBrandList = filterProductBrand;
    this.filterProductTypeList = _.uniqBy(this.filterProductBrandList, 'productBrandId');
    if (selectedEnggSite) {
      const filterSiteList = _.filter(this.filterProductBrandList, { 'siteId': selectedEnggSite.value });
      this.endUserList = filterSiteList;
      this.endUserList = _.uniqBy(this.endUserList, 'endUserTypeId');
      if (this.endUserList.length === 1) {
        this.form.get('endUserType').patchValue(this.endUserList[0].endUserTypeId);
        const selectedEndUser = new Object();
        selectedEndUser['value'] = this.endUserList[0].endUserTypeId;
        this.onEndUserTypeChange(selectedEndUser);
      }
    } else if (this.selectedSiteValue) {
      const filterSiteList = _.filter(this.filterProductBrandList, { 'siteId': this.selectedSiteValue });
      this.endUserList = filterSiteList;
      this.endUserList = _.uniqBy(this.endUserList, 'endUserTypeId');
      if (this.endUserList.length === 1) {
        this.form.get('endUserType').patchValue(this.endUserList[0].endUserTypeId);
        const selectedEndUser = new Object();
        selectedEndUser['value'] = this.endUserList[0].endUserTypeId;
        this.onEndUserTypeChange(selectedEndUser);
      }
    }
  }

  onProductBrandChange(selectedBrand) {
    this.adminRoleCheck = false;
    //this.productKnowledgeCheck = false;
    this.form.get('productDepartment').reset();
    this.form.get('role').reset();
    this.form.get('productType').reset();
    this.form.get('productModel').reset();
    //this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    const selectedProductBrand = _.filter(this.productBrandList, { "productBrandId": selectedBrand.value });
    this.selectedProductBrandName = selectedProductBrand[0]['productBrandName'];
    this.filterProductModelList = [];
    this.filterProductTypeList = [];
    this.productTypeList = [];
    this.productDepartmentList = [];
    this.productModelList = [];
    //this.productSubCategoryList = [];
    this.roleList = [];
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    let selectedSite;
    if (this.selectedSiteValue && this.selectedEnggSiteValue) {
      selectedSite = this.selectedEnggSiteValue;
    } else if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      selectedSite = this.selectedSiteValue;
    }
    if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      const filterSiteList = _.filter(this.productBrandList, { 'productBrandId': selectedBrand.value, 'siteId': selectedSite });
      this.endUserList = filterSiteList;
      this.endUserList = _.uniqBy(this.endUserList, 'endUserTypeId');
      this.masterEndUserTypeList = this.endUserList;
      if (this.endUserList.length === 1) {
        this.form.get('endUserType').patchValue(this.endUserList[0].endUserTypeId);
        const selectedEndUser = new Object();
        selectedEndUser['value'] = this.endUserList[0].endUserTypeId;
        this.onEndUserTypeChange(selectedEndUser);
      }
    }
  }

  onEndUserTypeChange(selectedEndUserType) {
    this.form.get('productDepartment').reset();
    this.form.get('role').reset();
    this.form.get('productType').reset();
    this.form.get('productModel').reset();
    //this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    this.productDepartmentList = [];
    this.roleList = [];
    this.filterProductModelList = [];
    this.filterProductTypeList = [];
    this.productTypeList = [];
    this.productModelList = [];
    //this.productSubCategoryList = [];
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    const selectedEndUser = _.filter(this.endUserList, { "endUserTypeId": selectedEndUserType.value });
    this.selectedEndUserTypeName = selectedEndUser[0]['endUserTypeName'];
    const selectedBrand = this.form.get('productBrand').value;
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    let selectedSite;
    if (this.selectedSiteValue && this.selectedEnggSiteValue) {
      selectedSite = this.selectedEnggSiteValue;
    } else if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      selectedSite = this.selectedSiteValue;
    }
    this.productDepartmentList = _.filter(this.masterRoleDepartmentList, {
      'productBrandId': selectedBrand
    });
    this.productDepartmentList = _.uniqBy(this.productDepartmentList, 'departmentId');
    if (this.productDepartmentList.length === 0) {
      this.form.get('productDepartment').disable();
      this.form.get('role').disable();
      this.form.get('productType').disable();
      this.form.get('productModel').disable();
      //this.form.get('productSubCategory').disable();
      //this.form.get('productVariant').disable();
      //this.form.get('productKnowledge').disable();
      this.bhAlertService.showAlert(
        'warning',
        'top',
        5000,
        'All the combination for this site has been all ready raised.'
      );
    }
    else if (this.productDepartmentList.length === 1) {
      this.form.get('productDepartment').enable();
      this.form.get('role').enable();
      this.form.get('productType').enable();
      this.form.get('productModel').enable();
     // this.form.get('productSubCategory').enable();
      //this.form.get('productVariant').enable();
      //this.form.get('productKnowledge').enable();
      this.form.get('productDepartment').patchValue(this.productDepartmentList[0].departmentId);
    }
  }

  onProductDepartmentChange(slectedDepartment) {
    this.adminRoleCheck = false;
    //this.productKnowledgeCheck = false;
    this.form.get('role').reset();
    this.form.get('productType').reset();
    this.form.get('productModel').reset();
    //this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    this.roleList = [];
    this.filterProductModelList = [];
    this.filterProductTypeList = [];
    this.productTypeList = [];
    this.productModelList = [];
    //this.productSubCategoryList = [];
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    const slectedDepart = _.filter(this.productDepartmentList, { "departmentId": slectedDepartment.value });
    this.selectedDeparmentName = slectedDepart[0]['departmentName'];
    const selectedBrand = this.form.get('productBrand').value;
    this.roleList = _.filter(this.masterRoleDepartmentList, { 'productBrandId': selectedBrand, 'departmentId': slectedDepartment.value });
    this.roleList = _.uniqBy(this.roleList, 'roleId');
    if (this.roleList.length === 0) {
      this.form.get('role').disable();
      this.form.get('productType').disable();
      this.form.get('productModel').disable();
      //this.form.get('productSubCategory').disable();
      //this.form.get('productVariant').disable();
      //this.form.get('productKnowledge').disable();
      this.bhAlertService.showAlert(
        'warning',
        'top',
        5000,
        'All the combination for this site has been all ready raised.'
      );
    }
    else if (this.roleList.length === 1) {
      this.form.get('role').enable();
      this.form.get('productType').enable();
      this.form.get('productModel').enable();
      //this.form.get('productSubCategory').enable();
      //this.form.get('productVariant').enable();
      //this.form.get('productKnowledge').enable();
      this.form.get('role').patchValue(this.roleList[0].roleId);
      const selecteRole = new Object();
      selecteRole['value'] = this.roleList[0].roleId;
      this.onRoleChange(selecteRole);
    }
  }

  onRoleChange(selectedRole) {
    this.adminRoleCheck = false;
    //this.productKnowledgeCheck = false;
    this.form.get('productType').reset();
    this.form.get('productModel').reset();
    //this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    const selectedRoleDesc = _.filter(this.roleList, { "roleId": selectedRole.value });
    this.selectedRoleDesc = selectedRoleDesc[0]['roleDesc'];
    const selectedBrand = this.form.get('productBrand').value;
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    let selectedSite;
    if (this.selectedSiteValue && this.selectedEnggSiteValue) {
      selectedSite = this.selectedEnggSiteValue;
    } else if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      selectedSite = this.selectedSiteValue;
    }
    const selectedEndUserType = this.form.get('endUserType').value;
    const selectedDepartmentId = this.form.get('productDepartment').value;
    const selectedRoleId = this.form.get('role').value;
    this.filterProductModelList = [];
    this.filterProductTypeList = [];
    this.productTypeList = [];
    this.productModelList = [];
    //this.productSubCategoryList = [];
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    const filterProductList = _.filter(this.productBrandList, {
      'roleId': selectedRoleId, 'departmentId': selectedDepartmentId, 'productBrandId': selectedBrand,
      'endUserTypeId': selectedEndUserType, 'siteId': selectedSite
    });
    const selectedDeparment = this.form.get('productDepartment').value;
    const filterDepartmentList = _.filter(this.masterRoleDepartmentList, { 'departmentId': selectedDeparment });
    const selectedRoleType = typeof (selectedRole);
    let selectedRoleValue = Number;
    if (selectedRoleType === 'number') {
      selectedRoleValue = selectedRole;
    } else if (selectedRoleType === 'object') {
      selectedRoleValue = selectedRole.value;
    }
    const filterRoleList = _.filter(this.masterRoleDepartmentList, { 'roleId': selectedRoleValue });
    const departmentName = filterDepartmentList[0]['departmentName'];
    const roleName = filterRoleList[0]['roleName'];
    const roleNameFilterValue = _.includes(roleName, 'EPL');
    if (Helpers.isLowerCaseEquals(departmentName, 'ER Tool') || Helpers.isLowerCaseEquals(departmentName, 'Project Management') || Helpers.isLowerCaseEquals(roleName, 'NPC Approver Engineer')
      || Helpers.isLowerCaseEquals(roleName, 'NPC Approver') || Helpers.isLowerCaseEquals(roleName, 'Admin') || Helpers.isLowerCaseEquals(roleName, 'Project Management') || roleNameFilterValue) {
      this.adminRoleCheck = true;
      this.displayComplexity =false;
      this.form.get('productType').setValidators([]);
      this.form.get('productModel').setValidators([]);
      this.form.get('productSubCategory').setValidators([]);
      if (Helpers.isLowerCaseEquals(departmentName, 'Quality') || Helpers.isLowerCaseEquals(departmentName, 'Engineering')) {
        //this.productKnowledgeCheck = false;
        this.form.get('complexity').setValidators([]);
        if (Helpers.isLowerCaseEquals(departmentName, 'Quality') && Helpers.isLowerCaseEquals(roleName, 'Creator')) {
          const filterPKLList = _.filter(this.masterProductKnownledgeList, { 'departmentId': selectedDeparment, 'roleId': selectedRoleValue });
          //this.productKnowledgeList = filterPKLList;
          this.form.get('complexity').setValidators([Validators.required]);
        } else if (Helpers.isLowerCaseEquals(departmentName, 'Quality') && Helpers.isLowerCaseEquals(roleName, 'Approver')) {
          const filterPKLList = _.filter(this.masterProductKnownledgeList, { 'departmentId': selectedDeparment, 'roleId': selectedRoleValue });
          this.form.get('complexity').setValidators([Validators.required]);
          //this.productKnowledgeList = filterPKLList;
        } else if (Helpers.isLowerCaseEquals(departmentName, 'Engineering') && Helpers.isLowerCaseEquals(roleName, 'Project Leader / EPL')) {
          const filterPKLList = _.filter(this.masterProductKnownledgeList, { 'departmentId': selectedDeparment, 'roleId': selectedRoleValue });
          //this.productKnowledgeList = filterPKLList;
          this.displayComplexity =true;
          this.form.get('complexity').setValidators([]);
        } else if (Helpers.isLowerCaseEquals(departmentName, 'Quality') && Helpers.isLowerCaseEquals(roleName, 'NPC Approver')) {
          //this.productKnowledgeCheck = true;
          this.form.get('complexity').setValidators([]);
        }
      } else {
        // this.productKnowledgeCheck = true;
        // this.form.get('productKnowledge').setValidators([]);
        this.form.get('complexity').setValidators([]);
      }
      //this.form.get('productVariant').setValidators([]);
    } else {
      this.adminRoleCheck = false;
      //this.productKnowledgeCheck = false;
      this.productTypeList = filterProductList;
      this.filterProductTypeList = this.productTypeList;
      this.filterProductTypeList = _.uniqBy(filterProductList, 'productTypeId');
      if (this.filterProductTypeList.length === 0) {
        this.form.get('productType').disable();
        this.form.get('productModel').disable();
        //this.form.get('productSubCategory').disable();
        //this.form.get('productVariant').disable();
        //this.form.get('productKnowledge').disable();
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'All the combination for this site has been all ready raised.'
        );
      } else if (this.filterProductTypeList.length === 1) {
        this.form.get('productType').enable();
        this.form.get('productModel').enable();
        //this.form.get('productSubCategory').enable();
        //this.form.get('productVariant').enable();
        //this.form.get('productKnowledge').enable();
        this.form.get('productType').patchValue(this.filterProductTypeList[0].productTypeId);
        const selecteProductType = new Object();
        selecteProductType['value'] = this.filterProductTypeList[0].productTypeId;
        this.onProductTypeChange(selecteProductType)
      }
    }
  }

  onProductTypeChange(selectedProductType) {
    this.form.get('productModel').reset();
  //this.form.get('productSubCategory').reset();
   // this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    const selectedprodType = _.filter(this.filterProductTypeList, { "productTypeId": selectedProductType.value });
    this.selectedProductTypeName = selectedprodType[0]['producTypeName'];
    const selectedBrand = this.form.get('productBrand').value;
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    let selectedSite;
    if (this.selectedSiteValue && this.selectedEnggSiteValue) {
      selectedSite = this.selectedEnggSiteValue;
    } else if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      selectedSite = this.selectedSiteValue;
    }
    const selectedEndUserType = this.form.get('endUserType').value;
    const selectedDepartmentId = this.form.get('productDepartment').value;
    const selectedRoleId = this.form.get('role').value;
    this.filterProductModelList = [];
    this.productModelList = [];
    //this.productSubCategoryList = [];
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    this.productModelList = _.filter(this.productBrandList, {
      'productBrandId': selectedBrand, 'siteId': selectedSite, 'endUserTypeId': selectedEndUserType, 'roleId': selectedRoleId, 'departmentId': selectedDepartmentId,
      'productTypeId': selectedProductType.value
    });
    this.filterProductModelList = _.uniqBy(this.productModelList, 'productModelName');

    if (this.filterProductModelList.length === 0) {
      this.form.get('productModel').disable();
     // this.form.get('productSubCategory').disable();
     // this.form.get('productVariant').disable();
     // this.form.get('productKnowledge').disable();
      this.bhAlertService.showAlert(
        'warning',
        'top',
        5000,
        'All the combination for this site has been all ready raised.'
      );
    }
    else if (this.filterProductModelList.length === 1) {
      this.form.get('productModel').enable();
      //this.form.get('productSubCategory').enable();
      //this.form.get('productVariant').enable();
      //this.form.get('productKnowledge').enable();
      this.form.get('productModel').patchValue(this.filterProductModelList[0].productModelId);
      const selectedModel = new Object();
      selectedModel['value'] = this.filterProductModelList[0].productModelId;
      this.onProductModelChange(selectedModel)
    }
  }

  onProductModelChange(selectedModel) {
   // this.form.get('productSubCategory').reset();
    //this.form.get('productVariant').reset();
    //this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    const selectedprodModel = _.filter(this.filterProductModelList, { "productModelId": selectedModel.value });
    this.selectedProductModelName = selectedprodModel[0]['productModelName'];
    const selectedBrand = this.form.get('productBrand').value;
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    let selectedSite;
    if (this.selectedSiteValue && this.selectedEnggSiteValue) {
      selectedSite = this.selectedEnggSiteValue;
    } else if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      selectedSite = this.selectedSiteValue;
    }
    const selectedEndUserType = this.form.get('endUserType').value;
    const selectedDepartmentId = this.form.get('productDepartment').value;
    const selectedRoleId = this.form.get('role').value;
    const selectedProductType = this.form.get('productType').value;
    const selectedProductModel = this.form.get('productModel').value;
    // this.productSubCategoryList = [];
    // this.productVariantList = [];
    // this.productKnowledgeList = [];
    // this.productSubCategoryList = _.filter(this.productBrandList, {
    //   'roleId': selectedRoleId, 'departmentId': selectedDepartmentId, 'productBrandId': selectedBrand,
    //   'productTypeId': selectedProductType, 'endUserTypeId': selectedEndUserType, 'siteId': selectedSite, 'productModelName': this.selectedProductModelName
    // });
    // this.productSubCategoryList = _.uniqBy(this.productSubCategoryList, 'productModelId');
    // if (this.productSubCategoryList.length === 0) {
    //   this.form.get('productSubCategory').disable();
    //   this.form.get('productVariant').disable();
    //   this.form.get('productKnowledge').disable();
    //   this.bhAlertService.showAlert(
    //     'warning',
    //     'top',
    //     5000,
    //     'All the combination for this site has been all ready raised.'
    //   );
    // }
    // else if (this.productSubCategoryList.length === 1) {
    //   this.form.get('productSubCategory').enable();
    //   this.form.get('productVariant').enable();
    //   this.form.get('productKnowledge').enable();
    //   this.form.get('productSubCategory').patchValue(this.productSubCategoryList[0].productSubCategoryId);
    //   const selectedSubCategory = new Object();
    //   selectedSubCategory['value'] = this.productSubCategoryList[0].productSubCategoryId;
    //   this.onProductSubCategoryChange(selectedSubCategory)
    // }
  }

  onProductSubCategoryChange(selectedSubCategory) {
    this.form.get('productVariant').reset();
    this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    //this.productVariantList = [];
    //this.productKnowledgeList = [];
    const selectedprodSubCategory = _.filter(this.productModelList, { "productSubCategoryId": selectedSubCategory.value });
    //this.selectedProductSubCategoryName = selectedprodSubCategory[0]['productSubCategoryName'];
    const selectedBrand = this.form.get('productBrand').value;
    this.selectedSiteValue = this.form.get('site').value;
    this.selectedEnggSiteValue = this.form.get('enggSite').value;
    let selectedSite;
    if (this.selectedSiteValue && this.selectedEnggSiteValue) {
      selectedSite = this.selectedEnggSiteValue;
    } else if (this.selectedSiteValue && !this.selectedEnggSiteValue) {
      selectedSite = this.selectedSiteValue;
    }
    const selectedEndUserType = this.form.get('endUserType').value;
    const selectedDepartmentId = this.form.get('productDepartment').value;
    const selectedRoleId = this.form.get('role').value;
    const selectedProductType = this.form.get('productType').value;
    const selectedProductModel = this.form.get('productModel').value;
    const selectedProductSubCategory = this.form.get('productSubCategory').value;
    const selectedprodModel = _.filter(this.productModelList, { "productModelId": selectedProductModel });
    this.selectedProductModelName = selectedprodModel[0]['productModelName'];
    // this.productVariantList = _.filter(this.productModelList, {
    //   'roleId': selectedRoleId, 'departmentId': selectedDepartmentId, 'productBrandId': selectedBrand,
    //   'productTypeId': selectedProductType, 'endUserTypeId': selectedEndUserType, 'siteId': selectedSite, 'productModelName': this.selectedProductModelName, 'productSubCategoryId': selectedProductSubCategory
    // });
    // this.productVariantList = _.uniqBy(this.productVariantList, 'productVariantId');
    // if (this.productVariantList.length === 0) {
    //   this.form.get('productVariant').disable();
    //   this.form.get('productKnowledge').disable();
    //   this.bhAlertService.showAlert(
    //     'warning',
    //     'top',
    //     5000,
    //     'All the combination for this site has been all ready raised.'
    //   );
    // } else if (this.productVariantList.length === 1) {
    //   this.form.get('productVariant').enable();
    //   this.form.get('productKnowledge').enable();
    //   this.form.get('productVariant').patchValue(this.productVariantList[0].productVariantId);
    //   const selectedProductVariant = new Object();
    //   selectedProductVariant['value'] = this.productVariantList[0].productVariantId;
    //   this.onProductVariantChange(selectedProductVariant);
    // }
  }

  onProductVariantChange(selectedProductVariant) {
    this.form.get('productKnowledge').reset();
    this.form.get('complexity').reset();
    const selectedDepartmentId = this.form.get('productDepartment').value;
    const selectedRoleId = this.form.get('role').value;
    //const selectecProductVariantName = _.filter(this.productVariantList, { "productVariantId": selectedProductVariant.value });
    //this.selectecProductVariantName = selectecProductVariantName[0]['productVariantName'];
    const filterPKLList = _.filter(this.masterProductKnownledgeList, { 'departmentId': selectedDepartmentId, 'roleId': selectedRoleId });
    // this.productKnowledgeList = filterPKLList;
    // if (this.productKnowledgeList.length === 1) {
    //   this.form.get('productKnowledge').patchValue(this.productKnowledgeList[0].productVariantId);
    //   const selectedProductKnowledge = new Object();
    //   selectedProductKnowledge['value'] = this.productKnowledgeList[0].productVariantId;
    //   this.onProductVariantChange(selectedProductVariant);
    // }
  }

  // onProductKnowledgeChange(selectedProductVariant) {
  //   const selectecPKL = _.filter(this.productKnowledgeList, { "productKnowledgeId": selectedProductVariant.value });
  //   this.selectedPKLName = selectecPKL[0]['productKnowledgeName'];
  // }
}
