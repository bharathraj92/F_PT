import { Component, OnInit, OnDestroy, ViewChild, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Chart } from 'angular-highcharts';
import * as _ from 'lodash';

@Component({
  selector: 'app-bar-graph-component',
  templateUrl: './bar-graph-component.component.html',
  styleUrls: ['./bar-graph-component.component.scss']
})
export class BarGraphComponentComponent implements OnInit, OnDestroy, OnChanges {
  @Input() chartData: any;
  @Input() stacked: boolean;
  @Input() seriesvisible: boolean;
  loaded = false;
  stacking: any;
  barchart: Chart;

  constructor() {
    this.chartData = {
      'maintitle': '',
      'categories': [],
      'title': '',
      'columnData': [],
      'series': [],
      'infoIconText': ''
    };
    this.stacked = false;
    this.seriesvisible = false;
    this.stacking = undefined;
  }

  ngOnInit() {
    if (this.stacked === true) {
      this.stacking = 'normal';
    } else {
      this.stacking = undefined;
    }
    this.initBarChart(this.chartData);
    this.loaded = true;
  }


  ngOnChanges(changes: SimpleChanges) {
    let cdata = changes.chartData.currentValue;
    if (this.loaded === true && cdata !== undefined) {
      this.initBarChart(cdata);
    }
  }


  ngOnDestroy(): void {
  }


  initBarChart(chartdata) {
    if (this.barchart !== undefined) {
      delete this.barchart;
    }
    let _chartdata = this.createSeries(chartdata);
    this.barchart = new Chart(
      {
        chart: {
          type: 'column',
          zoomType: 'xy'
        },
        credits: {
          enabled: false
        },
        title: {
          text: _chartdata.maintitle
        },
        xAxis: {
          //categories: _chartdata.categories,
          type: 'category',
          title: {
            text: _chartdata.categoriesName,
          }
        },
        yAxis: {
          min: 0,
          title: {
            text: _chartdata.title
          },
          stackLabels: {
            style: {
              color: 'black',
              fontWeight: 'bold',
            },
            enabled: true,
            formatter: function () {
              if (this.total !== 0) {
                return this.total + '';
              } else {
                return null;
              }
            }
          }
        },
        // tooltip: {
        //   pointFormat: '<span style="color:{series.color}">{series.name}</span>: {point.y} <br/> Total: {point.stackTotal}',
        //   shared: true
        // },
        tooltip: {
          headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
          pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y}</b></td></tr>',
          footerFormat: '</table>',
          shared: true,
          useHTML: true
        },
        plotOptions: {
          column: {
            stacking: 'normal',
            opacity: 0.8,
            dataLabels: {
              enabled: true,
              // style: {
              //   color: Highcharts.getOptions().colors[1]
              // },
              formatter: function () {
                if (this.y != null && this.y > 0) {
                  //return Math.round(100 * this.y / this.total) + ' %';
                  return this.y;
                }
              }
            }
          }
        },
        series: _chartdata.series
      }
    );
  }

  createSeries(chartdata) {
    if (chartdata.columnData !== null) {
      chartdata['chart'] = {};
      chartdata['chart'].type = 'column';
    } else {
      chartdata.columnData = [];
    }
    chartdata.series = chartdata.columnData;
    //
    return chartdata;
  }
}

