import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarGraphComponentComponent } from './bar-graph-component.component';

describe('BarGraphComponentComponent', () => {
  let component: BarGraphComponentComponent;
  let fixture: ComponentFixture<BarGraphComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarGraphComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarGraphComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
