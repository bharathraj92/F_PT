import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/request-access';
import * as _ from 'lodash';
import { filter } from 'minimatch';
import * as Helpers from 'src/app/util/helper';
import { BhAlertService } from 'bh-theme';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ExportExcel } from '../exportExcel';

@Component({
  selector: 'app-user-profile-modal',
  templateUrl: './user-profile-modal.component.html',
  styleUrls: ['./user-profile-modal.component.scss']
})
export class UserProfileModalComponent implements OnInit {

  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('myDashboard') myDashboardTable: MatTable<UserProfileInterface>;
  dataSource = new MatTableDataSource<UserProfileInterface>(ELEMENT_DATA);
  displayedColumns: string[] = [
    'roleName',
    'roleDesc',
    'siteName',
    'producTypeName',
    'productModelName',
    'departmentName',
    'productBrandName',
    'endUserTypeName',
    'enggSiteName',
    'productKnowledge',
    'approvalStatus',
    'userStatus',
  ];
  logginUserFirstName: any;
  firstName: any;
  lastName: any;
  sso: any;
  currentDate: Date;
  userProfile: any;

  // selectedComment: any;

  constructor(public formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public requestHeader,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient, private element: ElementRef,
    private commonService: CommonService, private bhAlertService: BhAlertService) {
    this.commonService.userDetails.subscribe(val => {
      this.logginUserFirstName = val['firstName'];
      this.currentDate = new Date();
    });
    this.getUserProfileData();
  }
  ngOnInit() {

  }

  getUserProfileData() {
    // Uncomment below line of code once api is done and comment mock
    this.apiMappingsService.getWhoAMI().subscribe((data) => {
      if (data) {
        this.userProfile = data['roles'];
        this.firstName = data['firstName'];
        this.lastName = data['lastName'];
        this.sso = data['sso'];
        this.dataSource.data = data['roles'];
        //this.prepareTableData(data);
      }
    });
  }

  exportArray() {
    if (this.dataSource.data) {
      const excelData = this.userProfile;
      const onlyNameAndSymbolArr: Partial<UserProfileInterface>[] = excelData.map(userProfile => ({
        // const onlyNameAndSymbolArr: Partial<MyDashboardInterface>[] = this.userProfileTableData.map(userProfile => ({
        roleName: userProfile.roleName,
        roleDesc: userProfile.roleDesc != null ? userProfile.roleDesc[0] : null,
        siteName: userProfile.siteName,
        producTypeName: userProfile.producTypeName,
        productModelName: userProfile.productModelName,
        departmentName: userProfile.departmentName,
        productBrandName: userProfile.productBrandName,
        endUserTypeName: userProfile.endUserTypeName,
        enggSiteName: userProfile.enggSiteName,
        productKnowledge: userProfile.productKnowledgeName,
        approvalStatus: userProfile.activeStatus,
        userStatus: userProfile.workflowStatus,
      }));
      ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "User Profile");
      //F&PT_MyDashboardData
    }
  }
  // prepareTableData(myDashboardTableData) {
  //   ELEMENT_DATA = [];
  //   myDashboardTableData.forEach(myDashboard => {
  //     ELEMENT_DATA.push({
  //       preConfigId: myDashboard.preConfigId,
  //       indicator: myDashboard.indicator,
  //       orderNumber: myDashboard.orderNumber,
  //       soli: myDashboard.soli,
  //       erNumber: myDashboard.erNumber,
  //       task: myDashboard.task,
  //       subTask: myDashboard.subTask,
  //       roleName: myDashboard.roleName,
  //       roleId: myDashboard.roleId,
  //       tagNumber: myDashboard.tagNumber,
  //       assignee: myDashboard.assignee,
  //       hoursAssign: myDashboard.hoursAssign,
  //       hoursSpent: myDashboard.hoursSpent,
  //       progress: myDashboard.progress,
  //       searchType: myDashboard.searchType,
  //       levelThreeId: myDashboard.levelThreeId,
  //       levelTwoId: myDashboard.levelTwoId
  //     });
  //     // id: erRequest.id,
  //   });
  //   this.dataSource.data = ELEMENT_DATA;

  // }

}
export interface UserProfileInterface {
  //status:string;
  roleName: string;
  roleDesc: string;
  siteName: string;
  producTypeName: string;
  productModelName: string;
  departmentName: string;
  productBrandName: string;
  endUserTypeName: string;
  enggSiteName: string;
  productKnowledge: string;
  approvalStatus: string;
  userStatus: string;
}
let ELEMENT_DATA: UserProfileInterface[] = [];
