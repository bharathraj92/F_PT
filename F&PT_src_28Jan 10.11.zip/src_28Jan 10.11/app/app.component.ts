import { Component, ViewChild, AfterViewInit, ChangeDetectorRef, AfterViewChecked, ViewContainerRef } from '@angular/core';
import { NotificationItem } from 'bh-theme/lib/types/notification-details';
import { ProfileDetails } from 'bh-theme/lib/types/profile-details';
import { NavService } from './Services/nav.service';
import { CommonService } from './Services/common.service';
import { MatSidenav } from '@angular/material/sidenav';
import { RequestAccessModalComponent } from './util/request-access-modal/request-access-modal.component';
import { FeedbackComponent } from './util/feedback/feedback.component';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ApiMappingsService } from './Services/api-mappings.service';
import { BhAlertService } from 'bh-theme';
import { BroadcastService } from './Services/broadcast.service';
import * as _ from 'lodash';
import { coerceArray } from '@angular/cdk/coercion';
import { TranslateService } from '@ngx-translate/core';
import * as Helpers from 'src/app/util/helper';
import { TemplateRef } from '@angular/core';
import { OverlayRef } from '@angular/cdk/overlay';
import { Overlay } from '@angular/cdk/overlay';
import { Subscription, fromEvent } from 'rxjs';
import { TemplatePortal } from '@angular/cdk/portal';
import { filter, take } from 'rxjs/operators';
import { ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserProfileModalComponent } from './util/user-profile-modal/user-profile-modal.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit, AfterViewChecked {
  @ViewChild('appDrawer') appDrawer: MatSidenav;
  title = 'Engineering Tool';
  sidenavChange: any;
  showSpinner: boolean;
  language: any;
  sub: Subscription;
  subblur: Subscription;
  params: any

  subMenuComponent: string;
  profileDetails1: ProfileDetails = {
    profileFirstName: null,
    profileLastName: null,
    profileEmail: null,
    profileImageUrl: null,
    logoutUrl: '/cachelogin',
    profileMenuItems: [
      { name: 'User Profile', icon: 'person', navUrl: '/requestAccess' },
      { name: 'Request Access', icon: 'manage_accounts', navUrl: '/requestAccess' }
      //   //  Commented coz not required as of now
      // { name: 'Feedback', icon: 'feedback', navUrl: '/feedback' }
    ]
  };
  @ViewChild('userMenu') userMenu: TemplateRef<any>;
  overlayRef: OverlayRef | null;
  languageList = [
    { code: 'en', label: 'English' },
    { code: 'fr', label: 'français' },
    { code: 'ja', label: '日本語' }
  ];

  navItems: any[] = [
    // {
    // displayName: 'Dashboard',
    // iconName: 'dashboard',
    // children: [
    {
      displayName: 'My Dashboard',
      iconName: 'assignment_ind',
      route: 'dashboard/myDashboard',
      parent: 'Dashboard'
    },
    {
      displayName: 'Master Dashboard',
      iconName: 'assignment',
      route: 'dashboard/masterDashboard',
      parent: 'Dashboard'
    },
    {
      displayName: 'Child ER Dashboard',
      iconName: 'filter_frames',
      route: 'dashboard/childERDashboard',
      parent: 'Dashboard'
    },
    {
      displayName: 'Npc Dashboard',
      iconName: 'integration_instructions',
      route: 'dashboard/npcDashboard',
      parent: 'Dashboard'
    },
    {
      displayName: 'Hold Dashboard',
      iconName: 'assignment_late',
      route: 'dashboard/holdDashboard',
      parent: 'Dashboard'
    },
    // ]
    // },
    {
      displayName: 'Dashboard Matrix',
      iconName: 'leaderboard',
      route: 'dashboardMatrix/generalDashboard',
    }
  ];
  adminMenuItems = {
    // displayName: 'Admin',
    // iconName: 'admin_panel_settings',
    // children: [
    // {
    displayName: 'Admin Dashboard',
    iconName: 'admin_panel_settings',
    route: 'admin/manageAccess',
    parent: 'Admin'
    // }
    // {
    //   displayName: 'View Feedback',
    //   route: 'admin/suggestion',
    //   parent: 'Admin'
    // }
    // ]
  };

  /* part of bh theme user menu, this features are not required as of now
  settingList: any[] = [];
  languageList: any[] = [];
  notificationItem: NotificationItem[] = [];
  notificationDetails: any = {
    strictMode: false,
    notificationItem: this.notificationItem,
  };
  */
  profileSso;
  requestAccessModal: MatDialogRef<RequestAccessModalComponent>;
  userProfileModal: MatDialogRef<UserProfileModalComponent>;
  FeedbackModal: MatDialogRef<FeedbackComponent>;
  sessionModal: any;

  constructor(private navService: NavService, private cdr: ChangeDetectorRef,
    private commonService: CommonService, private broadcastservice: BroadcastService,
    private apiMappingsService: ApiMappingsService, private dialog: MatDialog,
    private bhAlertService: BhAlertService, public translate: TranslateService,
    public overlay: Overlay,
    public viewContainerRef: ViewContainerRef,
    public router: Router) {
    this.language = 'en';
    this.commonService.selectedLanguage.next(this.language);
    this.broadcastservice.broadcastMessages.subscribe((val) => {
      if (val.length > 0) {
        if (val[0] === 'Invalid Token') {
          this.bhAlertService.showAlert(
            'error',
            'top',
            15000,
            'This might be due to session expiry or task performed by you is unauthorized This page will be reloaded 5 Seconds'
          );
          setTimeout(() => {
            this.refreshPage();
          }, 5000);
        } else {
          this.bhAlertService.showAlert(
            'error',
            'top',
            15000,
            val[0]
          );
        }
      }
    });
    //  Uncomment once get the api with data
    this.commonService.userDetails.subscribe((data: { sso: string, firstName: string, lastName: string, email: string, roles: [], admin: string, siteAdmin: string, siteAdminPlantCode: string,plant:string }) => {
      this.checkImage('https://supportcentral.gecdn.com/images/person/temp/' + data.sso + '.jpg');
      this.profileDetails1.profileFirstName = data.firstName;
      this.profileDetails1.profileLastName = data.lastName;
      this.profileDetails1.profileEmail = data.email;
      this.profileSso = data.sso;
      localStorage.setItem("loggedInUser", this.profileSso);
      localStorage.setItem("roles", JSON.stringify(data.roles));
      localStorage.setItem("admin", data.admin);
      localStorage.setItem("userPlant", data.plant);
      localStorage.setItem("siteAdmin", data.siteAdmin);
      localStorage.setItem("siteAdminPlantCode", data.siteAdminPlantCode);
      localStorage.setItem("linkAccess", 'false');
      localStorage.setItem("erToolUser", 'false');
      if ((data.roles || []).length > 0) {
        localStorage.setItem("erToolUser", 'true');
        //  Uncomment this for site admin and remove admin one
        // const admin = _.find(data.roles, ['roleName', 'Site Administrator']);
        const admin = _.find(data.roles, ['roleName', 'Admin']);
        if (admin !== undefined) {
          this.navItems.push(this.adminMenuItems);
        }
        this.checkMasterChildAccess(data.roles);
        localStorage.setItem("allowAccess", 'true');
      } else {//Check Roles
        localStorage.setItem("allowAccess", 'false');
      }
      // check is admin
      this.isAdmin(data.admin, data.siteAdmin);
    });
    this.commonService.spinnerState.subscribe((value: boolean) => {
      this.showSpinner = value;
    });
    this.sidenavChange = false;
    //  Language translation part
    translate.addLangs(['en', 'fr', 'ja']);
    translate.setDefaultLang('en');
  }
  // check is admin
  isAdmin(admin, siteAdmin) {
    localStorage.setItem("hasAdminRole", "false");
    let roles = JSON.parse(localStorage.getItem("roles"));
    //let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin' ||obj.roleName == 'Tool Administrator')
    let adminRoles = [
      'Admin',
      'Tool Administrator',
      'Site Administrator']
    if (roles && roles.length > 0) {
      let role = roles.filter((obj: any) => adminRoles.includes(obj.roleName));
      if (role && role.length > 0 || admin === 'true' || siteAdmin === 'true') {
        localStorage.setItem("hasAdminRole", "true");
      }
    }
  }
  checkMasterChildAccess(roles) {
    let admin = localStorage.getItem("admin");
    localStorage.setItem("linkAccess", 'false');
    let restrictRoles = [
      10,//NPC Approver Quality
      11,//NPC Approver Manufacturing
      12,//NPC Approver Sourcing
      13,//NPC Approver Finance
      14,//NPC Approver Planning,
      //16 //'Project Management',
    ]
    let role = roles.filter((obj: any) => !restrictRoles.includes(obj.roleId));
    if ((role && role.length > 0) || admin === 'true') {
      localStorage.setItem("linkAccess", 'true');
    }
  }
  ngAfterViewInit() {
    this.navService.appDrawer = this.appDrawer;
    setTimeout(() => {
      this.navService.openNav();
    }, 200);
  }

  ngAfterViewChecked() {
    // code to update the model
    this.cdr.detectChanges();
  }

  checkImage(url) {
    const s = document.createElement('IMG');
    s['src'] = url;
    s.onerror = () => {
      return null;
    };
    s.onload = () => {
      this.profileDetails1.profileImageUrl = url;
    };
    return s.onload;
  }

  toggleSidenav(e) {
    e.srcElement.classList.toggle('change');
    this.sidenavChange = !this.sidenavChange;
    if (this.sidenavChange) {
      this.navService.openNav();
    } else {
      this.navService.closeNav();
    }
  }

  profilItemClicked(event) {
    this.subMenuComponent = (event.name).toLocaleLowerCase();
    if (Helpers.isLowerCaseEquals(this.language, 'en')) {
      if (this.subMenuComponent === 'feedback') {
        this.showFeedbackModal();
      } else if (this.subMenuComponent === 'request access') {
        this.showRequestAccessModal();
      } else if (this.subMenuComponent === 'user profile') {
        this.showUserProfileModal();
      }
    }
    if (Helpers.isLowerCaseEquals(this.language, 'fr')) {
      if (this.subMenuComponent === "retour d'information") {
        this.showFeedbackModal();
      } else if (this.subMenuComponent === "demande d'accès") {
        this.showRequestAccessModal();
      } else if (this.subMenuComponent === "Profil de l'utilisateur") {
        this.showUserProfileModal();
      }
    }

    if (Helpers.isLowerCaseEquals(this.language, 'ja')) {
      if (this.subMenuComponent === "フィードバック") {
        this.showFeedbackModal();
      } else if (this.subMenuComponent === "アクセスをリクエスト") {
        this.showRequestAccessModal();
      } else if (this.subMenuComponent === 'ユーザープロファイル') {
        this.showUserProfileModal();
      }
    }
  }
  showRequestAccessModal() {
    const sendModaldata = { headerData: 'Request Access', bodyDetails: this.profileDetails1 }
    sendModaldata.bodyDetails['profileSso'] = this.profileSso;
    this.requestAccessModal = this.dialog.open(RequestAccessModalComponent, { data: sendModaldata });
    this.requestAccessModal.afterClosed().subscribe(value => {
      if (value) {
        this.submitAccessRequest(value);
      }
    });
  }
  showUserProfileModal() {
    const sendModaldata = { headerData: 'User Profile', bodyDetails: this.profileDetails1 }
    sendModaldata.bodyDetails['profileSso'] = this.profileSso;
    this.userProfileModal = this.dialog.open(UserProfileModalComponent, { data: sendModaldata });
    this.userProfileModal.afterClosed().subscribe(value => {
      if (value) {
        //this.submitAccessRequest(value);
      }
    });
  }
  showFeedbackModal() {
    const sendModaldata = { headerData: 'Feedback' };
    this.FeedbackModal = this.dialog.open(FeedbackComponent, { data: sendModaldata });
    this.FeedbackModal.afterClosed().subscribe(value => {
      if (value.formData) {
        const postData = {
          appModule: value.formData.module,
          suggestionType: value.formData.type,
          suggestionDesc: value.formData.comments

        };
        this.apiMappingsService.postFeedback(postData).subscribe(response => {
          if (response) {
            this.bhAlertService.showAlert(
              'success',
              'top',
              5000,
              'Feedback Submited Successfully!'
            );
          }
        });
      }
    });
  }

  submitAccessRequest(data) {
    const postRequestAccessData = new Object();
    postRequestAccessData['productBrandId'] = data.formData.productBrand;
    postRequestAccessData['departmentId'] = data.formData.productDepartment;
    postRequestAccessData['producTypeId'] = data.formData.productType;
    postRequestAccessData['productModelId'] = data.formData.productModel;
    postRequestAccessData['productSubCategoryId'] = data.formData.productSubCategory;
    postRequestAccessData['roleId'] = data.formData.role;
    postRequestAccessData['siteId'] = data.formData.site;
    postRequestAccessData['userName'] = data.formData.userName;
    postRequestAccessData['userSso'] = data.formData.userSso;
    postRequestAccessData['requestorComments'] = data.formData.requestorComments;
    postRequestAccessData['enggSite'] = data.formData.enggSite;
    postRequestAccessData['endUserType'] = data.formData.endUserType;
    postRequestAccessData['productKnowledge'] = data.formData.productKnowledge;
    postRequestAccessData['productVariant'] = data.formData.productVariant;
    postRequestAccessData['complexity'] = data.formData.complexity;
    this.apiMappingsService.submitAccessRequest(postRequestAccessData).subscribe(value => {
      if (Helpers.isLowerCaseEquals(this.language, 'en')) {
        this.bhAlertService.showAlert(
          'success',
          'top',
          5000,
          'Request Submited Successfully.'
        );
      } else if (Helpers.isLowerCaseEquals(this.language, 'fr')) {
        this.bhAlertService.showAlert(
          'success',
          'top',
          5000,
          'Demande soumise avec succès.'
        );
      } else if (Helpers.isLowerCaseEquals(this.language, 'ja')) {
        this.bhAlertService.showAlert(
          'success',
          'top',
          5000,
          'リクエストは正常に送信されました.'
        );
      }
    });
  }

  refreshPage() {
    setTimeout(() => {
      location.reload();
    }, 10000);
  }

  menuClick(link, type) {
    console.log(link + "@@@@@@-" + type);
  }

  showmenu(evt: MouseEvent, params) {
    this.close();
    this.params = params
    let pos = { x: evt.clientX, y: evt.clientY };
    const positionStrategy = this.overlay.position()
      .flexibleConnectedTo(pos)
      .withPositions([
        {
          originX: 'end',
          originY: 'bottom',
          overlayX: 'start',
          overlayY: 'top'
        }
      ]);

    this.overlayRef = this.overlay.create({
      positionStrategy,
      scrollStrategy: this.overlay.scrollStrategies.close()
    });

    this.overlayRef.attach(new TemplatePortal(this.userMenu, this.viewContainerRef, {
      $implicit: params
    }));

    this.sub = fromEvent<MouseEvent>(document, 'click')
      .pipe(
        filter(event => {
          const clickTarget = event.target as HTMLElement;
          return !!this.overlayRef && !this.overlayRef.overlayElement.contains(clickTarget);
        }),
        take(1)
      ).subscribe(() => this.close());
    return false;
  }

  close() {
    this.sub && this.sub.unsubscribe();
    if (this.overlayRef) {
      this.overlayRef.dispose();
      this.overlayRef = null;
    }
    const match = navigator.userAgent.search(/(?:Edge|MSIE|Trident\/.*; rv:)/);
    if (match !== -1) {
      let event = document.createEvent('MouseEvent');
      event.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
      document.dispatchEvent(event);
    } else {
      document.dispatchEvent(new Event('click'));
    }
  }

  navigateToRoute(route: any, tab: any) {
    console.log(route);
    try {
      if (tab === "newTab") {
        window.open(`${location.origin}${location.pathname}#/${route.route}`, '_blank');
      } else {
        this.router.navigate([`${route.route}`]);
      }
      this.close();

    } catch (_error) {
      this.close();
      return false;
    }
    this.close();
    return false;
  }



  onLanguageChange(selectedLanguage) {
    this.commonService.selectedLanguage.next(selectedLanguage.value);
    this.translate.use(selectedLanguage.value);
    if (Helpers.isLowerCaseEquals(selectedLanguage.value, 'fr')) {
      this.profileDetails1['profileMenuItems'] = [
        { name: "Demande d'accès", icon: 'manage_accounts', navUrl: '/requestAccess' }
        //  Commented coz not required as of now
        // { name: "Retour d'information", icon: 'feedback', navUrl: '/feedback' }
      ]
    }
    if (Helpers.isLowerCaseEquals(selectedLanguage.value, 'en')) {
      this.profileDetails1['profileMenuItems'] = [
        { name: 'User Profile', icon: 'person', navUrl: '/requestAccess' },
        { name: 'Request Access', icon: 'manage_accounts', navUrl: '/requestAccess' }
        //  Commented coz not required as of now
        // { name: 'Feedback', icon: 'feedback', navUrl: '/feedback' }
      ]
    }
    if (Helpers.isLowerCaseEquals(selectedLanguage.value, 'ja')) {
      this.profileDetails1['profileMenuItems'] = [
        { name: 'アクセスをリクエスト', icon: 'manage_accounts', navUrl: '/requestAccess' }
        //  Commented coz not required as of now
        // { name: 'フィードバック', icon: 'feedback', navUrl: '/feedback' }
      ]
    }
  }

}
