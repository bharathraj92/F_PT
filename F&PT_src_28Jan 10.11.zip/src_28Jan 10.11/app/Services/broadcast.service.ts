import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpErrorResponse, HttpResponse, HttpRequest } from '@angular/common/http';
import { Router } from '@angular/router';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class BroadcastService {

  alertStatus = new BehaviorSubject({ show: false, msg: '', title: '', type: '' });
  broadcastMessages = new BehaviorSubject([]);
  formObj: any = new BehaviorSubject({});
  serviceDown = new BehaviorSubject(false);
  timeout: any;

  constructor(private router: Router) {

  }
  handleError(error: HttpErrorResponse) {
    const messages: string[] = [];
    switch (error.status) {
      case 404:
        messages.push(error.error);
        this.broadcastMessages.next(messages);
        break;
      case 401:
        messages.push('Invalid Token');
        this.broadcastMessages.next(messages);
        break;
      case 500:
        messages.push(error.error.message);
        this.broadcastMessages.next(messages);
        break;
      case 409:
        messages.push(error.error);
        this.broadcastMessages.next(messages);
        break;
      case 400:
        if (typeof error.error === 'string' || error.error instanceof String) {
          messages.push(<string>error.error);
          this.broadcastMessages.next(messages);
          break;
        } else {
          const entries: any = Object.entries(error.error['fields']);
          _.forEach(entries, (entry) => {
            const control = document.querySelector('[formControlName=\'' + entry[0] + '\']');
            let label = '';
            if (control !== null) {
              label = control.getAttribute('data-label');
            }

            switch (entry[1][0]['code']) {
              case 'required':
                messages.push(`Field '${label}' is required.`);
                break;
              case 'duplicate':
                messages.push(`Record already exist!.`);
                break;
              case 'integer':
                messages.push(`${label} has to be an integer.`);
                break;
              case 'decimal':
                messages.push(`${label} has to be an integer or a decimal.`);
                break;
              case 'digits':
                messages.push(`${label} exceeds the possible precision of
                ${entry[1][0]['integerDigits']} integer and ${entry[1][0]['fractionalDigits']} fractional digits.`);
                break;
              case 'size':
                messages.push(`${label} size has to be min  of ${entry[1][0]['minSize']}
                 and max of ${entry[1][0]['maxSize']} characters.`);
                break;
              case 'min':
                messages.push(`${label} value has to be minimum of ${entry[1][0]['valueMin']}.`);
                break;
              case 'generic':
                messages.push(`Field '${label}' ${entry[1][0]['message']}.`);
                break;
              default:
                messages.push(`Field '${label}' didn't pass validation with error code '${entry[1][0]['code']}'.`);
                break;
            }
          });
          this.broadcastMessages.next(messages);
          break;
        }
      case 503:
        this.serviceDown.next(true);
        break;
    }
  }

  handleResponse(event: HttpResponse<any>, cloneReq: HttpRequest<any>) {
    if (cloneReq.method !== 'GET') {
      this.alertStatus.next({ show: true, msg: 'Completed Successfully', title: '', type: 'success' });
      this.broadcastMessages.next([]);
    }
  }
}
