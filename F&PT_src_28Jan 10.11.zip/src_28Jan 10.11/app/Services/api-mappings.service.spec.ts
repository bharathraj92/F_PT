import { TestBed } from '@angular/core/testing';

import { ApiMappingsService } from './api-mappings.service';

describe('ApiMappingsService', () => {
  let service: ApiMappingsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApiMappingsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
