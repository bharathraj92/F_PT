import { Injectable, Injector } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import * as _ from 'lodash';
import { first } from 'lodash';
import { last } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  userDetails = new BehaviorSubject({});
  currentview = new BehaviorSubject('');
  spinnerState = new BehaviorSubject(false);
  dynamicFormJson = new BehaviorSubject([]);
  bodyProductFamilyDetails = new Subject();
  erNumber = new BehaviorSubject('');
  saleOrderNumber = new BehaviorSubject('');
  soLiNumber =  new BehaviorSubject('');
  preConfigId = new BehaviorSubject('');
  cloneER = new BehaviorSubject('');
  activitiTreeData = new BehaviorSubject([]);
  selectedLanguage = new BehaviorSubject('');
  constructor(private http: HttpClient, private datePipe: DatePipe) {
  }

  initializeApp() {
    let headers = new HttpHeaders();
    headers = headers.set('Cache-Control', 'no-cache')
      .set('Pragma', 'no-cache')
      .set('X-Requested-With', 'XMLHttpRequest');

    const whoAmIObser = this.http.get('/api/engg-tool/who-am-i');
    const promise = whoAmIObser.toPromise()
      .then(resp => {
        this.userDetails.next(resp);      // Storing User Details
        //resp['roles']=[];// for Testing: User with no roles
        console.log(resp);
        return resp;
      }).catch(error => {
        console.error(error);
        window.location.reload(true);
      });
    return promise;
  }

  dateTimestamp(value) {
    if (value) {
      let selectedDate = new Date(value).getTime();
      const DateStr = selectedDate + '';
      selectedDate = Number(DateStr.substring(0, DateStr.length - 3));
      return selectedDate;
    }
  }
  // Utility functions
  dateTimeFormatter(val: any) {
    try {
      if (val !== undefined && this.isNumeric(val)) {
        if (val !== null && val !== 0) {
          if (val.toString().indexOf('.') > 0) {
            return this.datePipe.transform(new Date(val * 1000), 'dd-MMM-yyyy h:mm a').toString();
          } else {
            val = val.toString();
            return this.datePipe.transform(new Date(val * 1), 'dd-MMM-yyyy h:mm a').toString();
          }
        }
      }
    } catch (_error) {
      console.error('dateTimeFormatter -> ' + _error);
      return val;
    }
  }

  dateTimeFormatterMilliSeconds(val: any) {
    try {
      if (val !== undefined) {
        if (val !== null) {
          return this.datePipe.transform(new Date(val * 1000), 'dd-MMM-yyyy h:mm a').toString();
        }
      }
    } catch (_error) {
      console.error('dateTimeFormatterMilliSeconds -> ' + _error);
      return val;
    }
  }

  dateTimeFormatterCustom(val: any) {
    try {
      if (val !== null && val !== undefined && this.isNumeric(val)) {
        if (val.toString().indexOf('.') > 0) {
          return this.datePipe.transform(new Date(val * 1000), 'yyyy-MM-ddTHH:mm:ss') + '.000Z';
        } else {
          val = val.toString() + '.0000';
          return this.datePipe.transform(new Date(val * 1000), 'yyyy-MM-ddTHH:mm:ss') + '.000Z';
        }
      }
    } catch (_error) {
      console.error('dateTimeFormatterCustom -> ' + _error);
      return val;
    }
  }
  dateTimeFormatterWithoutZone(val: any) {
    try {
      if (val !== null && val !== undefined && this.isNumeric(val)) {
        if (val.toString().indexOf('.') > 0) {
          return this.datePipe.transform(new Date(val * 1000), 'yyyy-MM-ddTHH:mm:ss');
        } else {
          val = val.toString() + '.0000';
          return this.datePipe.transform(new Date(val * 1000), 'yyyy-MM-ddTHH:mm:ss');
        }
      }
    } catch (_error) {
      console.error('dateTimeFormatterCustom -> ' + _error);
      return val;
    }
  }
  dateFormatter(val: any) {
    try {
      if (val !== null && val !== undefined) {
        if (val.toString().indexOf('.') > 0) {
          return this.datePipe.transform(new Date(val * 1000), 'dd-MMM-yyyy').toString();
        } else {
          val = (val) ? val.toString() : '';
          return this.datePipe.transform(new Date(val * 1), 'dd-MMM-yyyy').toString();
        }
      }
    } catch (_error) {
      console.error('dateFormatter -> ' + _error);
      return val;
    }
  }

  isNumeric(value: any): boolean {
    return !isNaN(value - parseFloat(value));
  }

  isViewOnlyForCreatorAndReviewer(sso: any) {
    let roles = JSON.parse(localStorage.getItem("roles"));
    let role = roles.filter((obj: any) => obj.roleName == 'Site Administrator' || obj.roleName == 'Admin')
    if(roles && roles.length>0){
    if (localStorage.getItem("loggedInUser") == sso || (role && role.length > 0)) {
      return false;
    } else {
      return true;
    }
  }else{
    return true;
  }
  }
 
  getFullName(firstName: any, lastName: any) {
    let first = firstName == null ? "" : firstName;
    let last = lastName == null ? "" : lastName;
    return first + " " + last;
  }
//Allow Link Access
checkAccess(plant) {
  let hasAdminRole = localStorage.getItem("hasAdminRole");
  let userPlant = localStorage.getItem("userPlant");
  let siteAdmin =localStorage.getItem('siteAdmin');
  let siteAdminPlantCode = localStorage.getItem('siteAdminPlantCode');
  let allowLinkAccess = localStorage.getItem('linkAccess');
  let allowAccess = 'false';
  if (hasAdminRole == 'false') {
    if (allowLinkAccess == 'true') {
      allowAccess = 'true';
      if (plant != null) {
        if (userPlant == plant) {
          allowAccess = 'true';
        } else {
          allowAccess = 'false';
        }
      }
    }
  } else if (hasAdminRole == 'true') {
    allowAccess = 'true';
    if (siteAdmin === 'true') {
      if (siteAdminPlantCode == plant) {
        allowAccess = 'true';
      } else {
        allowAccess = 'false';
      }
    }
  }
  return allowAccess;
}  
//Check access to Force close
allowForceClose(plant){
  let hasAdminRole = localStorage.getItem("hasAdminRole");
  let siteAdmin =localStorage.getItem('siteAdmin');  
  let siteAdminPlantCode = localStorage.getItem('siteAdminPlantCode');
  let allowForceClose = 'false';
  if (hasAdminRole == 'true') {
    allowForceClose = 'true';
    if (siteAdmin === 'true') {
      if (siteAdminPlantCode == plant) {
        allowForceClose = 'true';
      } else {
        allowForceClose = 'false';
      }
    }
  }
  return allowForceClose;
}
//Edit Access
checkEditAccess(plant){
let erToolUser = localStorage.getItem("erToolUser");
let userPlant = localStorage.getItem("userPlant");
let allowEditAccess = 'false';
if(erToolUser == 'true'){
  if (plant != null) {
    if (userPlant == plant) {
      allowEditAccess = 'true';
    } else {
      allowEditAccess = 'false';
    }
  }
}
return allowEditAccess;
}
/// New Tab
setERInfo(soLiNumber: any ) {
  this.soLiNumber.next(soLiNumber);
  //this.cloneER.next(cloneER);
  //this.erNumber.next(erNumber);
}

getERInfo() {
  const result=[];
  result ["soLiNumber"] = localStorage.getItem('soLiNumber');
  localStorage.setItem("soLiNumber",'');
  return result;
}
///
}
