import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiMappingsService {
  baseAPIURL = '/api/engg-tool';
  constructor(private http: HttpClient) { }

  appendParamsToUrl(url, options): string {
    const params = new URLSearchParams();
    for (const key in options) { if (key) { params.set(key, options[key]); } }
    return Object.keys(options).length > 0 ? url + '?' + params.toString() : url;
  }
  /* make sure you append the function name with get/post/put */
  getWhoAMI() {
    return this.http.get(this.baseAPIURL + '/who-am-i');
  }
  // Get  ER Role Data
  getErtoolRolesData() {
    return this.http.get(this.baseAPIURL + '/getRolesData');
  }
  // Post Request Access
  submitAccessRequest(data) {
    return this.http.post(this.baseAPIURL + '/submitRequestAccess', data);
  }
  // Get Access Request Data
  getAccessRequests(approvalStatus: any, activeStatus: any) {
    return this.appendParamsToUrl(this.baseAPIURL + '/getRequestData', { approvalStatusId: approvalStatus, activeStatusId: activeStatus });
  }
  // Get Admin Filter Option
  getAdminFilterOption() {
    return this.http.get(this.baseAPIURL + '/getAdminFilterDropdown');
  }
  // Approve & Reject of request access
  approveOrRejectAccessRequest(data) {
    return this.http.post(this.baseAPIURL + '/approveOrRejectRequest', data);
  }
  // update request access
  onUpdateAccessRequest(data) {
    return this.http.post(this.baseAPIURL + '/updateUserStatus', data);
  }

  viewApprovers() {
    return this.http.get(this.baseAPIURL + '/getAllApprovers');
  }
  postFeedback(data) {
    return this.http.post(this.baseAPIURL + '/suggestions/create', data);
  }
  // Suggestions
  getSuggestionData() {
    return this.http.get(this.baseAPIURL + '/suggestions');
  }
  //getMasterDashboardCount
  getMasterDashboardCount() {
    return this.http.get(this.baseAPIURL + `/masterdashboard/getMasterDashboardCount`);
  }
  //getMasterDashboardHoldCount
  getMasterDashboardHoldCount() {
    return this.http.get(this.baseAPIURL + `/masterdashboard/getMasterDashboardHoldCount`);
  }
  //MasterDashboardData
  getMasterData(data) {
    return this.http.post(this.baseAPIURL + `/masterdashboard/getMasterData`, data);
  }
  //MasterDashboardData
  getMasterDashboardData(data) {
    // return this.http.get(this.baseAPIURL + `/masterdashboard`);
    return this.http.post(this.baseAPIURL + `/masterdashboard/getMyFiltersData`, data);
  }
  // get MyWorkflow MasterData
  getMasterDashboardExcelData(data) {
    return this.http.post(this.baseAPIURL + `/masterdashboard/getMyFiltersData/exportExcel`, data);
  }
  //MatrixFiltersData 
  getMatrixFiltersData() {
    return this.http.get(this.baseAPIURL + `/generaldashboard/getMatrixFilters`);
  }
  //GeneralDashboardData
  getGeneralDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/generaldashboard/getFiltersData`, data);
  }
  //WeekwiseDashboardData
  getWeekwiseDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/generaldashboard/getWeekwiseLobFiltersData`, data);
  }

  //Masoneilan Dashboard
  getMasoneilanDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/masoneilandashboard/getMasoneilanFiltersData`, data);
  }
  //PlantDashboardData
  getPlantDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/plantdashboard/getPlantFiltersData`, data);
  }
  //WIP ReportData
  getWipReportData(data) {
    return this.http.post(this.baseAPIURL + `/wipdashboard/getWipFiltersData`, data);
  }
  //Wip Deepdive Report Data
  getWipDeepdiveReportData(data) {
    return this.http.post(this.baseAPIURL + `/wipdashboard/getWipDeepDriveReport`, data);
  }
  //MyDashboardData
  getMyDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/masterdashboard/getMyWorkflowStatus`, data);
  }
  // get MyDashboard Excel Data
  getMyDashboardExcelData(data) {
    return this.http.post(this.baseAPIURL + `/masterdashboard/getMyWorkflowStatus/exportExcel`,data);
  }
  // get MyWorkflow MasterData
  getMyWorkflowMasterData() {
    return this.http.get(this.baseAPIURL + `/masterdashboard/getMyWorkflowMasterData`);
  }

  //Child ER Dashboard MasterData
  getChildERDashboardMasterData(data) {
    return this.http.post(this.baseAPIURL + `/erchilddashboard/getMasterData`, data);
  }
  //Child ER Dashboard Data
  getChildERDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/erchilddashboard/getFiltersData`, data);
  }
  //Child ER Dashboard Excel Data
  getChildERDashboardExcelData(data) {
    return this.http.post(this.baseAPIURL + `/erchilddashboard/getFiltersData/exportExcel`, data);
  }
  //NpcDashboardData
  getNpcDashboardMasterData(data) {
    return this.http.post(this.baseAPIURL + `/npcdashboard/getMasterData`, data);
  }
  //NpcDashboardData
  getNpcDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/npcdashboard/getFiltersData`, data);
  }
  //NpcDashboardData
  getNpcDashboardExcelData(data) {
    return this.http.post(this.baseAPIURL + `/npcdashboard/getFiltersData/exportExcel`, data);
  }
  //HoldDashboardData
  getHoldDashboardData(data) {
    return this.http.post(this.baseAPIURL + `/erholdDashboard/getholdDashboardData`, data);
  }
  // Suggestions
  getcommonoptions() {
    return this.http.get(this.baseAPIURL + `/common-options`);
  }
  //get Message History Data
  getMessageHistoryData(data) {
    return this.http.post(this.baseAPIURL + `/comments/getCommentsData`, data);
  }
  getPreConfigMasterEndUserType(soli: any) {
    // return this.http.get(this.baseAPIURL + `/erDetails/getPreConfigMasterData`);
    return this.http.get(this.baseAPIURL + `/erDetails/getPreConfigMasterData/${soli}`);
  }
  getPreConfigMasterData() {
    return this.http.get(this.baseAPIURL + `/erDetails/getPreConfigMasterData`);
  }
  getActuatorModelData() {
    return this.http.get(this.baseAPIURL + `/erDetails/getActuatorModelData`);
  }
  //clone services
  getCloneSequenceData(soli: any) {
    return this.appendParamsToUrl(this.baseAPIURL + `/clone/getCloneSequenceData`, { soli: soli });
  }
  getClonePreConfigMasterData() {
    return this.http.get(this.baseAPIURL + `/clone/getPreConfigMasterData`);
  }
  getCloneActuatorModelData() {
    return this.http.get(this.baseAPIURL + `/clone/getActuatorModelData`);
  }
  getCloneERSummaryInfo(salesOrder: any) {
    return this.http.get(this.baseAPIURL + `/clone/sapData/${salesOrder}`);
  }
  ////Automation for child ER Linking/De-linking
  saveChildReviewer(data) {///automate/saveReviewer
    return this.http.post(this.baseAPIURL + `/automate/saveReviewer`, data);
  }
  delinkCreator(moduleName, creatorId) {
    return this.http.get(this.baseAPIURL + `/automate/delinkCreator/${moduleName}/${creatorId}`);
  }
  //External Deliverable delink levelTwo Creator 
  delinklevelTwoCreator(moduleName, creatorId) {
    return this.http.get(this.baseAPIURL + `/automate/delinkReviewer/externalDeliverableslevelTwo/${creatorId}`);
  }
  //External Deliverable delink levelThree Creator 
  delinklevelThreeCreator(moduleName, creatorId) {
    return this.http.get(this.baseAPIURL + `/automate/delinkReviewer/externalDeliverableslevelthree/${creatorId}`);
  }
  delinkReviewer(moduleName, reviewerId) {
    return this.http.get(this.baseAPIURL + `/automate/delinkReviewer/${moduleName}/${reviewerId}`);
  }
  ////
  // Pre-Config Delete NPC
  deletePreConfigNPC(data, transactionId: any) {
    return this.http.put(this.baseAPIURL + `/erDetails/npcTransactionNumber/${transactionId}`, data);
  }
  getMasterErs(data) {
    return this.http.post(this.baseAPIURL + `/erDetails/searchMasterErs`, data);
  }
  getReferenceNpc(data) {
    return this.http.post(this.baseAPIURL + `/erDetails/getReferenceNpc`, data);
  }
  getReferenceDesign(data) {
    return this.http.post(this.baseAPIURL + `/design/searchDesignErs`, data);
  }
  getFilteredLevelDetails(soLiNumber: any) {
    return this.http.get(this.baseAPIURL + `/getFilteredLevelDetails/salesOrderNumber/${soLiNumber}`);
  }
  getERSummaryInfo(salesOrder: any) {
    return this.http.get(this.baseAPIURL + `/sapData/${salesOrder}`);
  }
  getERPreConfigInfo(erNumber: any) {
    return this.http.get(this.baseAPIURL + `/erDetails/${erNumber}`);
  }
  saveERPreConfigInfo(data) {
    return this.http.post(this.baseAPIURL + `/erDetails`, data);
  }
  //Submit
  submitERPreConfigInfo(data, id) {
    return this.http.put(this.baseAPIURL + `/erDetails/${id}`, data);
  }

  //  Scheduling Api
  // Get Scheduling Data
  getSchedulingData(erNumber: any) {
    return this.appendParamsToUrl(this.baseAPIURL + '/scheduling/getUserManualList', { erNumber: erNumber });
  }
  //getPreConfigScheduling
  getPreConfigScheduling(soli: any) {
    return this.appendParamsToUrl(this.baseAPIURL + '/scheduling/getPreConfigScheduling', { soli: soli });
  }
  // Post scheduling Form Data
  submitSchedulingData(data) {
    return this.http.post(this.baseAPIURL + '/scheduling/saveUserManualList', data);
  }
  // Get Scheduling Graph Data
  getSchedulingGraphData(ssoId: any) {
    return this.appendParamsToUrl(this.baseAPIURL + '/scheduling/getGraphData', { ssoId: ssoId });
  }
  //getBomStatusCounts
  getBomStatusCounts(preConfigId) {
    return this.appendParamsToUrl(this.baseAPIURL + '/statusCounts/bomStatusCounts', { preConfigId: preConfigId });
  }
  //getDesignStatusCounts
  getDesignStatusCounts(preConfigId) {
    return this.appendParamsToUrl(this.baseAPIURL + '/statusCounts/designStatusCounts', { preConfigId: preConfigId });
  }
  //Get Bom Config Data
  getpreConfigCommentData(preConfigId) {
    //return this.http.get(this.baseAPIURL + `/bom/getpreConfigCommentData/preConfigId${preConfigId}`);
    return this.appendParamsToUrl(this.baseAPIURL + '/bom/getpreConfigCommentData', { preconfigId: preConfigId });
  }
  //Get Bom Creator Data
  getBomCreatorData(preConfigIdNum) {
    return this.http.post(this.baseAPIURL + `/bom/getBomCreatorData`, { preConfigId: preConfigIdNum });
  }
  //Get Bom Reviewer Data
  getBomReviewerData(Id, bomCreatorId) {
    return this.http.post(this.baseAPIURL + `/bom/getBomReviewerData`, { preConfigId: Id, bomConfigCreatorId: bomCreatorId });
  }
  //Get Bom Release Data
  getBomReleaseData(preConfigIdNum) {
    return this.appendParamsToUrl(this.baseAPIURL + '/bom/getBomReleaseData', { preconfigId: preConfigIdNum });
  }
  //Save/Update Bom Config Data
  saveUpdatePreConfigData(data) {
    return this.http.post(this.baseAPIURL + `/bom/saveUpdatePreConfigCommentData`, data);
  }
  //Save Bom Creator Data
  saveBomCreator(data) {
    return this.http.post(this.baseAPIURL + `/bom/saveBomCreator`, data);
  }
  //Save Bom Reviewer Data
  saveBomReviewer(data) {
    return this.http.post(this.baseAPIURL + `/bom/saveBomReviewer`, data);
  }
  //Save Bom Release Data
  saveUpdateBomReleaseData(data) {
    return this.http.post(this.baseAPIURL + `/bom/saveUpdateBomReleaseData`, data);
  }
  /////   Bom Design   //////
  getDesignLevelOneData(preConfigId) {
    return this.http.get(this.baseAPIURL + `/design/getDesignLevelOneData/${preConfigId}`);
  }
  savedDesignLevelOne(data) {
    return this.http.put(this.baseAPIURL + `/design/updateDesignLevelOne`, data);
  }
  getDesignLevelFourData(preConfigId) {
    // return this.appendParamsToUrl(this.baseAPIURL + '/design/getDesignLevelFourData/', { preConfigId });
    return this.http.get(this.baseAPIURL + `/design/getDesignLevelFourData/${preConfigId}`);
  }
  //GetDesign Creator Data
  getDesignCreatorData(preConfigIdNum) {
    return this.http.post(this.baseAPIURL + `/design/getDesignCreatorData`, { preConfigId: preConfigIdNum });
  }
  //Save Design Creator Data
  saveDesignCreator(data) {
    return this.http.post(this.baseAPIURL + `/design/saveDesignCreator`, data);
  }
  //GetDesign Creator Data
  getDesignReviewerData(preConfigIdNum) {
    return this.http.post(this.baseAPIURL + `/design/getDesignReviewerData`, { preConfigId: preConfigIdNum });
  }
  //Save Design Creator Data
  saveDesignReviewer(data) {
    return this.http.post(this.baseAPIURL + `/design/saveDesignReviewer`, data);
  }

  //Get NPC Data
  getNpcData(preConfigIdNum) {
    return this.http.post(this.baseAPIURL + `/npc/getNpcData`, { parentId: preConfigIdNum });
  }

  //Get NPC Data
  saveNpcData(data: any) {
    return this.http.post(this.baseAPIURL + `/npc/saveNpcData`, data);
  }

  //Get Creator Data
  getCreatorData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/getExternalDelivarablesCreatorData`, { preConfigId: preConfigIdNum });
  }

  //Get Reviewer Data
  getReviewerData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/getExternalDelivarablesReviewerData`, { preConfigId: preConfigIdNum });
  }

  //Save External Deliverable Creator Data
  saveCreator(data: any) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/saveUpdateEdCreatorData`, data);
  }

  //Save External Deliverable Reviewer Data
  saveReviewer(data: any) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/saveUpdateEdReviewerData`, data);
  }

  getReferenceExternalDeliverable(data) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/searchEdErs`, data);
  }

  getCalculationsCreatorData(preConfigIdNum: any) {
    return this.http.get(this.baseAPIURL + `/calculations/getCalculationsCreatorData/${preConfigIdNum}`);
  }

  getExternalDeliverableLevelOneData(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/externaldelivarables/getEdLevelOneData/${preConfigId}`);
  }

  //Save Calculations Creator Data
  saveCalculationsCreator(data: any) {
    return this.http.post(this.baseAPIURL + `/calculations/saveCalculationsCreator`, data);
  }

  //Save External Deliverables Level 1 Data
  savedExternalDeliverablesLevelOne(data: any) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/saveOrUpdateCommentsData`, data);
  }

  //Get Calculations Reviewer Data
  getCalculationsReviewerData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/calculations/getCalculatiosLevelTwoReviewerData`, { preConfigId: preConfigIdNum });
  }

  //Save Calculations Reviewer Data
  saveCalculationsReviewerData(data: any) {
    return this.http.post(this.baseAPIURL + `/calculations/saveUpdateCalculatiosnLevelTwoReviewerData`, data);
  }

  getReferenceExternalLevelTwoDeliverable(data: any) {
    return this.http.post(this.baseAPIURL + `/externaldelivarables/searchLevelTwoEdErs`, data);
  }


  getTestLevelOneData(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/test/getTestLevelOneData/${preConfigId}`);
  }

  //Save Test Level 1 Data
  savedTestLevelOneData(data: any) {
    return this.http.post(this.baseAPIURL + `/test/saveOrUpdateCommentsData`, data);
  }


  //Save Calculations Level 1 Data
  savedCalculationsLevelOneData(data: any) {
    return this.http.post(this.baseAPIURL + `/calculations/saveOrUpdateCommentsData`, data);
  }

  getCalculationsLevelOneData(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/calculations/getCaluculationLevelOneData/${preConfigId}`);
  }

  //Save Other Engineering Activities Level 1 Data
  saveOtherEngineeringActivitiesLevelOneData(data: any) {
    return this.http.post(this.baseAPIURL + `/otherenggactivities/saveOrUpdateCommentsData`, data);
  }

  getOtherEngineeringActivitiesLevelOneData(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/otherenggactivities/getOtherEnggActivitiesLevelOneData/${preConfigId}`);
  }

  //Save Quality Activities Level 1 Data
  saveQualityactivitiesLevelOneData(data: any) {
    return this.http.post(this.baseAPIURL + `/qualityactivities/saveOrUpdateCommentsData`, data);
  }

  getQualityactivitiesLevelOneData(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/qualityactivities/getQualityActivitiesLevelOneData/${preConfigId}`);
  }

  //Get Test Creator Data
  getTestCreatorData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/test/getTestLevelTwoCreatorData`, { preConfigId: preConfigIdNum });
  }

  // save Creator  Data
  saveTestCreator(data: any) {
    return this.http.post(this.baseAPIURL + `/test/saveUpdateTestLevelTwoCreatorData`, data);
  }


  //Get Test Reviewer Data
  getTestReviewerData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/test/getTestLevelTwoReviewerData`, { preConfigId: preConfigIdNum });
  }

  // save Test Reviewer  Data
  saveTestReviewerData(data: any) {
    return this.http.post(this.baseAPIURL + `/test/saveUpdateTestLevelTwoReviewerData`, data);
  }

  getReferenceTest(data) {
    return this.http.post(this.baseAPIURL + `/test/searchTestLevelTwoData`, data);
  }

  //Get Other Engg Activities Creator Data
  getOtherEngineeringCreatorData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/otherenggactivities/getOEALevelTwoCreatorData`, { preConfigId: preConfigIdNum });
  }

  // save Other Engg Activities Creator  Data
  saveOtherEngineeringCreatorData(data: any) {
    return this.http.post(this.baseAPIURL + `/otherenggactivities/saveUpdateOEALevelTwoCreatorData`, data);
  }


  //Get Other Engg Activities Reviewer Data
  getOtherEngineeringReviewerData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/otherenggactivities/getOEALevelTwoReviewerData`, { preConfigId: preConfigIdNum });
  }

  // save Other Engg Activities Reviewer  Data
  saveOtherEngineeringReviewerData(data: any) {
    return this.http.post(this.baseAPIURL + `/otherenggactivities/saveUpdateOEALevelTwoReviewerData`, data);
  }

  getReferenceOtherengineeringActivities(data) {
    return this.http.post(this.baseAPIURL + `/otherenggactivities/searchOEALevelTwoData`, data);
  }


  //Get  Quality Activities Creator Data
  getQualityActivitiesCreatorData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/qualityactivities/getQALevelTwoCreatorData`, { preConfigId: preConfigIdNum });
  }

  //Get Quality Activities Reviewer Data
  getQualityActivitiesReviewerData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/qualityactivities/getQALevelTwoReviewerData`, { preConfigId: preConfigIdNum });
  }

  //Save Quality Activities External Deliverable Creator Data
  saveQualityActivitiesCreatorData(data: any) {
    return this.http.post(this.baseAPIURL + `/qualityactivities/saveUpdateQALevelTwoCreatorData`, data);
  }

  //Save Quality Activities External Deliverable Creator Data
  saveQualityActivitiesReviewer(data: any) {
    return this.http.post(this.baseAPIURL + `/qualityactivities/saveUpdateQALevelTwoReviewerData`, data);
  }

  getReferenceQualityActivities(data: any) {
    return this.http.post(this.baseAPIURL + `/qualityactivities/searchQALevelTwoData`, data);
  }

  getReferenceCalculationsData(data: any) {
    return this.http.post(this.baseAPIURL + `/calculations/searchCalculationsLevelTwoData`, data);
  }

  //getNpcStatusCounts
  getNpcStatusCounts(preConfigId: any) {
    return this.appendParamsToUrl(this.baseAPIURL + '/statusCounts/npcStatusCounts', { preConfigId: preConfigId });
  }

  //Get sub NPC Data
  getSubNpcData(preConfigIdNum: any) {
    return this.http.post(this.baseAPIURL + `/npc/getMasterSubNpc`, { parentId: preConfigIdNum });
  }

  //upload Attachments
  uploadAttachments(preConfigId: any, file: any, comments: any, moduleName: any) {
    const formData: FormData = new FormData();
    for (var x = 0; x < file.length; x++) {
      formData.append('files', file[x]);
    }
    formData.append('notes', comments ? comments : ""),
      formData.append('moduleName', moduleName)

    return this.http.post(this.baseAPIURL + `/attachments/uploadAttachmentsToS3/${preConfigId}`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  }

  deleteAttachments(preConfigId: any, attachmentId: any) {
    return this.http.delete(this.baseAPIURL + `/attachments/deleteAttachmentFromS3/${preConfigId}/${attachmentId}`);
  }

  downloadAttachments(preConfigId: any, attachmentId: any) {
    return this.http.get(this.baseAPIURL + `/attachments/downloadFileFromS3/${preConfigId}/${attachmentId}`);
  }

  getAllTasks() {
    return this.http.get(this.baseAPIURL + `/attachments/getAllTasks`);
  }

  getAllAttachments(preConfigId: any, moduleName: any) {
    return this.http.get(this.baseAPIURL + `/attachments/getAllAttachmentsFromS3/${moduleName}/${preConfigId}`);
  }

  isSchedulingAndPlanningDone(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/scheduling/isSchedulingDone?preConfigId=${preConfigId}`);
  }

  //Force Close
  forceClose(data: any) {
    return this.http.post(this.baseAPIURL + `/forceClose`, data);
  }

  getChildERData(data: any) {
    return this.http.post(this.baseAPIURL + `/childRelationshipData/getChildErData`, data);
  }

  getCreatorId(data: any) {
    return this.http.post(this.baseAPIURL + `/getForceCloseCreatorId`, data);
  }

  //save hold Data
  saveHoldData(data: any) {
    return this.http.post(this.baseAPIURL + `/erholdDashboard/updateHoldCommentsData`, data);
  }

  //Get BOM Types
  getBomTypes() {
    return this.http.get(this.baseAPIURL + `/bom/getBomTypeData`);
  }

  //save BOM Type
  saveBomType(data: any) {
    return this.http.post(this.baseAPIURL + `/bom/saveUpdateBomTypeReleaseData `, data);
  }
  //Plant dashboard Resource graph
  getPlantUsersData(data: any) {
    return this.http.post(this.baseAPIURL + `/plantdashboard/getPlantUsersData`, data);
  }

  getPlantUserFiltersData(data: any) {
    return this.http.post(this.baseAPIURL + `/plantdashboard/getPlantUserFiltersData`, data);
  }
  //Plant dashboard Resource graph

  //get user list
  getUserList(plant: any) {
    return this.http.get(this.baseAPIURL + `/masterdashboard/massUpdate/getUserList?plant=${plant}`);
  }

  saveAssigneeList(data: any) {
    return this.http.post(this.baseAPIURL + `/masterdashboard/massUpdate/saveAssigneeList`, data);
  }

  saveGeneralcomments(data: any) {
    return this.http.post(this.baseAPIURL + `/masterdashboard/massUpdate/saveGeneralcomments`, data);
  }
  //Get complete Timelog
  getTimelog(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/completeTimelog/${preConfigId}`);
  }
  //Support Team Level 4
  getSupportUserList(preConfigId, siteId, moduleName, levelFourId) {
    return this.http.get(this.baseAPIURL + `/design/getSupportUserList/${preConfigId}/${siteId}/${moduleName}/${levelFourId}`);
  }
  //get Mcode Data
  getMcodeData() {
    return this.http.get(this.baseAPIURL + `/mcode/getAllMcodeData`);
  }
  //update McodeData
  updateMcodeData(data, mCodeId) {
    return this.http.put(this.baseAPIURL + `/mcode/${mCodeId}`, data);
  }
  //save McodeData
  addMcodeData(data: any) {
    return this.http.post(this.baseAPIURL + `/mcode/saveMcodeData`, data);
  }
  //get Mcode History Data
  getMcodeHistoryData(mCodeId) {
    return this.http.get(this.baseAPIURL + `/mcode/getMcodeHistoryData/${mCodeId}`);
  }
  //get Mcode History Data
  getMcodeDesc(mCode) {
    return this.http.get(this.baseAPIURL + `/mcode/getMcodeData/${mCode}`);
  }
  //get Mcode History Data
  getDemoteDesc() {
    return this.http.get(this.baseAPIURL + `/admindashboard/getModuleData`);
  }
  //get Demote Excel Data
  getDemoteExcelData() {
    return this.http.get(this.baseAPIURL + `/admindashboard/getDemoteData`);
  }
  //Update Reopen Status
  updateMassReopen(data: any) {
    return this.http.put(this.baseAPIURL + `/sapData/updateSapStatus`, data);
  }
  //Get complete Timelog
  getActivityTreeTimelog(preConfigId: any) {
    return this.http.get(this.baseAPIURL + `/completeTimelog/activityTree/${preConfigId}`);
  }
  //Get Product Hierarchy Validation in Master Dashboard
  getProductHierarchyData(salesOrderNumber: any) {
    return this.http.get(this.baseAPIURL + `/sapData/getPhData/${salesOrderNumber}`);
  }
  // getPhAuditTrail
  getPhAuditTrail(salesOrderNumber: any) {
    return this.http.get(this.baseAPIURL + `/erDetails/getPhAuditTrail/${salesOrderNumber}`);
  }
  // NPC Combination check
  npcValidation(data: any) {
    return this.http.post(this.baseAPIURL + `/npc/npcValidation`, data);
  }
  // Part Number Validation
  partNumberValidation(data: any) {
    return this.http.post(this.baseAPIURL + `/npc/npcPartNumValidation`, data);
  }
  // Get Part Status Data
  getPartStatusData(data: any) {
    return this.http.post(this.baseAPIURL + `/npc/getNpcData/npcSapValidation`, data);
  }
}


