import { Component, OnInit, ViewChild, Injector, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatSort } from '@angular/material/sort';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { BhAlertService } from 'bh-theme';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-suggestions',
  templateUrl: './suggestions.component.html',
  styleUrls: ['./suggestions.component.scss']
})
export class SuggestionsComponent implements OnInit {
  displayedColumns: string[] = ['appModule', 'suggestionType', 'suggestionDesc', 'createdBy', 'createdDate'];

  dataSource = new MatTableDataSource<SuggestionElement>(ELEMENT_DATA);
  selection = new SelectionModel<SuggestionElement>(true, []);
  selectedRowIndex: number;
  suggestionList = [];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('suggestion') suggestionTable: MatTable<SuggestionElement>;
  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private dialog: MatDialog, private bhAlertService: BhAlertService) { }

  ngOnInit(): void {
    this.commonService.currentview.next('Admin > Suggestions');
    this.getSuggestionData();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
  getSuggestionData() {
    this.apiMappingsService.getSuggestionData().subscribe((suggestionList: []) => {
      this.suggestionList = suggestionList;
      this.prepareTableData(suggestionList);
    });
  }

  prepareTableData(suggestionList) {
    ELEMENT_DATA = [];
    for (const suggestion of suggestionList) {
      const date = new Date(suggestion.changeTracking.modifiedDate * 1000);
      const row = {
        appModule: suggestion.appModule,
        suggestionType: suggestion.suggestionType,
        suggestionDesc: suggestion.suggestionDesc,
        createdBy: suggestion.changeTracking.createdBy.firstName + ' ' + suggestion.changeTracking.createdBy.lastName + '(' + suggestion.changeTracking.createdBy.sso + ')',
        createdDate: date.getUTCDate() + '-' + (date.getUTCMonth() + 1) + '-' + date.getUTCFullYear()

      };
      ELEMENT_DATA.push(row);
    }
    this.dataSource.data = ELEMENT_DATA;
  }
}
export interface SuggestionElement {
  appModule: string;
  suggestionType: string;
  suggestionDesc: string;
}
let ELEMENT_DATA: SuggestionElement[] = [];
