import { Component, OnInit } from '@angular/core';

import { MatToolbarModule } from '@angular/material/toolbar';
import { Router } from '@angular/router';///
import { FormGroup, FormBuilder } from '@angular/forms';
import { ApiMappingsService } from '../Services/api-mappings.service';
import { CommonService } from '../Services/common.service';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
//import { McodeHistoryModalComponent } from './mcode-history-modal/mcode-history-modal.component';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  panelOpenState = true;
  navLinks: any[];
  activeLinkIndex = -1;
  enableFlag: any;
  //mcodeHistoryModal: MatDialogRef<McodeHistoryModalComponent>;
  constructor(private router: Router,
    //public formBuilder: FormBuilder,
    private apiMappingsService: ApiMappingsService,
    private commonservice: CommonService,
    public dialog: MatDialog
  ) {
    //this.enableFlag = localStorage.getItem("EnableTabs");//disableBom
    this.enableFlag = localStorage.getItem("disableBom");//disableBom
    this.prepareNavLink();
  }
  ngOnInit(): void {
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });

    // if (this.erNumber && this.router.url === '/enggTool/summaryInfo') {
    //   // else if (this.erNumber && this.router.url === '/enggTool/preConfig') {
    //   this.getERPreConfigInfo(this.erNumber);
    // }else if ((this.soLiNumber && this.router.url === '/enggTool/summaryInfo') || this.erNumber === '') {
    //   this.getERSummaryInfo(this.soLiNumber);
    // } 


  }
  getActiveClass(indexOfRouteLink) {
    let tabsclass = 'mat-tab-link';
    if (this.activeLinkIndex === indexOfRouteLink) {
      tabsclass = 'mat-tab-link mat-tab-label-active';
    }
    return tabsclass;
  }

  prepareNavLink() {
    this.navLinks = [
      {
        label: 'Manage Access',
        link: './manageAccess',
        index: 0,
        enabled: true
      }, {
        label: 'M-Code Master',
        link: './mCodeData',
        index: 1,
        enabled: true
      },
      {
        label: 'Demote',
        link: './demoteData',
        index: 2,
        enabled: true
      },
      // {
      //   label: 'BOM',
      //   link: './bomConfig',
      //   index: 3,
      //   enabled: enableFlag
      // }, {
      //   label: 'ENGINEERING-DOC',
      //   link: './configuration',
      //   index: 4,
      //   enabled: enableFlag
      // }, {
      //   label: 'QUALITY-DOC',
      //   link: './qualityDoc',
      //   index: 5,
      //   enabled: enableFlag
      // },
      // {
      //   label: 'ATTACHMENTS',
      //   link: './attachments',
      //   index: 6,
      //   enabled: enableFlag
      // },{
      //   label: 'HISTORY',
      //   link: './history',
      //   index: 7,
      //   enabled: true
      // },
    ];
  }
//show Mcode History Modal 
// showMcodeHistoryModal(mCodeId) {
//   if (mCodeId !== null) {
//     this.mcodeHistoryModal = this.dialog.open(McodeHistoryModalComponent, { data: { mCodeId:mCodeId } });
//     this.mcodeHistoryModal.afterClosed().subscribe(value => {
//       if (value) {
//       }
//     });
//   } else {
//     //this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select field.!');
//   }
// }
  // isSchedulingAndPlanningDone(erNumber: any) {
  //   if (erNumber) {
  //     let preConfigId = erNumber.split("-")[3];
  //     this.apiMappingsService.isSchedulingAndPlanningDone(preConfigId).subscribe((data: any) => {
  //       if (data) {
  //         localStorage.setItem("disableBom", "false");
  //         this.prepareNavLink(data);
  //       } else {
  //         if (erNumber.split("-")[4] && erNumber.split("-")[4] == 'NPC') {
  //           localStorage.setItem("disableBom", "true");
  //         } else {
  //           localStorage.setItem("disableBom", "false");
  //         }
  //         this.prepareNavLink(data);
  //       }
  //     });
  //   } else {
  //     localStorage.setItem("disableBom", "false");
  //     this.prepareNavLink(false);
  //   }
  // }

  //get ER Summary Info
  // getERSummaryInfo(soLiNumber) {
  //   this.apiMappingsService.getERSummaryInfo(soLiNumber).subscribe((data: []) => {
  //     if (data) {
  //       this.bannerData = data;
  //       this.bannerForm.patchValue(this.bannerData);
  //       //Date format change
  //       this.bannerForm.get('erRequestDate').patchValue(data['erRequestDate'] != null ? (this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy')) : null);
  //       this.bannerForm.get('enggCompletionDate').patchValue(data['enggCompletionDate'] != null ? this.datePipe.transform((data['enggCompletionDate'] * 1000), 'dd-MMM-yyyy') : null);
  //     }
  //   });
  // }
  // //get ER Summary Info
  // getERPreConfigInfo(erNumber) {
  //   this.apiMappingsService.getERPreConfigInfo(erNumber).subscribe((data: []) => {
  //     if (data) {
  //       this.bannerData = data;
  //       this.bannerForm.patchValue(this.bannerData);
  //       localStorage.setItem('soLiNumber', this.bannerData['soli']);
  //       localStorage.setItem('preConfigId', this.bannerData['id']);
  //       //Date format change
  //       // this.bannerForm.get('erRequestDate').patchValue(this.datePipe.transform((data['erRequestDate'], 'dd-MMM-yyyy'));
  //       this.bannerForm.get('erRequestDate').patchValue(data['erRequestDate'] != null ? (this.datePipe.transform((data['erRequestDate'] * 1000), 'dd-MMM-yyyy')) : null);

  //     }
  //   });
  // }
  //show Message History Modal 
  // showMessageHistoryModal(task, user, item, field) {
  //   if (field !== null) {
  //     this.messageHistoryModal = this.dialog.open(MessageHistoryModalComponent, { data: { task: task, user: user, item: item, fieldName: field } });
  //     this.messageHistoryModal.afterClosed().subscribe(value => {
  //       if (value) {
  //       }
  //     });
  //   } else {
  //     //this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select field.!');
  //   }
  // }
  //
}
