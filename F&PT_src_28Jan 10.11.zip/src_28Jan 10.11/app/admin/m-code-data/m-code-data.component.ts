import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AdminComponent } from '../admin.component';
//import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { MCodeHistoryModalComponent } from '../mcode-history-modal/mcode-history-modal.component';
//import { ChangeBomTypeModalComponent } from '../change-bom-type-modal/change-bom-type-modal.component';

@Component({
  selector: 'app-m-code-data',
  templateUrl: './m-code-data.component.html',
  styleUrls: ['./m-code-data.component.scss']
})
export class MCodeComponent implements OnInit {
  mCodeForm: FormGroup;
  mCodeId: any;
  mcodeInput: any;
  mcodeDescInput: any;
  revisionNumInput: any;
  plantInput: any;
  mcode_flagInput: boolean;
  mcode_flag_statusInput: any;
  editFlag = false;
  plantList: any;
  mCodeTableData;
  search;
  filterValues = {};
  mcodeHistoryModal: MatDialogRef<MCodeHistoryModalComponent>;
  displayedColumns: string[] = [
    'mcode',
    'mcodeDesc',
    'revisionNum',
    'plant',
    'mcode_flag_status',
    'mCodeEdit',
    'history'
  ];
  statusList = [
    {flag:true , status:'Enabled'},
    {flag:false , status:'Disabled'}
  ]
  dataSource = new MatTableDataSource<MCodeDataInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<MCodeDataInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('mCodeData') mCodeDataTable: MatTable<MCodeDataInterface>;
  //@ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  //ChildErForceClosureModal: MatDialogRef<NpcForceCloseComponent>;
  //HoldEditModal: MatDialogRef<HoldEditModalComponent>;


  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder,
     private http: HttpClient, public router: Router, private element: ElementRef, public dialog: MatDialog) {

    // 
    // this.commonService.userDetails.subscribe(val => {
    //   this.logginUserFirstName = val['firstName'];
    //   this.currentDate = new Date();
    // });

    // Object to create Filter for

  }


  ngOnInit(): void {
    this.mcode_flagInput = true;
    this.getMcodeData();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    //this.toggleAllSelection()
  }

  getMcodeData() {
    // Uncomment below line of code once api is done and comment mock
    // this.mCodeTableData = [];
    // this.prepareTableData(this.mCodeTableData);
    this.apiMappingsService.getMcodeData().subscribe((data) => {
      if (data) {
        this.plantList = data['plantMaster'];
        this.mCodeTableData = data['listOfMcodeData'];
        this.prepareTableData(this.mCodeTableData);
      }
    });
  }

  prepareTableData(mCodeTableData) {
    ELEMENT_DATA = [];
    mCodeTableData.forEach(mCodeData => {
      ELEMENT_DATA.push({
        mCodeId: mCodeData.id,
        mcode: mCodeData.mcode,
        mcodeDesc: mCodeData.mcodeDesc,
        revisionNum: mCodeData.revisionNum,
        mcode_flag: mCodeData.mcode_flag,
        mcode_flag_status: mCodeData.mcode_flag_status,
        plantName: mCodeData.plantName,
        plant: mCodeData.plant,
      });
    });
    this.dataSource.data = ELEMENT_DATA;

  }
  onSearchERRequest(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);

  }
  reset() {
    this.mCodeId = null;
    this.mcodeInput = null;
    this.mcodeDescInput = null;
    this.revisionNumInput = null;
    this.mcode_flagInput = true;
    this.plantInput = null;
    this.editFlag = false;
    this.mcode_flag_statusInput = 'Enabled';
    this.search = "";
    this.dataSource.filter = "";
    //this.onSearch();
  }

  // edit M Code
  mCodeEdit(element: any) {
    this.mCodeId = element.mCodeId;
    this.mcodeInput = element.mcode;
    this.mcodeDescInput = element.mcodeDesc;
    this.revisionNumInput = element.revisionNum;
    this.mcode_flagInput = element.mcode_flag;
    this.mcode_flag_statusInput = element.mcode_flag_status;
    this.plantInput = element.plant.toString();
    this.editFlag = true;
    //this.getMcodeData();
  }
  addMcodeData() {
    let formData = {};
    formData['id'] = 0,
      formData['mcode'] = this.mcodeInput,
      formData['plant'] = this.plantInput,
      formData['mcodeDesc'] = this.mcodeDescInput,
      formData['mcode_flag'] = this.mcode_flagInput,
      formData['revisionNum'] = this.revisionNumInput,
      this.apiMappingsService.addMcodeData(formData).subscribe((data: []) => {
        if (data) {
          console.log(data);
          this.reset();
          this.getMcodeData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'M-Code Data added Successfully!');
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to added M-Code Data!');
        }
      });
  }

  updateMcodeData() {
    let formData = {};
    const mCodeId = this.mCodeId;
    formData['id'] = this.mCodeId,
      formData['mcode'] = this.mcodeInput,
      formData['plant'] = this.plantInput,
      formData['mcodeDesc'] = this.mcodeDescInput,
      formData['mcode_flag'] = this.mcode_flagInput,
      formData['revisionNum'] = this.revisionNumInput,
      this.apiMappingsService.updateMcodeData(formData, mCodeId).subscribe((data) => {
        if (data) {
          console.log(data);
          this.reset();
          this.getMcodeData();
          this.bhAlertService.showAlert('success', 'top', 5000, 'M-Code Data updated Successfully!');
        } else {
          this.bhAlertService.showAlert('warning', 'top', 5000, 'Failed to Update M-Code Data!');
        }
      });
  }
   //show Mcode History Modal popup
  //  showMcodeHistoryModal(task, user, item, field) {
  //   this.enggToolComponent.showMcodeHistoryModal(task, user, item, field);
  // }
   //show Mcode History Modal 
    showMcodeHistoryModal(elementId) {
    ////this.adminComponent.showMcodeHistoryModal(mCodeId);
    if (elementId !== null) {
      this.mcodeHistoryModal = this.dialog.open(MCodeHistoryModalComponent, { data: { mCodeId:elementId } });
      this.mcodeHistoryModal.afterClosed().subscribe(value => {
        if (value) {
        }
      });
    } else {
      //this.bhAlertService.showAlert('warning', 'top', 5000, 'Please select field.!');
    }
   }
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("mCodeData");
  }

  exportArray() {
    const onlyNameAndSymbolArr: Partial<MCodeDataInterface>[] = this.mCodeTableData.map(mCodeData => ({
      mcode: mCodeData.mcode,
      mcodeDesc: mCodeData.mcodeDesc,
      revisionNum: mCodeData.revisionNum,
      status: mCodeData.mcode_flag_status,
      plant: mCodeData.plantName,
    }));
    ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "mCodeMasterData");
    //F&PT_NpcDashboardData
  }
}


export interface MCodeDataInterface {
  mCodeId: number;
  plant: number;
  plantName: string;
  mcode: string;
  mcodeDesc: string;
  revisionNum: string;
  mcode_flag: boolean;
  mcode_flag_status: string;
}
export interface MCodeComponentData {
  animal: string;
  name: string;
} 
let ELEMENT_DATA: MCodeDataInterface[] = [];
