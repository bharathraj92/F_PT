import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MCodeComponent } from './m-code-data.component';

describe('MCodeComponent', () => {
  let component: MCodeComponent;
  let fixture: ComponentFixture<MCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MCodeComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
