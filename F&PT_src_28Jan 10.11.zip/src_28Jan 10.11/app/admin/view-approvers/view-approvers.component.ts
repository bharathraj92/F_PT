import { Component, OnInit, Injector, ViewChild } from '@angular/core';
import * as apiMappings from '../../Services/api-mappings.service';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-view-approvers',
  templateUrl: './view-approvers.component.html',
  styleUrls: ['./view-approvers.component.scss']
})
export class ViewApproversComponent implements OnInit {

  displayedColumns = ['select', 'SSO Id', 'First Name', 'Last Name', 'Plant Name'];

  //admin
  adminListDataSource = new MatTableDataSource<RoleInterface>();
  adminSelection = new SelectionModel<any>(true, []);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild('adminRoleList') adminRoleTable: MatTable<RoleInterface>;
  @ViewChild('adminRolePaginator', { static: true }) adminRolePaginator: MatPaginator;
  @ViewChild('adminRoleList', { static: true }) adminRoleSort: MatSort;

  //planner
  plannerListDataSource = new MatTableDataSource<RoleInterface>();
  plannerSelection = new SelectionModel<any>(true, []);
  @ViewChild('plannerRoleList') plannerRoleTable: MatTable<RoleInterface>;
  @ViewChild('plannerRolePaginator', { static: true }) plannerRolePaginator: MatPaginator;
  @ViewChild('plannerRoleList', { static: true }) plannerRoleSort: MatSort;

  //inspector
  inspectorListDataSource = new MatTableDataSource<RoleInterface>();
  inspectorSelection = new SelectionModel<any>(true, []);
  @ViewChild('inspectorRoleList') inspectorRoleTable: MatTable<RoleInterface>;
  @ViewChild('inspectorRolePaginator', { static: true }) inspectorRolePaginator: MatPaginator;
  @ViewChild('inspectorRoleList', { static: true }) inspectorRoleSort: MatSort;

  //viewer
  viewerListDataSource = new MatTableDataSource<RoleInterface>();
  viewerSelection = new SelectionModel<any>(true, []);
  @ViewChild('viewerRoleList') viewerRoleTable: MatTable<RoleInterface>;
  @ViewChild('viewerRolePaginator', { static: true }) viewerRolePaginator: MatPaginator;
  @ViewChild('viewerRoleList', { static: true }) viewerRoleSort: MatSort;

  protected apiMapping: apiMappings.ApiMappingsService;
  constructor(protected injector: Injector, private commonService: CommonService) {
    this.apiMapping = this.injector.get(apiMappings.ApiMappingsService);
  }

  ngOnInit() {
    this.getAllApproversList();
    this.commonService.currentview.next('View Approvers');
  }
  ngAfterViewInit() {
    //admin
    this.adminListDataSource.paginator = this.adminRolePaginator;
    this.adminListDataSource.sort = this.adminRoleSort;
    //planner
    this.plannerListDataSource.paginator = this.plannerRolePaginator;
    this.plannerListDataSource.sort = this.plannerRoleSort;
    //inspector
    this.inspectorListDataSource.paginator = this.inspectorRolePaginator;
    this.inspectorListDataSource.sort = this.inspectorRoleSort;
    //viewer
    this.viewerListDataSource.paginator = this.viewerRolePaginator;
    this.viewerListDataSource.sort = this.viewerRoleSort;
  }
  prepareTableData(allRoleList) {
    for (let key in allRoleList) {
      allRoleData[key]=[];
      if (allRoleList[key].length > 0) {
        allRoleList[key].forEach(value => {
          allRoleData[key].push({
            'SSO Id': value.ssoId,
            'First Name': value.firstName,
            'Last Name': value.lastName,
            'Plant Name': value.plantName
          })
        });
      }
    }
    this.adminListDataSource.data = allRoleData.adminList;
    this.plannerListDataSource.data = allRoleData.plannerList;
    this.inspectorListDataSource.data = allRoleData.inspectorList;
    this.viewerListDataSource.data = allRoleData.viewerList;
  }
  getAllApproversList() {
    this.apiMapping.viewApprovers().subscribe(response => {

      if (response) {
        this.prepareTableData(response)
      }
    });
  }
  isAllSelected(role) {
    const numSelected = role == 'admin' ? this.adminSelection.selected.length :
      role == 'planner' ? this.plannerSelection.selected.length :
        role == 'inspector' ? this.inspectorSelection.selected.length :
          role == 'viewer' ? this.viewerSelection.selected.length : 0;
    const numRows = role == 'admin' ? this.adminListDataSource.data.length :
      role == 'planner' ? this.plannerListDataSource.data.length :
        role == 'inspector' ? this.inspectorListDataSource.data.length :
          role == 'viewer' ? this.viewerListDataSource.data.length : '0';
    return numSelected === numRows;

  }


  masterToggle(role) {
    if (role == 'admin') {
      this.isAllSelected('admin') ?
        this.adminSelection.clear() :
        this.adminListDataSource.data.forEach(row => this.adminSelection.select(row));
    }
    else if (role == 'planner') {
      this.isAllSelected('planner') ?
        this.plannerSelection.clear() :
        this.plannerListDataSource.data.forEach(row => this.plannerSelection.select(row));
    }
    else if (role == 'inspector') {
      this.isAllSelected('inspector') ?
        this.inspectorSelection.clear() :
        this.inspectorListDataSource.data.forEach(row => this.inspectorSelection.select(row));
    }
    else if (role == 'viewer') {
      this.isAllSelected('viewer') ?
        this.viewerSelection.clear() :
        this.viewerListDataSource.data.forEach(row => this.viewerSelection.select(row));
    }

  }
  checkboxLabel(row, role): string {
    if (!row) {
      return `${this.isAllSelected(role) ? 'select' : 'deselect'} all`;
    }
    return role == 'admin' ? `${this.adminSelection.isSelected(row) ? 'deselect' : 'select'}` :
      role == 'planner' ? `${this.plannerSelection.isSelected(row) ? 'deselect' : 'select'}` :
        role == 'inspector' ? `${this.inspectorSelection.isSelected(row) ? 'deselect' : 'select'}` :
          `${this.viewerSelection.isSelected(row) ? 'deselect' : 'select'}`;
  }

}
export interface RoleInterface {
  'SSO Id': number;
  'First Name': string;
  'Last Name': string;
  'Plant Name': string;
}
const allRoleData = {
  adminList: [],
  plannerList: [],
  inspectorList: [],
  viewerList: []
};
