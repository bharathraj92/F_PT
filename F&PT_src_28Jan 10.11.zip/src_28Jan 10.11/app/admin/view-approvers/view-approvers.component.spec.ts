import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewApproversComponent } from './view-approvers.component';

describe('ViewApproversComponent', () => {
  let component: ViewApproversComponent;
  let fixture: ComponentFixture<ViewApproversComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewApproversComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewApproversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
