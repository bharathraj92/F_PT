import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import * as Mock from 'src/app/mock/manage-access.mock';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import * as _ from 'lodash';
import { HttpClient } from '@angular/common/http';
import * as Helpers from 'src/app/util/helper';

@Component({
  selector: 'app-manage-access',
  templateUrl: './manage-access.component.html',
  styleUrls: ['./manage-access.component.scss']
})
export class ManageAccessComponent implements OnInit {
  requestAccessDashboardForm: FormGroup;
  accessForm: FormGroup;
  displayedColumns: string[] = ['Select', 'Id', 'RequestorName', 'ProductBrand', 'ManufacturingSite', 'EnggSite', 'EndUserType', 'DepartmentName', 'RoleName', 'ProductType', 'ProductModel', 'ProductSubCategory', 'ProductVariant', 'ProductKnowledge', 'User Status', 'RequestComment', 'Date', 'Action'];
  dataSource = new MatTableDataSource<AccessRequestInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('accessRequest') accessRequestTable: MatTable<AccessRequestInterface>;
  selection = new SelectionModel<AccessRequestInterface>(true, []);
  selectedRowIndex: number;
  selectedLanguage: any = [];
  productKnowlegdeList: any = [];
  showUpdateFiled: boolean;
  accessListData: any = [];
  taskStatusList: any = [];
  userStatusList: any = [];
  showActionField: boolean;
  showCheckBox: boolean;

  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService, public translate: TranslateService, public formBuilder: FormBuilder, private http: HttpClient) {
    this.showUpdateFiled = false;
    this.showActionField = false;
    this.showCheckBox = false;
    this.commonService.selectedLanguage.subscribe((data) => {
      this.selectedLanguage = data;
      console.log('manage access------' + this.selectedLanguage);
    });
  }

  ngOnInit() {
    this.createForm();
    this.commonService.currentview.next('Admin > Manage Access');
    this.getAdminFilterOption();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

  }

  createForm() {
    this.requestAccessDashboardForm = this.formBuilder.group({
      approvalStatus: [null],
      activeStatus: [null],
    })
    this.accessForm = this.formBuilder.group({
      productKnowledge: [null],
      activeUser: [null],
    })
  }

  getAdminFilterOption() {
    this.apiMappingsService.getAdminFilterOption().subscribe((data) => {
      this.taskStatusList = data['approvalStatus'];
      this.userStatusList = data['activeStatus'];
      const approveTaskStatus = _.filter(this.taskStatusList, { 'approvalStatusName': 'Pending' });
      const activeUserStatus = _.filter(this.userStatusList, { 'activeStatusName': 'InActive' });
      //  Change the activeStatusName filter value with below value after pull
      // InActive
      if(approveTaskStatus.length){
      this.requestAccessDashboardForm.get('approvalStatus').patchValue(approveTaskStatus[0]['id']);
      this.requestAccessDashboardForm.get('activeStatus').patchValue(activeUserStatus[0]['id']);
      if(approveTaskStatus.length){
      this.getAccessRequestList(approveTaskStatus[0]['id'], activeUserStatus[0]['id']);
      }
    }
      const selectedApprovalStatus = this.requestAccessDashboardForm.get('approvalStatus').value;
      const selectedUserStatus = this.requestAccessDashboardForm.get('activeStatus').value;
      const selectedApprovalStatusName = _.filter(this.taskStatusList, { 'id': selectedApprovalStatus });
      const selectedUserStatusName = _.filter(this.userStatusList, { 'id': selectedUserStatus });
      if (Helpers.isLowerCaseEquals(selectedApprovalStatusName[0]['approvalStatusName'], 'Approved') && Helpers.isLowerCaseEquals(selectedUserStatusName[0]['activeStatusName'], 'Active')) {
        this.showActionField = true;
      }
      if (Helpers.isLowerCaseEquals(selectedApprovalStatusName[0]['approvalStatusName'], 'Pending') && Helpers.isLowerCaseEquals(selectedUserStatusName[0]['activeStatusName'], 'InActive')) {
        this.showCheckBox = true;
      }
    });
  }
  getAccessRequestList(selectedTaskStatus, selectedUserStatus) {
    this.http.get(this.apiMappingsService.getAccessRequests(selectedTaskStatus, selectedUserStatus)).subscribe(data => {
      // this.accessListData = data;
      this.accessListData = _.sortBy(data, ['requestId']);
      this.prepareTableData();
    });
  }
  prepareTableData() {
    ELEMENT_DATA = [];
    this.accessListData.forEach(accessRequest => {
      accessRequest['showUpdateFiled'] = this.showUpdateFiled;
      ELEMENT_DATA.push({
        id: accessRequest.requestId,
        requestedBy: accessRequest.requstedBy,
        productBrand: accessRequest.productBrandName,
        departmentName: accessRequest.departmentName,
        roleName: accessRequest.roleName,
        productType: accessRequest.producTypeName,
        productModel: accessRequest.productModelName,
        productSubCategory: accessRequest.productSubCategoryName,
        requestorComments: accessRequest.requestorComments,
        manufacturingSite: accessRequest.siteName,
        enggSite: accessRequest.enggSiteName,
        endUserType: accessRequest.endUserTypeName,
        productKnowledgeId: accessRequest.productKnowledgeId,
        productKnowledge: accessRequest.productKnowledgeName,
        productVariant: accessRequest.productVariantName,
        date: accessRequest.requestedDate,
        showUpdateFiled: accessRequest.showUpdateFiled,
        userStatus: accessRequest.activeStatus,
        filterProductKnowledgeList: accessRequest.productKnowledge,
        departmentId: accessRequest.departmentId,
        roleId: accessRequest.roleId
      });

    });
    this.dataSource.data = ELEMENT_DATA;
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  checkboxLabel(row?: AccessRequestInterface): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'}`;
  }
  getAllRequestId(allRequestList) {
    this.selection.clear();
    return allRequestList.map(val => val.id);
  }

  approveRejectRequest(status) {
    const selectedApprovalStatus = this.requestAccessDashboardForm.get('approvalStatus').value;
    const selectedUserStatus = this.requestAccessDashboardForm.get('activeStatus').value;
    const data = {
      requestIds: this.getAllRequestId(this.selection.selected),
      action: status
    };
    this.apiMappingsService.approveOrRejectAccessRequest(data).subscribe((res) => {
      if (res) {
        this.getAccessRequestList(selectedApprovalStatus, selectedUserStatus);
        this.bhAlertService.showAlert(
          'success',
          'top',
          5000,
          `Request ${data.action} successfully`
        );
      }
    })
  }

  onSearch() {
    let formValue = this.requestAccessDashboardForm.value;
    this.getAccessRequestList(formValue.approvalStatus, formValue.activeStatus);
    this.showActionField = false;
    this.showCheckBox = false;
    const selectedApprovalStatusName = _.filter(this.taskStatusList, { 'id': formValue.approvalStatus });
    const selectedUserStatusName = _.filter(this.userStatusList, { 'id': formValue.activeStatus });
    if (Helpers.isLowerCaseEquals(selectedApprovalStatusName[0]['approvalStatusName'], 'Approved') && Helpers.isLowerCaseEquals(selectedUserStatusName[0]['activeStatusName'], 'Active')) {
      this.showActionField = true;
    }
    if (Helpers.isLowerCaseEquals(selectedApprovalStatusName[0]['approvalStatusName'], 'Pending') && Helpers.isLowerCaseEquals(selectedUserStatusName[0]['activeStatusName'], 'InActive')) {
      this.showCheckBox = true;
    }
  }

  onUpdateAction(element) {
    element['showUpdateFiled'] = true;
    this.productKnowlegdeList = element['filterProductKnowledgeList'];
    const productKnowledgeValue = _.filter(this.productKnowlegdeList, { 'productKnowledgeName': element['productKnowledge'] });
    if (productKnowledgeValue.length > 0) {
      this.accessForm.get("productKnowledge").patchValue(productKnowledgeValue[0]['productKnowledgeId']);
    }
    const userStatusValue = _.filter(this.userStatusList, { 'activeStatusName': element['userStatus'] });
    this.accessForm.get("activeUser").patchValue(userStatusValue[0]['id']);
  }

  onSaveUpdate(element) {
    element['showUpdateFiled'] = false;
    const selectedApprovalStatus = this.requestAccessDashboardForm.get('approvalStatus').value;
    const selectedUserStatus = this.requestAccessDashboardForm.get('activeStatus').value;
    const selectedProductKnowledge = this.accessForm.get('productKnowledge').value;
    const selectedActiveStatusId = this.accessForm.get('activeUser').value;
    const updateData = {
      requestId: element['id'],
      roleId: element['roleId'],
      departmentId: element['departmentId'],
      productKnowledgeId: selectedProductKnowledge,
      activeStatusId: selectedActiveStatusId
    };
    this.apiMappingsService.onUpdateAccessRequest(updateData).subscribe((res) => {
      this.getAccessRequestList(selectedApprovalStatus, selectedUserStatus);
    });
  }
}
export interface AccessRequestInterface {
  id: number;
  requestedBy: string;
  productBrand: string;
  departmentName: string;
  roleName: string;
  productType: string;
  productModel: string;
  productSubCategory: string;
  requestorComments: string;
  manufacturingSite: string,
  enggSite: string,
  endUserType: string,
  productKnowledge: string,
  productVariant: string,
  date: Date,
  showUpdateFiled: boolean,
  productKnowledgeId: number,
  userStatus: string,
  filterProductKnowledgeList: [],
  departmentId: number,
  roleId: number;
}
let ELEMENT_DATA: AccessRequestInterface[] = [];
