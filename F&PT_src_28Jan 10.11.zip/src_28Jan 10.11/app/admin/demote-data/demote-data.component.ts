import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { findIndex } from 'rxjs/operators';
import { BhAlertService, BhAlertsComponent } from 'bh-theme';
import { CommonService } from 'src/app/Services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import { Router } from '@angular/router';
import * as Helpers from 'src/app/util/helper';
import { DatePipe } from '@angular/common';
import { ExportExcel } from "src/app/util/exportExcel";
import { MatTableFilter } from 'mat-table-filter';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AdminComponent } from '../admin.component';
//import { ViewAttachmentsComponent } from '../view-attachments/view-attachments.component';
import { MCodeHistoryModalComponent } from '../mcode-history-modal/mcode-history-modal.component';
//import { ChangeBomTypeModalComponent } from '../change-bom-type-modal/change-bom-type-modal.component';

@Component({
  selector: 'app-demote-data',
  templateUrl: './demote-data.component.html',
  styleUrls: ['./demote-data.component.scss']
})
export class DemoteComponent implements OnInit {
  mCodeForm: FormGroup;
  mCodeId: any;
  mcodeInput: any;
  mcodeDescInput: any;
  revisionNumInput: any;
  mcode_flagInput: boolean;
  mcode_flag_statusInput: any;
  editFlag = false;
  plantList: any;
  demoteTableData;
  demoteExcelData
  plantMasterList;
  taskMasterList;
  search;
  filterValues = {};
  mcodeHistoryModal: MatDialogRef<MCodeHistoryModalComponent>;
  plantInput: any;
  datePipe = new DatePipe("en-US");
  displayedColumns: string[] = [
    'module',
    'promoteCount',
    'demoteCount',
  ];
  statusList = [
    { flag: true, status: 'Enabled' },
    { flag: false, status: 'Disabled' }
  ]
  dataSource = new MatTableDataSource<DemoteDataInterface>(ELEMENT_DATA);
  //dataSource = new MatTableDataSource<DemoteDataInterface>();
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('demoteData') demoteDataTable: MatTable<DemoteDataInterface>;
  //@ViewChild('filterbar') filterbar: ElementRef;
  @ViewChild('select') select: MatSelect;
  //ChildErForceClosureModal: MatDialogRef<NpcForceCloseComponent>;
  //HoldEditModal: MatDialogRef<HoldEditModalComponent>;


  constructor(private apiMappingsService: ApiMappingsService,
    private commonService: CommonService, private bhAlertService: BhAlertService,
    public formBuilder: FormBuilder,
    private http: HttpClient, public router: Router, private element: ElementRef, public dialog: MatDialog) {

    // 
    // this.commonService.userDetails.subscribe(val => {
    //   this.logginUserFirstName = val['firstName'];
    //   this.currentDate = new Date();
    // });

    // Object to create Filter for

  }


  ngOnInit(): void {
    this.plantInput = 'DVI';
    this.getMcodeData(this.plantInput);
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    //this.toggleAllSelection()
  }

  getMcodeData(plant) {
    // Uncomment below line of code once api is done and comment mock
    // this.demoteTableData = [];
    // this.prepareTableData(this.demoteTableData);
    this.apiMappingsService.getDemoteDesc().subscribe((data) => {
      if (data) {
        console.log(data);
        // this.plantList = data['plantMaster'];
        this.plantMasterList = data['plantNames'];
        this.taskMasterList = data['taskNames'];
        //this.demoteTableData = Mock.getDemoteData;//Mock Data        
        this.demoteTableData = data;
        this.prepareTableData(this.demoteTableData['plantList'][plant]);
      }
    });
  }

  prepareTableData(demoteTableData) {
    ELEMENT_DATA = [];
    demoteTableData.forEach(demoteData => {
      ELEMENT_DATA.push({
        module: demoteData.module,
        promoteCount: demoteData.promoteCount,
        demoteCount: demoteData.demoteCount,
      });
    });
    this.dataSource.data = ELEMENT_DATA;

  }
  onSearchERRequest(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues);
  }
  dateFormatter(value) {
    if (value) {
      value = value + '';
      value = Number(value.substring(0, value.length - 0));
      //const result = this.datePipe.transform((value * 1000), 'dd-MMM-yyyy');//String
      const result = new Date(value * 1000);
      return result;
    }
  }
  //Export to Excel
  exportTable() {
    ExportExcel.exportTableToExcel("demoteData");
  }

  exportArray() {
    this.apiMappingsService.getDemoteExcelData().subscribe((data) => {
      if (data) {
        this.demoteExcelData = data;
        //this.demoteExcelData = Mock.getDemoteData["excelData"];
        //excelData
        const onlyNameAndSymbolArr: Partial<DemoteDataInterface>[] = this.demoteExcelData.map(demoteData => ({
          plant: demoteData.plant,
          module: demoteData.moduleType,
          soli: demoteData.soli,
          childErNumber: demoteData.erNumber,
          demoteComments: demoteData.comments,
          modifiedByDate: this.dateFormatter(demoteData.modifiedByDate),//demoteData.modifiedByDate,
          modifiedByFirstName: demoteData.modifiedByFirstName,
          modifiedBySso: demoteData.modifiedBySso,
        }));
        ExportExcel.exportArrayToExcel(this.displayedColumns, onlyNameAndSymbolArr, "demoteData");

        //
      }
    });

  }
}

export interface DemoteDataInterface {
  module: string;
  promoteCount: number;
  demoteCount: number;
  //
}

export interface DemoteComponentData {
  animal: string;
  name: string;
}
let ELEMENT_DATA: DemoteDataInterface[] = [];
