import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiMappingsService } from '../../Services/api-mappings.service';
import { HttpClient } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, timeout } from 'rxjs/operators';
import { CommonService } from '../../Services/common.service';
import * as Mock from 'src/app/mock/er-dashboard.mock';
import * as _ from 'lodash';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MCodeComponent } from '../m-code-data/m-code-data.component';
import { BhAlertService } from 'bh-theme';
@Component({
  selector: 'app-mcode-history-modal',
  templateUrl: './mcode-history-modal.component.html',
  styleUrls: ['./mcode-history-modal.component.scss']
})
export class MCodeHistoryModalComponent implements OnInit {

  displayedColumns: string[] = [
    'mcode',
  'mcodeDesc',
  'revisionNum',
  'plant',
  'mcode_flag_status',
  'userName',
  'timeStamp'];
  mCodeHistoryDataSource = new MatTableDataSource<mCodeHistoryInterface>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('testSearch') myDashboardTable: MatTable<mCodeHistoryInterface>;
  selectedRowIndex: number;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  mCodeHistoryForm: FormGroup;
  // selectedTest: any;
  // levelTwoId: any;
  // creatorId: any;
  msgHistoryData: any[];
  constructor(public formBuilder: FormBuilder,
    public calculationsDialogRef: MatDialogRef<MCodeHistoryModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: MCodeComponent,
    private apiMappingsService: ApiMappingsService,
    private http: HttpClient,
    private commonService: CommonService, private bhAlertService: BhAlertService
  ) {
  }

  ngOnInit() {
    this.mCodeHistoryForm = this.formBuilder.group({
      saleOrder: [null],
      lineItem: [null],
      erRevisionNo: [null]
    })
    // this.levelTwoId = this.data['levelTwoId'];
    // this.creatorId = this.data['creatorId'];
    this.mCodeHistoryDataSource.paginator = this.paginator;
    this.mCodeHistoryDataSource.sort = this.sort;
    this.getMcodeHistory(this.data);
  }

  getMcodeHistory(data) {
    //this.erSearchForm.enable();
    ELEMENT_DATA = [];
    const mCodeId = data['mCodeId'];
    this.apiMappingsService.getMcodeHistoryData(mCodeId).subscribe((mCodeData: []) => {
      if (mCodeData) {
        this.msgHistoryData = mCodeData;
        // let filteredHistoryData=[];
        // if(this.field === 'general'){
        // filteredHistoryData = this.msgHistoryData.filter(item=>item.generalComments !=null && item.generalComments != "");
        // }else if(this.field === 'hold'){
        //   filteredHistoryData = this.msgHistoryData.filter(item=>item.holdComments !=null && item.holdComments !="");
        //   }
        this.prepareTableData(mCodeData);
      } else {
        this.bhAlertService.showAlert(
          'warning',
          'top',
          5000,
          'No data found !'
        );
      }
    });
  }

  prepareTableData(mCodeTableData) {
    ELEMENT_DATA = [];
    mCodeTableData.forEach(mCodeData => {
      ELEMENT_DATA.push({
        mcode: mCodeData.mcode,
        mcodeDesc: mCodeData.mcodeDesc,
        revisionNum: mCodeData.revisonNUm,
        plantName: mCodeData.plantName,
        mcode_flag_status: mCodeData.mcode_flag_status,
        timeStamp: mCodeData.timeStamp,
        userName: mCodeData.userName
      });
    });
    this.mCodeHistoryDataSource.data = ELEMENT_DATA;
  }
  // selectTest(element: any) {
  //   this.calculationsDialogRef.close(element);
  // }

  // onClickERNumber(value: any) {

  // }

}

export interface mCodeHistoryInterface {
  mcode: string;
  mcodeDesc: string;
  revisionNum: string;
  plantName: string;
  mcode_flag_status: string;  
  timeStamp: Date;
  userName: string;
}

let ELEMENT_DATA: mCodeHistoryInterface[] = [];

// export interface CalcultionsCreatorData {
//   aging: number;
//   generalComments: string;
//   calculationCreatedByFirstname: string;
//   calculationCreatedByLastname: string;
//   calculationCreatedBySso: string;
//   calculationCreatorStatus: string;
//   calculationCreatorStatusId: number;
//   calculationProgress: string;
//   floatingDays: number;
//   hold: boolean;
//   holdComments: string;
//   hourSpent: number;
//   hoursAssigned: number;
//   id: number;
//   levelTwoId: number;
//   levelTwo: string;
//   percentageCompleted: number;
//   preConfigId: number;
//   supportTeamId: number;
//   targetDate: number;
//   childEr: string;
//   currentStatus: string;
//   currentStatusId: number
// }
// export interface CalcultionsReviewerData {
//   generalComments: string;
//   testCreatedByFirstname: string;
//   testCreatedByLastname: string;
//   testCreatedBySso: string;
//   testCreatorStatus: string;
//   testCreatorStatusId: number;
//   testProgressStatus: string;
//   floatingDays: number;
//   hold: true
//   holdComments: string;
//   id: number;
//   levelTwoId: number;
//   levelTwo: string;
//   percentageCompleted: number;
//   preConfigId: number;
//   reviewedByFirstname: string;
//   reviewedByLastname: string;
//   reviewedBySso: number
// }


