import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MCodeHistoryModalComponent } from './mcode-history-modal.component';

describe('mCodeHistoryModalComponent', () => {
  let component: MCodeHistoryModalComponent;
  let fixture: ComponentFixture<MCodeHistoryModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MCodeHistoryModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MCodeHistoryModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
