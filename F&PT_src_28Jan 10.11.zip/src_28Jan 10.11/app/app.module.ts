import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { ThemeLibModule, NavService } from 'bh-theme';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalComponent } from './components/modal/modal.component';
import { RequestAccessModalComponent } from './util/request-access-modal/request-access-modal.component';
import { EnggToolInterceptor } from './engg-tool.interceptor';
import { BroadcastService } from './Services/broadcast.service';
import { CommonService } from './Services/common.service';
import { ViewApproversComponent } from './admin/view-approvers/view-approvers.component';
import { FeedbackComponent } from './util/feedback/feedback.component';
import { EnggToolDashboardComponent } from './engg-tool-dashboard/engg-tool-dashboard.component';
import { EnggToolComponent } from './engg-tool/engg-tool.component';
import { EnggPreConfigReviewComponent } from './engg-tool/engg-pre-config-review/engg-pre-config-review.component';
import { EnggSummaryInfoComponent } from './engg-tool/engg-summary-info/engg-summary-info.component';
import { BomConfigurationComponent } from './engg-tool/bom-configuration/bom-configuration.component';
import { EnggSchedulingPlanningInfoComponent } from './engg-tool/engg-scheduling-planning-info/engg-scheduling-planning-info.component'

import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ERSearchModalComponent } from './engg-tool/er-search-modal/er-search-modal.component';
import { TranslateLoader, TranslateModule, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { from } from 'rxjs';
import { DatePipe } from '@angular/common';
import { custom_date_format } from './util/custom-date-format';
import { NPCSearchModalComponent } from './engg-tool/npc-search-modal/npc-search-modal.component';
import { DesignSearchModalComponent } from './engg-tool/design-search-modal/design-search-modal.component';
import { MessageHistoryModalComponent } from './engg-tool/message-history-modal/message-history-modal.component';
import { SchedulingGraphModalComponent } from './util/scheduling-graph-modal/scheduling-graph-modal.component';
//import { McodeHistoryModalComponent } from './admin/mcode-history-modal/mcode-history-modal.component';
// import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateModule } from '@angular/material-moment-adapter';
// import * as _moment from "moment";
import { ChartModule, HIGHCHARTS_MODULES } from 'angular-highcharts';
import * as more from 'highcharts/highcharts-more.src';
import * as exporting from 'highcharts/modules/exporting.src';
import { BarGraphComponentComponent } from './util/bar-graph-component/bar-graph-component.component';
import { BomNpcConfigComponent } from './engg-tool/bom-npc-config/bom-npc-config.component';
import { BomDesignComponent } from './engg-tool/bom-design/bom-design.component';
import {OnlyNumberDirective} from './util/only-number.directive';
import { ConfigurationComponent } from './engg-tool//configuration/configuration.component';
import { ExternalDeliverablesComponent } from './engg-tool/external-deliverables/external-deliverables.component';
import { ExternalDeliverablesSearchModalComponent } from './engg-tool/external-deliverables-search-modal/external-deliverables-search-modal.component';
import { CalculationsComponent } from './engg-tool/calculations/calculations.component';
import { TestComponent } from './engg-tool/test/test.component';
import { QualityActivityComponent } from './engg-tool/quality-activity/quality-activity.component';
import { OtherEnggActivitiesComponent } from './engg-tool/other-engg-activities/other-engg-activities.component';
import { DashboardMatrixComponent } from './engg-tool-dashboard-matrix/engg-tool-dashboard-matrix.component';
import { GeneralDashboardComponent } from './engg-tool-dashboard-matrix/general-dashboard/general-dashboard.component';
import { WeekwiseDashboardComponent } from './engg-tool-dashboard-matrix/weekwise-dashboard/weekwise-dashboard.component';
import { MasoneilanDashboardComponent } from './engg-tool-dashboard-matrix/masoneilan-dashboard/masoneilan-dashboard.component';
import { PlantDashboardComponent } from './engg-tool-dashboard-matrix/plant-dashboard/plant-dashboard.component';
import { WIPDashboardComponent } from './engg-tool-dashboard-matrix/wip-dashboard/wip-dashboard.component';
import { WIPDeepdiveComponent } from './engg-tool-dashboard-matrix/wip-deepdive-dashboard/wip-deepdive-dashboard.component';
import { QualityDocComponent } from './engg-tool/quality-doc/quality-doc.component';
import { TestSearchModalComponent } from './engg-tool/test-search-modal/test-search-modal.component';
import { OtherEnggActivitiesSearchModalComponent } from './engg-tool/other-engg-activities-search-modal/other-engg-activities-search-modal.component';
import { QualityActivitySearchModalComponent } from './engg-tool/quality-activity-search-modal/quality-activity-search-modal.component';
import { CalculationsSearchModalComponent } from './engg-tool/calculations-search-modal/calculations-search-modal.component';
import { ViewAttachmentsComponent } from './engg-tool/view-attachments/view-attachments.component';
import { AttachmentsComponent } from './engg-tool/attachments/attachments.component';
import { HistoryComponent } from './engg-tool/history/history.component';
import { ChildErForceClosureModalComponent } from './engg-tool-dashboard/child-er-force-closure-modal/child-er-force-closure-modal.component';
import { NpcForceCloseComponent } from './engg-tool-dashboard/npc-force-close/npc-force-close.component';
import { ConfirmDialogComponent } from './util/confirm-dialog/confirm-dialog.component';
import { AddNPcModalComponent } from './engg-tool-dashboard/add-npc-modal/add-npc-modal.component';
import { HoldEditModalComponent } from './engg-tool-dashboard/hold-edit-modal/hold-edit-modal.component';
import { MassUpdateModalComponent } from './engg-tool-dashboard/mass-update-modal/mass-update-modal.component';
import { ChangeBomTypeModalComponent } from './engg-tool/change-bom-type-modal/change-bom-type-modal.component';
import { MassUpdateCommentsComponent } from './engg-tool-dashboard/mass-update-comments/mass-update-comments.component';
import { AdminComponent } from './admin/admin.component';
import { MCodeHistoryModalComponent } from './admin/mcode-history-modal/mcode-history-modal.component';
import { MassReopenModelComponent } from './engg-tool-dashboard/mass-reopen-modal/mass-reopen-modal.component';
import { ActivityTreeHistoryComponent } from './engg-tool/activity-tree-history/activity-tree-history.component';
import { ERHistoryComponent } from './engg-tool/er-history/er-history.component';
import { UserProfileModalComponent } from './util/user-profile-modal/user-profile-modal.component';
export function init_app(commonService: CommonService) {
  return () => commonService.initializeApp();
}

@NgModule({
  entryComponents: [ConfirmDialogComponent],
  declarations: [
    AppComponent,
    ModalComponent,
    RequestAccessModalComponent,
    UserProfileModalComponent,
    ViewApproversComponent,
    FeedbackComponent,
    EnggToolDashboardComponent,
    EnggToolComponent,
    EnggPreConfigReviewComponent,
    EnggSummaryInfoComponent,
    ERSearchModalComponent,
    NPCSearchModalComponent,
    DesignSearchModalComponent,
    MessageHistoryModalComponent,
    BomConfigurationComponent,
    BomDesignComponent,
    EnggSchedulingPlanningInfoComponent,
    SchedulingGraphModalComponent,
    BarGraphComponentComponent,
    BomNpcConfigComponent,
    OnlyNumberDirective,
    ConfigurationComponent,
    ExternalDeliverablesComponent,
    ExternalDeliverablesSearchModalComponent,
    CalculationsComponent,
    TestComponent,
    QualityActivityComponent,
    OtherEnggActivitiesComponent,
    DashboardMatrixComponent,
    GeneralDashboardComponent,
    WeekwiseDashboardComponent,
    QualityDocComponent,
    TestSearchModalComponent,
    OtherEnggActivitiesSearchModalComponent,
    MasoneilanDashboardComponent,
    PlantDashboardComponent,    
    WIPDashboardComponent,
    WIPDeepdiveComponent,
    QualityDocComponent,
    QualityActivitySearchModalComponent,
    CalculationsSearchModalComponent,
    ViewAttachmentsComponent,
    AttachmentsComponent,
    HistoryComponent,
    ChildErForceClosureModalComponent,
    NpcForceCloseComponent,
    ConfirmDialogComponent,
    AddNPcModalComponent,
    HoldEditModalComponent,
    MassUpdateModalComponent,
    ChangeBomTypeModalComponent,
    MassUpdateCommentsComponent,
  MCodeHistoryModalComponent,
  MassReopenModelComponent,
  ERHistoryComponent,
  ActivityTreeHistoryComponent
    //McodeHistoryModalComponent,
    //AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ThemeLibModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatNativeDateModule,
    MatDatepickerModule,
    ChartModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ],
  providers: [DatePipe, NavService, BroadcastService, CommonService,EnggToolComponent,
    { provide: APP_INITIALIZER, useFactory: init_app, deps: [CommonService], multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: EnggToolInterceptor, multi: true },
    // { provide: HIGHCHARTS_MODULES, useFactory: () => [ more, exporting ] },
    // {
    //   provide: DateAdapter,
    //   useClass: MomentDateAdapter,
    //   deps: [MAT_DATE_LOCALE]
    // },
    // { provide: MAT_DATE_LOCALE, useValue: custom_date_format }
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

// AOT compilation support
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, "assets/i18n/", ".json");
}

