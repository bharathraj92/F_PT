import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpHeaders
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { CommonService } from './Services/common.service';
import { BroadcastService } from './Services/broadcast.service';
import { map, tap } from 'rxjs/operators';

@Injectable()
export class EnggToolInterceptor implements HttpInterceptor {
  token: string;
  private requests: HttpRequest<any>[] = [];

  constructor(private commonservice: CommonService, private broadcast: BroadcastService) { }
  removeRequest(req: HttpRequest<any>) {
    const i = this.requests.indexOf(req);
    this.requests.splice(i, 1);
    this.commonservice.spinnerState.next(this.requests.length > 0);
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.requests.push(request);
    this.commonservice.spinnerState.next(true);
    this.commonservice.userDetails.subscribe(val => {
      this.token = val['token'];
    });
    let cloneReq;
    let headers = new HttpHeaders();
    headers = headers.set('Cache-Control', 'no-cache')
      .set('Pragma', 'no-cache')
      .set('X-Requested-With', 'XMLHttpRequest');
    if (this.token && request.url.includes('/api/engg-tool')) {
      headers = headers.set('Authorization', 'Bearer ' + this.token);
    } else {
      headers = request.headers;
    }
    // send the newly created request
    cloneReq = request.clone({ headers });

    // RXJS 6 Compatible
    return next.handle(cloneReq).pipe(
      tap(
        (event) => {
          if (event instanceof HttpResponse) {
            this.removeRequest(request);
            this.broadcast.handleResponse(event, cloneReq);
          }
        },
        (error) => {
          this.removeRequest(request);
          this.broadcast.handleError(error);
          return throwError(error);
        }
      )
    ) as any;
  }
}
