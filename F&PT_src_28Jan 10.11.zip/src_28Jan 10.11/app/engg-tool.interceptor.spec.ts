import { TestBed } from '@angular/core/testing';

import { EnggToolInterceptor } from './engg-tool.interceptor';

describe('EnggToolInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      EnggToolInterceptor
    ]
  }));

  it('should be created', () => {
    const interceptor: EnggToolInterceptor = TestBed.inject(EnggToolInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
